﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing
{
    public class VersionedEvent : EventBase, IVersionedEvent
    {                
        public Guid SourceId { get; set; }
        public long SourceVersion { get; set; }
    }
}
