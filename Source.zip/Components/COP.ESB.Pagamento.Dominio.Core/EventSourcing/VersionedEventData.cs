﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing
{
    public class VersionedEventData : EventData
    {
        public VersionedEventData()
        {

        }

        public VersionedEventData(string bucketId, string streamId, Guid commitId, DateTimeOffset commitDateTimeOffset,
            IDictionary<string, object> commitHeaders, IVersionedEvent versionedEvent)
            : base(commitHeaders, versionedEvent)
        {
            BucketId = bucketId;
            StreamId = streamId;
            StreamRevision = versionedEvent.SourceVersion;
            CommitId = commitId;
            CommitDateTimeOffset = commitDateTimeOffset;
        }

        public string BucketId { get; set; }
        public string StreamId { get; set; }
        public long StreamRevision { get; set; }
        public Guid CommitId { get; set; }
        public DateTimeOffset CommitDateTimeOffset { get; set; }

        public override IEvent ToEvent()
        {
            var headers = DeserializeHeaders();

            var assemblyName = (string)headers["EventAssemblyName"];

            var assembly = Assembly.Load(assemblyName);

            var eventTypeFullName = (string)headers["EventTypeFullName"];

            var type = assembly.GetType(eventTypeFullName);

            return (IEvent)JsonConvert.DeserializeObject(Payload, type, new JsonSerializerSettings
            {
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Full,
                TypeNameHandling = TypeNameHandling.All,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
        }

        public IVersionedEvent ToVersionedEvent()
        {
            return (IVersionedEvent)ToEvent();
        }

        protected override string GetPayload(IVersionedEvent versionedEvent)
        {
            return JsonConvert.SerializeObject(versionedEvent, new JsonSerializerSettings
            {
                TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Full,
                TypeNameHandling = TypeNameHandling.All,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
        }
    }
}
