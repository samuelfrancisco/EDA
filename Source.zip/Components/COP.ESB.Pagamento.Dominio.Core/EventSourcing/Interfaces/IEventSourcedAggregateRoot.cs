﻿using COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces
{
    public interface IEventSourcedAggregateRoot : IAggregateRoot
    {           
        IReadOnlyCollection<IVersionedEvent> UncommittedEvents { get; }

        void ClearUncommittedEvents();
    }
}
