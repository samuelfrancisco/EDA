﻿using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces
{
    public interface IEventSourcedAggregateRootRepository<TAggregate> 
        where TAggregate : class, IEventSourcedAggregateRoot        
    {
        Task<TAggregate> GetByIdAsync(Guid id);        
        Task SaveAsync(TAggregate aggregate, Guid commitId);        
    }
}
