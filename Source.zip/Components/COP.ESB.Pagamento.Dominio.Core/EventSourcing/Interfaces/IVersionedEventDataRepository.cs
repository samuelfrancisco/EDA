﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces
{
    public interface IVersionedEventDataRepository
    {
        Task<IEnumerable<VersionedEventData>> GetAllEventsFromAsync(long globalSequenceNumber);
        Task<IEnumerable<VersionedEventData>> GetAllEventsFromAsync(long globalSequenceNumber, Type eventHandlerType);
        Task<IEnumerable<KeyValuePair<VersionedEventData, string>>> GetAllNotReceivedAsync(IEnumerable<KeyValuePair<string, string>> eventHandlers);
        Task<long> GetLatestGlobalSequenceNumberOfTypesAsync(IEnumerable<Type> tiposDeEventos);
    }
}
