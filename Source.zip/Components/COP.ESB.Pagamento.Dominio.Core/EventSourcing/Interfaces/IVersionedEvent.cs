﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces
{
    public interface IVersionedEvent : IEvent
    {
        Guid SourceId { get; set; }
        long SourceVersion { get; set; }
    }
}
