﻿using COP.ESB.Pagamento.Dominio.Core.Domain;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing
{
    public abstract class EventSourcedAggregateRoot : AggregateRoot, IEventSourcedAggregateRoot
    {
        private List<IVersionedEvent> _uncommittedEvents = new List<IVersionedEvent>();        

        public EventSourcedAggregateRoot()
            : base()
        {
                        
        }

        public EventSourcedAggregateRoot(Guid id, IEnumerable<IVersionedEvent> pastEvents)       
            : this()
        {
            Id = id;

            LoadFromHistory(pastEvents);
        }

        
        public IReadOnlyCollection<IVersionedEvent> UncommittedEvents { get { return _uncommittedEvents; } }

        public void ClearUncommittedEvents()
        {
            _uncommittedEvents.Clear();
        }

        protected void Update(IVersionedEvent @event)
        {
            @event.SourceId = Id;
            @event.SourceVersion = Version + 1L;

            Handle(@event);

            _uncommittedEvents.Add(@event);
        }

        private void Handle(IVersionedEvent @event)
        {
            var method = GetType().GetMethod("When", BindingFlags.NonPublic | BindingFlags.Instance, null, new[] { @event.GetType() }, null);

            if(method == null)
                method = GetType().BaseType.GetMethod("When", BindingFlags.NonPublic | BindingFlags.Instance, null, new[] { @event.GetType() }, null);

            method.Invoke(this, new[] { @event });

            Version = @event.SourceVersion;
        }

        private void LoadFromHistory(IEnumerable<IVersionedEvent> pastEvents)
        {
            foreach (var e in pastEvents)
            {
                Handle(e);
            }
        }
    }
}
