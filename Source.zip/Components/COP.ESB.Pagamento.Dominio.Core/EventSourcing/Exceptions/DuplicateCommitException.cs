﻿using System;
using System.Runtime.Serialization;

namespace COP.ESB.Pagamento.Dominio.Core.EventSourcing.Exceptions
{
    [Serializable]
    public class DuplicateCommitException : Exception
    {
        public DuplicateCommitException()
        {
        }
        public DuplicateCommitException(string message)
            : base(message)
        {
        }
        public DuplicateCommitException(string message, Exception inner)
            : base(message, inner)
        {
        }
        protected DuplicateCommitException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
