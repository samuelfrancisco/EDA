﻿using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Data.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        void Reset();
        Task SaveChangesAsync();
    }
}
