﻿namespace COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces
{
    public interface IServicoDeValidacaoDeEmails
    {
        Result ValidarEmails(string emailsParaNotificacoes);
    }
}