﻿namespace COP.ESB.Pagamento.Dominio.Core.Logs.Interfaces
{
    public interface ILogWebServiceRepository
    {
        void AdicionarLogWebServiceChamadaSaida(LogServicoChamadaSaida _logWebServiceChamadaSaida);
    }

}
