﻿using System;

namespace COP.ESB.Pagamento.Dominio.Core.Logs
{
    public class LogServicoChamadaSaida
    {
        public long LogServicoChamadaSaidaId { get; set; }
        public long? LogAutenticacaoEmpresaAplicacaoId { get; set; }
        public DateTime? DataEnvio { get; set; }
        public DateTime? DataRecebimento { get; set; }
        public string Endpoint { get; set; }
        public string Request { get; set; }
        public string Response { get; set; }
        public long? TempoDuracao { get; set; }        
    }
}
