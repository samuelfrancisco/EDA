﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging
{
    public class IntegrationEvent : EventBase, IIntegrationEvent
    {
       
    }
}
