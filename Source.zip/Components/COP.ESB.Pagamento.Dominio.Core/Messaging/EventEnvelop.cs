﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging
{
    public class EventEnvelop<TEvent> : IEventEnvelop<TEvent> where TEvent: IEvent
    {
        public EventEnvelop(long? globalSequenceNumber, string sourceServerName, TEvent body)
        {
            GlobalSequenceNumber = globalSequenceNumber;
            SourceServerName = sourceServerName;
            Body = body;
        }

        public long? GlobalSequenceNumber { get; set; }
        public string SourceServerName { get; set; }
        public TEvent Body { get; set; }

        public IEventEnvelop<IEvent> ToGeneric()
        {
            return new EventEnvelop<IEvent>(GlobalSequenceNumber, SourceServerName, Body);
        }
    }
}
