﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging
{
    public abstract class EventData
    {
        public EventData()
        {

        }

        public EventData(IDictionary<string, object> commitHeaders, IVersionedEvent versionedEvent)
        {

            EventTypeFullName = versionedEvent.GetType().FullName;
            EventId = versionedEvent.Id;
            Headers = GetHeaders(commitHeaders, versionedEvent);
            Payload = GetPayload(versionedEvent);
        }

        public long GlobalSequenceNumber { get; set; }
        public string EventTypeFullName { get; set; }
        public Guid EventId { get; set; }
        public string Headers { get; set; }
        public string Payload { get; set; }

        public abstract IEvent ToEvent();

        protected string GetHeaders(IDictionary<string, object> commitHeaders, IVersionedEvent versionedEvent)
        {
            var eventType = versionedEvent.GetType();

            commitHeaders["EventAssemblyName"] = eventType.Assembly.FullName;
            commitHeaders["EventNamespace"] = eventType.Namespace;
            commitHeaders["EventTypeFullName"] = eventType.FullName;
            commitHeaders["EventTypeName"] = eventType.Name;
            commitHeaders["EventClrTypeName"] = eventType.AssemblyQualifiedName;

            return JsonConvert.SerializeObject(commitHeaders);
        }

        protected virtual string GetPayload(IVersionedEvent versionedEvent)
        {
            return JsonConvert.SerializeObject(versionedEvent);
        }

        protected IDictionary<string, object> DeserializeHeaders()
        {
            return JsonConvert.DeserializeObject<IDictionary<string, object>>(Headers);
        }
    }
}
