﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging
{
    public class EventBase : IEvent
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public DateTimeOffset Date { get; set; } = DateTime.Now;
        public IMessage CorrelationMessage { get; set; }
        public IMessage OriginalCorrelationMessage { get; set; }
    }
}
