﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public class ReceivedCommand : PersistedCommand
    {
        public string ReceiveDates { get; set; }

        public ReceivedCommand()
            : base()
        {

        }

        public ReceivedCommand(ICommand command, Type commandHandlerType)
            : base(command, commandHandlerType)
        {
            ReceiveDates = GetReceiveDates(new[] { new DateTimeOffset(DateTime.Now) });
        }

        public void AddNewReceiveDate()
        {
            var dateList = GetReceiveDateList();

            dateList.Add(new DateTimeOffset(DateTime.Now));

            ReceiveDates = GetReceiveDates(dateList);
        }

        private List<DateTimeOffset> GetReceiveDateList()
        {
            var dates = JsonConvert.DeserializeObject<IEnumerable<DateTimeOffset>>(ReceiveDates);
            
            return dates.ToList();
        }

        private string GetReceiveDates(IEnumerable<DateTimeOffset> dates)
        {
            return JsonConvert.SerializeObject(dates);
        }
    }
}
