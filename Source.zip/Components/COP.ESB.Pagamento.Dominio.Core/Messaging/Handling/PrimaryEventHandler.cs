﻿using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Exceptions;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class PrimaryEventHandler : EventHandler
    {
        protected readonly IUnitOfWork _unitOfWork;

        public PrimaryEventHandler(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository)
            : base(eventHandlerRepository)
        {
            _unitOfWork = unitOfWork;
        }

        public override async Task HandleAsync<TEvent>(IEventEnvelop<TEvent> envelop, Func<TEvent, CancellationToken, Task> doHandleAsync, CancellationToken cancellationToken)            
        {
            var genericEnvelop = envelop.ToGeneric();

            var @event = envelop.Body;

            var isTheEventAlreadyReceived = await _eventHandlerRepository
                    .IsTheEventAlreadyReceivedAsync(GetType().FullName, envelop.SourceServerName, @event.GetType().FullName, @event.Id)
                    .ConfigureAwait(false);

            if (isTheEventAlreadyReceived) return;

            await SaveReceivedEventAsync(genericEnvelop).ConfigureAwait(false);            

            while (true)
            {
                try
                {
                    await doHandleAsync(@event, cancellationToken).ConfigureAwait(false);

                    await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

                    await SaveSucceededEventAsync(genericEnvelop).ConfigureAwait(false);                    

                    return;
                }
                catch (ConcurrencyException)
                {
                    _unitOfWork.Reset();

                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    await SaveFailedEventAsync(genericEnvelop, ex).ConfigureAwait(false);                    

                    throw;
                }
            }
        }
    }
}
