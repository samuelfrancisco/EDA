﻿using COP.ESB.Pagamento.Dominio.Core.Exceptions;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public class SucceededCommand : PersistedCommand
    {
        public string PreviousFails { get; set; }

        public SucceededCommand()
            : base()
        {
            
        }

        public SucceededCommand(ICommand command, Type commandHandlerType)
            : base(command, commandHandlerType)
        {
            
        }       

        public SucceededCommand(ICommand command, Type commandHandlerType, IEnumerable<ExceptionInfo> previousFails)
            : base(command, commandHandlerType)
        {
            PreviousFails = GetPreviousFails(previousFails);
        }

        private string GetPreviousFails(IEnumerable<ExceptionInfo> previousFails)
        {
            return JsonConvert.SerializeObject(previousFails);
        }
    }
}
