﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class EventHandler
    {
        protected readonly IEventHandlerRepository _eventHandlerRepository;

        public EventHandler(IEventHandlerRepository eventHandlerRepository)
        {
            _eventHandlerRepository = eventHandlerRepository;
        }

        public virtual async Task HandleAsync<TEvent>(IEventEnvelop<TEvent> envelop, Func<TEvent, CancellationToken, Task> doHandleAsync, CancellationToken cancellationToken)
            where TEvent : IEvent
        {                       
            var genericEnvelop = envelop.ToGeneric();

            var @event = envelop.Body;

            var isTheEventAlreadyReceived = await _eventHandlerRepository
                            .IsTheEventAlreadyReceivedAsync(GetType().FullName, envelop.SourceServerName, @event.GetType().FullName, @event.Id)
                            .ConfigureAwait(false);

            if (isTheEventAlreadyReceived)
                return;

            await SaveReceivedEventAsync(genericEnvelop).ConfigureAwait(false);

            try
            {
                await doHandleAsync(@event, cancellationToken).ConfigureAwait(false);

                await SaveSucceededEventAsync(genericEnvelop).ConfigureAwait(false);

                return;
            }
            catch (Exception ex)
            {
                await SaveFailedEventAsync(genericEnvelop, ex).ConfigureAwait(false);

                throw;
            }
        }

        protected async Task SaveReceivedEventAsync(IEventEnvelop<IEvent> envelop)
        {
            var @event = envelop.Body;

            var receivedEvent = await _eventHandlerRepository
                .GetReceivedEventByIdAsync(GetType().FullName, envelop.SourceServerName, @event.GetType().FullName, @event.Id)
                .ConfigureAwait(false);

            if (receivedEvent == null)
            {
                receivedEvent = new ReceivedEvent(envelop, GetType());
            }
            else
            {
                receivedEvent.AddNewReceiveDate();
            }

            await _eventHandlerRepository.SaveReceivedEventAsync(receivedEvent).ConfigureAwait(false);
        }

        protected async Task SaveSucceededEventAsync(IEventEnvelop<IEvent> envelop)
        {
            var @event = envelop.Body;

            var failedEvent = await _eventHandlerRepository
                .GetFailedEventByIdAsync(GetType().FullName, envelop.SourceServerName, @event.GetType().FullName, @event.Id)
                .ConfigureAwait(false);

            var succeededEvent = failedEvent == null
                                       ? new SucceededEvent(envelop, GetType())
                                       : new SucceededEvent(envelop, GetType(), failedEvent.GetFailList());

            await _eventHandlerRepository.SaveSucceededEventAsync(succeededEvent).ConfigureAwait(false);

            if (failedEvent != null)
                await _eventHandlerRepository.RemoveFailedEventAsync(failedEvent).ConfigureAwait(false);
        }

        protected async Task SaveFailedEventAsync(IEventEnvelop<IEvent> envelop, Exception exception)
        {
            var @event = envelop.Body;

            var failedEvent = await _eventHandlerRepository
                .GetFailedEventByIdAsync(GetType().FullName, envelop.SourceServerName, @event.GetType().FullName, @event.Id)
                .ConfigureAwait(false);

            if (failedEvent == null)
            {
                failedEvent = new FailedEvent(envelop, GetType(), exception);
            }
            else
            {
                failedEvent.AddNewFail(exception);
            }

            await _eventHandlerRepository.SaveFailedEventAsync(failedEvent).ConfigureAwait(false);
        }
    }
}
