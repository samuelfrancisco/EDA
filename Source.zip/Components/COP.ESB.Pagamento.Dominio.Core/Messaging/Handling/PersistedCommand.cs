﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class PersistedCommand
    {
        protected PersistedCommand()
        {
           
        }

        protected PersistedCommand(ICommand command, Type commandHandlerType)            
        {
            CommandId = command.Id;
            CommandHandlerTypeFullName = commandHandlerType.FullName;
            CommandTypeFullName = command.GetType().FullName;
            CommandDate = command.Date;
            Metadata = GetMetadata(command, commandHandlerType);
            Payload = GetPayload(command);            
        }        

        public Guid CommandId { get; set; }
        public string CommandHandlerTypeFullName { get; set; }
        public string CommandTypeFullName { get; set; }
        public DateTimeOffset CommandDate { get; set; }
        public string Metadata { get; set; }
        public string Payload { get; set; }        

        private string GetMetadata(ICommand command, Type commandHandlerType)
        {
            var commandType = command.GetType();

            var metadataDictionary = new Dictionary<string, string>
            {
                { "CommandHandlerTypeFullName", commandHandlerType.FullName },
                { "CommandHandlerTypeName", commandHandlerType.Name },
                { "CommandHandlerAssemblyFullName", commandHandlerType.Assembly.FullName },
                { "CommandHandlerAssemblyQualifiedName", commandHandlerType.AssemblyQualifiedName },
                { "CommandHandlerNamespace", commandHandlerType.Namespace },
                { "CommandTypeFullName", commandType.FullName },
                { "CommandTypeName", commandType.Name },
                { "CommandAssemblyFullName", commandType.Assembly.FullName },
                { "CommandAssemblyQualifiedName", commandType.AssemblyQualifiedName },
                { "CommandNamespace", commandType.Namespace }
            };

            return JsonConvert.SerializeObject(metadataDictionary);
        }

        private string GetPayload(ICommand command)
        {
            return JsonConvert.SerializeObject(command);
        }
    }
}
