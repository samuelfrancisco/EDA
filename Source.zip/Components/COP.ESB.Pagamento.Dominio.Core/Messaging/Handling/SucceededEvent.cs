﻿using COP.ESB.Pagamento.Dominio.Core.Exceptions;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public class SucceededEvent : PersistedEvent        
    {
        public string PreviousFails { get; set; }

        public SucceededEvent()
            : base()
        {

        }

        public SucceededEvent(IEventEnvelop<IEvent> envelop, Type eventHandlerType)
            : base(envelop, eventHandlerType)
        {

        }

        public SucceededEvent(IEventEnvelop<IEvent> envelop, Type eventHandlerType, IEnumerable<ExceptionInfo> previousFails)
            : base(envelop, eventHandlerType)
        {
            PreviousFails = GetPreviousFails(previousFails);
        }

        private string GetPreviousFails(IEnumerable<ExceptionInfo> previousFails)
        {
            return JsonConvert.SerializeObject(previousFails);
        }
    }
}
