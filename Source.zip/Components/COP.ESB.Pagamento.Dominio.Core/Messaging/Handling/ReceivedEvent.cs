﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public class ReceivedEvent : PersistedEvent        
    {
        public string ReceiveDates { get; set; }

        public ReceivedEvent()
            : base()
        {

        }

        public ReceivedEvent(IEventEnvelop<IEvent> envelop, Type eventHandlerType)
            : base(envelop, eventHandlerType)
        {
            ReceiveDates = GetReceiveDates(new[] { new DateTimeOffset(DateTime.Now) });
        }

        public void AddNewReceiveDate()
        {
            var dateList = GetReceiveDateList();

            dateList.Add(new DateTimeOffset(DateTime.Now));

            ReceiveDates = GetReceiveDates(dateList);
        }

        private List<DateTimeOffset> GetReceiveDateList()
        {
            var dates = JsonConvert.DeserializeObject<IEnumerable<DateTimeOffset>>(ReceiveDates);

            return dates.ToList();
        }

        private string GetReceiveDates(IEnumerable<DateTimeOffset> dates)
        {
            return JsonConvert.SerializeObject(dates);
        }
    }
}
