﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces
{
    public interface IInternalAsyncEventHandler<TEvent> : IAsyncEventHandler<TEvent>
        where TEvent : IEvent
    {
    }
}
