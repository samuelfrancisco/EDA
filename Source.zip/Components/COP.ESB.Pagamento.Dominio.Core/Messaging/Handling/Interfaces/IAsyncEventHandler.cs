﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces
{
    public interface IAsyncEventHandler<TEvent> : IEventHandler<TEvent>
        where TEvent : IEvent
    {
    }
}
