﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging
{
    public interface ICommandHandler<TCommand> where TCommand : ICommand
    {
        Task HandleAsync(TCommand command, CancellationToken cancellationToken);
    }

    public interface ICommandHandler<TCommand, TResult> where TCommand : ICommand where TResult : Result
    {
        Task<TResult> HandleAsync(TCommand command, CancellationToken cancellationToken);
    }

    public interface ICommandHandler<TCommand, TResult, TValue> where TCommand : ICommand where TResult : Result<TValue>
    {
        Task<TResult> HandleAsync(TCommand command, CancellationToken cancellationToken);
    }
}
