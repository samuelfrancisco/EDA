﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces
{
    public interface ICommandHandlerRepository
    {
        Task<bool> IsTheCommandAlreadyReceivedAsync(Guid commandId);
        Task<ReceivedCommand> GetReceivedCommandByIdAsync(Type commandHandlerType, Guid commandId);
        Task<SucceededCommand> GetSucceededCommandByIdAsync(Type commandHandlerType, Guid commandId);
        Task<FailedCommand> GetFailedCommandByIdAsync(Type commandHandlerType, Guid commandId);
        Task<List<ReceivedCommand>> GetAllReceivedCommandsWhereAsync(Type commandHandlerType, Expression<Func<ReceivedCommand, bool>> expression);
        Task<List<SucceededCommand>> GetAllSucceededCommandsWhereAsync(Type commandHandlerType, Expression<Func<SucceededCommand, bool>> expression);
        Task<List<FailedCommand>> GetAllFailedCommandsWhereAsync(Type commandHandlerType, Expression<Func<FailedCommand, bool>> expression);
        Task SaveReceivedCommandAsync(ReceivedCommand receivedCommand);
        Task SaveSucceededCommandAsync(SucceededCommand succeededCommand);
        Task SaveFailedCommandAsync(FailedCommand failedCommand);
        Task RemoveFailedCommandAsync(FailedCommand failedCommand);
    }
}
