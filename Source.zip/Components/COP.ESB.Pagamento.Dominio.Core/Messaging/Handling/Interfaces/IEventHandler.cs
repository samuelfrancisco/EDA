﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces
{
    public interface IEventHandler<TEvent> where TEvent : IEvent
    {
        Task HandleAsync(IEventEnvelop<TEvent> envelop, CancellationToken cancellationToken);
    }
}
