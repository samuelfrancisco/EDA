﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces
{
    public interface IEventHandlerRepository
    {
        Task<long> GetLatestReceivedEventGlobalSequenceNumberAsync(string eventHandleTypeFullName, string eventSourceServerName);
        Task<bool> IsTheEventAlreadyReceivedAsync(string eventHandleTypeFullName, string eventSourceServerName, string eventTypeFullName, Guid eventId);
        Task<ReceivedEvent> GetReceivedEventByIdAsync(string eventHandleTypeFullName, string eventSourceServerName, string eventTypeFullName, Guid eventId);
        Task<SucceededEvent> GetSucceededEventByIdAsync(string eventHandleTypeFullName, string eventSourceServerName, string eventTypeFullName, Guid eventId);
        Task<FailedEvent> GetFailedEventByIdAsync(string eventHandleTypeFullName, string eventSourceServerName, string eventTypeFullName, Guid eventId);
        Task<List<ReceivedEvent>> GetAllReceivedEventsWhereAsync(Type eventHandlerType, Expression<Func<ReceivedEvent, bool>> expression);
        Task<List<SucceededEvent>> GetAllSucceededEventsWhereAsync(Type eventHandlerType, Expression<Func<SucceededEvent, bool>> expression);
        Task<List<FailedEvent>> GetAllFailedEventsWhereAsync(Type eventHandlerType, Expression<Func<FailedEvent, bool>> expression);
        Task SaveReceivedEventAsync(ReceivedEvent receivedEvent);
        Task SaveSucceededEventAsync(SucceededEvent succeededEvent);
        Task SaveFailedEventAsync(FailedEvent failedEvent);
        Task RemoveFailedEventAsync(FailedEvent failedEvent);
    }
}
