﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class PersistedEvent
    {
        protected PersistedEvent()
        {
            //Id = Guid.NewGuid();
        }

        protected PersistedEvent(IEventEnvelop<IEvent> envelop, Type eventHandlerType)
            : this()
        {
            var @event = envelop.Body;

            EventHandlerTypeFullName = eventHandlerType.FullName;
            EventSourceServerName = envelop.SourceServerName;
            EventGlobalSequenceNumber = envelop.GlobalSequenceNumber;
            EventTypeFullName = @event.GetType().FullName;
            EventId = @event.Id;
            EventDate = @event.Date;
            Metadata = GetMetadata(@event, eventHandlerType);
            Payload = GetPayload(@event);            
        }

        public long Id { get; set; }
        public string EventHandlerTypeFullName { get; set; }
        public string EventSourceServerName { get; set; }
        public long? EventGlobalSequenceNumber { get; set; }        
        public string EventTypeFullName { get; set; }
        public Guid EventId { get; set; }
        public DateTimeOffset EventDate { get; set; }
        public string Metadata { get; set; }
        public string Payload { get; set; }        

        private string GetMetadata(IEvent @event, Type eventHandlerType)
        {
            var eventType = @event.GetType();

            var metadataDictionary = new Dictionary<string, string>
            {
                { "EventHandlerTypeFullName", eventHandlerType.FullName },
                { "EventHandlerTypeName", eventHandlerType.Name },
                { "EventHandlerAssemblyFullName", eventHandlerType.Assembly.FullName },
                { "EventHandlerAssemblyQualifiedName", eventHandlerType.AssemblyQualifiedName },
                { "EventHandlerNamespace", eventHandlerType.Namespace },
                { "EventTypeFullName", eventType.FullName },
                { "EventTypeName", eventType.Name },
                { "EventAssemblyFullName", eventType.Assembly.FullName },
                { "EventAssemblyQualifiedName", eventType.AssemblyQualifiedName },
                { "EventNamespace", eventType.Namespace }
            };

            return JsonConvert.SerializeObject(metadataDictionary);            
        }

        private string GetPayload(IEvent @event)
        {
            return JsonConvert.SerializeObject(@event);            
        }
    }
}
