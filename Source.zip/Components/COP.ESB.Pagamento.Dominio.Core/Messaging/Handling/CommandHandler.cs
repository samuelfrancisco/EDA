﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class CommandHandler<TCommand> : ICommandHandler<TCommand>
        where TCommand : ICommand        
    {
        protected readonly ICommandHandlerRepository _commandHandlerRepository;

        public CommandHandler(ICommandHandlerRepository commandHandlerRepository)
        {
            _commandHandlerRepository = commandHandlerRepository;
        }

        public virtual async Task HandleAsync(TCommand command, CancellationToken cancellationToken)
        {
            await SaveReceivedCommandAsync(command).ConfigureAwait(false);

            try
            {
                await DoHandleAsync(command, cancellationToken).ConfigureAwait(false);

                await SaveSucceededCommandAsync(command).ConfigureAwait(false);

                return;
            }
            catch (Exception ex)
            {
                await SaveFailedCommandAsync(command, ex).ConfigureAwait(false);

                throw;
            }
        }

        protected abstract Task DoHandleAsync(TCommand command, CancellationToken cancellationToken);

        protected async Task SaveReceivedCommandAsync(TCommand command)
        {
            var receivedCommand = await _commandHandlerRepository.GetReceivedCommandByIdAsync(this.GetType(), command.Id).ConfigureAwait(false);

            if (receivedCommand == null)
            {
                receivedCommand = new ReceivedCommand(command, GetType());
            }
            else
            {
                receivedCommand.AddNewReceiveDate();
            }

            await _commandHandlerRepository.SaveReceivedCommandAsync(receivedCommand).ConfigureAwait(false);
        }

        protected async Task SaveSucceededCommandAsync(TCommand command)
        {
            var failedCommand = await _commandHandlerRepository.GetFailedCommandByIdAsync(GetType(), command.Id).ConfigureAwait(false);

            var succeededCommand = failedCommand == null
                                       ? new SucceededCommand(command, GetType())
                                       : new SucceededCommand(command, GetType(), failedCommand.GetFailList());

            await _commandHandlerRepository.SaveSucceededCommandAsync(succeededCommand).ConfigureAwait(false);

            if (failedCommand != null)
                await _commandHandlerRepository.RemoveFailedCommandAsync(failedCommand).ConfigureAwait(false);
        }

        protected async Task SaveFailedCommandAsync(TCommand command, Exception exception)
        {
            var failedCommand = await _commandHandlerRepository.GetFailedCommandByIdAsync(GetType(), command.Id).ConfigureAwait(false);

            if (failedCommand == null)
            {
                failedCommand = new FailedCommand(command, GetType(), exception);
            }
            else
            {
                failedCommand.AddNewFail(exception);
            }

            await _commandHandlerRepository.SaveFailedCommandAsync(failedCommand).ConfigureAwait(false);
        }
    }

    public abstract class CommandHandler<TCommand, TResult> : ICommandHandler<TCommand, TResult> 
        where TCommand : ICommand 
        where TResult : Result
    {
        protected readonly ICommandHandlerRepository _commandHandlerRepository;

        public CommandHandler(ICommandHandlerRepository commandHandlerRepository)
        {
            _commandHandlerRepository = commandHandlerRepository;
        }

        public virtual async Task<TResult> HandleAsync(TCommand command, CancellationToken cancellationToken)
        {
            await SaveReceivedCommandAsync(command).ConfigureAwait(false);

            try
            {
                var result = await DoHandleAsync(command, cancellationToken).ConfigureAwait(false);

                await SaveSucceededCommandAsync(command).ConfigureAwait(false);

                return result;
            }
            catch (Exception ex)
            {
                await SaveFailedCommandAsync(command, ex).ConfigureAwait(false);

                throw;
            }
        }

        protected abstract Task<TResult> DoHandleAsync(TCommand command, CancellationToken cancellationToken);

        protected async Task SaveReceivedCommandAsync(TCommand command)
        {
            var receivedCommand = await _commandHandlerRepository.GetReceivedCommandByIdAsync(this.GetType(), command.Id).ConfigureAwait(false);

            if (receivedCommand == null)
            {
                receivedCommand = new ReceivedCommand(command, GetType());
            }
            else
            {
                receivedCommand.AddNewReceiveDate();
            }

            await _commandHandlerRepository.SaveReceivedCommandAsync(receivedCommand).ConfigureAwait(false);
        }

        protected async Task SaveSucceededCommandAsync(TCommand command)
        {
            var failedCommand = await _commandHandlerRepository.GetFailedCommandByIdAsync(GetType(), command.Id).ConfigureAwait(false);

            var succeededCommand = failedCommand == null
                                       ? new SucceededCommand(command, GetType())
                                       : new SucceededCommand(command, GetType(), failedCommand.GetFailList());

            await _commandHandlerRepository.SaveSucceededCommandAsync(succeededCommand).ConfigureAwait(false);

            if (failedCommand != null)
                await _commandHandlerRepository.RemoveFailedCommandAsync(failedCommand).ConfigureAwait(false);
        }

        protected async Task SaveFailedCommandAsync(TCommand command, Exception exception)
        {
            var failedCommand = await _commandHandlerRepository.GetFailedCommandByIdAsync(GetType(), command.Id).ConfigureAwait(false);

            if (failedCommand == null)
            {
                failedCommand = new FailedCommand(command, GetType(), exception);
            }
            else
            {
                failedCommand.AddNewFail(exception);
            }

            await _commandHandlerRepository.SaveFailedCommandAsync(failedCommand).ConfigureAwait(false);
        }
    }

    public abstract class CommandHandler<TCommand, TResult, TValue> : CommandHandler<TCommand, TResult>, ICommandHandler<TCommand, TResult, TValue> 
        where TCommand : ICommand 
        where TResult : Result<TValue>
    {
        public CommandHandler(ICommandHandlerRepository commandHandlerRepository) 
            : base(commandHandlerRepository)
        {
        }
    }
}
