﻿using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Exceptions;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public abstract class PrimaryCommandHandler<TCommand> : CommandHandler<TCommand>, ICommandHandler<TCommand>
        where TCommand : ICommand
    {
        protected readonly IUnitOfWork _unitOfWork;

        public PrimaryCommandHandler(IUnitOfWork unitOfWork, ICommandHandlerRepository commandHandlerRepository)
            : base(commandHandlerRepository)
        {
            _unitOfWork = unitOfWork;
        }

        public override async Task HandleAsync(TCommand command, CancellationToken cancellationToken)
        {
            await SaveReceivedCommandAsync(command).ConfigureAwait(false);

            while (true)
            {
                try
                {
                    await DoHandleAsync(command, cancellationToken).ConfigureAwait(false);

                    await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

                    await SaveSucceededCommandAsync(command).ConfigureAwait(false);

                    return;
                }
                catch (ConcurrencyException)
                {
                    _unitOfWork.Reset();

                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    await SaveFailedCommandAsync(command, ex).ConfigureAwait(false);

                    throw ex;
                }
            }
        }
    }

    public abstract class PrimaryCommandHandler<TCommand, TResult> : CommandHandler<TCommand, TResult>, ICommandHandler<TCommand, TResult>
        where TCommand : ICommand
        where TResult : Result
    {
        protected readonly IUnitOfWork _unitOfWork;

        public PrimaryCommandHandler(IUnitOfWork unitOfWork, ICommandHandlerRepository commandHandlerRepository)
            : base(commandHandlerRepository)
        {
            _unitOfWork = unitOfWork;
        }

        public override async Task<TResult> HandleAsync(TCommand command, CancellationToken cancellationToken)
        {
            await SaveReceivedCommandAsync(command).ConfigureAwait(false);

            while (true)
            {
                try
                {
                    var result = await DoHandleAsync(command, cancellationToken).ConfigureAwait(false);

                    await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

                    await SaveSucceededCommandAsync(command).ConfigureAwait(false);

                    return result;
                }
                catch (ConcurrencyException)
                {
                    _unitOfWork.Reset();

                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    await SaveFailedCommandAsync(command, ex).ConfigureAwait(false);

                    throw ex;
                }
            }
        }
    }

    public abstract class PrimaryCommandHandler<TCommand, TResult, TValue> : PrimaryCommandHandler<TCommand, TResult>, ICommandHandler<TCommand, TResult, TValue>
        where TCommand : ICommand
        where TResult : Result<TValue>
    {
        public PrimaryCommandHandler(IUnitOfWork unitOfWork, ICommandHandlerRepository commandHandlerRepository)
            : base(unitOfWork, commandHandlerRepository)
        {
        }
    }
}
