﻿using COP.ESB.Pagamento.Dominio.Core.Exceptions;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling
{
    public class FailedCommand : PersistedCommand
    {
        public string Fails { get; set; }

        public FailedCommand()
            : base()
        {
            
        }

        public FailedCommand(ICommand command, Type commandHandlerType, Exception exception)
            : base(command, commandHandlerType)
        {
            Fails = GetFails(new[] { new ExceptionInfo(exception) });
        }

        public void AddNewFail(Exception exception)
        {
            var failList = GetFailList();

            failList.Add(new ExceptionInfo(exception));

            Fails = GetFails(failList);
        }

        public List<ExceptionInfo> GetFailList()
        {
            var fails = JsonConvert.DeserializeObject<IEnumerable<ExceptionInfo>>(Fails);

            return fails.ToList();
        }

        private string GetFails(IEnumerable<ExceptionInfo> fails)
        {
            return JsonConvert.SerializeObject(fails);
        }        
    }
}
