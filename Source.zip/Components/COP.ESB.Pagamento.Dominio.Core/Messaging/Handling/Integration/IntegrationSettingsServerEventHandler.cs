﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsServerEventHandler
    {
        public string HandlerTypeFullName { get; set; }
        public string ExecutionInterval { get; set; }
    }
}