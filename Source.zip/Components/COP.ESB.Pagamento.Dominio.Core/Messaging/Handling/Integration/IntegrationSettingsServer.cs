﻿using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsServer
    {
        public string ServerName { get; set; }
        public string ConnectionString { get; set; }
        public IEnumerable<IntegrationSettingsServerEventHandler> Handlers { get; set; }
        public IEnumerable<IntegrationSettingsServerIntegration> Integrations { get; set; }
    }
}