﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsEventSource
    {
        public string ServerName { get; set; }        
    }
}