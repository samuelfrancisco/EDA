﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsEventHandler
    {
        public string HandlerTypeFullName { get; set; }
    }
}