﻿using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsEvent
    {
        public string OriginEventTypeFullName { get; set; }
        public string DestinyEventTypeFullName { get; set; }
        public string IntegrationName { get; set; }
        public IEnumerable<IntegrationSettingsEventSource> Sources { get; set; }
        public IEnumerable<IntegrationSettingsEventHandler> Handlers { get; set; }
    }
}