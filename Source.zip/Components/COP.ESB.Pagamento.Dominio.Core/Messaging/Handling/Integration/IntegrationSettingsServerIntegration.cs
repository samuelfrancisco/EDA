﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettingsServerIntegration
    {
        public string Name { get; set; }       
    }
}
