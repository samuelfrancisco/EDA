﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration
{
    public class IntegrationSettings
    {
        private static IntegrationSettings _instancia;
        public static IntegrationSettings Instancia
        {
            get
            {
                return _instancia ?? (_instancia = CarregarConfiguracoes());
            }
        }

        private static IntegrationSettings CarregarConfiguracoes()
        {
            try
            {
                string filePath = GetFilePath();

                using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                using (var reader = new StreamReader(stream))
                using (var jsonReader = new JsonTextReader(reader))
                {
                    var jsonSerializer = new JsonSerializer();

                    return jsonSerializer.Deserialize<IntegrationSettings>(jsonReader);
                }
            }
            catch (Exception)
            {
                return default(IntegrationSettings);
            }
        }

        private static string GetFilePath()
        {
            var appPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase).Replace("file:\\", "");

            var filePath = Path.Combine(appPath, "integration_settings.json");

            return filePath;
        }
        public IEnumerable<IntegrationSettingsServer> Servers { get; set; }
        public IEnumerable<IntegrationSettingsEvent> Events { get; set; }
    }
}
