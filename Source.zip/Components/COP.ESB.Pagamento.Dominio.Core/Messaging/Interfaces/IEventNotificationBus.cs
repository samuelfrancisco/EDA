﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface IEventNotificationBus
    {
        void PublishOne<TEvent>(TEvent @event) where TEvent : class, IEvent;
        void PublishMany<TEvent>(IEnumerable<TEvent> events) where TEvent : class, IEvent;
        Task PublishOneAsync<TEvent>(TEvent @event) where TEvent : class, IEvent;
        Task PublishManyAsync<TEvent>(IEnumerable<TEvent> events) where TEvent : class, IEvent;
    }
}
