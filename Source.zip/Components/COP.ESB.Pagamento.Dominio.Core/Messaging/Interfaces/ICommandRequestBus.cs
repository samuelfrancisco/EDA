﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface ICommandRequestBus
    {
        void SendOne<TCommand>(TCommand command) where TCommand : class, ICommand;
        TResult SendOne<TCommand, TResult>(TCommand command) where TCommand : class, ICommand where TResult : Result;
        TResult SendOne<TCommand, TResult, TValue>(TCommand command) where TCommand : class, ICommand where TResult : Result<TValue>;
        void SendMany<TCommand>(IEnumerable<TCommand> commands) where TCommand : class, ICommand;
        IEnumerable<TResult> SendMany<TCommand, TResult>(IEnumerable<TCommand> commands) where TCommand : class, ICommand where TResult : Result;
        IEnumerable<TResult> SendMany<TCommand, TResult, TValue>(IEnumerable<TCommand> commands) where TCommand : class, ICommand where TResult : Result<TValue>;
        Task SendOneAsync<TCommand>(TCommand command) where TCommand : class, ICommand;
        Task<TResult> SendOneAsync<TCommand, TResult>(TCommand command) where TCommand : class, ICommand where TResult : Result;
        Task<TResult> SendOneAsync<TCommand, TResult, TValue>(TCommand command) where TCommand : class, ICommand where TResult : Result<TValue>;
        Task SendManyAsync<TCommand>(IEnumerable<TCommand> commands) where TCommand : class, ICommand;
        Task<IEnumerable<TResult>> SendManyAsync<TCommand, TResult>(IEnumerable<TCommand> commands) where TCommand : class, ICommand where TResult : Result;
        Task<IEnumerable<TResult>> SendManyAsync<TCommand, TResult, TValue>(IEnumerable<TCommand> commands) where TCommand : class, ICommand where TResult : Result<TValue>;
    }
}
