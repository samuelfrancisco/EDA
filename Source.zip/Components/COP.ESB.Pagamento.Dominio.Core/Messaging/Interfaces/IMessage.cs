﻿using System;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface IMessage
    {
        Guid Id { get; }
        DateTimeOffset Date { get; }
        IMessage CorrelationMessage { get; }
        IMessage OriginalCorrelationMessage { get; }
    }
}
