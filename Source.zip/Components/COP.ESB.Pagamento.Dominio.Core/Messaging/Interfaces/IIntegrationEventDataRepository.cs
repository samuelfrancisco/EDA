﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface IIntegrationEventDataRepository
    {
        void Start(string connectionString);
        Task<IEnumerable<IntegrationEventData>> GetAllEventsFromAsync(long globalSequenceNumber);
        Task<IEnumerable<IntegrationEventData>> GetAllEventsFromAsync(long globalSequenceNumber, string eventHandlerTypeFullName);
    }
}
