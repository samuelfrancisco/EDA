﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface IEvent : IMessage
    {
    }
}
