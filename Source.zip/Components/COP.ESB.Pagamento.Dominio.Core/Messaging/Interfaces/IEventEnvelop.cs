﻿namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces
{
    public interface IEventEnvelop<TEvent> where TEvent: IEvent
    {
        long? GlobalSequenceNumber { get; }
        string SourceServerName { get; }
        TEvent Body { get; }

        IEventEnvelop<IEvent> ToGeneric();
    }
}
