﻿using System;
using System.Runtime.Serialization;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging.Exceptions
{

    [Serializable]
    public class DuplicatedCommandException : Exception
    {
        public DuplicatedCommandException()
        {
        }

        public DuplicatedCommandException(string message)
            : base(message)
        {
        }

        public DuplicatedCommandException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected DuplicatedCommandException(SerializationInfo info, StreamingContext context) 
            : base(info, context)
        {
        }
    }
}
