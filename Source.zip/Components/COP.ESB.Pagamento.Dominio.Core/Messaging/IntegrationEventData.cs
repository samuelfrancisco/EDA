﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Integration;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Messaging
{
    public class IntegrationEventData : EventData
    {
        public override IEvent ToEvent()
        {
            var eventDefinition = IntegrationSettings.Instancia.Events.FirstOrDefault(x => x.OriginEventTypeFullName == EventTypeFullName);

            if (eventDefinition == null)
                return null;

            var eventType = AppDomain.CurrentDomain.GetAssemblies().SelectMany(x => x.GetTypes())
                .FirstOrDefault(x => x.FullName == eventDefinition.DestinyEventTypeFullName);

            if (eventType == null)
                return null;

            return (IEvent)JsonConvert.DeserializeObject(Payload, eventType);
        }
    }
}
