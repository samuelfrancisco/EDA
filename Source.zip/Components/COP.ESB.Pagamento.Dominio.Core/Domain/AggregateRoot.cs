﻿using COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.Domain
{
    public class AggregateRoot : IAggregateRoot
    {
        public AggregateRoot()
        {
            Id = Guid.NewGuid();
            Version = 0;
            Active = true;
        }

        public virtual Guid Id { get; set; }
        public virtual long Version { get; set; }
        public virtual bool Active { get; set; }

        public Result Disable()
        {
            Active = false;

            return new Result();
        }
    }
}
