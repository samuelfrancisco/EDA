﻿using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces
{
    public interface IAggregateRootRepository<TAggregate> where TAggregate : class, IAggregateRoot
    {
        Task SaveAsync(TAggregate aggregate);
    }
}
