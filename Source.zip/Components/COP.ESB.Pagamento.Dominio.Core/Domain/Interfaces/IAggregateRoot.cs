﻿using System;

namespace COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces
{
    public interface IAggregateRoot
    {
        Guid Id { get; set; }
        long Version { get; set; }
        bool Active { get; set; }

        Result Disable();
    }
}
