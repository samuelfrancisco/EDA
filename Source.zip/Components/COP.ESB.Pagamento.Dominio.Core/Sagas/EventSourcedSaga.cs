﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Sagas.Interfaces;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Sagas
{
    public class EventSourcedSaga : EventSourcedAggregateRoot, IEventSourcedSaga
    {
        private List<ICommand> _unsendedCommands = new List<ICommand>();

        public EventSourcedSaga()
            : base()
        {

        }

        public EventSourcedSaga(Guid id, IEnumerable<IVersionedEvent> pastEvents)
            : base(id, pastEvents)
        {
            
        }

        public IReadOnlyCollection<ICommand> UnsendedCommands { get { return _unsendedCommands; } }

        public void ClearUnsendedCommands()
        {
            _unsendedCommands.Clear();
        }

        protected void SendNewCommand(ICommand command)
        {
            _unsendedCommands.Add(command);
        }
    }
}
