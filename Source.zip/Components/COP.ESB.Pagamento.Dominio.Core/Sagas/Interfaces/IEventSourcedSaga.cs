﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Core.Sagas.Interfaces
{
    public interface IEventSourcedSaga : IEventSourcedAggregateRoot
    {
        IReadOnlyCollection<ICommand> UnsendedCommands { get; }

        void ClearUnsendedCommands();
    }
}
