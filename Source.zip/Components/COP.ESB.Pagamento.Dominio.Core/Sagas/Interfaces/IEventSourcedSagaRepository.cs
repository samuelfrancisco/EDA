﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;

namespace COP.ESB.Pagamento.Dominio.Core.Sagas.Interfaces
{
    public interface IEventSourcedSagaRepository<TSaga> : IEventSourcedAggregateRootRepository<TSaga>
        where TSaga : class, IEventSourcedSaga
    {

    }
}
