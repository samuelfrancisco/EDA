﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace COP.ESB.Pagamento.Dominio.Core.IoC.Interfaces
{
    public interface ICustomContainer : IDisposable
    {
        object GetInstance(Type serviceType);
        TService GetInstance<TService>() where TService : class;
        IEnumerable<object> GetAllInstances(Type serviceType);
        IEnumerable<TService> GetAllInstances<TService>() where TService : class;
        IEnumerable<Assembly> GetAssemblies();
        IDisposable BeginAsyncScope();
        IDisposable BeginThreadScope();
    }
}
