﻿namespace COP.ESB.Pagamento.Dominio.Core
{
    public static class CodigosDeErro
    {
        public static readonly int Excecao = int.MinValue;

        public static readonly int RegraDeNegocioNaoAtendida = int.MinValue + 1;

        public static readonly int QuantidadeMaximaDeTentativasAlcancada = int.MinValue + 2;

        public static readonly int HorarioFinalParaRealizacaoDaOperacaoAlcancado = int.MinValue + 3;

        public static readonly int Timeout = int.MinValue + 4;

        public static readonly int OcorrenciasDoSisPag = int.MinValue + 5;
    }
}
