﻿namespace COP.ESB.Pagamento.Dominio.Core.Extensions
{
    public static class IntExtensions
    {
        public static int SomarDigitos(this int value)
        {
            if (value <= 9)
                return value;

            int sum = 0, r;

            while (value != 0)
            {
                r = value % 10;
                value = value / 10;
                sum = sum + r;
            }

            return sum;
        }
    }
}
