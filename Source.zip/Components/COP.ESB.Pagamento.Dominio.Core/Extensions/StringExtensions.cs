﻿using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Core.Extensions
{
    public static class StringExtensions
    {
        public static bool SoContemNumeros(this string str)
        {
            if (string.IsNullOrWhiteSpace(str))
                return false;

            var chars = str.ToCharArray();

            return chars.All(x => char.IsDigit(x));
        }
    }
}
