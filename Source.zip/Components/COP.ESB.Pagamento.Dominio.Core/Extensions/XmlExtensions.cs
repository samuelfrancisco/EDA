﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.Core.Extensions
{
    public static class XmlExtensions
    {
        public static T FromXml<T>(string xml)
        {
            try
            {
                if (string.IsNullOrEmpty(xml))
                    return (T)Activator.CreateInstance(typeof(T));

                var xmlDocument = new XmlDocument
                {
                    InnerXml = xml
                };

                var serializer = new XmlSerializer(typeof(T));

                using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(xmlDocument.InnerXml)))
                using (var streamReader = new StreamReader(memoryStream))
                {
                    return (T)serializer.Deserialize(streamReader);
                }
            }
            catch (Exception)
            {
                return (T)Activator.CreateInstance(typeof(T));
            }
        }

        public static string ToStringXml<T>(T envio)
        {
            var serializer = new XmlSerializer(typeof(T));
            var subReq = (T)Activator.CreateInstance(typeof(T));
            var xml = "";

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces(); ns.Add("", "");
            XmlWriterSettings st = new XmlWriterSettings
            {
                OmitXmlDeclaration = true
            };

            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww, st))
                {
                    serializer.Serialize(writer, envio, ns, string.Empty);
                    xml = sww.ToString();
                }
            }

            return xml;
        }

        public static XmlDocument ToXml<T>(T envio)
        {
            var serializer = new XmlSerializer(typeof(T));
            var subReq = (T)Activator.CreateInstance(typeof(T));
            var xml = "";

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces(); ns.Add("", "");
            XmlWriterSettings st = new XmlWriterSettings
            {
                OmitXmlDeclaration = true
            };

            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww, st))
                {
                    serializer.Serialize(writer, envio, ns, string.Empty);
                    xml = sww.ToString();
                }
            }


            return new XmlDocument
            {
                InnerXml = xml
            };

        }
    }


}
