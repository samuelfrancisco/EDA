﻿using System;
using System.Globalization;

namespace COP.ESB.Pagamento.Dominio.Core.Extensions
{
    public static class DateTimeExtensions
    {
        public static bool TryParseFromJulianFormat(string julianDate, out DateTime newDateTime)
        {
            if (string.IsNullOrWhiteSpace(julianDate))
            {
                newDateTime = default(DateTime);
                return false;
            }

            if (julianDate.Length != 5)
            {
                newDateTime = default(DateTime);
                return false;
            }

            var julianCalendar = new JulianCalendar();

            if (!int.TryParse(julianDate.Substring(0, 2), out int year))
            {
                newDateTime = default(DateTime);
                return false;
            }

            try
            {
                var fourDigitYear = julianCalendar.ToFourDigitYear(year);

                if (!int.TryParse(julianDate.Substring(2, 3), out int day))
                {
                    newDateTime = default(DateTime);
                    return false;
                }

                if(day > 366)
                {
                    newDateTime = default(DateTime);
                    return false;
                }

                try
                {
                    var tempDate = new DateTime(fourDigitYear, 1, 1);

                    newDateTime = tempDate.AddDays(day - 1);
                }
                catch (Exception)
                {
                    newDateTime = default(DateTime);
                    return false;
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                newDateTime = default(DateTime);
                return false;
            }                        

            return true;
        }
    }
}
