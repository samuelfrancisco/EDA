﻿using COP.ESB.Pagamento.Dominio.Core.ReadModels.Interfaces;
using System;

namespace COP.ESB.Pagamento.Dominio.Core.ReadModels
{
    public class VersionedReadModel : IVersionedReadModel
    {
        public VersionedReadModel()
        {
            Id = Guid.NewGuid();
            Version = 0;
            Active = true;
        }

        public virtual Guid Id { get; set; }
        public virtual long Version { get; set; }
        public virtual bool Active { get; set; }

        public Result Disable()
        {
            Active = false;

            return new Result();
        }
    }
}
