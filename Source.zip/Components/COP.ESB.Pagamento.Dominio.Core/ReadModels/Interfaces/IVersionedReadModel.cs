﻿using System;

namespace COP.ESB.Pagamento.Dominio.Core.ReadModels.Interfaces
{
    public interface IVersionedReadModel
    {
        Guid Id { get; set; }
        long Version { get; set; }
        bool Active { get; set; }

        Result Disable();
    }
}
