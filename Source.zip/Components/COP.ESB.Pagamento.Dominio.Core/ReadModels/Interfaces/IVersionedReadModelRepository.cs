﻿using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Core.ReadModels.Interfaces
{
    public interface IVersionedReadModelRepository<TReadModel> where TReadModel : class, IVersionedReadModel
    {
        Task SaveAsync(TReadModel readModel);
    }
}
