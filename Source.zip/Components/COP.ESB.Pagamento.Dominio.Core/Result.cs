﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COP.ESB.Pagamento.Dominio.Core
{    
    [Serializable]
    public class Result
    {
        public Result()
        {

        }

        public Result(Result result)
        {
            if (result == null)
                return;

            ErroMessage.Message = result.ErroMessage.Message;
            ErroMessage.StatusCode = result.ErroMessage.StatusCode;

            foreach (var error in result.ErroMessage.Errors)
            {
                ErroMessage.Errors.Add(error);
            }
        }

        public ErrorMessage ErroMessage { get; set; } = new ErrorMessage();
        public bool IsSuccess { get { return !IsFailure; } }
        public bool IsFailure { get { return ErroMessage.Errors.Any(); } }

        public void AddError(string message, string reason, string domain)
        {
            ErroMessage.Errors.Add(new ErrorDescription { Message = message, Domain = domain, Reason = reason });
        }

        public void Merge(Result result)
        {
            if (result == null)
                return;

            foreach (var error in result.ErroMessage.Errors)
            {
                ErroMessage.Errors.Add(error);
            }
        }

        public void Merge(IEnumerable<Result> results)
        {
            if (results == null)
                return;

            foreach (var result in results)
            {
                Merge(result);
            }
        }

        public Result<T> ToResult<T>()
        {
            return new Result<T>(default(T), this);
        }

        public Result<T> ToResult<T>(T value)
        {
            return new Result<T>(value, this);
        }

        public override string ToString()
        {
            if (ErroMessage == null)
                return "Sem Erros";

            var sb = new StringBuilder();
            sb.AppendLine(ErroMessage.Message);

            foreach (var error in ErroMessage.Errors)
            {
                sb.AppendLine($"{error.Message}: {error.Reason}");
            }

            return sb.ToString();
        }
    }

    [Serializable]
    public class Result<T> : Result
    {
        public Result(T value)
        {
            Value = value;
        }

        public Result(T value, Result result)
            : base(result)
        {
            Value = value;
        }
        public T Value { get; set; }
    }

    [Serializable]
    public class ErrorMessage
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public ICollection<ErrorDescription> Errors { get; set; }


        public ErrorMessage()
        {
            Errors = new HashSet<ErrorDescription>();
        }

        public ErrorMessage(int statusCode, string message)
            : this()
        {
            StatusCode = statusCode;
            Message = message;
        }

        public ErrorMessage(string message)
            : this(0, message)
        {

        }
    }

    [Serializable]
    public class ErrorDescription
    {
        public string Domain { get; set; }
        public string Reason { get; set; }
        public string Message { get; set; }
    }
}
