﻿using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.CancelamentosDeBaixasOperacionaisDeBoletosAgendados.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Events;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletosAgendados.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletosAgendados.Events;
using COP.ESB.Pagamento.Dominio.Sagas.CancelamentosDePagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.Sagas.CancelamentosDePagamentosDeBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Sagas.CancelamentosDePagamentosDeBoletos.Events;
using FizzWare.NBuilder;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Sagas.CancelamentosDePagamentosDeBoletos
{
    [TestFixture]
    public class SagaDeCancelamentoDePagamentoDeBoletoTests
    {
        [TestCaseSource("GeradorDeEventosCancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent")]
        public void CancelamentoDePagamentoDeBoletoEfetivadoIniciado_DeveExecutarFluxoDeCancelamentoDeBaixaOperacional(CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoCancelamentoDaBaixaOperacional);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: true, realizarEstornoDoPagamento: false);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: true, realizarEstornoDoPagamento: false);

            ValidarFluxoDeCancelamentoDeBaixaOperacional(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent")]
        public void CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciado_DeveExecutarFluxoDeEstornoDoPagamento(CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: true, realizarEstornoDoPagamento: true);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: true, realizarEstornoDoPagamento: true);

            ValidarFluxoDeEstornoDoPagamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosCancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent")]
        public void CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciado_DeveExecutarFluxoDeConclusaoDoCancelamento(CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: false);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: false);

            ValidarFluxoDeConclusaoDoCancelamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent")]
        public void CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciado_DeveExecutarFluxoDeEstornoDoPagamento(CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: true);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: true);

            ValidarFluxoDeEstornoDoPagamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosCancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent")]
        public void CancelamentoDePagamentoDeBoletoSemRegistroIniciado_DeveExecutarFluxoDeConclusaoDoCancelamento(CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: false);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: false);

            ValidarFluxoDeConclusaoDoCancelamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent")]
        public void CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciado_DeveExecutarFluxoDeEstornoDoPagamento(CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            var saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento);

            ValidarValoresDaSaga(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: true);

            ValidarEventoDeInicioDoProcessoDeCancelamento(@event, saga, realizarCancelamentoDeBaixaOperacional: false, realizarEstornoDoPagamento: true);

            ValidarFluxoDeEstornoDoPagamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoRealizadoComSucessoEvent")]
        public void EstornoDePagamentoDeBoletoRealizadoComSucesso_DeUmPagamentoEfetivado_DeveExecutarFluxoDeCancelamentoDeBaixaOperacional(EstornoDePagamentoDeBoletoRealizadoComSucessoEvent @event)
        {
            var saga = Mock.Of<SagaDeCancelamentoDePagamentoDeBoleto>(x => x.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.RealizarCancelamentoDeBaixaOperacional == true
            && x.RealizarEstornoDoPagamento == true);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoCancelamentoDaBaixaOperacional);

            ValidarFluxoDeCancelamentoDeBaixaOperacional(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoRealizadoComSucessoEvent")]
        public void EstornoDePagamentoDeBoletoRealizadoComSucesso_DeUmPagamentoComBaixaRecusada_DeveExecutarFluxoDeConclusaoDoCancelamento(EstornoDePagamentoDeBoletoRealizadoComSucessoEvent @event)
        {
            var saga = Mock.Of<SagaDeCancelamentoDePagamentoDeBoleto>(x => x.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.RealizarCancelamentoDeBaixaOperacional == false
            && x.RealizarEstornoDoPagamento == true);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido);

            ValidarFluxoDeConclusaoDoCancelamento(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoRealizadoComSucessoEventComStatus")]
        public void EstornoDePagamentoDeBoletoRealizadoComSucesso_EmUmStatusInvalido_NaoDeveFazerNada(SagaDeCancelamentoDePagamentoDeBoleto saga,
            EstornoDePagamentoDeBoletoRealizadoComSucessoEvent @event)
        {
            var status = saga.Status;

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoRecusadoEvent")]
        public void EstornoDePagamentoDeBoletoRecusado_DeveExecutarFluxoDeConclusaoDoCancelamento(EstornoDePagamentoDeBoletoRecusadoEvent @event)
        {
            var saga = Mock.Of<SagaDeCancelamentoDePagamentoDeBoleto>(x => x.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent)
                            as ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoRecusadoEventComStatus")]
        public void EstornoDePagamentoDeBoletoRecusado_EmUmStatusInvalido_NaoDeveFazerNada(SagaDeCancelamentoDePagamentoDeBoleto saga,
            EstornoDePagamentoDeBoletoRecusadoEvent @event)
        {
            var status = saga.Status;

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent")]
        public void EstornoDePagamentoDeBoletoAgendadoConcluidoComErro_DeveExecutarFluxoDeConclusaoDoCancelamento(EstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent @event)
        {
            var saga = Mock.Of<SagaDeCancelamentoDePagamentoDeBoleto>(x => x.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoEstornoDoPagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.CodigoDaColigada == @event.CodigoDaColigada && x.CodigoDaAgencia == @event.CodigoDaAgencia
            && x.NumeroDaContaCorrente == @event.NumeroDaContaCorrente && x.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal
            && x.ValorDoPagamento == @event.ValorDoPagamento && x.DataDoPagamento == @event.DataDoPagamento);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent)
                            as ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommand)
                            as RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento);
            Assert.IsTrue(comando?.CodigoDeErro == @event.CodigoDeErro);
            Assert.IsTrue(comando?.DescricaoDoErro == @event.DescricaoDoErro);
        }

        [TestCaseSource("GeradorDeEventosEstornoDePagamentoDeBoletoAgendadoConcluidoComErroEventComStatus")]
        public void EstornoDePagamentoDeBoletoAgendadoConcluidoComErro_EmUmStatusInvalido_NaoDeveFazerNada(SagaDeCancelamentoDePagamentoDeBoleto saga,
            EstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent @event)
        {
            var status = saga.Status;

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        private static void ValidarValoresDaSaga(dynamic @event, SagaDeCancelamentoDePagamentoDeBoleto saga,
            bool realizarCancelamentoDeBaixaOperacional, bool realizarEstornoDoPagamento)
        {
            Assert.IsTrue(saga.CodigoDaAgencia == @event.CodigoDaAgencia);
            Assert.IsTrue(saga.CodigoDaColigada == @event.CodigoDaColigada);
            Assert.IsTrue(saga.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(saga.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(saga.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(saga.NumeroDaContaCorrente == @event.NumeroDaContaCorrente);
            Assert.IsTrue(saga.RealizarCancelamentoDeBaixaOperacional == realizarCancelamentoDeBaixaOperacional);
            Assert.IsTrue(saga.RealizarEstornoDoPagamento == realizarEstornoDoPagamento);
            Assert.IsTrue(saga.ValorDoPagamento == @event.ValorDoPagamento);
        }

        private static void ValidarEventoDeInicioDoProcessoDeCancelamento(dynamic @event, SagaDeCancelamentoDePagamentoDeBoleto saga,
            bool realizarCancelamentoDeBaixaOperacional, bool realizarEstornoDoPagamento)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeCancelamentoDePagamentoDeBoletoIniciadoEvent)
                            as ProcessoDeCancelamentoDePagamentoDeBoletoIniciadoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CodigoDaAgencia == @event.CodigoDaAgencia);
            Assert.IsTrue(evento?.CodigoDaColigada == @event.CodigoDaColigada);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.DataDoPagamento == @event.DataDoPagamento);
            Assert.IsTrue(evento?.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.NumeroDaContaCorrente == @event.NumeroDaContaCorrente);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(evento?.RealizarCancelamentoDeBaixaOperacional == realizarCancelamentoDeBaixaOperacional);
            Assert.IsTrue(evento?.RealizarEstornoDoPagamento == realizarEstornoDoPagamento);
            Assert.IsTrue(evento?.ValorDoPagamento == @event.ValorDoPagamento);
        }

        private static void ValidarFluxoDeCancelamentoDeBaixaOperacional(dynamic @event, SagaDeCancelamentoDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is AgendamentoDeCancelamentoDeBaixaOperacionalDeBoletoSolicitadoEvent)
                            as AgendamentoDeCancelamentoDeBaixaOperacionalDeBoletoSolicitadoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var primeiroComando = saga.UnsendedCommands.FirstOrDefault(x => x is AgendarCancelamentoDeBaixaOperacionalDeBoletoCommand)
                            as AgendarCancelamentoDeBaixaOperacionalDeBoletoCommand;

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando?.CorrelationMessage == @event);
            Assert.IsTrue(primeiroComando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(primeiroComando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(primeiroComando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(primeiroComando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(primeiroComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && primeiroComando?.OriginalCorrelationMessage == @event));

            var segundoComando = saga.UnsendedCommands.FirstOrDefault(x => x is MarcarPagamentoDeBoletoComoPendenteDeCancelamentoDeBaixaOperacionalCommand)
                                        as MarcarPagamentoDeBoletoComoPendenteDeCancelamentoDeBaixaOperacionalCommand;

            Assert.IsNotNull(segundoComando);
            Assert.IsTrue(segundoComando?.CorrelationMessage == @event);
            Assert.IsTrue(segundoComando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoComando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoComando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(segundoComando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && segundoComando?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarFluxoDeEstornoDoPagamento(dynamic @event, SagaDeCancelamentoDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is AgendamentoDeEstornoDePagamentoDeBoletoSolicitadoEvent)
                            as AgendamentoDeEstornoDePagamentoDeBoletoSolicitadoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(evento?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(evento?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(evento?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(evento?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(evento?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(evento?.DataDoPagamento == saga.DataDoPagamento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is AgendarEstornoDePagamentoDeBoletoCommand)
                            as AgendarEstornoDePagamentoDeBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento);
        }

        private static void ValidarFluxoDeConclusaoDoCancelamento(dynamic @event, SagaDeCancelamentoDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent)
                            as ProcessoDeCancelamentoDePagamentoDeBoletoConcluidoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is ConcluirCancelamentoDePagamentoDeBoletoCommand)
                            as ConcluirCancelamentoDePagamentoDeBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        private static IEnumerable<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent> GeradorDeEventosCancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent()
        {
            return Builder<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent> GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent()
        {
            return Builder<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> GeradorDeEventosCancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent()
        {
            return Builder<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent()
        {
            return Builder<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent> GeradorDeEventosCancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent()
        {
            return Builder<CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent> GeradorDeEventosCancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent()
        {
            return Builder<CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<EstornoDePagamentoDeBoletoRealizadoComSucessoEvent> GeradorDeEventosEstornoDePagamentoDeBoletoRealizadoComSucessoEvent()
        {
            return Builder<EstornoDePagamentoDeBoletoRealizadoComSucessoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosEstornoDePagamentoDeBoletoRealizadoComSucessoEventComStatus()
        {
            return (from status in new[]
                    {
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoCancelamentoDaBaixaOperacional,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Iniciado
                    }
                    from saga in Builder<SagaDeCancelamentoDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = status)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new EstornoDePagamentoDeBoletoRealizadoComSucessoEvent
                        {
                            CodigoDaAgencia = saga.CodigoDaAgencia,
                            CodigoDaColigada = saga.CodigoDaColigada,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NumeroDaContaCorrente = saga.NumeroDaContaCorrente,
                            DataDoPagamento = saga.DataDoPagamento,
                            ValorDoPagamento = saga.ValorDoPagamento
                        }
                    });
        }

        private static IEnumerable<EstornoDePagamentoDeBoletoRecusadoEvent> GeradorDeEventosEstornoDePagamentoDeBoletoRecusadoEvent()
        {
            return Builder<EstornoDePagamentoDeBoletoRecusadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosEstornoDePagamentoDeBoletoRecusadoEventComStatus()
        {
            return (from status in new[]
                    {
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoCancelamentoDaBaixaOperacional,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Iniciado
                    }
                    from saga in Builder<SagaDeCancelamentoDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = status)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new EstornoDePagamentoDeBoletoRecusadoEvent
                        {
                            CodigoDaAgencia = saga.CodigoDaAgencia,
                            CodigoDaColigada = saga.CodigoDaColigada,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NumeroDaContaCorrente = saga.NumeroDaContaCorrente,
                            DataDoPagamento = saga.DataDoPagamento,
                            ValorDoPagamento = saga.ValorDoPagamento
                        }
                    });
        }

        private static IEnumerable<EstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent> GeradorDeEventosEstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent()
        {
            return Builder<EstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosEstornoDePagamentoDeBoletoAgendadoConcluidoComErroEventComStatus()
        {
            return (from status in new[]
                    {
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.AguardandoCancelamentoDaBaixaOperacional,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Concluido,
                        SagaDeCancelamentoDePagamentoDeBoletoStatus.Iniciado
                    }
                    from saga in Builder<SagaDeCancelamentoDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = status)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new EstornoDePagamentoDeBoletoAgendadoConcluidoComErroEvent
                        {
                            CodigoDaAgencia = saga.CodigoDaAgencia,
                            CodigoDaColigada = saga.CodigoDaColigada,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NumeroDaContaCorrente = saga.NumeroDaContaCorrente,
                            DataDoPagamento = saga.DataDoPagamento,
                            ValorDoPagamento = saga.ValorDoPagamento
                        }
                    });
        }
    }
}
