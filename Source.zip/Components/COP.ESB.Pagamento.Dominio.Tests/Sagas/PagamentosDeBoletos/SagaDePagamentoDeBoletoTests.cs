﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos.Events;
using FizzWare.NBuilder;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Sagas.PagamentosDeBoletos
{
    [TestFixture]
    public class SagaDePagamentoDeBoletoTests
    {
        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoIniciadoEvent")]
        public void NovoPagamentoDeBoletoIniciado_DeveExecutarFluxoDePagamentoDeTitulo(NovoPagamentoDeBoletoIniciadoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is PagamentoDeTituloAgendadoEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: false);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: false);

            ValidarEventoDePagamentoDeTituloAgendado(@event, saga);

            ValidarComandoDePagamentoDeTituloAgendado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoIniciadoEmContingenciaEvent")]
        public void NovoPagamentoDeBoletoIniciadoEmContingencia_DeveExecutarFluxoDePagamentoDeTitulo(NovoPagamentoDeBoletoIniciadoEmContingenciaEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is PagamentoDeTituloAgendadoEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: false);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: false);

            ValidarEventoDePagamentoDeTituloAgendado(@event, saga);

            ValidarComandoDePagamentoDeTituloAgendado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent")]
        public void NovoPagamentoDeBoletoIniciadoComValidacaoDoSaldo_DeveExecutarFluxoDeConsultaDoSaldo(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ConsultaDoSaldoDaContaCorrenteAgendadaEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: true);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: true);

            ValidarEventoDeConsultaDeSaldoAgendada(@event, saga);

            ValidarComandoDeConsultaDeSaldoAgendada(@event, saga);
        }
      
        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent")]
        public void NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDoSaldo_DeveExecutarFluxoDeConsultaDoSaldo(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ConsultaDoSaldoDaContaCorrenteAgendadaEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: true);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: true);

            ValidarEventoDeConsultaDeSaldoAgendada(@event, saga);

            ValidarComandoDeConsultaDeSaldoAgendada(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEvent")]
        public void NovoPagamentoDeBoletoSemRegistroIniciado_DeveExecutarFluxoDePagamentoDeTitulo(NovoPagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is PagamentoDeTituloAgendadoEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: false);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: false);

            ValidarEventoDePagamentoDeTituloAgendado(@event, saga);

            ValidarComandoDePagamentoDeTituloAgendado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent")]
        public void NovoPagamentoDeBoletoSemRegistroIniciadoEmContingencia_DeveExecutarFluxoDePagamentoDeTitulo(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is PagamentoDeTituloAgendadoEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: false);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: false);

            ValidarEventoDePagamentoDeTituloAgendado(@event, saga);

            ValidarComandoDePagamentoDeTituloAgendado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent")]
        public void NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldo_DeveExecutarFluxoDeConsultaDoSaldo(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ConsultaDoSaldoDaContaCorrenteAgendadaEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: true);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: false, validarSaldoDaContaCorrente: true);

            ValidarEventoDeConsultaDeSaldoAgendada(@event, saga);

            ValidarComandoDeConsultaDeSaldoAgendada(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent")]
        public void NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldo_DeveExecutarFluxoDeConsultaDoSaldo(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent @event)
        {
            var saga = new SagaDePagamentoDeBoleto(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ConsultaDoSaldoDaContaCorrenteAgendadaEvent) == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente);

            ValidarPropriedadesDaSaga(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: true);

            ValidarEventoDeInicializacaoDoProcesso(@event, saga, foiRealizadoEmContingencia: true, validarSaldoDaContaCorrente: true);

            ValidarEventoDeConsultaDeSaldoAgendada(@event, saga);

            ValidarComandoDeConsultaDeSaldoAgendada(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosConsultaDeSaldoParaBoletoRealizadaComSucessoEvent")]
        public void ConsultaDeSaldoParaBoletoRealizadaComSucesso_DeveExecutarFluxoDeValidacaoDoSaldo(ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ValidacaoDoSaldoDisponivelDaContaCorrenteSolicitadaEvent) as ValidacaoDoSaldoDisponivelDaContaCorrenteSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is ValidarSaldoDisponivelDaContaCorrenteCommand) as ValidarSaldoDisponivelDaContaCorrenteCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.SaldoDisponivel == @event.SaldoDisponivel);
        }

        [TestCaseSource("GeradorDeEventosConsultaDeSaldoParaBoletoRealizadaComSucessoEventComStatus")]
        public void ConsultaDeSaldoParaBoletoRealizadaComSucesso_EmStatusDiferenteDeAguardandoConsultaDeSaldoDeContaCorrente_NaoDeveFazerNada(ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent")]
        public void ConsultaDeSaldoAgendadaParaBoletoConcluidaComErro_DeveExecutarFluxoDeValidacaoDoSaldo(ConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.CodigoDaAgencia == @event.CodigoDaAgencia && x.CodigoDaColigada == @event.CodigoDaColigada 
            && x.NumeroDaContaCorrente == @event.NumeroDaContaCorrente);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is RecusaDePagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteSolicitadaEvent)
                as RecusaDePagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var primeiroComando = saga.UnsendedCommands.FirstOrDefault(x => x is RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommand)
                as RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommand;

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando?.CorrelationMessage == @event);
            Assert.IsTrue(primeiroComando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(primeiroComando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(primeiroComando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(primeiroComando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(primeiroComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && primeiroComando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(primeiroComando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(primeiroComando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(primeiroComando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(primeiroComando?.CodigoDeErro == @event.CodigoDeErro);
            Assert.IsTrue(primeiroComando?.DescricaoDoErro == @event.DescricaoDoErro);                        

            var segundoComando = saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand)
                as RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand;

            Assert.IsNotNull(segundoComando);
            Assert.IsTrue(segundoComando?.CorrelationMessage == @event);
            Assert.IsTrue(segundoComando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoComando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoComando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(segundoComando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && segundoComando?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEventComStatus")]
        public void ConsultaDeSaldoAgendadaParaBoletoConcluidaComErro_EmStatusDiferenteDeAguardandoConsultaDeSaldoDeContaCorrente_NaoDeveFazerNada(ConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosSaldoDisponivelDaContaCorrenteValidadoEvent")]
        public void SaldoDisponivelDaContaCorrenteValidado_DeveExecutarFluxoDePagamentoDeTitulo(SaldoDisponivelDaContaCorrenteValidadoEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.CodigoDaAgencia == @event.CodigoDaAgencia && x.CodigoDaColigada == @event.CodigoDaColigada
            && x.NumeroDaContaCorrente == @event.NumeroDaContaCorrente && x.ValorDoPagamento == @event.ValorDoPagamento
            && x.DocumentoDoPagadorFinal == "05846629000251" && x.DataDoPagamento == DateTime.Today);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo);

            ValidarEventoDePagamentoDeTituloAgendado(@event, saga);

            ValidarComandoDePagamentoDeTituloAgendado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosSaldoDisponivelDaContaCorrenteValidadoEventComStatus")]
        public void SaldoDisponivelDaContaCorrenteValidado_EmStatusDiferenteDeAguardandoValidacaoDeSaldoDeContaCorrente_NaoDeveFazerNada(SaldoDisponivelDaContaCorrenteValidadoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEvent")]
        public void PagamentoDeTituloRealizadoComSucesso_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(SagaDePagamentoDeBoleto saga, PagamentoDeTituloParaBoletoRealizadoComSucessoEvent @event)
        {
            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento);

            ValidarEventoDeGeracaoDeComprovante(@event, saga);

            ValidarComandoDeGeracaoDeComprovante(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventV2")]
        public void PagamentoDeTituloRealizadoComSucesso_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(SagaDePagamentoDeBoleto saga, PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2 @event)
        {
            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento);

            ValidarEventoDeGeracaoDeComprovante(@event, saga);

            ValidarComandoDeGeracaoDeComprovante(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventComStatus")]
        public void PagamentoDeTituloRealizadoComSucesso_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloParaBoletoRealizadoComSucessoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventV2ComStatus")]
        public void PagamentoDeTituloRealizadoComSucesso_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2 @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRecusadoEvent")]
        public void PagamentoDeTituloRecusado_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(PagamentoDeTituloParaBoletoRecusadoEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeDebitoDeContaCorrenteRecusado(@event, saga);

            ValidarComandoDeDebitoDeContaCorrenteRecusado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRecusadoEventV2")]
        public void PagamentoDeTituloRecusado_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(PagamentoDeTituloParaBoletoRecusadoEventV2 @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeDebitoDeContaCorrenteRecusado(@event, saga);

            ValidarComandoDeDebitoDeContaCorrenteRecusado(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRecusadoEventComStatus")]
        public void PagamentoDeTituloRecusado_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloParaBoletoRecusadoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeTituloRecusadoEventV2ComStatus")]
        public void PagamentoDeTituloRecusado_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloParaBoletoRecusadoEventV2 @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEvent")]
        public void DebitoDeContaAgendadoParaBoletoConcluidoComErro_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.CodigoDaAgencia == @event.CodigoDaAgencia && x.CodigoDaColigada == @event.CodigoDaColigada
            && x.CodigoDeBarrasDoBoleto == @event.CodigoDeBarrasDoBoleto && x.DataDoPagamento == @event.DataDoPagamento
            && x.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal && x.NumeroDaContaCorrente == @event.NumeroDaContaCorrente
            && x.ValorDoPagamento == @event.ValorDoPagamento && x.ValidarSaldoDaContaCorrente == @event.ValidarSaldoDaContaCorrente);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeDebitoDeContaCorrenteRecusado(@event, saga);

            ValidarComandoDeDebitoDeContaCorrenteRecusado(@event, saga);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2) as RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CodigoDeBarrasDoBoleto == saga.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento.Date);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.ValidarSaldoDaContaCorrente == saga.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(comando?.CodigoDeErro == @event.CodigoDeErro);
            Assert.IsTrue(comando?.DescricaoDoErro == @event.DescricaoDoErro);
        }        

        [TestCaseSource("GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventV2")]
        public void DebitoDeContaAgendadoParaBoletoConcluidoComErro_DeveExecutarFluxoDeGeracaoDeComprovanteDePagamento(PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2 @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId
            && x.CodigoDaAgencia == @event.CodigoDaAgencia && x.CodigoDaColigada == @event.CodigoDaColigada
            && x.CodigoDeBarrasDoBoleto == @event.CodigoDeBarrasDoBoleto && x.DataDoPagamento == @event.DataDoPagamento
            && x.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal && x.NumeroDaContaCorrente == @event.NumeroDaContaCorrente
            && x.ValorDoPagamento == @event.ValorDoPagamento && x.ValidarSaldoDaContaCorrente == @event.ValidarSaldoDaContaCorrente);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeDebitoDeContaCorrenteRecusado(@event, saga);

            ValidarComandoDeDebitoDeContaCorrenteRecusado(@event, saga);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2) as RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CodigoDeBarrasDoBoleto == saga.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento.Date);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.ValidarSaldoDaContaCorrente == saga.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(comando?.CodigoDeErro == @event.CodigoDeErro);
            Assert.IsTrue(comando?.DescricaoDoErro == @event.DescricaoDoErro);
        }

        [TestCaseSource("GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventComStatus")]
        public void DebitoDeContaAgendadoParaBoletoConcluidoComErro_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventV2ComStatus")]
        public void DebitoDeContaAgendadoParaBoletoConcluidoComErro_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2 @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEvent")]
        public void ComprovanteDePagamentoDeBoletoGerado_DeveExecutarFluxoDeAgendamentoDeBaixaOperacional(SagaDePagamentoDeBoleto saga, ComprovanteDePagamentoDeBoletoGeradoEvent @event)
        {
            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is AgendamentoDeBaixaOperacionalDeBoletoSolicitadaEvent)
                as AgendamentoDeBaixaOperacionalDeBoletoSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var primeiroComando = saga.UnsendedCommands.FirstOrDefault(x => x is MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand)
                as MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand;

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando?.CorrelationMessage == @event);
            Assert.IsTrue(primeiroComando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(primeiroComando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(primeiroComando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(primeiroComando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(primeiroComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && primeiroComando?.OriginalCorrelationMessage == @event));

            var segundoComando = saga.UnsendedCommands.FirstOrDefault(x => x is EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand)
                as EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand;

            Assert.IsNotNull(segundoComando);
            Assert.IsTrue(segundoComando?.CorrelationMessage == @event);
            Assert.IsTrue(segundoComando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoComando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoComando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(segundoComando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoComando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && primeiroComando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(segundoComando?.NroControleParticipante == saga.NumeroControleParticipante);
            Assert.IsTrue(segundoComando?.ISPBRecebedorPrincipal == saga.ISPBParticipanteRecebedorPrincipal);
            Assert.IsTrue(segundoComando?.ISPBRecebedorADM == saga.ISPBParticipanteRecebedorAdministrado);
            Assert.IsTrue(segundoComando?.NrTitulo == saga.NumeroIdentificacaoTitulo);
            Assert.IsTrue(segundoComando?.NumRefCadTitBaixaOperac == saga.NumeroReferenciaCadastroTituloBaixaOperacional);
            Assert.IsTrue(segundoComando?.NumRefAtlBaixaOperac == saga.NumeroReferenciaAtualBaixaOperacional);
            Assert.IsTrue(segundoComando?.TipoBaixa == saga.TipoDeBaixaOperacional);
            Assert.IsTrue(segundoComando?.TipoPortador == saga.TipoDePessoaDoPagadorFinal);
            Assert.IsTrue(segundoComando?.DocIdentificacaoPortador == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(segundoComando?.DataHoraPagamento == saga.DataDoPagamento.DateTime);
            Assert.IsTrue(segundoComando?.DataProcessamento == saga.DataDoPagamento.DateTime);
            Assert.IsTrue(segundoComando?.ValorPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(segundoComando?.CodigoBarras == saga.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(segundoComando?.CanalPagamento == saga.CanalDoPagamento);
            Assert.IsTrue(segundoComando?.MeioPagamento == saga.MeioDePagamento);
            Assert.IsTrue(segundoComando?.IndicadorContigencia == "N");
            Assert.IsTrue(segundoComando?.DataMovimento == saga.DataDoPagamento.DateTime);
            Assert.IsTrue(segundoComando?.ISPBBaixa == saga.ISPBBaixa);
            Assert.IsTrue(segundoComando?.CodigoRecebedor == saga.CodigoRecebedor);
        }

        [TestCaseSource("GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEvent")]
        public void ComprovanteDePagamentoDeBoletoGerado_DeBoletoSemRegistro_DeveExecutarFluxoDeGeracaoConclusaoDoPagamento(SagaDePagamentoDeBoleto saga, ComprovanteDePagamentoDeBoletoGeradoEvent @event)
        {
            saga.EBoletoSemRegistro = true;
            
            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is EfetivacaoDoPagamentoSolicitadaEvent)
                as EfetivacaoDoPagamentoSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is EfetivarPagamentoDeBoletoCommand)
                as EfetivarPagamentoDeBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEventEmContingencia")]
        public void ComprovanteDePagamentoDeBoletoGerado_EmContingencia_DeveExecutarFluxoDeAgendamentoDeBaixaOperacional(SagaDePagamentoDeBoleto saga, ComprovanteDePagamentoDeBoletoGeradoEvent @event)
        {
            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is PagamentoRealizadoEmContingenciaMarcadoComoPendenteDeBaixaOperacionalEvent)
                as PagamentoRealizadoEmContingenciaMarcadoComoPendenteDeBaixaOperacionalEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand)
                as MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEventComStatus")]
        public void ComprovanteDePagamentoDeBoletoGerado_EmStatusDiferenteDeAguardandoDebitoDaContaCorrente_NaoDeveFazerNada(ComprovanteDePagamentoDeBoletoGeradoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRealizadaComSucessoEvent")]
        public void BaixaOperacionalBoletoRealizadaComSucesso_DeveExecutarFluxoDeGeracaoConclusaoDoPagamento(BaixaOperacionalBoletoRealizadaComSucessoEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is EfetivacaoDoPagamentoSolicitadaEvent)
                as EfetivacaoDoPagamentoSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is EfetivarPagamentoDeBoletoCommand)
                as EfetivarPagamentoDeBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRealizadaComSucessoEventComStatus")]
        public void BaixaOperacionalBoletoRealizadaComSucesso_EmStatusDiferenteDeAguardandoBaixaOperacionalDePagamento_NaoDeveFazerNada(BaixaOperacionalBoletoRealizadaComSucessoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRecusadaEvent")]
        public void BaixaOperacionalBoletoRecusada_DeveExecutarFluxoDeGeracaoConclusaoDoPagamento(BaixaOperacionalBoletoRecusadaEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeSolicitacaoDaMarcacaoDoPagamentoComoBaixaOperacionalRecusada(@event, saga);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand)
                as MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRecusadaEventComStatus")]
        public void BaixaOperacionalBoletoRecusada_EmStatusDiferenteDeAguardandoBaixaOperacionalDePagamento_NaoDeveFazerNada(BaixaOperacionalBoletoRecusadaEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoEnviadaComErroEvent")]
        public void BaixaOperacionalBoletoEnviadaComErro_DeveExecutarFluxoDeGeracaoConclusaoDoPagamento(BaixaOperacionalBoletoEnviadaComErroEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeSolicitacaoDaMarcacaoDoPagamentoComoBaixaOperacionalRecusada(@event, saga);

            ValidarComandoDeMarcacaoDoPagamentoComoBaixaOperacionalRejeitada(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoEnviadaComErroEventComStatus")]
        public void BaixaOperacionalBoletoEnviadaComErro_EmStatusDiferenteDeAguardandoBaixaOperacionalDePagamento_NaoDeveFazerNada(BaixaOperacionalBoletoEnviadaComErroEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRejeitadaEvent")]
        public void BaixaOperacionalBoletoRejeitada_DeveExecutarFluxoDeGeracaoConclusaoDoPagamento(BaixaOperacionalBoletoRejeitadaEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento);

            ValidarEventoDeSolicitacaoDaMarcacaoDoPagamentoComoBaixaOperacionalRecusada(@event, saga);

            ValidarComandoDeMarcacaoDoPagamentoComoBaixaOperacionalRejeitada(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosBaixaOperacionalBoletoRejeitadaEventComStatus")]
        public void BaixaOperacionalBoletoRejeitada_EmStatusDiferenteDeAguardandoBaixaOperacionalDePagamento_NaoDeveFazerNada(BaixaOperacionalBoletoRejeitadaEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeBoletoEfetivadoEvent")]
        public void PagamentoDeBoletoEfetivado_DeveConcluirOProcesso(PagamentoDeBoletoEfetivadoEvent @event)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.Concluido);

            ValidarEventoDeConclusaoDoProcesso(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeBoletoEfetivadoEventComStatus")]
        public void BaixaOperacionalBoletoRejeitada_EmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoEfetivadoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeBoletoRecusadoEventComStatusValido")]
        public void PagamentoDeBoletoRecusado_DeveConcluirOProcesso(PagamentoDeBoletoRecusadoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == SagaDePagamentoDeBoletoStatus.Concluido);

            ValidarEventoDeConclusaoDoProcesso(@event, saga);
        }

        [TestCaseSource("GeradorDeEventosPagamentoDeBoletoRecusadoEventComStatusInvalido")]
        public void PagamentoDeBoletoRecusado_EmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoRecusadoEvent @event,
            SagaDePagamentoDeBoletoStatus status)
        {
            var saga = Mock.Of<SagaDePagamentoDeBoleto>(x => x.Status == status
            && x.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto && x.IdDoBoleto == @event.IdDoBoleto
            && x.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto && x.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);

            saga.Handle(@event);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.Status == status);
        }

        private static void ValidarPropriedadesDaSaga(NovoPagamentoDeBoletoIniciadoBaseEvent @event, SagaDePagamentoDeBoleto saga,
            bool foiRealizadoEmContingencia, bool validarSaldoDaContaCorrente)
        {
            Assert.IsTrue(saga.CanalDoPagamento == @event.CanalDoPagamento);
            Assert.IsTrue(saga.CodigoDaAgencia == @event.CodigoDaAgencia);
            Assert.IsTrue(saga.CodigoDaColigada == @event.CodigoDaColigada);
            Assert.IsTrue(saga.CodigoDeBarrasDoBoleto == @event.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(saga.CodigoRecebedor == @event.CodigoRecebedor);
            Assert.IsTrue(saga.DataDeVencimento == @event.DataDeVencimento);
            Assert.IsTrue(saga.DataDoPagamento == @event.DataDoPagamento);
            Assert.IsTrue(saga.Descontos == @event.Descontos);
            Assert.IsTrue(saga.DocumentoDoBeneficiario == @event.DocumentoDoBeneficiario);
            Assert.IsTrue(saga.DocumentoDoPagador == @event.DocumentoDoPagador);
            Assert.IsTrue(saga.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal);
            Assert.IsTrue(saga.DocumentoDoSacadorOuAvalista == @event.DocumentoDoSacadorOuAvalista);
            Assert.IsTrue(saga.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(saga.Encargos == @event.Encargos);
            Assert.IsTrue(saga.FoiRealizadoEmContingencia == foiRealizadoEmContingencia);
            Assert.IsTrue(saga.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(saga.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(saga.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(saga.IdentificadorDoPagamentoNoCliente == @event.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(saga.ISPBBaixa == @event.ISPBBaixa);
            Assert.IsTrue(saga.ISPBParticipanteRecebedorAdministrado == @event.ISPBParticipanteRecebedorAdministrado);
            Assert.IsTrue(saga.ISPBParticipanteRecebedorPrincipal == @event.ISPBParticipanteRecebedorPrincipal);
            Assert.IsTrue(saga.MeioDePagamento == @event.MeioDePagamento);
            Assert.IsTrue(saga.NomeFantasiaDoBeneficiario == @event.NomeFantasiaDoBeneficiario);
            Assert.IsTrue(saga.NomeFantasiaDoPagador == @event.NomeFantasiaDoPagador);
            Assert.IsTrue(saga.NomeFantasiaDoSacadorOuAvalista == @event.NomeFantasiaDoSacadorOuAvalista);
            Assert.IsTrue(saga.NumeroControleParticipante == @event.NumeroControleParticipante);
            Assert.IsTrue(saga.NumeroDaContaCorrente == @event.NumeroDaContaCorrente);
            Assert.IsTrue(saga.CodigoDeBarrasDoBoleto == @event.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(saga.NumeroIdentificacaoTitulo == @event.NumeroIdentificacaoTitulo);
            Assert.IsTrue(saga.NumeroReferenciaAtualBaixaOperacional == @event.NumeroReferenciaAtualBaixaOperacional);
            Assert.IsTrue(saga.NumeroReferenciaCadastroTituloBaixaOperacional == @event.NumeroReferenciaCadastroTituloBaixaOperacional);
            Assert.IsTrue(saga.RazaoSocialDoBeneficiario == @event.RazaoSocialDoBeneficiario);
            Assert.IsTrue(saga.RazaoSocialDoPagador == @event.RazaoSocialDoPagador);
            Assert.IsTrue(saga.RazaoSocialDoSacadorOuAvalista == @event.RazaoSocialDoSacadorOuAvalista);
            Assert.IsTrue(saga.TipoDeBaixaOperacional == @event.TipoDeBaixaOperacional);
            Assert.IsTrue(saga.TipoDePessoaDoPagadorFinal == @event.TipoDePessoaDoPagadorFinal);
            Assert.IsTrue(saga.ValidarSaldoDaContaCorrente == validarSaldoDaContaCorrente);
            Assert.IsTrue(saga.ValorDoPagamento == @event.ValorDoPagamento);
            Assert.IsTrue(saga.ValorNominal == @event.ValorNominal);
        }

        private static void ValidarEventoDeInicializacaoDoProcesso(NovoPagamentoDeBoletoIniciadoBaseEvent @event, SagaDePagamentoDeBoleto saga,
            bool foiRealizadoEmContingencia, bool validarSaldoDaContaCorrente)
        {
            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDePagamentoDeBoletoIniciadoEvent)
                as ProcessoDePagamentoDeBoletoIniciadoEvent;

            Assert.IsNotNull(primeiroEvento);
            Assert.IsTrue(primeiroEvento?.CanalDoPagamento == @event.CanalDoPagamento);
            Assert.IsTrue(primeiroEvento?.CodigoDaAgencia == @event.CodigoDaAgencia);
            Assert.IsTrue(primeiroEvento?.CodigoDaColigada == @event.CodigoDaColigada);
            Assert.IsTrue(primeiroEvento?.CodigoDeBarrasDoBoleto == @event.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(primeiroEvento?.CodigoRecebedor == @event.CodigoRecebedor);
            Assert.IsTrue(primeiroEvento?.CorrelationMessage == @event);
            Assert.IsTrue(primeiroEvento?.DataDeVencimento == @event.DataDeVencimento);
            Assert.IsTrue(primeiroEvento?.DataDoPagamento == @event.DataDoPagamento);
            Assert.IsTrue(primeiroEvento?.Descontos == @event.Descontos);
            Assert.IsTrue(primeiroEvento?.DocumentoDoBeneficiario == @event.DocumentoDoBeneficiario);
            Assert.IsTrue(primeiroEvento?.DocumentoDoPagador == @event.DocumentoDoPagador);
            Assert.IsTrue(primeiroEvento?.DocumentoDoPagadorFinal == @event.DocumentoDoPagadorFinal);
            Assert.IsTrue(primeiroEvento?.DocumentoDoSacadorOuAvalista == @event.DocumentoDoSacadorOuAvalista);
            Assert.IsTrue(primeiroEvento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(primeiroEvento?.Encargos == @event.Encargos);
            Assert.IsTrue(primeiroEvento?.FoiRealizadoEmContingencia == foiRealizadoEmContingencia);
            Assert.IsTrue(primeiroEvento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(primeiroEvento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(primeiroEvento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(primeiroEvento?.IdentificadorDoPagamentoNoCliente == @event.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(primeiroEvento?.ISPBBaixa == @event.ISPBBaixa);
            Assert.IsTrue(primeiroEvento?.ISPBParticipanteRecebedorAdministrado == @event.ISPBParticipanteRecebedorAdministrado);
            Assert.IsTrue(primeiroEvento?.ISPBParticipanteRecebedorPrincipal == @event.ISPBParticipanteRecebedorPrincipal);
            Assert.IsTrue(primeiroEvento?.MeioDePagamento == @event.MeioDePagamento);
            Assert.IsTrue(primeiroEvento?.NomeFantasiaDoBeneficiario == @event.NomeFantasiaDoBeneficiario);
            Assert.IsTrue(primeiroEvento?.NomeFantasiaDoPagador == @event.NomeFantasiaDoPagador);
            Assert.IsTrue(primeiroEvento?.NomeFantasiaDoSacadorOuAvalista == @event.NomeFantasiaDoSacadorOuAvalista);
            Assert.IsTrue(primeiroEvento?.NumeroControleParticipante == @event.NumeroControleParticipante);
            Assert.IsTrue(primeiroEvento?.NumeroDaContaCorrente == @event.NumeroDaContaCorrente);
            Assert.IsTrue(primeiroEvento?.NumeroDoCodigoDeBarrasDoBoleto == @event.NumeroDoCodigoDeBarrasDoBoleto);
            Assert.IsTrue(primeiroEvento?.NumeroIdentificacaoTitulo == @event.NumeroIdentificacaoTitulo);
            Assert.IsTrue(primeiroEvento?.NumeroReferenciaAtualBaixaOperacional == @event.NumeroReferenciaAtualBaixaOperacional);
            Assert.IsTrue(primeiroEvento?.NumeroReferenciaCadastroTituloBaixaOperacional == @event.NumeroReferenciaCadastroTituloBaixaOperacional);
            Assert.IsTrue(primeiroEvento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && primeiroEvento?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(primeiroEvento?.RazaoSocialDoBeneficiario == @event.RazaoSocialDoBeneficiario);
            Assert.IsTrue(primeiroEvento?.RazaoSocialDoPagador == @event.RazaoSocialDoPagador);
            Assert.IsTrue(primeiroEvento?.RazaoSocialDoSacadorOuAvalista == @event.RazaoSocialDoSacadorOuAvalista);
            Assert.IsTrue(primeiroEvento?.TipoDeBaixaOperacional == @event.TipoDeBaixaOperacional);
            Assert.IsTrue(primeiroEvento?.TipoDePessoaDoPagadorFinal == @event.TipoDePessoaDoPagadorFinal);
            Assert.IsTrue(primeiroEvento?.ValidarSaldoDaContaCorrente == validarSaldoDaContaCorrente);
            Assert.IsTrue(primeiroEvento?.ValorDoPagamento == @event.ValorDoPagamento);
            Assert.IsTrue(primeiroEvento?.ValorNominal == @event.ValorNominal);
        }

        private static void ValidarEventoDeGeracaoDeComprovante(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is GeracaoDeComprovanteDePagamentoDeBoletoIniciadaEvent) as GeracaoDeComprovanteDePagamentoDeBoletoIniciadaEvent;

            Assert.IsNotNull(segundoEvento);
            Assert.IsTrue(segundoEvento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoEvento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(segundoEvento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoEvento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoEvento?.CorrelationMessage == @event);
            Assert.IsTrue(segundoEvento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && segundoEvento?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarComandoDeGeracaoDeComprovante(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is GerarComprovanteDePagamentoDeBoletoCommand) as GerarComprovanteDePagamentoDeBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.DataDeVencimento == saga.DataDeVencimento);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento);
            Assert.IsTrue(comando?.Descontos == saga.Descontos);
            Assert.IsTrue(comando?.DocumentoDoBeneficiario == saga.DocumentoDoBeneficiario);
            Assert.IsTrue(comando?.DocumentoDoPagador == saga.DocumentoDoPagador);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.DocumentoDoSacadorOuAvalista == saga.DocumentoDoSacadorOuAvalista);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.Encargos == saga.Encargos);
            Assert.IsTrue(comando?.FoiRealizadoEmContingencia == saga.FoiRealizadoEmContingencia);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.NomeFantasiaDoBeneficiario == saga.NomeFantasiaDoBeneficiario);
            Assert.IsTrue(comando?.NomeFantasiaDoPagador == saga.NomeFantasiaDoPagador);
            Assert.IsTrue(comando?.NomeFantasiaDoSacadorOuAvalista == saga.NomeFantasiaDoSacadorOuAvalista);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.RazaoSocialDoBeneficiario == saga.RazaoSocialDoBeneficiario);
            Assert.IsTrue(comando?.RazaoSocialDoPagador == saga.RazaoSocialDoPagador);
            Assert.IsTrue(comando?.RazaoSocialDoSacadorOuAvalista == saga.RazaoSocialDoSacadorOuAvalista);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
            Assert.IsTrue(comando?.ValorNominal == saga.ValorNominal);
        }

        private static void ValidarEventoDeConsultaDeSaldoAgendada(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ConsultaDoSaldoDaContaCorrenteAgendadaEvent) as ConsultaDoSaldoDaContaCorrenteAgendadaEvent;

            Assert.IsNotNull(segundoEvento);
            Assert.IsTrue(segundoEvento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoEvento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(segundoEvento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoEvento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoEvento?.CorrelationMessage == @event);
            Assert.IsTrue(segundoEvento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && segundoEvento?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarComandoDeConsultaDeSaldoAgendada(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is AgendarConsultaDeSaldoParaBoletoCommand) as AgendarConsultaDeSaldoParaBoletoCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarEventoDePagamentoDeTituloAgendado(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is PagamentoDeTituloAgendadoEvent) as PagamentoDeTituloAgendadoEvent;

            Assert.IsNotNull(segundoEvento);
            Assert.IsTrue(segundoEvento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(segundoEvento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(segundoEvento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(segundoEvento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(segundoEvento?.CorrelationMessage == @event);
            Assert.IsTrue(segundoEvento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && segundoEvento?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarComandoDePagamentoDeTituloAgendado(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is AgendarPagamentoDeTituloParaBoletoCommandV2) as AgendarPagamentoDeTituloParaBoletoCommandV2;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CodigoDaAgencia == saga.CodigoDaAgencia);
            Assert.IsTrue(comando?.CodigoDaColigada == saga.CodigoDaColigada);
            Assert.IsTrue(comando?.CodigoDeBarrasDoBoleto == saga.CodigoDeBarrasDoBoleto);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.DataDoPagamento == saga.DataDoPagamento.Date);
            Assert.IsTrue(comando?.DocumentoDoPagadorFinal == saga.DocumentoDoPagadorFinal);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == saga.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == saga.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == saga.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == saga.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.NumeroDaContaCorrente == saga.NumeroDaContaCorrente);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
            Assert.IsTrue(comando?.ValidarSaldoDaContaCorrente == saga.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(comando?.ValorDoPagamento == saga.ValorDoPagamento);
        }

        private static void ValidarEventoDeDebitoDeContaCorrenteRecusado(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is RecusaDePagamentoDeBoletoPorErroAoPagarTituloSolicitadaEvent)
                            as RecusaDePagamentoDeBoletoPorErroAoPagarTituloSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarComandoDeDebitoDeContaCorrenteRecusado(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand)
                            as RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarEventoDeSolicitacaoDaMarcacaoDoPagamentoComoBaixaOperacionalRecusada(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is MarcacaoDoPagamentoComoBaixaOperacionalRecusadaSolicitadaEvent)
                            as MarcacaoDoPagamentoComoBaixaOperacionalRecusadaSolicitadaEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarComandoDeMarcacaoDoPagamentoComoBaixaOperacionalRejeitada(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitadaCommand)
                            as MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitadaCommand;

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando?.CorrelationMessage == @event);
            Assert.IsTrue(comando?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(comando?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(comando?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(comando?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(comando?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && comando?.OriginalCorrelationMessage == @event));
        }

        private static void ValidarEventoDeConclusaoDoProcesso(dynamic @event, SagaDePagamentoDeBoleto saga)
        {
            var evento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDePagamentoDeBoletoConcluidoEvent)
                           as ProcessoDePagamentoDeBoletoConcluidoEvent;

            Assert.IsNotNull(evento);
            Assert.IsTrue(evento?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(evento?.IdDoBoleto == @event.IdDoBoleto);
            Assert.IsTrue(evento?.IdDoPagamentoDeBoleto == @event.IdDoPagamentoDeBoleto);
            Assert.IsTrue(evento?.EmpresaAplicacaoTransacaoId == @event.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(evento?.CorrelationMessage == @event);
            Assert.IsTrue(evento?.OriginalCorrelationMessage == @event.OriginalCorrelationMessage || (@event.OriginalCorrelationMessage == null && evento?.OriginalCorrelationMessage == @event));
        }

        private static IEnumerable<NovoPagamentoDeBoletoIniciadoEvent> GeradorDeEventosNovoPagamentoDeBoletoIniciadoEvent()
        {
            return Builder<NovoPagamentoDeBoletoIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent> GeradorDeEventosNovoPagamentoDeBoletoIniciadoEmContingenciaEvent()
        {
            return Builder<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent>.CreateListOfSize(10).Build();
        }        

        private static IEnumerable<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent> GeradorDeEventosNovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent()
        {
            return Builder<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent> GeradorDeEventosNovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent()
        {
            return Builder<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent>.CreateListOfSize(10).Build();
        }
        
        private static IEnumerable<NovoPagamentoDeBoletoSemRegistroIniciadoEvent> GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEvent()
        {
            return Builder<NovoPagamentoDeBoletoSemRegistroIniciadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent> GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent()
        {
            return Builder<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent> GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent()
        {
            return Builder<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent> GeradorDeEventosNovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent()
        {
            return Builder<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent> GeradorDeEventosConsultaDeSaldoParaBoletoRealizadaComSucessoEvent()
        {
            return Builder<ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosConsultaDeSaldoParaBoletoRealizadaComSucessoEventComStatus()
        {
            return (from @event in Builder<ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<ConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent> GeradorDeEventosConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent()
        {
            return Builder<ConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEventComStatus()
        {
            return (from @event in Builder<ConsultaDeSaldoAgendadaParaBoletoConcluidaComErroEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<SaldoDisponivelDaContaCorrenteValidadoEvent> GeradorDeEventosSaldoDisponivelDaContaCorrenteValidadoEvent()
        {
            return Builder<SaldoDisponivelDaContaCorrenteValidadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosSaldoDisponivelDaContaCorrenteValidadoEventComStatus()
        {
            return (from @event in Builder<SaldoDisponivelDaContaCorrenteValidadoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEvent()
        {
            return (from saga in Builder<SagaDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new PagamentoDeTituloParaBoletoRealizadoComSucessoEvent
                        {
                            CodigoDaAgencia = saga.CodigoDaAgencia,
                            CodigoDaColigada = saga.CodigoDaColigada,
                            DataDoPagamento = saga.DataDoPagamento.Date,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NumeroDaContaCorrente = saga.NumeroDaContaCorrente,
                            ValorDoPagamento = saga.ValorDoPagamento
                        }
                    });
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventV2()
        {
            return (from saga in Builder<SagaDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2
                        {
                            CodigoDaAgencia = saga.CodigoDaAgencia,
                            CodigoDaColigada = saga.CodigoDaColigada,
                            DataDoPagamento = saga.DataDoPagamento.Date,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NumeroDaContaCorrente = saga.NumeroDaContaCorrente,
                            ValorDoPagamento = saga.ValorDoPagamento
                        }
                    });
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloParaBoletoRealizadoComSucessoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRealizadoComSucessoEventV2ComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<PagamentoDeTituloParaBoletoRecusadoEvent> GeradorDeEventosPagamentoDeTituloRecusadoEvent()
        {
            return Builder<PagamentoDeTituloParaBoletoRecusadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<PagamentoDeTituloParaBoletoRecusadoEventV2> GeradorDeEventosPagamentoDeTituloRecusadoEventV2()
        {
            return Builder<PagamentoDeTituloParaBoletoRecusadoEventV2>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRecusadoEventComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloParaBoletoRecusadoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeTituloRecusadoEventV2ComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloParaBoletoRecusadoEventV2>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEvent> GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEvent()
        {
            return Builder<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2> GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventV2()
        {
            return Builder<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }        

        private static IEnumerable<object[]> GeradorDeEventosDebitoDeContaAgendadoParaBoletoConcluidoComErroEventV2ComStatus()
        {
            return (from @event in Builder<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEvent()
        {
            return (from saga in Builder<SagaDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento)
                    .With(x => x.FoiRealizadoEmContingencia = false)
                    .With(x => x.EBoletoSemRegistro = false)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new ComprovanteDePagamentoDeBoletoGeradoEvent
                        {
                            DataDeVencimento = saga.DataDeVencimento,
                            DataDoPagamento = saga.DataDoPagamento,
                            Descontos = saga.Descontos,
                            DocumentoDoBeneficiario = saga.DocumentoDoBeneficiario,
                            DocumentoDoPagador = saga.DocumentoDoPagador,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            DocumentoDoSacadorOuAvalista = saga.DocumentoDoSacadorOuAvalista,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            Encargos = saga.Encargos,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NomeFantasiaDoBeneficiario = saga.NomeFantasiaDoBeneficiario,
                            NomeFantasiaDoPagador = saga.NomeFantasiaDoPagador,
                            NomeFantasiaDoSacadorOuAvalista = saga.NomeFantasiaDoSacadorOuAvalista,
                            FoiRealizadoEmContingencia = saga.FoiRealizadoEmContingencia,
                            RazaoSocialDoBeneficiario = saga.RazaoSocialDoBeneficiario,
                            RazaoSocialDoPagador = saga.RazaoSocialDoPagador,
                            RazaoSocialDoSacadorOuAvalista = saga.RazaoSocialDoSacadorOuAvalista,
                            ValorDoPagamento = saga.ValorDoPagamento,
                            ValorNominal = saga.ValorNominal
                        }
                    });
        }

        private static IEnumerable<object[]> GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEventEmContingencia()
        {
            return (from saga in Builder<SagaDePagamentoDeBoleto>.CreateListOfSize(10)
                    .All()
                    .With(x => x.Status = SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento)
                    .With(x => x.FoiRealizadoEmContingencia = true)
                    .With(x => x.EBoletoSemRegistro = false)
                    .Build()
                    select new object[]
                    {
                        saga,
                        new ComprovanteDePagamentoDeBoletoGeradoEvent
                        {
                            DataDeVencimento = saga.DataDeVencimento,
                            DataDoPagamento = saga.DataDoPagamento,
                            Descontos = saga.Descontos,
                            DocumentoDoBeneficiario = saga.DocumentoDoBeneficiario,
                            DocumentoDoPagador = saga.DocumentoDoPagador,
                            DocumentoDoPagadorFinal = saga.DocumentoDoPagadorFinal,
                            DocumentoDoSacadorOuAvalista = saga.DocumentoDoSacadorOuAvalista,
                            EmpresaAplicacaoTransacaoId = saga.EmpresaAplicacaoTransacaoId,
                            Encargos = saga.Encargos,
                            IdDaConsultaDeBoleto = saga.IdDaConsultaDeBoleto,
                            IdDoBoleto = saga.IdDoBoleto,
                            IdDoPagamentoDeBoleto = saga.IdDoPagamentoDeBoleto,
                            NomeFantasiaDoBeneficiario = saga.NomeFantasiaDoBeneficiario,
                            NomeFantasiaDoPagador = saga.NomeFantasiaDoPagador,
                            NomeFantasiaDoSacadorOuAvalista = saga.NomeFantasiaDoSacadorOuAvalista,
                            FoiRealizadoEmContingencia = saga.FoiRealizadoEmContingencia,
                            RazaoSocialDoBeneficiario = saga.RazaoSocialDoBeneficiario,
                            RazaoSocialDoPagador = saga.RazaoSocialDoPagador,
                            RazaoSocialDoSacadorOuAvalista = saga.RazaoSocialDoSacadorOuAvalista,
                            ValorDoPagamento = saga.ValorDoPagamento,
                            ValorNominal = saga.ValorNominal
                        }
                    });
        }

        private static IEnumerable<object[]> GeradorDeEventosComprovanteDePagamentoDeBoletoGeradoEventComStatus()
        {
            return (from @event in Builder<ComprovanteDePagamentoDeBoletoGeradoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<BaixaOperacionalBoletoRealizadaComSucessoEvent> GeradorDeEventosBaixaOperacionalBoletoRealizadaComSucessoEvent()
        {
            return Builder<BaixaOperacionalBoletoRealizadaComSucessoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosBaixaOperacionalBoletoRealizadaComSucessoEventComStatus()
        {
            return (from @event in Builder<BaixaOperacionalBoletoRealizadaComSucessoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<BaixaOperacionalBoletoRecusadaEvent> GeradorDeEventosBaixaOperacionalBoletoRecusadaEvent()
        {
            return Builder<BaixaOperacionalBoletoRecusadaEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosBaixaOperacionalBoletoRecusadaEventComStatus()
        {
            return (from @event in Builder<BaixaOperacionalBoletoRecusadaEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<BaixaOperacionalBoletoEnviadaComErroEvent> GeradorDeEventosBaixaOperacionalBoletoEnviadaComErroEvent()
        {
            return Builder<BaixaOperacionalBoletoEnviadaComErroEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosBaixaOperacionalBoletoEnviadaComErroEventComStatus()
        {
            return (from @event in Builder<BaixaOperacionalBoletoEnviadaComErroEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<BaixaOperacionalBoletoRejeitadaEvent> GeradorDeEventosBaixaOperacionalBoletoRejeitadaEvent()
        {
            return Builder<BaixaOperacionalBoletoRejeitadaEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosBaixaOperacionalBoletoRejeitadaEventComStatus()
        {
            return (from @event in Builder<BaixaOperacionalBoletoRejeitadaEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<PagamentoDeBoletoEfetivadoEvent> GeradorDeEventosPagamentoDeBoletoEfetivadoEvent()
        {
            return Builder<PagamentoDeBoletoEfetivadoEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeBoletoEfetivadoEventComStatus()
        {
            return (from @event in Builder<PagamentoDeBoletoEfetivadoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,
                       SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                       SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                       SagaDePagamentoDeBoletoStatus.Concluido,
                       SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeBoletoRecusadoEventComStatusValido()
        {
            return (from @event in Builder<PagamentoDeBoletoRecusadoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                        SagaDePagamentoDeBoletoStatus.AguardandoValidacaoDeSaldoDeContaCorrente,
                        SagaDePagamentoDeBoletoStatus.AguardandoConclusaoDePagamento
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeEventosPagamentoDeBoletoRecusadoEventComStatusInvalido()
        {
            return (from @event in Builder<PagamentoDeBoletoRecusadoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                        SagaDePagamentoDeBoletoStatus.AguardandoBaixaOperacionalDePagamento,
                        SagaDePagamentoDeBoletoStatus.AguardandoConsultaDeSaldoDeContaCorrente,
                        SagaDePagamentoDeBoletoStatus.AguardandoPagamentoDeTitulo,                        
                        SagaDePagamentoDeBoletoStatus.AguardandoGeracaoDeComprovanteDePagamento,
                        SagaDePagamentoDeBoletoStatus.Concluido,
                        SagaDePagamentoDeBoletoStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }
    }
}
