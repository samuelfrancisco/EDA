﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.RetornoDeArquivosDeBoletosPagosEmContingencia.Events;
using FizzWare.NBuilder;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia
{
    [TestFixture]
    public class SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaTests
    {
        private long _empresaAplicacaoTransacaoId = 1;
        private Mock<ConfiguracoesDaEmpresaAplicacaoTransacao> _configuracoesDaEmpresaAplicacaoTransacaoMock;
        private Mock<ConfiguracoesDeBoletos> _configuracoesDeBoletosMock;
        private Mock<ConfiguracoesDoMotor> _configuracoesDoMotorMock;
        private Mock<IConfiguracoesDoMotorService> _configuracoesDoMotorServiceMock;

        private void IniciarConfiguracoesDoMotor()
        {
            _configuracoesDaEmpresaAplicacaoTransacaoMock = new Mock<ConfiguracoesDaEmpresaAplicacaoTransacao>();
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(_empresaAplicacaoTransacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));

            _configuracoesDeBoletosMock = new Mock<ConfiguracoesDeBoletos>();
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMaximoAceitoEmContingencia).Returns(5000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMinimoParaVRBoleto).Returns(250000);
            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(false);
            _configuracoesDeBoletosMock.SetupGet(x => x.AConsultaDePagamentosEmContingenciaDeveSerAutomatica).Returns(true);
            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeConsultaEmContingencia).Returns(@"C:\FileSytemWatcher");
            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeConsultaEmContingencia).Returns(@"C:\FileSytemWatcher");
            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(true);
            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia).Returns(@"C:\FileSytemWatcher");
            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia).Returns(@"C:\FileSytemWatcher");
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes)
                .Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao> { _configuracoesDaEmpresaAplicacaoTransacaoMock.Object });

            _configuracoesDoMotorMock = new Mock<ConfiguracoesDoMotor>();
            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns(_configuracoesDeBoletosMock.Object);

            _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            _configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor).Returns(_configuracoesDoMotorMock.Object);
        }

        [Test]
        public void ContingenciaDeBoletosDesligada_DeveIniciarConsultaDeBoletosPagosEmContingencia()
        {
            IniciarConfiguracoesDoMotor();

            var evento = new ContingenciaDeBoletosDesligadaEvent();

            var saga = new SagaDeConsultaEBaixaDeBoletosPagosEmContingencia(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(primeiroEvento);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is IniciarConsultaDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(((IniciarConsultaDeBoletosPagosEmContingenciaCommand)comando).IdDaConsultaDeBoletosPagosEmContingencia
                == ((ProcessoDeConsultaDeBoletosPagosEmContingenciaIniciadoEvent)segundoEvento).IdDaConsultaDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.DataDeInicio == primeiroEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [Test]
        public void ContingenciaDeBoletosDesligada_SemConsultaAutomatica_DeveIniciarBaixaOperacionalDeBoletosPagosEmContingencia()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.AConsultaDePagamentosEmContingenciaDeveSerAutomatica).Returns(false);

            var evento = new ContingenciaDeBoletosDesligadaEvent();

            var saga = new SagaDeConsultaEBaixaDeBoletosPagosEmContingencia(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(primeiroEvento);
            Assert.IsTrue(saga.DataDeInicio == primeiroEvento.Date);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                == ((ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)segundoEvento).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == ((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [Test]
        public void ContingenciaDeBoletosDesligada_SemLocalDeEnvioDaConsulta_DeveIniciarBaixaOperacionalDeBoletosPagosEmContingencia()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeConsultaEmContingencia).Returns(string.Empty);

            var evento = new ContingenciaDeBoletosDesligadaEvent();

            var saga = new SagaDeConsultaEBaixaDeBoletosPagosEmContingencia(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(primeiroEvento);
            Assert.IsTrue(saga.DataDeInicio == primeiroEvento.Date);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                == ((ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)segundoEvento).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == ((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [Test]
        public void ContingenciaDeBoletosDesligada_SemLocalDeRetornoDaConsulta_DeveIniciarBaixaOperacionalDeBoletosPagosEmContingencia()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeConsultaEmContingencia).Returns(string.Empty);

            var evento = new ContingenciaDeBoletosDesligadaEvent();

            var saga = new SagaDeConsultaEBaixaDeBoletosPagosEmContingencia(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(primeiroEvento);
            Assert.IsTrue(saga.DataDeInicio == primeiroEvento.Date);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                == ((ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)segundoEvento).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == ((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [Test]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_DeveIniciarBaixaOperacionalDeBoletosPagosEmContingencia()
        {
            IniciarConfiguracoesDoMotor();

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent);

            Assert.IsNotNull(primeiroEvento);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                == ((ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)segundoEvento).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == ((IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)comando).IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [Test]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_EmContingencia_DeveCancelarOProcesso()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent @event
                && @event?.CorrelationMessage == evento
                && @event?.MotivoDoCancelamento == "O motor entrou novamente em contingência"
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado);
            Assert.IsTrue(saga.DataDeCancelamento == segundoEvento.Date);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [Test]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_SemBaixaAutomatica_DeveConcluirOProcesso()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [Test]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_SemLocalDeEnvioDaBaixa_DeveConcluirOProcesso()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [Test]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_SemLocalDeRetornoDaBaixa_DeveConcluirOProcesso()
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaCanceladoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaCancelada_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaCancelada_EmUmStatusDiferenteDeConsultaIniciada_NaoDeveFazerNada(SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var evento = new ConsultaDeBoletosPagosEmContingenciaCanceladaEvent();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_TestCase")]
        public void ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_DeveEnviarComandoParaProcessarArquivo(
            ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarRetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarRetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.NomeCompletoDoArquivo == evento.NomeCompletoDoArquivo
                && command?.NomeDoArquivoOriginal == evento.NomeDoArquivoOriginal
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase")]
        public void ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_NaoDevefazerNada(
            ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_TestCase")]
        public void ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_DeveEnviarComandoParaProcessarArquivo(
            ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.NomeCompletoDoArquivo == evento.NomeCompletoDoArquivo
                && command?.NomeDoArquivoOriginal == evento.NomeDoArquivoOriginal
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase")]
        public void ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_NaoDevefazerNada(
            ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_DeveEnviarComandoParaRecusarPagamentosRecusadosEIniciarBaixaDePagamentosAceitos(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = (ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);
            Assert.IsNotNull(primeiroEvento);

            var primeiroComando = (RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            var segundoComando = (IniciarBaixaOperacionalDosPagamentosSelecionadosCommand)saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand);
            Assert.IsNotNull(segundoComando);
            Assert.IsTrue(segundoComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == primeiroEvento.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(segundoComando.Pagamentos.Count == evento.PagamentosAceitos.Count);
            Assert.IsTrue(segundoComando.Pagamentos.All(x => evento.PagamentosAceitos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == segundoComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmContingencia_DeveEnviarComandoParaRecusarPagamentosRecusados(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemBaixaAutomatica_DeveEnviarComandoParaRecusarPagamentosRecusados(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemLocalDeEnvioDaBaixa_DeveEnviarComandoParaRecusarPagamentosRecusados(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemLocalDeRetornoDaBaixa_DeveEnviarComandoParaRecusarPagamentosRecusados(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is RecusarPagamentosRecusadosNaConsultaDeBoletosPagosEmContingenciaCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_DeveEnviarComandoParaIniciarBaixaDePagamentosAceitos(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = (ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);
            Assert.IsNotNull(primeiroEvento);

            var primeiroComando = (IniciarBaixaOperacionalDosPagamentosSelecionadosCommand)saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == primeiroEvento.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.Pagamentos.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.Pagamentos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == primeiroComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_EmContingencia_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_SemBaixaAutomatica_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_SemLocalDeEnvioDaBaixa_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_SemLocalDeRetornoDaBaixa_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_TestCase")]
        public void RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_NaoDevefazerNada(
            RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_DeveEnviarComandoParaIniciarBaixaDePagamentosAceitos(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = (ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);
            Assert.IsNotNull(primeiroEvento);

            var primeiroComando = (IniciarBaixaOperacionalDosPagamentosSelecionadosCommand)saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDosPagamentosSelecionadosCommand);
            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == primeiroEvento.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.Pagamentos.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.Pagamentos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == primeiroComando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmContingencia_NaoDevefazerNada(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemBaixaAutomatica_NaoDevefazerNada(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemLocalDeEnvioDaBaixa_NaoDevefazerNada(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_SemLocalDeRetornoDaBaixa_NaoDevefazerNada(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase")]
        public void ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_NaoDevefazerNada(
            ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_SemBaixasIniciadas_DeveIniciarBaixa(ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(primeiroEvento);

            var segundoEvento = (ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent)saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaIniciadoEvent);

            Assert.IsNotNull(segundoEvento);

            var comando = (IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands.FirstOrDefault(x => x is IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(comando);
            Assert.IsTrue(comando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == segundoEvento.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 1);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);

            var baixa = saga.BaixasOperacionais.FirstOrDefault();

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == saga.Id);
            Assert.IsTrue(baixa.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == comando.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_ComBaixasIniciadas_DeveApenasConcluirAConsulta(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_EmContingenciaESemBaixasIniciadas_DeveCancelarOProcesso(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent @event
                && @event?.CorrelationMessage == evento
                && @event?.MotivoDoCancelamento == "O motor entrou novamente em contingência"
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaCanceladoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado);
            Assert.IsTrue(saga.DataDeCancelamento == segundoEvento.Date);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_SemBaixaAutomatica_DeveConcluirOProcesso(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ABaixaOperacionalEmContingenciaDeveSerAutomatica).Returns(false);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_SemLocalDeEnvioDaBaixa_DeveConcluirOProcesso(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_SemLocalDeRetornoDaBaixa_DeveConcluirOProcesso(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento)
        {
            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia).Returns(string.Empty);

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaDeBoletosPagosEmContingenciaConcluidoEvent @event
            && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
        }

        [TestCaseSource("ConsultaDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_TestCase")]
        public void ConsultaDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_NaoDevefazerNada(
            ConsultaDeBoletosPagosEmContingenciaConcluidaEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_ComTodasAsOutrasBaixasFinalizadas_DeveConcluirOProcesso(
            BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada) == 0);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Cancelada);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_ComAConsultaNaoConcluida_DeveApenasCancelarABaixa(
            BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsNull(saga.DataDeCancelamento);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Cancelada);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_ComAlgumaBaixaNaoConcluida_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_ComAlgumaBaixaNaoConcluida_DeveApenasCancelarABaixa(
            BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaCanceladoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsNull(saga.DataDeCancelamento);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Cancelada);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_EmUmStatusInvalido_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_EmUmStatusInvalido_NaoDevefazerNada(
            BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == baixas.ToList()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == baixas.ToList()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == sagaAntes.BaixasOperacionais.Count());
            Assert.IsTrue(saga.BaixasOperacionais.All(x =>
            {
                var indice = saga.BaixasOperacionais.IndexOf(x);

                var baixaAntes = sagaAntes.BaixasOperacionais[indice];

                return baixaAntes?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                && baixaAntes?.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == x.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia
                && baixaAntes?.Status == x.Status;
            }));
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_TestCase")]
        public void ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_DeveEnviarComandoParaProcessarArquivo(
            ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarRetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarRetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.NomeCompletoDoArquivo == evento.NomeCompletoDoArquivo
                && command?.NomeDoArquivoOriginal == evento.NomeDoArquivoOriginal
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase")]
        public void ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_NaoDevefazerNada(
            ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_TestCase")]
        public void ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_DeveEnviarComandoParaProcessarArquivo(
            ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.NomeCompletoDoArquivo == evento.NomeCompletoDoArquivo
                && command?.NomeDoArquivoOriginal == evento.NomeDoArquivoOriginal
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase")]
        public void ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_NaoDevefazerNada(
            ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_DeveEnviarComandoParaRecusarPagamentosRecusadosEEfetivarPagamentosAceitos(
            RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 2);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RecusarPagamentosRecusadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RecusarPagamentosRecusadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands
                .FirstOrDefault(x => x is RecusarPagamentosRecusadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.PagamentosRecusados.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.PagamentosRecusados.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            var segundoComando = (EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands
                .FirstOrDefault(x => x is EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(segundoComando);
            Assert.IsTrue(segundoComando.Pagamentos.Count == evento.PagamentosAceitos.Count);
            Assert.IsTrue(segundoComando.Pagamentos.All(x => evento.PagamentosAceitos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase")]
        public void RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_NaoDevefazerNada(
            RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_TestCase")]
        public void ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_DeveEnviarComandoParaRejeitarPagamentos(
            ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands
                .FirstOrDefault(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.Pagamentos.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.Pagamentos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase")]
        public void ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_NaoDevefazerNada(
                    ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent evento,
                    SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_TestCase")]
        public void RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_DeveEnviarComandoParaRejeitarPagamentos(
            RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>());

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 1);

            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand) == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand command
                && command?.IdDoProcessoDeConsultaEBaixa == saga.Id
                && command?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && command?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && command?.OriginalCorrelationMessage == evento))
                ) == 1);

            var primeiroComando = (RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand)saga.UnsendedCommands
                .FirstOrDefault(x => x is RejeitarPagamentosRejeitadosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand);

            Assert.IsNotNull(primeiroComando);
            Assert.IsTrue(primeiroComando.Pagamentos.Count == evento.Pagamentos.Count);
            Assert.IsTrue(primeiroComando.Pagamentos.All(x => evento.Pagamentos.Any(y => x.EmpresaAplicacaoTransacaoId == y.EmpresaAplicacaoTransacaoId
            && x.IdDaConsultaDeBoleto == y.IdDaConsultaDeBoleto
            && x.IdDoBoleto == y.IdDoBoleto && x.IdDoPagamentoDeBoleto == y.IdDoPagamentoDeBoleto)));

            Assert.IsTrue(saga.Status == status);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsNull(saga.DataDeConclusao);
        }

        [TestCaseSource("RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_TestCase")]
        public void RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_NaoDevefazerNada(
                    RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent evento,
                    SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == new List<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == 0);
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_ComTodasAsOutrasBaixasFinalizadas_DeveConcluirOProcesso(
            BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 2);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
                ) == 1);

            var segundoEvento = saga.UncommittedEvents.FirstOrDefault(x => x is ProcessoDeConsultaEBaixaDeBoletosPagosEmContingenciaConcluidoEvent);

            Assert.IsNotNull(segundoEvento);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido);
            Assert.IsTrue(saga.DataDeConclusao == segundoEvento.Date);
            Assert.IsNull(saga.DataDeCancelamento);
            Assert.IsTrue(saga.BaixasOperacionais.Count(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada) == 0);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Concluida);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_ComAConsultaNaoConcluida_DeveApenasConcluirABaixa(
            BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsNull(saga.DataDeCancelamento);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Concluida);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_ComAlgumaBaixaNaoConcluida_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_ComAlgumaBaixaNaoConcluida_DeveApenasConcluirABaixa(
            BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas)
        {
            IniciarConfiguracoesDoMotor();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
            && x.BaixasOperacionais == baixas.ToList());

            saga.BaixasOperacionais.Add(new SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional
            {
                IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia = saga.Id,
                IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = evento.SourceId,
                Status = SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada
            });

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 1);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);

            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent) == 1);
            Assert.IsTrue(saga.UncommittedEvents.Count(x => x is ProcessoDeBaixaOperacionalDeBoletosPagosEmContingenciaConcluidoEvent @event
                && @event?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId
                && @event?.CorrelationMessage == evento
                && ((evento.OriginalCorrelationMessage != null && @event?.OriginalCorrelationMessage == evento.OriginalCorrelationMessage)
                || (evento.OriginalCorrelationMessage == null && @event?.OriginalCorrelationMessage == evento))
            ) == 1);

            Assert.IsTrue(saga.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas);
            Assert.IsNull(saga.DataDeConclusao);
            Assert.IsNull(saga.DataDeCancelamento);

            var baixa = saga.BaixasOperacionais.FirstOrDefault(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == evento.SourceId);

            Assert.IsNotNull(baixa);
            Assert.IsTrue(baixa.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Concluida);
        }

        [TestCaseSource("BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_TestCase")]
        public void BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_NaoDevefazerNada(
            BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent evento,
            IEnumerable<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional> baixas,
            SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var id = Guid.NewGuid();

            var saga = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == baixas.ToList()
            && x.Id == id);

            var sagaAntes = Mock.Of<SagaDeConsultaEBaixaDeBoletosPagosEmContingencia>(x => x.Status == status
            && x.BaixasOperacionais == baixas.ToList()
            && x.Id == id);

            saga.Handle(evento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsTrue(saga.UncommittedEvents.Count() == 0);
            Assert.IsTrue(saga.UnsendedCommands.Count() == 0);
            Assert.IsTrue(saga.BaixasOperacionais.Count() == sagaAntes.BaixasOperacionais.Count());
            Assert.IsTrue(saga.BaixasOperacionais.All(x =>
            {
                var indice = saga.BaixasOperacionais.IndexOf(x);

                var baixaAntes = sagaAntes.BaixasOperacionais[indice];

                return baixaAntes?.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia == x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia
                && baixaAntes?.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia == x.IdDaSagaDeConsultaEBaixaDeBoletosPagosEmContingencia
                && baixaAntes?.Status == x.Status;
            }));
            Assert.IsTrue(saga.Active == sagaAntes.Active);
            Assert.IsTrue(saga.DataDeCancelamento == sagaAntes.DataDeCancelamento);
            Assert.IsTrue(saga.DataDeConclusao == sagaAntes.DataDeConclusao);
            Assert.IsTrue(saga.DataDeInicio == sagaAntes.DataDeInicio);
            Assert.IsTrue(saga.Id == sagaAntes.Id);
            Assert.IsTrue(saga.MotivoDoCancelamento == sagaAntes.MotivoDoCancelamento);
            Assert.IsTrue(saga.Status == sagaAntes.Status);
            Assert.IsTrue(saga.Version == sagaAntes.Version);
        }

        private static IEnumerable<object[]> ConsultaDeBoletosPagosEmContingenciaCancelada_TestCase()
        {
            return (from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_TestCase()
        {
            return (from @event in Builder<ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase()
        {
            return (from @event in Builder<ArquivoDeRetornoDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_TestCase()
        {
            return (from @event in Builder<ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase()
        {
            return (from @event in Builder<ArquivoDeErroDeConsultaDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase()
        {
            var random = new Random();

            var pagamentos = Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            var indices = Enumerable.Range(0, 11);

            return (from indice in indices
                    let pagamentosAceitos = pagamentos.Take(indice).ToList()
                    let pagamentosRecusados = pagamentos.Skip(indice).Take(10 - indice).ToList()
                    from @event in Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.PagamentosAceitos = pagamentosAceitos)
                            .With(x => x.PagamentosRecusados = pagamentosRecusados)
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase()
        {
            var random = new Random();

            var pagamentos = Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            var indices = Enumerable.Range(0, 11);

            return (from indice in indices
                    let pagamentosAceitos = pagamentos.Take(indice).ToList()
                    let pagamentosRecusados = pagamentos.Skip(indice).Take(10 - indice).ToList()
                    from @event in Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.PagamentosAceitos = pagamentosAceitos)
                            .With(x => x.PagamentosRecusados = pagamentosRecusados)
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_TestCase()
        {
            var pagamentos = Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_TestCase()
        {
            var pagamentos = Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_TestCase()
        {
            var pagamentos = Builder<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase()
        {
            var pagamentos = Builder<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent> ConsultaDeBoletosPagosEmContingenciaConcluida_TestCase()
        {
            return Builder<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent>.CreateListOfSize(10).Build();
        }

        private static IEnumerable<object[]> ConsultaDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_TestCase()
        {
            return (from @event in Builder<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_TestCase()
        {
            var random = new Random();

            var status = (SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus)random.Next(2, 3);

            var quantidade = random.Next(0, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                .With(x => x.Status = status)
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent>.CreateListOfSize(10).Build()
                    select new object[]
                    {
                        @event,
                        baixas.Where(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia != @event.SourceId)
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_ComAlgumaBaixaNaoConcluida_TestCase()
        {
            var random = new Random();

            var quantidade = random.Next(2, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                    .With(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = Guid.NewGuid())
                .TheFirst(1)
                    .With(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada)                
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent>.CreateListOfSize(10).Build()
                    select new object[]
                    {
                        @event,
                        baixas
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaCancelada_EmUmStatusInvalido_TestCase()
        {
            var random = new Random();

            var statusDasBaixas = (SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus)random.Next(2, 3);

            var quantidade = random.Next(0, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                .With(x => x.Status = statusDasBaixas)
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        baixas.Where(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia != @event.SourceId),
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_TestCase()
        {
            return (from @event in Builder<ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase()
        {
            return (from @event in Builder<ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_TestCase()
        {
            return (from @event in Builder<ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebido_EmUmStatusInvalido_TestCase()
        {
            return (from @event in Builder<ArquivoDeErroDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_TestCase()
        {
            var random = new Random();

            var pagamentos = Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            var indices = Enumerable.Range(0, 11);

            return (from indice in indices
                    let pagamentosAceitos = pagamentos.Take(indice).ToList()
                    let pagamentosRecusados = pagamentos.Skip(indice).Take(10 - indice).ToList()
                    from @event in Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.PagamentosAceitos = pagamentosAceitos)
                            .With(x => x.PagamentosRecusados = pagamentosRecusados)
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase()
        {
            var random = new Random();

            var pagamentos = Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            var indices = Enumerable.Range(0, 11);

            return (from indice in indices
                    let pagamentosAceitos = pagamentos.Take(indice).ToList()
                    let pagamentosRecusados = pagamentos.Skip(indice).Take(10 - indice).ToList()
                    from @event in Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.PagamentosAceitos = pagamentosAceitos)
                            .With(x => x.PagamentosRecusados = pagamentosRecusados)
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_TestCase()
        {
            var pagamentos = Builder<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessado_EmUmStatusInvalido_TestCase()
        {
            var pagamentos = Builder<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_TestCase()
        {
            var pagamentos = Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaEBaixasIniciadas,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.BaixasIniciadas
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErro_EmUmStatusInvalido_TestCase()
        {
            var pagamentos = Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEventPagamento>
                .CreateListOfSize(10)
                .Build();

            return (from @event in Builder<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent>.CreateListOfSize(10)
                        .All()
                            .With(x => x.Pagamentos = pagamentos.ToList())
                        .Build()
                    from status in new[]
                    {

                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaCancelada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        status
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_TestCase()
        {
            var random = new Random();

            var status = (SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus)random.Next(2, 3);

            var quantidade = random.Next(0, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                .With(x => x.Status = status)
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent>.CreateListOfSize(10).Build()
                    select new object[]
                    {
                        @event,
                        baixas.Where(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia != @event.SourceId)
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_ComAlgumaBaixaNaoConcluida_TestCase()
        {
            var random = new Random();

            var quantidade = random.Next(2, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                    .With(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia = Guid.NewGuid())
                .TheFirst(1)
                    .With(x => x.Status == SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus.Iniciada)
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent>.CreateListOfSize(10).Build()
                    select new object[]
                    {
                        @event,
                        baixas
                    }).ToList();
        }

        private static IEnumerable<object[]> BaixaOperacionalDeBoletosPagosEmContingenciaConcluida_EmUmStatusInvalido_TestCase()
        {
            var random = new Random();

            var statusDasBaixas = (SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacionalStatus)random.Next(2, 3);

            var quantidade = random.Next(0, 10);

            var baixas = Builder<SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaBaixaOperacional>
                .CreateListOfSize(10)
                .All()
                .With(x => x.Status = statusDasBaixas)
                .Build()
                .Take(quantidade);

            return (from @event in Builder<BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent>.CreateListOfSize(10).Build()
                    from status in new[]
                    {
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Cancelado,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Concluido,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaConcluida,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.ConsultaIniciada,
                       SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaStatus.Iniciado
                    }
                    select new object[]
                    {
                        @event,
                        baixas.Where(x => x.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia != @event.SourceId),
                        status
                    }).ToList();
        }
    }
}