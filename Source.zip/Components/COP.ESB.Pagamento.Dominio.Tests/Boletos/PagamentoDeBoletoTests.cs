﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Clientes;
using COP.ESB.Pagamento.Dominio.Clientes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Titulares;
using COP.ESB.Pagamento.Dominio.Titulares.Services.Interfaces;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{
    [TestFixture]
    public class PagamentoDeBoletoTests
    {
        private string _valorDoCodigoDeBarras;
        private string _codigoDoBanco;
        private Guid _idDaConsultaDeBoleto;
        private string _horarioInicial;
        private string _horarioFinal;
        private string _identificadorDoPagamentoNoCliente;
        private string _codigoDaColigada;
        private string _codigoDaAgencia;
        private string _codPraca;
        private string _numeroDaConta;
        private string _documentoDoPagadorFinal;
        private string _codigoDoCliente;
        private long _empresaAplicacaoId;
        private long _empresaAplicacaoTransacaoId;
        private decimal _valorDoPagamento;
        private IniciarNovoPagamentoDeBoletoCommandV3 _command;
        private Mock<CodigoDeBarras> _codigoDeBarras;
        private Mock<ConsultaDeBoleto> _consultaDeBoleto;
        private Mock<Banco> _banco;
        private Mock<Agencia> _agencia;
        private Mock<IBancoService> _bancoService;
        private Mock<IAgenciaService> _agenciaService;
        private Mock<Cliente> _cliente;
        private Mock<IClienteService> _clienteService;
        private Mock<Titular> _titular;
        private Mock<ITitularService> _titularService;
        private Mock<ICalendarioService> _calendarioService;
        private Mock<ConfiguracoesDaEmpresaAplicacaoTransacao> _configuracoesDaEmpresaAplicacaoTransacaoMock;
        private Mock<ConfiguracoesDeBoletos> _configuracoesDeBoletosMock;
        private Mock<ConfiguracoesDoMotor> _configuracoesDoMotorMock;
        private Mock<IConfiguracoesDoMotorService> _configuracoesDoMotorServiceMock;

        private void IniciarConfiguracoesDoMotor()
        {
            _configuracoesDaEmpresaAplicacaoTransacaoMock = new Mock<ConfiguracoesDaEmpresaAplicacaoTransacao>();
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoId).Returns(_empresaAplicacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(_empresaAplicacaoTransacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));

            _configuracoesDeBoletosMock = new Mock<ConfiguracoesDeBoletos>();
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicialDeBackOffice).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(2)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinalDeBackOffice).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(2)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMaximoAceitoEmContingencia).Returns(5000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorPermitidoSemRegistroNaCIP).Returns(1000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes)
                .Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao> { _configuracoesDaEmpresaAplicacaoTransacaoMock.Object });

            _configuracoesDoMotorMock = new Mock<ConfiguracoesDoMotor>();
            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns(_configuracoesDeBoletosMock.Object);

            _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            _configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor).Returns(_configuracoesDoMotorMock.Object);
        }

        private void IniciarNovoPagamento_InicializacaoPadrao()
        {
            _valorDoCodigoDeBarras = "34194728000144783220320116542280000000000000";
            _codigoDoBanco = "0341";
            _idDaConsultaDeBoleto = Guid.NewGuid();
            _horarioInicial = DateTime.Now.AddHours(-1).ToString("HH:mm");
            _horarioFinal = DateTime.Now.AddHours(1).ToString("HH:mm");
            _identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            _codigoDaColigada = "001";
            _codigoDaAgencia = "00019";
            _codPraca = "00018";
            _numeroDaConta = "0117200007";
            _documentoDoPagadorFinal = "14450647661";
            _codigoDoCliente = "ABCDEF";
            _empresaAplicacaoId = 4;
            _empresaAplicacaoTransacaoId = 1;
            _valorDoPagamento = 5000;

            _command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDaConsultaDeBoleto = _idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = _identificadorDoPagamentoNoCliente,
                ValorDoPagamento = _valorDoPagamento,
                CanalDoPagamento = 1,
                MeioDePagamento = 1
            };

            _codigoDeBarras = new Mock<CodigoDeBarras>();
            _codigoDeBarras.SetupGet(x => x.Valor).Returns(_valorDoCodigoDeBarras);
            _codigoDeBarras.Setup(x => x.ObterCodigoDoBanco()).Returns(_codigoDoBanco);
            _codigoDeBarras.Setup(x => x.ObterOValorDoBoleto()).Returns(5000);

            _consultaDeBoleto = new Mock<ConsultaDeBoleto>();
            _consultaDeBoleto.SetupGet(x => x.Id).Returns(_idDaConsultaDeBoleto);
            _consultaDeBoleto.SetupGet(x => x.IdDoBoleto).Returns(Guid.NewGuid());
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorCalculado).Returns(5000);
            _consultaDeBoleto.SetupGet(x => x.CodigoDaColigada).Returns(_codigoDaColigada);
            _consultaDeBoleto.SetupGet(x => x.CodigoDaAgencia).Returns(_codigoDaAgencia);
            _consultaDeBoleto.SetupGet(x => x.NumeroDaContaCorrente).Returns(_numeroDaConta);

            _banco = new Mock<Banco>();
            _banco.SetupGet(x => x.Active).Returns(true);

            _bancoService = new Mock<IBancoService>();
            _bancoService.Setup(x => x.ObterBancoPeloCodigoAsync(_codigoDoBanco)).ReturnsAsync(_banco.Object);

            _agencia = new Mock<Agencia>();
            _agencia.SetupGet(x => x.Active).Returns(true);
            _agencia.SetupGet(x => x.CodPraca).Returns(_codPraca);

            _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(_codigoDaColigada, _codigoDaAgencia)).ReturnsAsync(_agencia.Object);

            _cliente = new Mock<Cliente>();
            _cliente.SetupGet(x => x.Active).Returns(true);
            _cliente.SetupGet(x => x.Cgc_Cpf).Returns(_documentoDoPagadorFinal);
            _cliente.SetupGet(x => x.TipoPessoa).Returns("F");
            _cliente.SetupGet(x => x.CodCliente).Returns(_codigoDoCliente);

            _clienteService = new Mock<IClienteService>();
            _clienteService.Setup(x => x.ObterClientePeloCodigoAsync(_codigoDoCliente)).ReturnsAsync(_cliente.Object);

            _titular = new Mock<Titular>();
            _titular.SetupGet(x => x.Active).Returns(true);
            _titular.SetupGet(x => x.CodigoDaColigada).Returns(_codigoDaColigada);
            _titular.SetupGet(x => x.CodigoDaAgencia).Returns(_codigoDaAgencia);
            _titular.SetupGet(x => x.NumeroDaContaCorrente).Returns(_numeroDaConta);
            _titular.SetupGet(x => x.CodigoDoCliente).Returns(_codigoDoCliente);
            _titular.SetupGet(x => x.Cgc_Cpf).Returns(_documentoDoPagadorFinal);

            _titularService = new Mock<ITitularService>();
            _titularService.Setup(x => x.ObterPrimeiroTitularDaConta(_codigoDaColigada, _codigoDaAgencia, _numeroDaConta)).ReturnsAsync(_titular.Object);

            _calendarioService = new Mock<ICalendarioService>();
            _calendarioService.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), _codPraca)).Returns(DateTime.Today);
        }

        private void IniciarNovoPagamento_ValidacaoDeSucesso(Result<PagamentoDeBoleto> result)
        {
            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value?.CanalDoPagamento == _command.CanalDoPagamento);
            Assert.IsTrue(result?.Value?.DocumentoDoPagadorFinal == _cliente.Object.Cgc_Cpf);
            Assert.IsTrue(result?.Value?.EmpresaAplicacaoTransacaoId == _empresaAplicacaoTransacaoId);
            Assert.IsTrue(result?.Value?.FoiRealizadoEmContingencia == _configuracoesDeBoletosMock.Object.EstaEmContingencia);
            Assert.IsTrue(result?.Value?.IdDaConsultaDeBoleto == _command.IdDaConsultaDeBoleto);
            Assert.IsTrue(result?.Value?.IdDoBoleto == _consultaDeBoleto.Object.IdDoBoleto);
            Assert.IsTrue(result?.Value?.IdentificadorDoPagamentoNoCliente == _command.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(result?.Value?.MeioDePagamento == _command.MeioDePagamento);
            Assert.IsTrue(result?.Value?.TipoDePessoaDoPagadorFinal == _cliente.Object.TipoPessoa);
            Assert.IsTrue(result?.Value?.ValorDoPagamento == _command.ValorDoPagamento);
            Assert.IsTrue(result?.Value?.TipoDeBaixaOperacional == ObterTipoDeBaixaOperacional());
        }

        private int ObterTipoDeBaixaOperacional()
        {
            if (_banco.Object.CodBanco != "0633" && _consultaDeBoleto.Object.IndicadorPagamentoParcial != "S")
                return 0;

            if (_banco.Object.CodBanco == "0633" && _consultaDeBoleto.Object.IndicadorPagamentoParcial == "S")
                return 2;

            if (_banco.Object.CodBanco != "0633" && _consultaDeBoleto.Object.IndicadorPagamentoParcial == "S")
                return 3;

            return 1;
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidos_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComCommandoComTodosOsValoresNulos_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command = new IniciarNovoPagamentoDeBoletoCommandV3();

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Valor do pagamento inválido."));
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Canal do Pagamento deve estar entre 1 e 8."));
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Meio de Pagamento deve estar entre 1 e 4."));
        }

        [Test]
        public void IniciarNovoPagamento_ComEmpresaAplicacaoTransacaoInvalida_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.EmpresaAplicacaoId = 0;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
        }

        [Test]
        public void IniciarNovoPagamento_AntesDoHorarioInicialDaTransacao_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var horarioInicial = DateTime.Now.AddHours(1).TimeOfDay;
            var horarioFinal = DateTime.Now.AddHours(2).TimeOfDay;

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(horarioInicial);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(horarioFinal);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(horarioInicial);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(horarioFinal);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
        }

        [Test]
        public void IniciarNovoPagamento_AntesDoHorarioInicial_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var horarioInicial = DateTime.Now.AddHours(1).TimeOfDay;
            var horarioFinal = DateTime.Now.AddHours(2).TimeOfDay;
            var horarioInicialDaTransacao = DateTime.Now.AddHours(-1).TimeOfDay;

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(horarioInicialDaTransacao);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(horarioFinal);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(horarioInicial);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(horarioFinal);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação {0}", _command.EmpresaAplicacaoId)));
        }

        [Test]
        public void IniciarNovoPagamento_DepoisDoHorarioFinalDaTransacao_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var horarioInicial = DateTime.Now.AddHours(-2).TimeOfDay;
            var horarioFinal = DateTime.Now.AddHours(-1).TimeOfDay;

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(horarioInicial);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(horarioFinal);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(horarioInicial);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(horarioFinal);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
        }

        [Test]
        public void IniciarNovoPagamento_DepoisDoHorarioFinal_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var horarioInicial = DateTime.Now.AddHours(-2).TimeOfDay;
            var horarioFinal = DateTime.Now.AddHours(-1).TimeOfDay;
            var horarioFinalDaTransacao = DateTime.Now.AddHours(1).TimeOfDay;

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(horarioInicial);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(horarioFinalDaTransacao);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(horarioInicial);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(horarioFinal);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação {0}", _command.EmpresaAplicacaoId)));
        }

        [Test]
        public void IniciarNovoPagamento_ComValorDoPagamentoZerado_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = 0;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_EmContingenciaComValorDoPagamentoMaiorQueOValorMaximoAceitoEmContingencia_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMaximoAceitoEmContingencia).Returns(_command.ValorDoPagamento - 1);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento superior ao limite para contingência."));
        }

        [Test]
        public void IniciarNovoPagamento_EmContingenciaComValorDoPagamentoIgualAoValorMaximoAceitoEmContingencia_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            _command.ValorDoPagamento = _configuracoesDeBoletosMock.Object.ValorMaximoAceitoEmContingencia;

            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorCalculado).Returns(_command.ValorDoPagamento);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_EmContingenciaComValorDoPagamentoMenorQueOValorMaximoAceitoEmContingencia_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            _command.ValorDoPagamento = _configuracoesDeBoletosMock.Object.ValorMaximoAceitoEmContingencia - 1;

            _codigoDeBarras.Setup(s => s.ObterOValorDoBoleto()).Returns(_command.ValorDoPagamento);

            _consultaDeBoleto.SetupGet(s => s.Calculo).Returns((CalculoDeBoleto)null);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComValorDoPagamentoDivergenteDoValorDoBoleto_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = _consultaDeBoleto.Object.Calculo.ValorCalculado - 1;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento diferente do permitido."));
        }

        [Test]
        public void IniciarNovoPagamento_PermitindoAlterarOValorETipoDeValidacaoIgualAUm_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = _consultaDeBoleto.Object.Calculo.ValorCalculado - 1;

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.TipoAutorizacaoRebVlrDivergente).Returns(1);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComValorDoPagamentoMenorQueOMinimo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = 2000;

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMinimoCalculado).Returns(3000);
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMaximoCalculado).Returns(5000);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento inferior ao mínimo."));
        }

        [Test]
        public void IniciarNovoPagamento_ComValorDoPagamentoMaiorQueOMaximo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = 6000;

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMinimoCalculado).Returns(3000);
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMaximoCalculado).Returns(5000);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento superior ao máximo."));
        }

        [Test]
        public void IniciarNovoPagamento_SemValorMinimo_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = 2000;

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMinimoCalculado).Returns(0);
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMaximoCalculado).Returns(5000);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_SemValorMaximo_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.ValorDoPagamento = 4000;

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMinimoCalculado).Returns(3000);
            _consultaDeBoleto.SetupGet(x => x.Calculo.ValorMaximoCalculado).Returns(0);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComCanalDoPagamentoMenorQueUm_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.CanalDoPagamento = 0;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Canal do Pagamento deve estar entre 1 e 8."));
        }

        [Test]
        public void IniciarNovoPagamento_ComCanalDoPagamentoMaiorQueOito_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.CanalDoPagamento = 9;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Canal do Pagamento deve estar entre 1 e 8."));
        }

        [Test]
        public void IniciarNovoPagamento_ComMeioDePagamentoMenorQueUm_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.MeioDePagamento = 0;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Meio de Pagamento deve estar entre 1 e 4."));
        }

        [Test]
        public void IniciarNovoPagamento_ComMeioDePagamentoMaiorQueQuatro_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _command.MeioDePagamento = 5;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Meio de Pagamento deve estar entre 1 e 4."));
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoNulo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _bancoService.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).ReturnsAsync((Banco)null);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Banco inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoInativo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _banco.SetupGet(x => x.Active).Returns(false);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Banco inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComClienteNulo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _clienteService.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>())).ReturnsAsync((Cliente)null);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Cliente inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComClienteInativo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _cliente.SetupGet(x => x.Active).Returns(false);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Cliente inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComTitularNulo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _titularService.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync((Titular)null);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Titular inválido."));
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Cliente inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComTitularInativo_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _titular.SetupGet(x => x.Active).Returns(false);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Titular inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoRendimentoEPagamentoIntegral_DeveRetornarTipoDeBaixaOperacinalZero()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _banco.SetupGet(x => x.CodBanco).Returns("0633");

            _consultaDeBoleto.SetupGet(x => x.IndicadorPagamentoParcial).Returns("N");

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoNaoRendimentoEPagamentoIntegral_DeveRetornarTipoDeBaixaOperacinalUm()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _banco.SetupGet(x => x.CodBanco).Returns("0001");

            _consultaDeBoleto.SetupGet(x => x.IndicadorPagamentoParcial).Returns("N");

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoRendimentoEPagamentoParcial_DeveRetornarTipoDeBaixaOperacinalDois()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _banco.SetupGet(x => x.CodBanco).Returns("0633");

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.IndicadorPagamentoParcial).Returns("S");

            _command.ValorDoPagamento = _consultaDeBoleto.Object.Calculo.ValorCalculado - 1;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComBancoNaoRendimentoEPagamentoParcial_DeveRetornarTipoDeBaixaOperacinalTres()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _banco.SetupGet(x => x.CodBanco).Returns("0001");

            _consultaDeBoleto.SetupGet(x => x.Calculo.PermiteAlterarValorTotal).Returns("S");
            _consultaDeBoleto.SetupGet(x => x.IndicadorPagamentoParcial).Returns("S");

            _command.ValorDoPagamento = _consultaDeBoleto.Object.Calculo.ValorCalculado - 1;

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_SemTransacaoBoletosConfigurada_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns((ConfiguracoesDeBoletos)null);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Não existe uma trasação Boletos configurada no sistema."));
        }

        [Test]
        public void IniciarNovoPagamento_SemTransacaoBoletosConfiguradaParaAEmpresaAplicacao_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes).Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao>());

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {_empresaAplicacaoId}."));
        }

        [Test]
        public void IniciarNovoPagamento_ComConsultaDeBoletoSemRegistro_DeveRetornarQueEBoletoSemRegistro()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            _consultaDeBoleto.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            IniciarConfiguracoesDoMotor();

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);

            Assert.IsTrue(result.Value?.EBoletoSemRegistro);
        }

        [Test]
        public void IniciarNovoPagamento_ComValorMenorQueOLimitePermitido_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var valorLimite = _valorDoPagamento + 1;

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValorLimiteParaPagamento).Returns(valorLimite);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComValorIgualAoLimitePermitido_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var valorLimite = _valorDoPagamento;

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValorLimiteParaPagamento).Returns(valorLimite);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ComValorMaiorQueOLimitePermitido_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            var valorLimite = _valorDoPagamento - 1;

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValorLimiteParaPagamento).Returns(valorLimite);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors
                ?.Any(x => x.Message == $"Valor do pagamento {_valorDoPagamento.ToString("N2")} superior ao limite permitido {valorLimite.ToString("N2")}."));
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComSaldoMaiorQueOValorDoPagamento_DeveRetornarResultSemErros()
        {
            var valorDoPagamento = 5000;
            var saldoDisponivel = valorDoPagamento + 1;

            var pagamentoDeBoleto = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoleto.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);

            var result = pagamentoDeBoleto.Object.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComSaldoIgualAoValorDoPagamento_DeveRetornarResultSemErros()
        {
            var valorDoPagamento = 5000;
            var saldoDisponivel = valorDoPagamento;

            var pagamentoDeBoleto = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoleto.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);

            var result = pagamentoDeBoleto.Object.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComSaldoMenorQueOValorDoPagamento_DeveRetornarResultComErros()
        {
            var valorDoPagamento = 5000;
            var saldoDisponivel = valorDoPagamento - 1;

            var pagamentoDeBoleto = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoleto.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);

            var result = pagamentoDeBoleto.Object.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.All(x => x.Message == "Valor do pagamento superior ao saldo disponível na conta corrente."));
        }

        [Test]
        public void Recusar_DeveAtualizarOsValores()
        {
            var motivoDaRecusa = "Teste de recusa.";

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>();

            pagamentoDeBoleto.Recusar(motivoDaRecusa);

            Assert.IsTrue(pagamentoDeBoleto.MotivoDaRecusa == motivoDaRecusa);
            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.Recusado);
        }

        [Test]
        public void MarcarComoPendenteDeBaixaOperacional_DeveAtualizarOsValores()
        {
            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>();

            pagamentoDeBoleto.MarcarComoPendenteDeBaixaOperacional();

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional);
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_ComTodosOsDadosValidos_DeveRetornarResultSemErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void ValidarCancelamento_ComStatusDiferenteDeEfetivadoEBaixaRecusada_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id do pagamento indisponível."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EVRBoleto_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == true
            && x.Id == idDoPagamentoDeBoleto);

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Pagamento realizado como VR Boleto não pode ser cancelado pelo motor."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_ComADataDePagamentoMenorQueADataDeProcessamento_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date.AddDays(1);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Cancelamento são realizados somente no dia do pagamento."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_SemTransacaoBoletosConfigurada_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns((ConfiguracoesDeBoletos)null);

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Não existe uma trasação Boletos configurada no sistema."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_SemTransacaoBoletosConfiguradaParaAEmpresaAplicacao_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes).Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao>());

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {_empresaAplicacaoId}."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMenorQueOHorarioInicialDoBackOffice_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicialDeBackOffice).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Horário para BackOffice encerrado."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMenorQueOHorarioInicialDaTransacao_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Cancelamento de pagamento não liberado para a transação Boletos."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMenorQueOHorarioInicial_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Cancelamento de pagamento não liberado para a Empresa x Aplicação {0}", _empresaAplicacaoId)));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMaiorQueOHorarioFinalDoBackOffice_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinalDeBackOffice).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Horário para BackOffice encerrado."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMaiorQueOHorarioFinalDaTransacao_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Cancelamento de pagamento não liberado para a transação Boletos."));
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        public void ValidarCancelamento_EmHorarioMaiorQueOHorarioFinal_DeveRetornarResultComErros(PagamentoDeBoletoStatus status)
        {
            IniciarConfiguracoesDoMotor();

            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDoPagamento = DateTime.Now;
            var dataDeProcessamento = dataDoPagamento.Date;

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.Status == status && x.DataDoPagamento == dataDoPagamento && x.EVRBoleto == false
            && x.Id == idDoPagamentoDeBoleto);

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromHours(1)));

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto
            };

            var result = pagamentoDeBoleto.ValidarCancelamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Cancelamento de pagamento não liberado para a Empresa x Aplicação {0}", _empresaAplicacaoId)));
        }


        [Test]
        public void IniciarNovoPagamento_ForaDaFaixaComDescontoEAbatimentoECodigoDeBarrasComValor_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _consultaDeBoleto.Setup(s => s.EBoletoSemRegistro).Returns(true);
            _consultaDeBoleto.Setup(s => s.Calculo).Returns((CalculoDeBoleto)null);

            _command.ValorDoPagamento = 850;
            _command.ValorDoAbatimento = 100;
            _command.ValorDoDesconto = 50;

            _codigoDeBarras.Setup(s => s.ObterOValorDoBoleto()).Returns(1000);            

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }

        [Test]
        public void IniciarNovoPagamento_ForaDaFaixaComDescontoEAbatimentoInvalidos_DeveRetornarResultComErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _consultaDeBoleto.Setup(s => s.EBoletoSemRegistro).Returns(true);
            _consultaDeBoleto.Setup(s => s.Calculo).Returns((CalculoDeBoleto)null);

            _command.ValorDoPagamento = 900;
            _command.ValorDoAbatimento = -2;
            _command.ValorDoDesconto = -1;

            _codigoDeBarras.Setup(s => s.ObterOValorDoBoleto()).Returns(1000);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Valor do Abatimento menor que zero.")));
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Valor do Desconto menor que zero.")));
        }

        [Test]
        public void IniciarNovoPagamento_ForaDaFaixaComDescontoEAbatimentoECodigoDeBarrasSemValor_DeveRetornarResultSemErros()
        {
            IniciarNovoPagamento_InicializacaoPadrao();

            IniciarConfiguracoesDoMotor();

            _consultaDeBoleto.Setup(s => s.EBoletoSemRegistro).Returns(true);
            _consultaDeBoleto.Setup(s => s.Calculo).Returns((CalculoDeBoleto)null);

            _command.ValorDoPagamento = 850;
            _command.ValorDoAbatimento = 100;
            _command.ValorDoDesconto = 50;

            _codigoDeBarras.Setup(s => s.ObterOValorDoBoleto()).Returns(0);

            var result = PagamentoDeBoleto.IniciarNovoPagamento(_command, _codigoDeBarras.Object, _consultaDeBoleto.Object, _bancoService.Object,
               _agenciaService.Object, _titularService.Object, _clienteService.Object, _calendarioService.Object, _configuracoesDoMotorServiceMock.Object);

            IniciarNovoPagamento_ValidacaoDeSucesso(result);
        }
    }
}
