﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Boletos.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{
    [TestFixture]
    public class BoletoTests
    {
        #region Settings

        private long _empresaAplicacaoId = 4;
        private long _empresaAplicacaoTransacaoId = 1;
        private string _codigoDaColigada = "001";
        private string _codigoDaAgencia = "00020";
        private string _codigoDaPraca = "00011";
        private XmlDocument _xmlDocument = new XmlDocument
        {
            InnerXml = @"<DDA0110R1>
<CodMsg>DDA0110R1</CodMsg>
<NumCtrlPart>DDA20171220000049305</NumCtrlPart>
<ISPBPartRecbdrPrincipal>68900810</ISPBPartRecbdrPrincipal>
<ISPBPartRecbdrAdmtd>68900810</ISPBPartRecbdrAdmtd>
<NumCtrlDDA>20171220000080647540</NumCtrlDDA>
<NumIdentcTit>2017061700001844240</NumIdentcTit>
<NumRefAtlCadTit>1511078767417001119</NumRefAtlCadTit>
<NumSeqAtlzCadTit>2</NumSeqAtlzCadTit>
<DtHrSitTit>2017-11-19T06:06:07</DtHrSitTit>
<ISPBPartDestinatario>60701190</ISPBPartDestinatario>
<CodPartDestinatario>341</CodPartDestinatario>
<TpPessoaBenfcrioOr>J</TpPessoaBenfcrioOr>
<CNPJ_CPFBenfcrioOr>60701190000104</CNPJ_CPFBenfcrioOr>
<Nom_RzSocBenfcrioOr>BANCO ITAU S.A.</Nom_RzSocBenfcrioOr>
<NomFantsBenfcrioOr>BANCO ITAU S.A.</NomFantsBenfcrioOr>
<LogradBenfcrioOr>PCA ALFREDO E S ARANHA, 100 BL B 5A</LogradBenfcrioOr>
<CidBenfcrioOr>SAO PAULO</CidBenfcrioOr>
<UFBenfcrioOr>SP</UFBenfcrioOr>
<CEPBenfcrioOr>4344902</CEPBenfcrioOr>
<TpPessoaBenfcrioFinl>J</TpPessoaBenfcrioFinl>
<CNPJ_CPFBenfcrioFinl>60701190000104</CNPJ_CPFBenfcrioFinl>
<Nom_RzSocBenfcrioFinl>BANCO ITAU S.A.</Nom_RzSocBenfcrioFinl>
<NomFantsBenfcrioFinl>BANCO ITAU S.A.</NomFantsBenfcrioFinl>
<TpPessoaPagdr>J</TpPessoaPagdr>
<CNPJ_CPFPagdr>61739003986</CNPJ_CPFPagdr>
<Nom_RzSocPagdr>IND. LUIZ FIGUEIRA</Nom_RzSocPagdr>
<NomFantsPagdr>IND. LUIZ FIGUEIRA</NomFantsPagdr>
<CodMoedaCNAB>09</CodMoedaCNAB>
<NumCodBarras>34194728000144783220320116542280000000000000</NumCodBarras>
<NumLinhaDigtvl>34190320101654228000900000000000472800014478322</NumLinhaDigtvl>
<DtVencTit>2017-09-12</DtVencTit>
<VlrTit>144783.22</VlrTit>
<CodEspTit>99</CodEspTit>
<DtLimPgtoTit>2017-11-11</DtLimPgtoTit>
<IndrBloqPgto>N</IndrBloqPgto>
<IndrPgtoParcl>N</IndrPgtoParcl>
<VlrAbattTit>0.00</VlrAbattTit>
<Grupo_DDA0110R1_JurosTit>
<DtJurosTit>2017-09-13</DtJurosTit>
<CodJurosTit>3</CodJurosTit>
<Vlr_PercJurosTit>2.63000</Vlr_PercJurosTit>
</Grupo_DDA0110R1_JurosTit>
<Grupo_DDA0110R1_MultaTit>
<DtMultaTit>2017-09-13</DtMultaTit>
<CodMultaTit>1</CodMultaTit>
<Vlr_PercMultaTit>2.00</Vlr_PercMultaTit>
</Grupo_DDA0110R1_MultaTit>
<Grupo_DDA0110R1_DesctTit>
<CodDesctTit>0</CodDesctTit>
<Vlr_PercDesctTit>0.00</Vlr_PercDesctTit>
</Grupo_DDA0110R1_DesctTit>
<TpModlCalc>03</TpModlCalc>
<TpAutcRecbtVlrDivgte>3</TpAutcRecbtVlrDivgte>
<Grupo_DDA0110R1_Calc>
<VlrCalcdJuros>0.00</VlrCalcdJuros>
<VlrCalcdMulta>0.00</VlrCalcdMulta>
<VlrCalcdDesct>0.00</VlrCalcdDesct>
<VlrTotCobrar>138300.19</VlrTotCobrar>
<DtValiddCalc>2017-06-19</DtValiddCalc>
</Grupo_DDA0110R1_Calc>
<Grupo_DDA0110R1_BaixaEft>
<NumIdentcBaixaEft>2017111900002588596</NumIdentcBaixaEft>
<NumRefAtlBaixaEft>1511078768664001119</NumRefAtlBaixaEft>
<NumSeqAtlzBaixaEft>1</NumSeqAtlzBaixaEft>
<DtProcBaixaEft>2017-11-19</DtProcBaixaEft>
<DtHrProcBaixaEft>2017-11-19T06:06:08</DtHrProcBaixaEft>
<NumCodBarrasBaixaEft>34194728000144783220320116542280000000000000</NumCodBarrasBaixaEft>
<DtHrSitBaixaEft>2017-11-19T06:06:09</DtHrSitBaixaEft>
</Grupo_DDA0110R1_BaixaEft>
<SitTitPgto>12</SitTitPgto>
<DtHrDDA>2017-12-20T16:10:51</DtHrDDA>
<DtMovto>2017-12-20</DtMovto>
</DDA0110R1>"
        };

        private Mock<ConfiguracoesDaEmpresaAplicacaoTransacao> _configuracoesDaEmpresaAplicacaoTransacaoMock;
        private Mock<ConfiguracoesDeBoletos> _configuracoesDeBoletosMock;
        private Mock<ConfiguracoesDoMotor> _configuracoesDoMotorMock;
        private Mock<IConfiguracoesDoMotorService> _configuracoesDoMotorServiceMock;

        private void IniciarConfiguracoesDoMotor()
        {
            _configuracoesDaEmpresaAplicacaoTransacaoMock = new Mock<ConfiguracoesDaEmpresaAplicacaoTransacao>();
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoId).Returns(_empresaAplicacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(_empresaAplicacaoTransacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));

            _configuracoesDeBoletosMock = new Mock<ConfiguracoesDeBoletos>();
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMaximoAceitoEmContingencia).Returns(5000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMinimoParaVRBoleto).Returns(250000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes)
                .Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao> { _configuracoesDaEmpresaAplicacaoTransacaoMock.Object });

            _configuracoesDoMotorMock = new Mock<ConfiguracoesDoMotor>();
            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns(_configuracoesDeBoletosMock.Object);

            _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            _configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor).Returns(_configuracoesDoMotorMock.Object);
        }

        #endregion

        [Test]
        [TestCase("75697728100004701351426401000681500325449033", "75691426440100068150003254490331772810000470135")]
        [TestCase("08994972810000050000000601050164700002476000", "08990000620105016470400024760001472810000050000")]
        [TestCase("08997728300000220001000301020121000003983000", "08991000360102012100800039830005772830000022000")]
        [TestCase("08991728300000260001001001090143400000008000", "08991001010109014340300000080002172830000026000")]
        [TestCase("08994728300000260001001001090143400000288000", "08991001010109014340300002880003472830000026000")]
        [TestCase("08991728300000280001001001090120000000408000", "08991001010109012000500004080008172830000028000")]
        [TestCase("08991728300000180001000301020121000005055000", "08991000360102012100800050550003172830000018000")]
        [TestCase("08994728300000025001000101000342600000161000", "08991000100100034260800001610005472830000002500")]
        [TestCase("08997728300000180001000601050168400001057000", "08991000690105016840800010570000772830000018000")]
        [TestCase("08992728300000210001000301020121000005250000", "08991000360102012100800052500006272830000021000")]
        public void RegistrarNovoBoleto_ComCodigoDeBarrasValido_DeveRetornarResultSemErros(string codigoDeBarras, string linhaDigitavel)
        {
            var codigoDoBanco = "0" + codigoDeBarras.Substring(0, 3);

            var codigoDeBarrasMock = Mock.Of<CodigoDeBarras>(x => x.Valor == codigoDeBarras);

            var linhaDigitavelMock = Mock.Of<LinhaDigitavel>(x => x.Valor == linhaDigitavel);

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(codigoDoBanco)).ReturnsAsync(new Banco { CodBanco = codigoDoBanco, Active = true });

            var codigoDeBarrasFactoryMock = new Mock<ICodigoDeBarrasFactory>();
            codigoDeBarrasFactoryMock.Setup(x => x.Criar(It.IsAny<string>(), It.IsAny<IBancoService>()))
                .Returns(() => new Result<CodigoDeBarras>(codigoDeBarrasMock));

            var linhaDigitavelFactoryMock = new Mock<ILinhaDigitavelFactory>();
            linhaDigitavelFactoryMock.Setup(x => x.Criar(It.IsAny<CodigoDeBarras>()))
                .Returns(() => new Result<LinhaDigitavel>(linhaDigitavelMock));

            var command = new RegistrarNovoBoletoCommand { CodigoDeBarras = codigoDeBarras };

            var result = Boleto.RegistrarNovoBoleto(command, bancoServiceMock.Object, codigoDeBarrasFactoryMock.Object, linhaDigitavelFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is Boleto);
            Assert.IsNotNull(result?.Value?.CodigoDeBarras);
            Assert.IsTrue(result?.Value?.CodigoDeBarras?.Valor == codigoDeBarras);
            Assert.IsNotNull(result?.Value?.LinhaDigitavel);
            Assert.IsTrue(result?.Value?.LinhaDigitavel?.Valor == linhaDigitavel);
            Assert.IsTrue(result?.Value?.UncommittedEvents?.Any(x =>
            {
                var ev = x as NovoBoletoRegistradoEvent;

                return ev != null && ev?.CodigoDeBarras == codigoDeBarras && ev?.LinhaDigitavel == linhaDigitavel;
            }));
        }

        [Test]
        [TestCase("75697728100004701351426401000681500325449033", "75691426440100068150003254490331772810000470135")]
        [TestCase("08994972810000050000000601050164700002476000", "08990000620105016470400024760001472810000050000")]
        [TestCase("08997728300000220001000301020121000003983000", "08991000360102012100800039830005772830000022000")]
        [TestCase("08991728300000260001001001090143400000008000", "08991001010109014340300000080002172830000026000")]
        [TestCase("08994728300000260001001001090143400000288000", "08991001010109014340300002880003472830000026000")]
        [TestCase("08991728300000280001001001090120000000408000", "08991001010109012000500004080008172830000028000")]
        [TestCase("08991728300000180001000301020121000005055000", "08991000360102012100800050550003172830000018000")]
        [TestCase("08994728300000025001000101000342600000161000", "08991000100100034260800001610005472830000002500")]
        [TestCase("08997728300000180001000601050168400001057000", "08991000690105016840800010570000772830000018000")]
        [TestCase("08992728300000210001000301020121000005250000", "08991000360102012100800052500006272830000021000")]
        public void RegistrarNovoBoleto_ComLinhaDigitavelValida_DeveRetornarResultSemErros(string codigoDeBarras, string linhaDigitavel)
        {
            var codigoDoBanco = "0" + codigoDeBarras.Substring(0, 3);

            var codigoDeBarrasMock = Mock.Of<CodigoDeBarras>(x => x.Valor == codigoDeBarras);

            var codigoDeBarrasFactoryMock = Mock.Of<ICodigoDeBarrasFactory>();

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(codigoDoBanco)).ReturnsAsync(new Banco { CodBanco = codigoDoBanco, Active = true });

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock
                .Setup(x => x.GerarCodigoDeBarras())
                .Returns(() => new Result<CodigoDeBarras>(codigoDeBarrasMock));
            linhaDigitavelMock
                .SetupGet(x => x.Valor)
                .Returns(linhaDigitavel);

            var linhaDigitavelFactoryMock = new Mock<ILinhaDigitavelFactory>();
            linhaDigitavelFactoryMock
                .Setup(x => x.Criar(It.IsAny<string>(), It.IsAny<IBancoService>()))
                .Returns(() => new Result<LinhaDigitavel>(linhaDigitavelMock.Object));

            var command = new RegistrarNovoBoletoCommand { LinhaDigitavel = linhaDigitavel };

            var result = Boleto.RegistrarNovoBoleto(command, bancoServiceMock.Object, codigoDeBarrasFactoryMock, linhaDigitavelFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is Boleto);
            Assert.IsNotNull(result?.Value?.CodigoDeBarras);
            Assert.IsTrue(result?.Value?.CodigoDeBarras?.Valor == codigoDeBarras);
            Assert.IsNotNull(result?.Value?.LinhaDigitavel);
            Assert.IsTrue(result?.Value?.LinhaDigitavel?.Valor == linhaDigitavel);
            Assert.IsTrue(result?.Value?.UncommittedEvents?.Any(x =>
            {
                var ev = x as NovoBoletoRegistradoEvent;

                return ev != null && ev?.CodigoDeBarras == codigoDeBarras && ev?.LinhaDigitavel == linhaDigitavel;
            }));
        }

        [Test]
        public void RegistrarNovoBoleto_SemCodigoDeBarrasESemLinhaDigitavel_DeveRetornarResultComErro()
        {
            var bancoServiceMock = Mock.Of<IBancoService>();

            var codigoDeBarrasFactoryMock = Mock.Of<ICodigoDeBarrasFactory>();

            var linhaDigitavelFactoryMock = Mock.Of<ILinhaDigitavelFactory>();

            var command = new RegistrarNovoBoletoCommand();

            var result = Boleto.RegistrarNovoBoleto(command, bancoServiceMock, codigoDeBarrasFactoryMock, linhaDigitavelFactoryMock);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Informe código de barras ou linha digitável."));
        }

        [Test]
        [TestCase("75697728100004701351426401000681500325449033", "75691426440100068150003254490331772810000470135")]
        [TestCase("08994972810000050000000601050164700002476000", "08990000620105016470400024760001472810000050000")]
        [TestCase("08997728300000220001000301020121000003983000", "08991000360102012100800039830005772830000022000")]
        [TestCase("08991728300000260001001001090143400000008000", "08991001010109014340300000080002172830000026000")]
        [TestCase("08994728300000260001001001090143400000288000", "08991001010109014340300002880003472830000026000")]
        [TestCase("08991728300000280001001001090120000000408000", "08991001010109012000500004080008172830000028000")]
        [TestCase("08991728300000180001000301020121000005055000", "08991000360102012100800050550003172830000018000")]
        [TestCase("08994728300000025001000101000342600000161000", "08991000100100034260800001610005472830000002500")]
        [TestCase("08997728300000180001000601050168400001057000", "08991000690105016840800010570000772830000018000")]
        [TestCase("08992728300000210001000301020121000005250000", "08991000360102012100800052500006272830000021000")]
        public void RegistrarNovoBoleto_ComCodigoDeBarrasELinhaDigitavel_DeveRetornarResultComErro(string codigoDeBarras, string linhaDigitavel)
        {
            var bancoServiceMock = Mock.Of<IBancoService>();

            var codigoDeBarrasFactoryMock = Mock.Of<ICodigoDeBarrasFactory>();

            var linhaDigitavelFactoryMock = Mock.Of<ILinhaDigitavelFactory>();

            var command = new RegistrarNovoBoletoCommand { CodigoDeBarras = codigoDeBarras, LinhaDigitavel = linhaDigitavel };

            var result = Boleto.RegistrarNovoBoleto(command, bancoServiceMock, codigoDeBarrasFactoryMock, linhaDigitavelFactoryMock);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Informe código de barras ou linha digitável."));
        }

        [Test]
        public void IniciarNovaConsulta_SemContingencia_DeveRetornarResultSemErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var codigoDeBarras = "75697728100004701351426401000681500325449033";
            var coligada = "001";
            var agencia = "00019";
            var contaCorrente = "0173020043";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorNominal = 5000;

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                Agencia = agencia,
                CodigoDeBarras = codigoDeBarras,
                Coligada = coligada,
                ContaCorrente = contaCorrente,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd"),
                EmpresaAplicacaoId = 1
            };

            var agenciaService = Mock.Of<IAgenciaService>();

            var contaService = Mock.Of<IContaService>();

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada && x.NumeroDaContaCorrente == contaCorrente
            && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiConcluidaComErro == null
            && x.FoiIniciadaComDuplicidade == false && x.FoiRealizadaEmContingencia == false && x.Status == ConsultaDeBoletoStatus.EmConsulta
            && x.Id == Guid.NewGuid());

            var consultaDeBoletoFactoryMock = new Mock<IConsultaDeBoletoFactory>();
            consultaDeBoletoFactoryMock.Setup(x => x.Iniciar(It.IsAny<IniciarNovaConsultaDeBoletoCommandV2>(), It.IsAny<DateTime>(),
                It.IsAny<decimal>(), It.IsAny<DateTime?>()))
                .Returns(() => new Result<ConsultaDeBoleto>(consultaDeBoleto));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns(codigoDeBarras);
            codigoDeBarrasMock.Setup(x => x.ObterOValorDoBoleto()).Returns(valorNominal);

            var boleto = Mock.Of<Boleto>(x => x.CodigoDeBarras == codigoDeBarrasMock.Object && x.Consultas == new List<ConsultaDeBoleto>()
            && x.Pagamentos == new List<PagamentoDeBoleto>());

            var result = boleto.IniciarNovaConsulta(command, dataDeProcessamento, consultaDeBoletoFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is ConsultaDeBoleto);
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {
                var ev = x as NovaConsultaDeBoletoIniciadaEvent;

                return ev != null && ev?.CodigoDeBarras == codigoDeBarras && ev?.Agencia == agencia && ev?.Coligada == coligada
                && ev?.ContaCorrente == contaCorrente && ev?.DataDePagamento == dataDePagamento && ev?.DataDeProcessamento == dataDeProcessamento
                && ev?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && ev?.FoiIniciadaComDuplicidade == false
                && ev?.ValorNominal == valorNominal && ev?.IdDaConsultaDeBoleto == consultaDeBoleto.Id;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada
                && x.NumeroDaContaCorrente == contaCorrente && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
                && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiIniciadaComDuplicidade == false
                && x.FoiRealizadaEmContingencia == false && x.Status == ConsultaDeBoletoStatus.EmConsulta && x.Id == consultaDeBoleto.Id));
        }

        [Test]
        public void IniciarNovaConsulta_ComContingencia_DeveRetornarResultSemErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var codigoDeBarras = "75697728100004701351426401000681500325449033";
            var coligada = "001";
            var agencia = "00019";
            var contaCorrente = "0173020043";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorNominal = 5000;

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                Agencia = agencia,
                CodigoDeBarras = codigoDeBarras,
                Coligada = coligada,
                ContaCorrente = contaCorrente,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd"),
                EmpresaAplicacaoId = 1
            };

            var agenciaService = Mock.Of<IAgenciaService>();

            var contaService = Mock.Of<IContaService>();

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada && x.NumeroDaContaCorrente == contaCorrente
            && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiConcluidaComErro == null
            && x.FoiIniciadaComDuplicidade == false && x.FoiRealizadaEmContingencia == true && x.Status == ConsultaDeBoletoStatus.Consultado
            && x.Id == Guid.NewGuid());

            var consultaDeBoletoFactoryMock = new Mock<IConsultaDeBoletoFactory>();
            consultaDeBoletoFactoryMock.Setup(x => x.Iniciar(It.IsAny<IniciarNovaConsultaDeBoletoCommandV2>(), It.IsAny<DateTime>(),
                It.IsAny<decimal>(), It.IsAny<DateTime?>()))
                .Returns(() => new Result<ConsultaDeBoleto>(consultaDeBoleto));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns(codigoDeBarras);
            codigoDeBarrasMock.Setup(x => x.ObterOValorDoBoleto()).Returns(valorNominal);

            var boleto = Mock.Of<Boleto>(x => x.CodigoDeBarras == codigoDeBarrasMock.Object && x.Consultas == new List<ConsultaDeBoleto>()
            && x.Pagamentos == new List<PagamentoDeBoleto>());

            var result = boleto.IniciarNovaConsulta(command, dataDeProcessamento, consultaDeBoletoFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is ConsultaDeBoleto);
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {
                var ev = x as NovaConsultaDeBoletoIniciadaEmContingenciaEvent;

                return ev != null && ev?.CodigoDeBarras == codigoDeBarras && ev?.Agencia == agencia && ev?.Coligada == coligada
                && ev?.ContaCorrente == contaCorrente && ev?.DataDePagamento == dataDePagamento && ev?.DataDeProcessamento == dataDeProcessamento
                && ev?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && ev?.FoiIniciadaComDuplicidade == false
                && ev?.ValorNominal == valorNominal && ev?.IdDaConsultaDeBoleto == consultaDeBoleto.Id;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada
                && x.NumeroDaContaCorrente == contaCorrente && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
                && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiIniciadaComDuplicidade == false
                && x.FoiRealizadaEmContingencia == true && x.Status == ConsultaDeBoletoStatus.Consultado && x.Id == consultaDeBoleto.Id));
        }

        [Test]
        public void IniciarNovaConsulta_SemContingenciaDeBoletoSemRegistro_DeveRetornarResultSemErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var codigoDeBarras = "75697728100004701351426401000681500325449033";
            var coligada = "001";
            var agencia = "00019";
            var contaCorrente = "0173020043";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorNominal = 5000;

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                Agencia = agencia,
                CodigoDeBarras = codigoDeBarras,
                Coligada = coligada,
                ContaCorrente = contaCorrente,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd"),
                EmpresaAplicacaoId = 1
            };

            var agenciaService = Mock.Of<IAgenciaService>();

            var contaService = Mock.Of<IContaService>();

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada && x.NumeroDaContaCorrente == contaCorrente
            && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiConcluidaComErro == null
            && x.FoiIniciadaComDuplicidade == false && x.FoiRealizadaEmContingencia == false && x.Status == ConsultaDeBoletoStatus.EmConsulta
            && x.EBoletoSemRegistro == true
            && x.Id == Guid.NewGuid());

            var consultaDeBoletoFactoryMock = new Mock<IConsultaDeBoletoFactory>();
            consultaDeBoletoFactoryMock.Setup(x => x.Iniciar(It.IsAny<IniciarNovaConsultaDeBoletoCommandV2>(), It.IsAny<DateTime>(),
                It.IsAny<decimal>(), It.IsAny<DateTime?>()))
                .Returns(() => new Result<ConsultaDeBoleto>(consultaDeBoleto));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns(codigoDeBarras);
            codigoDeBarrasMock.Setup(x => x.ObterOValorDoBoleto()).Returns(valorNominal);

            var boleto = Mock.Of<Boleto>(x => x.CodigoDeBarras == codigoDeBarrasMock.Object && x.Consultas == new List<ConsultaDeBoleto>()
            && x.Pagamentos == new List<PagamentoDeBoleto>());

            var result = boleto.IniciarNovaConsulta(command, dataDeProcessamento, consultaDeBoletoFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is ConsultaDeBoleto);
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {

                return x is NovaConsultaDeBoletoSemRegistroIniciadaEvent ev && ev?.CodigoDeBarras == codigoDeBarras
                && ev?.Agencia == agencia && ev?.Coligada == coligada
                && ev?.ContaCorrente == contaCorrente && ev?.DataDePagamento == dataDePagamento && ev?.DataDeProcessamento == dataDeProcessamento
                && ev?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && ev?.FoiIniciadaComDuplicidade == false
                && ev?.ValorNominal == valorNominal && ev?.IdDaConsultaDeBoleto == consultaDeBoleto.Id;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada
                && x.NumeroDaContaCorrente == contaCorrente && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
                && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiIniciadaComDuplicidade == false
                && x.FoiRealizadaEmContingencia == false && x.Status == ConsultaDeBoletoStatus.Consultado && x.EBoletoSemRegistro == true
                && x.Id == consultaDeBoleto.Id));
        }

        [Test]
        public void IniciarNovaConsulta_ComContingenciaDeBoletoSemRegistro_DeveRetornarResultSemErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var codigoDeBarras = "75697728100004701351426401000681500325449033";
            var coligada = "001";
            var agencia = "00019";
            var contaCorrente = "0173020043";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorNominal = 5000;

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                Agencia = agencia,
                CodigoDeBarras = codigoDeBarras,
                Coligada = coligada,
                ContaCorrente = contaCorrente,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd"),
                EmpresaAplicacaoId = empresaAplicacaoTransacaoId
            };

            var agenciaService = Mock.Of<IAgenciaService>();

            var contaService = Mock.Of<IContaService>();

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada && x.NumeroDaContaCorrente == contaCorrente
            && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiConcluidaComErro == null
            && x.FoiIniciadaComDuplicidade == false && x.FoiRealizadaEmContingencia == true && x.Status == ConsultaDeBoletoStatus.Consultado
            && x.EBoletoSemRegistro == true
            && x.Id == Guid.NewGuid());

            var consultaDeBoletoFactoryMock = new Mock<IConsultaDeBoletoFactory>();
            consultaDeBoletoFactoryMock.Setup(x => x.Iniciar(It.IsAny<IniciarNovaConsultaDeBoletoCommandV2>(), It.IsAny<DateTime>(),
                It.IsAny<decimal>(), It.IsAny<DateTime?>()))
                .Returns(() => new Result<ConsultaDeBoleto>(consultaDeBoleto));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns(codigoDeBarras);
            codigoDeBarrasMock.Setup(x => x.ObterOValorDoBoleto()).Returns(valorNominal);

            var boleto = Mock.Of<Boleto>(x => x.CodigoDeBarras == codigoDeBarrasMock.Object && x.Consultas == new List<ConsultaDeBoleto>()
            && x.Pagamentos == new List<PagamentoDeBoleto>());

            var result = boleto.IniciarNovaConsulta(command, dataDeProcessamento, consultaDeBoletoFactoryMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is ConsultaDeBoleto);
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {
                return x is NovaConsultaDeBoletoSemRegistroIniciadaEmContingenciaEvent ev
                && ev?.CodigoDeBarras == codigoDeBarras && ev?.Agencia == agencia && ev?.Coligada == coligada
                && ev?.ContaCorrente == contaCorrente && ev?.DataDePagamento == dataDePagamento && ev?.DataDeProcessamento == dataDeProcessamento
                && ev?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && ev?.FoiIniciadaComDuplicidade == false
                && ev?.ValorNominal == valorNominal && ev?.IdDaConsultaDeBoleto == consultaDeBoleto.Id;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.CodigoDaAgencia == agencia && x.CodigoDaColigada == coligada
                && x.NumeroDaContaCorrente == contaCorrente && x.DataDePagamento == dataDePagamento && x.DataDeProcessamento == dataDeProcessamento
                && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiIniciadaComDuplicidade == false
                && x.FoiRealizadaEmContingencia == true && x.Status == ConsultaDeBoletoStatus.Consultado && x.EBoletoSemRegistro == true
                && x.Id == consultaDeBoleto.Id));
        }

        [Test]
        public void ConcluirAConsultaComErroNaConsultaACIP_DeUmaConsultaExistenteENaoConcluida_DeveRetornarResultSemErros()
        {
            var idDaConsulta = Guid.NewGuid();
            var codigoDeErro = 987;
            var descricaoDoErro = "Teste unitário.";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.EmConsulta);

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto> { consultaDeBoleto });

            var command = new ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand
            {
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                IdDaConsultaDeBoleto = idDaConsulta
            };

            var result = boleto.ConcluirAConsultaComErroNaConsultaACIP(command);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {
                var ev = x as NovaConsultaDeBoletoConcluidaComErroNaConsultaACIPEvent;

                return ev != null && ev?.IdDaConsultaDeBoleto == idDaConsulta && ev.CodigoDeErro == codigoDeErro
                && ev.DescricaoDoErro == descricaoDoErro;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.Rejeitado
            && x.CodigoDeErro == codigoDeErro && x.DescricaoDoErro == descricaoDoErro && x.XmlRetornado == null));
        }

        [Test]
        public void ConcluirAConsultaComErroNaConsultaACIP_DeUmaConsultaNaoExistente_DeveRetornarResultComErros()
        {
            var idDaConsulta = Guid.NewGuid();
            var codigoDeErro = 987;
            var descricaoDoErro = "Teste unitário.";

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto>());

            var command = new ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand
            {
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                IdDaConsultaDeBoleto = idDaConsulta
            };

            var result = boleto.ConcluirAConsultaComErroNaConsultaACIP(command);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Consulta {0} não encontrada.", idDaConsulta)));
        }

        [Test]
        public void ConcluirAConsultaComErroNaConsultaACIP_DeUmaConsultaExistenteConcluida_DeveRetornarResultComErros()
        {
            var idDaConsulta = Guid.NewGuid();
            var codigoDeErro = 987;
            var descricaoDoErro = "Teste unitário.";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.Consultado);

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto> { consultaDeBoleto });

            var command = new ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand
            {
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                IdDaConsultaDeBoleto = idDaConsulta
            };

            var result = boleto.ConcluirAConsultaComErroNaConsultaACIP(command);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("A {0} consulta já foi concluída.", idDaConsulta)));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_DeUmaConsultaExistenteENaoConcluida_DeveRetornarResultSemErros()
        {
            var idDaConsulta = Guid.NewGuid();
            var dataDePagamento = DateTime.Today;

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                IdDaConsultaDeBoleto = idDaConsulta,
                XmlRetornadoPelaCIP = _xmlDocument.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var calculoResult = CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
               _codigoDaAgencia, calendarioService, agenciaServiceMock.Object);

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => new Result<CalculoDeBoleto>(calculoResult.Value));

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.EmConsulta);

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto> { consultaDeBoleto });

            var result = boleto.ProcessarRetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsFalse(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Consulta {0} não encontrada.", idDaConsulta)));
            Assert.IsFalse(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("A {0} consulta já foi concluída.", idDaConsulta)));
            Assert.IsTrue(boleto.UncommittedEvents.Any(x =>
            {
                var ev = x as NovaConsultaDeBoletoConcluidaEvent;

                return ev != null && ev?.IdDaConsultaDeBoleto == idDaConsulta
                && ev?.XmlRetornadoPelaCIP == command.XmlRetornadoPelaCIP
                && ev?.PermiteAlterarValorTotal == calculoResult.Value.PermiteAlterarValorTotal
                && ev?.ValorASerCalculado == calculoResult.Value.ValorASerCalculado
                && ev?.ValorCalculado == calculoResult.Value.ValorCalculado
                && ev?.ValorDesconto == calculoResult.Value.ValorDesconto
                && ev?.ValorJuros == calculoResult.Value.ValorJuros
                && ev?.ValorMaximoCalculado == calculoResult.Value.ValorMaximoCalculado
                && ev?.ValorMinimoCalculado == calculoResult.Value.ValorMinimoCalculado
                && ev?.ValorMulta == calculoResult.Value.ValorMulta;
            }));
            Assert.IsTrue(boleto.Consultas.Any(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.Consultado
            && x.XmlRetornado == command.XmlRetornadoPelaCIP && x.Calculo != null
            && x.Calculo?.PermiteAlterarValorTotal == calculoResult.Value.PermiteAlterarValorTotal
            && x.Calculo?.ValorASerCalculado == calculoResult.Value.ValorASerCalculado
            && x.Calculo?.ValorCalculado == calculoResult.Value.ValorCalculado
            && x.Calculo?.ValorDesconto == calculoResult.Value.ValorDesconto
            && x.Calculo?.ValorJuros == calculoResult.Value.ValorJuros
            && x.Calculo?.ValorMaximoCalculado == calculoResult.Value.ValorMaximoCalculado
            && x.Calculo?.ValorMinimoCalculado == calculoResult.Value.ValorMinimoCalculado
            && x.Calculo?.ValorMulta == calculoResult.Value.ValorMulta));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_DeUmaConsultaNaoExistente_DeveRetornarResultComErros()
        {
            var idDaConsulta = Guid.NewGuid();

            var servicoDeCalculoDeBoleto = Mock.Of<IServicoDeCalculoDeBoleto>();

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto>());

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                IdDaConsultaDeBoleto = idDaConsulta,
                XmlRetornadoPelaCIP = _xmlDocument.InnerXml
            };

            var result = boleto.ProcessarRetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoleto);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("Consulta {0} não encontrada.", idDaConsulta)));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_DeUmaConsultaExistenteConcluida_DeveRetornarResultComErros()
        {
            var idDaConsulta = Guid.NewGuid();

            var servicoDeCalculoDeBoleto = Mock.Of<IServicoDeCalculoDeBoleto>();

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.Id == idDaConsulta && x.Status == ConsultaDeBoletoStatus.Consultado);

            var boleto = Mock.Of<Boleto>(x => x.Consultas == new List<ConsultaDeBoleto> { consultaDeBoleto });

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                IdDaConsultaDeBoleto = idDaConsulta,
                XmlRetornadoPelaCIP = _xmlDocument.InnerXml
            };

            var result = boleto.ProcessarRetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoleto);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == string.Format("A {0} consulta já foi concluída.", idDaConsulta)));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosSemValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == false
                && x.EBoletoSemRegistro == false
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosEmContingenciaSemValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.FoiRealizadoEmContingencia).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == true
                && x.EBoletoSemRegistro == false
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosComValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValidarSaldoDaContaCorrente).Returns(true);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == false
                && x.EBoletoSemRegistro == false
                && x.Status == PagamentoDeBoletoStatus.EmPagamento;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosEmContingenciaComValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.FoiRealizadoEmContingencia).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValidarSaldoDaContaCorrente).Returns(true);
            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == true
                && x.EBoletoSemRegistro == false
                && x.Status == PagamentoDeBoletoStatus.EmPagamento;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosSemRegistroSemValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);
            consultaDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoSemRegistroIniciadoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == false
                && x.EBoletoSemRegistro == true
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosEmContingenciaSemRegistroSemValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.FoiRealizadoEmContingencia).Returns(true);
            pagamentoDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);
            consultaDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == true
                && x.EBoletoSemRegistro == true
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosSemRegistroComValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValidarSaldoDaContaCorrente).Returns(true);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == false
                && x.EBoletoSemRegistro == true
                && x.Status == PagamentoDeBoletoStatus.EmPagamento;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComTodosOsDadosValidosEmContingenciaSemRegistroComValidacaoDeSaldo_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);
            pagamentoDeBoletoMock.SetupGet(x => x.FoiRealizadoEmContingencia).Returns(true);
            pagamentoDeBoletoMock.SetupGet(x => x.EBoletoSemRegistro).Returns(true);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.ValidarSaldoDaContaCorrente).Returns(true);
            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.FoiRealizadoEmContingencia == true
                && x.EBoletoSemRegistro == true
                && x.Status == PagamentoDeBoletoStatus.EmPagamento;
            }));
        }        

        [Test]
        public void IniciarNovoPagamento_SemUmaConsultaValida_DeveRetornarResultComErros()
        {
            var idDaEmpresaAplicacao = 4;            
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto>());
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            IniciarConfiguracoesDoMotor();

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id da consulta inexistente."));
        }

        [Test]
        [TestCase(ConsultaDeBoletoStatus.Cancelado)]
        [TestCase(ConsultaDeBoletoStatus.EmConsulta)]
        [TestCase(ConsultaDeBoletoStatus.EmPagamento)]
        [TestCase(ConsultaDeBoletoStatus.Processado)]
        [TestCase(ConsultaDeBoletoStatus.Rejeitado)]
        public void IniciarNovoPagamento_ComUmaConsultaEmStatusDiferenteDeConsultado_DeveRetornarResultComErros(ConsultaDeBoletoStatus statusDaConsulta)
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(statusDaConsulta);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id da consulta indisponível."));
        }

        [Test]
        public void IniciarNovoPagamento_ComUmaConsultaEmUmaDataAnteriorADataDeProcessamentoConsultado_DeveRetornarResultComErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento.AddDays(-1));
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id da consulta vencido, reinicie o processo de pagamento."));
        }

        [Test]
        public void IniciarNovoPagamento_ComUmaConsultaEmUmaDataMaiorQueADataDeProcessamentoConsultado_DeveRetornarResultComErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento.AddDays(1));
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto>());
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.DebitarContaCorrente).Returns(true);

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id da consulta inválido."));
        }

        [Test]
        public void IniciarNovoPagamento_ComUmPagamentoParaAMesmaConsulta_DeveRetornarResultComErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoExistenteMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(idDaConsultaDeBoleto);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto> { pagamentoDeBoletoExistenteMock.Object });
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Id da consulta indisponível."));
        }

        [Test]
        public void IniciarNovoPagamento_ComUmPagamentoParaOutraConsultaEPermitindoPagamentoParcial_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoExistenteMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(Guid.NewGuid());

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);
            consultaDeBoletoMock.SetupGet(x => x.IndicadorPagamentoParcial).Returns("S");

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto> { pagamentoDeBoletoExistenteMock.Object });
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        public void IniciarNovoPagamento_ComUmPagamentoParaOutraConsultaEAceitandoDuplicidade_DeveRetornarResultSemErros()
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoExistenteMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(Guid.NewGuid());

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto> { pagamentoDeBoletoExistenteMock.Object });
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento,
                AceitaDuplicidade = true
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        [TestCase(0, PagamentoDeBoletoStatus.Recusado)]
        [TestCase(0, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(-1, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(-1, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(-1, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(-1, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(-1, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(-1, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(-1, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(-1, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(-1, PagamentoDeBoletoStatus.Recusado)]
        [TestCase(-15, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(-15, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(-15, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(-15, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(-15, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(-15, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(-15, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(-15, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(-15, PagamentoDeBoletoStatus.Recusado)]
        [TestCase(-16, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(-16, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(-16, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(-16, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(-16, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(-16, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(-16, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(-16, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(-16, PagamentoDeBoletoStatus.Recusado)]
        [TestCase(-16, PagamentoDeBoletoStatus.Efetivado)]
        public void IniciarNovoPagamento_SemUmPagamentoRecenteValido_DeveRetornarResultSemErros(int diasAnterioresAoProcessamento, PagamentoDeBoletoStatus statusDoPagamento)
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var documentoDoPagadorFinal = "38971160810";
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoExistenteMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(Guid.NewGuid());
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.Status).Returns(statusDoPagamento);
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.DataDoPagamento).Returns(dataDeProcessamento.AddDays(diasAnterioresAoProcessamento));

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.CanalDoPagamento).Returns(canalDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.MeioDePagamento).Returns(meioDePagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            pagamentoDeBoletoMock.SetupGet(x => x.IdentificadorDoPagamentoNoCliente).Returns(identificadorDoPagamentoNoCliente);
            pagamentoDeBoletoMock.SetupGet(x => x.DocumentoDoPagadorFinal).Returns(documentoDoPagadorFinal);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDePessoaDoPagadorFinal).Returns("F");
            pagamentoDeBoletoMock.SetupGet(x => x.DataDoPagamento).Returns(DateTime.Now);
            pagamentoDeBoletoMock.SetupGet(x => x.TipoDeBaixaOperacional).Returns(1);

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();
            pagamentoDeBoletoFactoryMock.Setup(x => x.IniciarNovoPagamento(It.IsAny<IniciarNovoPagamentoDeBoletoCommandV3>(),
                It.IsAny<CodigoDeBarras>(), It.IsAny<ConsultaDeBoleto>()))
                .Returns(new Result<PagamentoDeBoleto>(pagamentoDeBoletoMock.Object));

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto> { pagamentoDeBoletoExistenteMock.Object });
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsSuccess);
            Assert.IsNotNull(result?.Value);
            Assert.IsTrue(result?.Value is PagamentoDeBoleto);
            Assert.IsTrue(boletoMock.Object.UncommittedEvents.Any(x =>
            {
                var ev = x as NovoPagamentoDeBoletoIniciadoEventV2;

                return ev != null && ev.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && ev.CodigoDaAgencia == consultaDeBoletoMock.Object.CodigoDaAgencia
                && ev.CodigoDaColigada == consultaDeBoletoMock.Object.CodigoDaColigada
                && ev.CorrelationMessage == command
                && ev.DataDoPagamento == result?.Value?.DataDoPagamento
                && ev.DataDeVencimento == consultaDeBoletoMock.Object.DataDeVencimento
                && ev.Descontos == consultaDeBoletoMock.Object.Calculo.ValorDesconto
                && ev.DocumentoDoBeneficiario == consultaDeBoletoMock.Object.DocumentoDoBeneficiario
                && ev.DocumentoDoPagador == consultaDeBoletoMock.Object.DocumentoDoPagador
                && ev.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && ev.DocumentoDoSacadorOuAvalista == consultaDeBoletoMock.Object.DocumentoDoSacadorOuAvalista
                && ev.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && ev.Encargos == consultaDeBoletoMock.Object.Calculo.ValorEncargos
                && ev.EVRBoleto == eVRBoleto
                && ev.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && ev.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && ev.IdDoPagamentoDeBoleto == result?.Value?.Id
                && ev.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && ev.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && ev.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && ev.ISPBParticipanteRecebedorAdministrado == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorAdministrado
                && ev.ISPBParticipanteRecebedorPrincipal == consultaDeBoletoMock.Object.ISPBParticipanteRecebedorPrincipal
                && ev.MeioDePagamento == result?.Value?.MeioDePagamento
                && ev.NomeFantasiaDoBeneficiario == consultaDeBoletoMock.Object.NomeFantasiaDoBeneficiario
                && ev.NomeFantasiaDoPagador == consultaDeBoletoMock.Object.NomeFantasiaDoPagador
                && ev.NomeFantasiaDoSacadorOuAvalista == consultaDeBoletoMock.Object.NomeFantasiaDoSacadorOuAvalista
                && ev.NumeroControleParticipante == pagamentoDeBoletoMock.Object.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "")
                && ev.NumeroDaContaCorrente == consultaDeBoletoMock.Object.NumeroDaContaCorrente
                && ev.NumeroDoCodigoDeBarrasDoBoleto == codigoDeBarrasMock.Object.Valor
                && ev.NumeroIdentificacaoTitulo == consultaDeBoletoMock.Object.NumeroIdentificacaoTitulo
                && ev.NumeroReferenciaAtualBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaAtualBaixaOperacional
                && ev.NumeroReferenciaCadastroTituloBaixaOperacional == consultaDeBoletoMock.Object.NumeroReferenciaCadastroTituloBaixaOperacional
                && ev.OriginalCorrelationMessage == command
                && ev.RazaoSocialDoBeneficiario == consultaDeBoletoMock.Object.RazaoSocialDoBeneficiario
                && ev.RazaoSocialDoPagador == consultaDeBoletoMock.Object.RazaoSocialDoPagador
                && ev.RazaoSocialDoSacadorOuAvalista == consultaDeBoletoMock.Object.RazaoSocialDoSacadorOuAvalista
                && ev.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && ev.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && ev.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && ev.ValorNominal == consultaDeBoletoMock.Object.ValorNominal;
            }));
            Assert.IsTrue(boletoMock.Object.Pagamentos.Any(x =>
            {
                return x != null && x.CanalDoPagamento == result?.Value?.CanalDoPagamento
                && x.DataDoPagamento == result?.Value?.DataDoPagamento
                && x.DocumentoDoPagadorFinal == result?.Value?.DocumentoDoPagadorFinal
                && x.EmpresaAplicacaoTransacaoId == result?.Value?.EmpresaAplicacaoTransacaoId
                && x.EVRBoleto == eVRBoleto
                && x.IdDaConsultaDeBoleto == consultaDeBoletoMock.Object.Id
                && x.IdDoBoleto == consultaDeBoletoMock.Object.IdDoBoleto
                && x.IdentificadorDoPagamentoNoCliente == result?.Value?.IdentificadorDoPagamentoNoCliente
                && x.DocumentoDoPagadorInformadoPeloCliente == result?.Value?.DocumentoDoPagadorInformadoPeloCliente
                && x.NomeDoPagadorInformadoPeloCliente == result?.Value?.NomeDoPagadorInformadoPeloCliente
                && x.MeioDePagamento == result?.Value?.MeioDePagamento
                && x.TipoDeBaixaOperacional == result?.Value?.TipoDeBaixaOperacional
                && x.TipoDePessoaDoPagadorFinal == result?.Value?.TipoDePessoaDoPagadorFinal
                && x.ValorDoPagamento == result?.Value?.ValorDoPagamento
                && x.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao;
            }));
        }

        [Test]
        [TestCase(0, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(0, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(0, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(0, PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(0, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(0, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(0, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(0, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(-1, PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(-15, PagamentoDeBoletoStatus.Efetivado)]
        public void IniciarNovoPagamento_ComUmPagamentoRecenteValido_DeveRetornarResultComErros(int diasAnterioresAoProcessamento, PagamentoDeBoletoStatus statusDoPagamento)
        {
            var idDaEmpresaAplicacao = 4;
            var idDaEmpresaAplicacaoTransacao = 1;
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var dataDeProcessamento = DateTime.Today;
            var identificadorDoPagamentoNoCliente = Guid.NewGuid().ToString();
            var canalDoPagamento = 1;
            var meioDePagamento = 1;
            var valorDoPagamento = 5000;
            var valorInicialDoVRBoleto = 250000;

            var eVRBoleto = valorDoPagamento >= valorInicialDoVRBoleto;

            var pagamentoDeBoletoExistenteMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(Guid.NewGuid());
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.Status).Returns(statusDoPagamento);
            pagamentoDeBoletoExistenteMock.SetupGet(x => x.DataDoPagamento).Returns(dataDeProcessamento.AddDays(diasAnterioresAoProcessamento));

            var pagamentoDeBoletoFactoryMock = new Mock<IPagamentoDeBoletoFactory>();

            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns("75697728100004701351426401000681500325449033");

            var linhaDigitavelMock = new Mock<LinhaDigitavel>();
            linhaDigitavelMock.SetupGet(x => x.Valor).Returns("75691426440100068150003254490331772810000470135");

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(idDaEmpresaAplicacaoTransacao);
            consultaDeBoletoMock.SetupGet(x => x.Status).Returns(ConsultaDeBoletoStatus.Consultado);
            consultaDeBoletoMock.SetupGet(x => x.DataDaConsulta).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns("00019");
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns("001");
            consultaDeBoletoMock.SetupGet(x => x.DataDeVencimento).Returns(dataDeProcessamento);
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorDesconto).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoBeneficiario).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoPagador).Returns("38971160810");
            consultaDeBoletoMock.SetupGet(x => x.DocumentoDoSacadorOuAvalista).Returns("16862377000190");
            consultaDeBoletoMock.SetupGet(x => x.Calculo.ValorEncargos).Returns(0);
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorAdministrado).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.ISPBParticipanteRecebedorPrincipal).Returns("00000000");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.NomeFantasiaDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.NumeroControleParticipante).Returns("78d0a95f-1cac-4b65-9d66-504705dbaed5");
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns("4171060008");
            consultaDeBoletoMock.SetupGet(x => x.NumeroIdentificacaoTitulo).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaAtualBaixaOperacional).Returns(string.Empty);
            consultaDeBoletoMock.SetupGet(x => x.NumeroReferenciaCadastroTituloBaixaOperacional).Returns("005");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoBeneficiario).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoPagador).Returns("Samuel Francisco");
            consultaDeBoletoMock.SetupGet(x => x.RazaoSocialDoSacadorOuAvalista).Returns("BANCO DO BRASIL S.A.");
            consultaDeBoletoMock.SetupGet(x => x.ValorNominal).Returns(valorDoPagamento);

            var boletoMock = new Mock<Boleto>().SetupProperty(x => x.Pagamentos, new List<PagamentoDeBoleto> { pagamentoDeBoletoExistenteMock.Object });
            boletoMock.SetupGet(x => x.Id).Returns(idDoBoleto);
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.CodigoDeBarras).Returns(codigoDeBarrasMock.Object);
            boletoMock.SetupGet(x => x.LinhaDigitavel).Returns(linhaDigitavelMock.Object);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovoPagamentoDeBoletoCommandV3
            {
                CanalDoPagamento = canalDoPagamento,
                EmpresaAplicacaoId = idDaEmpresaAplicacao,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdentificadorDoPagamentoNoCliente = identificadorDoPagamentoNoCliente,
                MeioDePagamento = meioDePagamento,
                ValorDoPagamento = valorDoPagamento
            };

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoRendimentoAsync()).Returns(Task.FromResult(new Banco() { CodBanco = "0633", CodISPB = "68900810", Active = true }));
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(It.IsAny<string>())).Returns(Task.FromResult(new Banco() { CodBanco = "0756", CodISPB = "02038232", Active = true }));

            var result = boletoMock.Object.IniciarNovoPagamento(command, dataDeProcessamento, pagamentoDeBoletoFactoryMock.Object,
                bancoServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsNull(result?.Value);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == $"Pagamento em Duplicidade – Boleto pago em {pagamentoDeBoletoExistenteMock.Object.DataDoPagamento.ToString("dd/MM/yyyy")}."));
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComValorMenorQueOSaldoDisponivel_DeveRetornarSaldoValidado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(idDaConsultaDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.Status).Returns(PagamentoDeBoletoStatus.EmPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.Consulta).Returns(consultaDeBoletoMock.Object);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock.Object });

            var command = new ValidarSaldoDisponivelDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                SaldoDisponivel = valorDoPagamento + 1
            };

            var boleto = boletoMock.Object;

            boleto.ValidarSaldoDisponivelDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is SaldoDisponivelDaContaCorrenteValidadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as SaldoDisponivelDaContaCorrenteValidadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CodigoDaColigada == codigoDaColigada);
            Assert.IsTrue(@event.CodigoDaAgencia == codigoDaAgencia);
            Assert.IsTrue(@event.NumeroDaContaCorrente == numeroDaContaCorrente);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComValorIgualAoSaldoDisponivel_DeveRetornarSaldoValidado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var pagamentoDeBoletoMock = new Mock<PagamentoDeBoleto>();
            pagamentoDeBoletoMock.SetupGet(x => x.Id).Returns(idDoPagamentoDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.IdDaConsultaDeBoleto).Returns(idDaConsultaDeBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            pagamentoDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            pagamentoDeBoletoMock.SetupGet(x => x.ValorDoPagamento).Returns(valorDoPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.Status).Returns(PagamentoDeBoletoStatus.EmPagamento);
            pagamentoDeBoletoMock.SetupGet(x => x.Consulta).Returns(consultaDeBoletoMock.Object);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock.Object });

            var command = new ValidarSaldoDisponivelDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                SaldoDisponivel = valorDoPagamento
            };

            var boleto = boletoMock.Object;

            boleto.ValidarSaldoDisponivelDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is SaldoDisponivelDaContaCorrenteValidadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as SaldoDisponivelDaContaCorrenteValidadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CodigoDaColigada == codigoDaColigada);
            Assert.IsTrue(@event.CodigoDaAgencia == codigoDaAgencia);
            Assert.IsTrue(@event.NumeroDaContaCorrente == numeroDaContaCorrente);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_ComValorMaiorQueOSaldoDisponivel_DeveRetornarPagamentoRecusado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "Valor do pagamento superior ao saldo disponível na conta corrente.";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.EmPagamento);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new ValidarSaldoDisponivelDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                SaldoDisponivel = valorDoPagamento - 1
            };

            var boleto = boletoMock.Object;

            boleto.ValidarSaldoDisponivelDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa == motivoDaRecusa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Recusado);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa == motivoDaRecusa);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void ValidarOSaldoDisponivelDaContaCorrente_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new ValidarSaldoDisponivelDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                SaldoDisponivel = 5000
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.ValidarSaldoDisponivelDaContaCorrente(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void ValidarOSaldoDisponivelDaContaCorrente_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new ValidarSaldoDisponivelDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                SaldoDisponivel = valorDoPagamento - 1
            };

            var boleto = boletoMock.Object;

            boleto.ValidarSaldoDisponivelDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente_ComUmPagamentoValido_DeveRetornarPagamentoRecusado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "Não foi possível consultar o saldo da conta corrente";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.EmPagamento);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa.Contains(motivoDaRecusa));
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Recusado);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa.Contains(motivoDaRecusa));

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente_ComUmPagamentoValido_DeveRetornarPagamentoRecusado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "Não foi possível debitar a conta corrente";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.EmPagamento);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa.Contains(motivoDaRecusa));
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Recusado);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa.Contains(motivoDaRecusa));

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        public void MarcarPagamentoComoPendenteDeBaixaOperacional_ComUmPagamentoValido_DeveRetornarPagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacional(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoComoPendenteDeBaixaOperacional(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional);
        }

        [Test]
        public void MarcarPagamentoComoPendenteDeBaixaOperacional_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.MarcarPagamentoComoPendenteDeBaixaOperacional(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void MarcarPagamentoComoPendenteDeBaixaOperacional_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoComoPendenteDeBaixaOperacional(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void RecusarPagamentoDeBoletoRealizadoEmContingencia_ComUmPagamentoValido_DeveRetornarPagamentoRecusado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoRealizadoEmContingenciaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoRealizadoEmContingencia(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa == motivoDaRecusa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Recusado);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa == motivoDaRecusa);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void RecusarPagamentoDeBoletoRealizadoEmContingencia_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new RecusarPagamentoDeBoletoRealizadoEmContingenciaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.RecusarPagamentoDeBoletoRealizadoEmContingencia(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void RecusarPagamentoDeBoletoRealizadoEmContingencia_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new RecusarPagamentoDeBoletoRealizadoEmContingenciaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.RecusarPagamentoDeBoletoRealizadoEmContingencia(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        [TestCase(true, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(true, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(true, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(true, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(false, PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        public void EfetivarPagamentoDeBoleto_ComUmPagamentoValido_DeveRetornarPagamentoEfetivado(bool eBoletoSemRegistro, PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente && x.EBoletoSemRegistro == eBoletoSemRegistro);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status && x.EBoletoSemRegistro == eBoletoSemRegistro);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new EfetivarPagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
            };

            var boleto = boletoMock.Object;

            boleto.EfetivarPagamentoDeBoleto(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoEfetivadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoEfetivadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Efetivado);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void EfetivarPagamentoDeBoleto_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new EfetivarPagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.EfetivarPagamentoDeBoleto(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(true, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(true, PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(true, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(true, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(true, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(true, PagamentoDeBoletoStatus.Recusado)]
        [TestCase(false, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(false, PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(false, PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(false, PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(false, PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(false, PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(false, PagamentoDeBoletoStatus.Estornado)]
        [TestCase(false, PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(false, PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(false, PagamentoDeBoletoStatus.Recusado)]
        public void EfetivarPagamentoDeBoleto_EmUmStatusInvalido_NaoDeveFazerNada(bool eBoletoSemRegistro, PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente && x.EBoletoSemRegistro == eBoletoSemRegistro);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status && x.EBoletoSemRegistro == eBoletoSemRegistro);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new EfetivarPagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.EfetivarPagamentoDeBoleto(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada_ComUmPagamentoValido_DeveRetornarPagamentoDeBoletoRecusadoNaBaixaOperacional()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa == motivoDaRecusa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.BaixaOperacionalRecusada);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa == motivoDaRecusa);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitada_ComUmPagamentoValido_DeveRetornarPagamentoDeBoletoRecusadoNaBaixaOperacional()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.MotivoDaRecusa == motivoDaRecusa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.BaixaOperacionalRecusada);
            Assert.IsTrue(pagamentoDeBoletoMock.MotivoDaRecusa == motivoDaRecusa);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Processado);
        }

        [Test]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitada_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var motivoDaRecusa = "AAAAAA";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmEstorno)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitada_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoEfetivadoSemEstornoAutomatico_DeveRetornarCancelamentoDePagamentoDeBoletoEfetivadoIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.Efetivado
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = false
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoEfetivadoComEstornoAutomatico_DeveRetornarCancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.Efetivado
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento
            && x.DebitarContaCorrente == true);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = true
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoComBaixaRecusadaSemEstornoAutomatico_DeveRetornarCancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.BaixaOperacionalRecusada
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = false
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoComBaixaRecusadaComEstornoAutomatico_DeveRetornarCancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);            
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.BaixaOperacionalRecusada
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento
            && x.DebitarContaCorrente == true);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = true
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoDeBoletoSemRegistroSemEstornoAutomatico_DeveRetornarCancelamentoDePagamentoDeBoletoSemRegistroIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.Efetivado
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento
            && x.EBoletoSemRegistro == true);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = false
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_ComUmPagamentoDeBoletoSemRegistroComEstornoAutomatico_CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciado()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var pagamentoDeBoleto = Mock.Of<PagamentoDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.Id == idDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.Status == PagamentoDeBoletoStatus.Efetivado
            && x.EVRBoleto == false && x.DataDoPagamento == dataDeProcessamento
            && x.DebitarContaCorrente == true && x.EBoletoSemRegistro == true);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoleto });

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor.Boletos)
                .Returns(new ConfiguracoesDeBoletos
                {
                    ConfiguracoesDaTransacao = new ConfiguracoesDaTransacao
                    {
                        EmpresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                        {
                            new ConfiguracoesDaEmpresaAplicacaoTransacao
                            {
                                EmpresaAplicacaoId = empresaAplicacaoId,
                                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId,
                                EstornarAutomaticamente = true
                            }
                        }
                    }
                });

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.Justificativa == justificativa);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoleto.Status == PagamentoDeBoletoStatus.EmEstorno);
            Assert.IsTrue(pagamentoDeBoleto.JustificativaDoCancelamento == justificativa);
        }

        [Test]
        public void CancelarPagamento_SemPagamentoValido_DeveRetornarResultComErro()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoId = 4;
            var empresaAplicacaoTransacaoId = 1;
            var justificativa = "AAAAAA";
            var dataDeProcessamento = DateTime.Today;

            IniciarConfiguracoesDoMotor();

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());            

            var command = new IniciarCancelamentoDePagamentoDeBoletoCommandV2
            {
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoId = empresaAplicacaoId,
                Justificativa = justificativa
            };

            var boleto = boletoMock.Object;

            var result = boleto.CancelarPagamento(command, dataDeProcessamento, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado."));
        }

        [Test]
        public void MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional_ComUmPagamentoValido_DeveRetornarPagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacional()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.EmEstorno);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoPendenteDeCancelamentoDeBaixaOperacionalCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional);
        }

        [Test]
        public void MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new MarcarPagamentoDeBoletoComoPendenteDeCancelamentoDeBaixaOperacionalCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

        [Test]
        public void ConcluirCancelamentoDePagamento_ComUmPagamentoValido_DeveRetornarCancelamentoDePagamentoDeBoletoConcluido()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new ConcluirCancelamentoDePagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.ConcluirCancelamentoDePagamento(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 1);
            Assert.IsTrue(boleto.UncommittedEvents.Count(x => x is CancelamentoDePagamentoDeBoletoConcluidoEvent) == 1);

            var @event = boleto.UncommittedEvents.FirstOrDefault() as CancelamentoDePagamentoDeBoletoConcluidoEvent;

            Assert.IsTrue(@event.IdDoBoleto == idDoBoleto);
            Assert.IsTrue(@event.IdDaConsultaDeBoleto == idDaConsultaDeBoleto);
            Assert.IsTrue(@event.IdDoPagamentoDeBoleto == idDoPagamentoDeBoleto);
            Assert.IsTrue(@event.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(@event.CorrelationMessage == command);
            Assert.IsTrue(@event.OriginalCorrelationMessage == command);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == PagamentoDeBoletoStatus.Estornado);

            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Cancelado);
        }

        [Test]
        public void ConcluirCancelamentoDePagamento_SemPagamentoValido_DeveDispararException()
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";

            var consultaDeBoletoMock = new Mock<ConsultaDeBoleto>();
            consultaDeBoletoMock.SetupGet(x => x.IdDoBoleto).Returns(idDoBoleto);
            consultaDeBoletoMock.SetupGet(x => x.Id).Returns(idDaConsultaDeBoleto);
            consultaDeBoletoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(empresaAplicacaoTransacaoId);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaColigada).Returns(codigoDaColigada);
            consultaDeBoletoMock.SetupGet(x => x.CodigoDaAgencia).Returns(codigoDaAgencia);
            consultaDeBoletoMock.SetupGet(x => x.NumeroDaContaCorrente).Returns(numeroDaContaCorrente);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoletoMock.Object });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto>());

            var command = new ConcluirCancelamentoDePagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            var exception = Assert.Throws<InvalidOperationException>(delegate { boleto.ConcluirCancelamentoDePagamento(command); });

            Assert.IsTrue(exception.Message == $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");
        }

        [Test]
        [TestCase(PagamentoDeBoletoStatus.BaixaOperacionalRecusada)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPelaAplicacao)]
        [TestCase(PagamentoDeBoletoStatus.DebitadoPeloMotor)]
        [TestCase(PagamentoDeBoletoStatus.Efetivado)]
        [TestCase(PagamentoDeBoletoStatus.EmPagamento)]        
        [TestCase(PagamentoDeBoletoStatus.Estornado)]
        [TestCase(PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)]
        [TestCase(PagamentoDeBoletoStatus.Recusado)]
        public void ConcluirCancelamentoDePagamento_EmUmStatusInvalido_NaoDeveFazerNada(PagamentoDeBoletoStatus status)
        {
            var idDoBoleto = Guid.NewGuid();
            var idDaConsultaDeBoleto = Guid.NewGuid();
            var idDoPagamentoDeBoleto = Guid.NewGuid();
            var empresaAplicacaoTransacaoId = 1;
            var codigoDaColigada = "001";
            var codigoDaAgencia = "00019";
            var numeroDaContaCorrente = "4171060008";
            var valorDoPagamento = 5000;

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>(x => x.IdDoBoleto == idDoBoleto
            && x.Id == idDaConsultaDeBoleto && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.CodigoDaColigada == codigoDaColigada && x.CodigoDaAgencia == codigoDaAgencia
            && x.NumeroDaContaCorrente == numeroDaContaCorrente);

            var pagamentoDeBoletoMock = Mock.Of<PagamentoDeBoleto>(x => x.Id == idDoPagamentoDeBoleto
            && x.IdDaConsultaDeBoleto == idDaConsultaDeBoleto && x.IdDoBoleto == idDoBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId
            && x.ValorDoPagamento == valorDoPagamento && x.Consulta == consultaDeBoleto
            && x.Status == status);

            var boletoMock = new Mock<Boleto>();
            boletoMock.SetupGet(x => x.Consultas).Returns(new List<ConsultaDeBoleto> { consultaDeBoleto });
            boletoMock.SetupGet(x => x.Pagamentos).Returns(new List<PagamentoDeBoleto> { pagamentoDeBoletoMock });

            var command = new ConcluirCancelamentoDePagamentoDeBoletoCommand
            {
                IdDoBoleto = idDoBoleto,
                IdDaConsultaDeBoleto = idDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = idDoPagamentoDeBoleto,
                EmpresaAplicacaoTransacaoId = empresaAplicacaoTransacaoId
            };

            var boleto = boletoMock.Object;

            boleto.ConcluirCancelamentoDePagamento(command);

            Assert.IsTrue(boleto.UncommittedEvents.Count() == 0);

            Assert.IsTrue(pagamentoDeBoletoMock.Status == status);
        }

    }
}