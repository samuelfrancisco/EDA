﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{
    public class CalculoTipo1DeBoletoTests
    {

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo0Invalido_DeveRetornarResultComErros(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>();

            Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            var valorTitulo = (decimal)4701.35;

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 valorTitulo, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,

                new GrupoValores(),
                new GrupoValores(), new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        Data = Convert.ToDateTime("10-12-2017"),
                        ValorPercentual = (decimal)2555.18
                    }
                },
                new List<GrupoCalculo>(),
                             DateTime.Now,
                             _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(!result.Value.ValorCalculado.Equals(valorTitulo));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo0Valido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>();
            Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            var valorTitulo = (decimal)4701.35;

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 valorTitulo, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,

                new GrupoValores(),
                new GrupoValores(),
                 new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        Data = Convert.ToDateTime("31-08-2017"),
                        ValorPercentual = (decimal)2555.18
                    }
                },
                new List<GrupoCalculo>(),
                             DateTime.Now,
                             _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(valorTitulo));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo1Invalido_DeveRetornarResultComErros(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>();
            Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)2146.17;

            DateTime dataPagamento = Convert.ToDateTime("13-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,

                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 1,
                        Data = Convert.ToDateTime("31-08-2017"),
                        ValorPercentual = (decimal)2555.18
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(!result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo1Valido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)2146.17;
            DateTime dataPagamento = Convert.ToDateTime("13-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,

               new GrupoValores(),
               new GrupoValores(),
               new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 1,
                        Data = Convert.ToDateTime("31-08-2017"),
                        ValorPercentual = (decimal)2555.18
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo1ComDoisGruposValido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));
            decimal _valorRetorno = 3146.17M;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 1,
                        Data = Convert.ToDateTime("02-12-2017"),
                        ValorPercentual = (decimal)2555.18
                    },
                    new GrupoValores()
                    {
                        Codigo = 1,
                        Data = Convert.ToDateTime("10-12-2017"),
                        ValorPercentual = (decimal)1555.18
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo2Invalido_DeveRetornarValorInvalido(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4654.34;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                 Convert.ToDateTime("13-12-2017"),
                  (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,

                 new GrupoValores(),
                 new GrupoValores(),
                 new List<GrupoValores>()
                 {
                                new GrupoValores()
                                {
                                    Codigo = 2,
                                    Data = Convert.ToDateTime("31-08-2017"),
                                    ValorPercentual = (decimal)0.01
                                }
                 },
                 new List<GrupoCalculo>(),
                 dataPagamento,
                 _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo01DescontoTipo2Valido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4654.33;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 2,
                        Data = Convert.ToDateTime("12-12-2017"),
                        ValorPercentual = (decimal)1
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo3ValorPorDiaCorridoInvalido_DeveRetornarValorInvalido(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4661;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 3,
                        Data = Convert.ToDateTime("10-12-2017"),
                        ValorPercentual = (decimal)10
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo3ValorPorDiaCorridoValido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4661.35;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 3,
                        Data = Convert.ToDateTime("10-12-2017"),
                        ValorPercentual = (decimal)10
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo3ValorPorDiaCorridoSemDataNoGrupoDesconto_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4631.35;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 3,
                        ValorPercentual = (decimal)10
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo5Invalido_DeveRetornarValorInvalido(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)4325.25;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 (decimal)4701.35, 1, "N", 0, 0, (decimal)0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 5,
                        Data = Convert.ToDateTime("31-08-2017"),
                        ValorPercentual = (decimal)0.01
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo5Valido_SemGrupoBaixa_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 4698.52M;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 4701.35M, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 5,
                        Data = Convert.ToDateTime("12-12-2017"),
                        ValorPercentual = 0.01M
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DescontoTipo5Valido_ComGrupoBaixa_DeveRetornarSucessoSemDesconto(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>();
            Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 4701.35M;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("13-12-2017"),
                 4701.35M, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores(),
                new GrupoValores(),
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 5,
                        Data = Convert.ToDateTime("12-12-2017"),
                        ValorPercentual = 0.01M
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object,
                new List<GrupoBaixa>() { new GrupoBaixa() { NumeroIdentificacao = "2017100300002161609" } }, null,
                 "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1JurosTipo1ValorDiasCorridosInvalido_DeveRetornarValorInvalido(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = (decimal)242;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                Convert.ToDateTime("01-12-2017"),
                 (decimal)280, 1, "N", 0, 0, (decimal)40, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 5
                }
                ,
                new GrupoValores(),
                new List<GrupoValores>(),
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1JurosTipo1ValorDiaCorridoValido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("01-12-2017"), "00018")).Returns(Convert.ToDateTime("04-12-2017"));

            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 243M;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                            Convert.ToDateTime("01-12-2017"),
                             280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            new GrupoValores()
                            {
                                Codigo = 1,
                                ValorPercentual = 1
                            },
                            new GrupoValores(),
                            new List<GrupoValores>(),
                            new List<GrupoCalculo>(),
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DeJurosTipo2PercentualDiaCorrido_ParaModeloDeCalculo1InValido_DeveRetornarValorInvalido(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 241.92M;
            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                            Convert.ToDateTime("01-12-2017"),
                             280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            new GrupoValores()
                            {
                                Codigo = 2,
                                ValorPercentual = 0.2M
                            },
                            new GrupoValores(),
                            new List<GrupoValores>(),
                            new List<GrupoCalculo>(),
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsFalse(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DeJurosTipo3PercentualMesCorrido_ComDataVencimentoNaoUtil_SemMulta_Valido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>();
            Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();

            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(Convert.ToDateTime("04-12-2017"));

            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("07-12-2017");

            decimal _valorRetorno = 241.2M;

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                            Convert.ToDateTime("02-12-2017"),
                             280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            new GrupoValores()
                            {
                                Codigo = 3,
                                ValorPercentual = 5
                            },
                            new GrupoValores(),
                            new List<GrupoValores>(),
                            new List<GrupoCalculo>(),
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1DeJurosTipo3PercentualMesCorrido_ComDataVencimentoNaoUtil_ComMulta_Valido_DeveRetornarComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(Convert.ToDateTime("04-12-2017"));
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 245.2M;
            DateTime dataPagamento = Convert.ToDateTime("05-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                            Convert.ToDateTime("02-12-2017"),
                             280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            new GrupoValores()
                            {
                                Codigo = 3,
                                ValorPercentual = 5
                            },
                            new GrupoValores()
                            {
                                Codigo = 2,
                                ValorPercentual = 2
                            },
                            new List<GrupoValores>(),
                            new List<GrupoCalculo>(),
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        [TestCase(1)]
        [TestCase(4)]
        public void Calculo_Tipo1JurosValorDiaCorridoTipo6ComMultaValido_DeveRetornarResultComSucesso(int tipoDeModeloDeCalculo)
        {
            Moq.Mock<ICalendarioService> _calendario = new Moq.Mock<ICalendarioService>(); Moq.Mock<IAgenciaService> _agenciaService = new Moq.Mock<IAgenciaService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("09-12-2017"), "00018")).Returns(Convert.ToDateTime("09-12-2017"));
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("10-12-2017"), "00018")).Returns(Convert.ToDateTime("10-12-2017"));
            _calendario.Setup(s => s.ObterCalendarioEntreDatas(Convert.ToDateTime("10-12-2017"), Convert.ToDateTime("11-12-2017"), "00018")).Returns(new Calendarios.Calendario() { QuantidadeDiasUteis = 2 });

            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            decimal _valorRetorno = 1031.18M;
            DateTime dataPagamento = Convert.ToDateTime("11-12-2017");

            var result = CalculoDeBoleto.Calcular(tipoDeModeloDeCalculo,
                            Convert.ToDateTime("09-12-2017"),
                             1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,

                            new GrupoValores()
                            {
                                Codigo = 6,
                                Data = Convert.ToDateTime("10-12-2017"),
                                ValorPercentual = 2.59M
                            },
                            new GrupoValores()
                            {
                                Codigo = 1,
                                Data = Convert.ToDateTime("10-12-2017"),
                                ValorPercentual = 26M
                            },
                            new List<GrupoValores>()
                            {
                                new GrupoValores()
                                {
                                    Codigo = 3,
                                    ValorPercentual = 2
                                }
                            },
                            new List<GrupoCalculo>(),
                             dataPagamento,
                             _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }
    }
}
