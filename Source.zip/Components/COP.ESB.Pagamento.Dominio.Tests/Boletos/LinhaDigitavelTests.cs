﻿using COP.ESB.Pagamento.Dominio.Bancos;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Tests.Helpers;
using Moq;
using NUnit.Framework;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{
    [TestFixture]
    public class LinhaDigitavelTests
    {
        [Test]
        public void CriarPeloValor_ComValorNulo_DeveRetornarResultComErros()
        {
            var bancoServiceMock = new Mock<IBancoService>();

            var result = LinhaDigitavel.Criar(null, bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."));
        }

        [Test]
        public void CriarPeloValor_ComValorEmBranco_DeveRetornarResultComErros()
        {
            var bancoServiceMock = new Mock<IBancoService>();

            var result = LinhaDigitavel.Criar(string.Empty, bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."));
        }

        [Test]
        public void CriarPeloValor_ComValorComMenosCaracteres_DeveRetornarResultComErros()
        {
            var bancoServiceMock = new Mock<IBancoService>();

            var result = LinhaDigitavel.Criar(StringHelper.GerarStringComDigitosRandomicos(43), bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."));
        }

        [Test]
        public void CriarPeloValor_ComValorSoComEspacos_DeveRetornarResultComErros()
        {
            var bancoServiceMock = new Mock<IBancoService>();

            var result = LinhaDigitavel.Criar(StringHelper.GerarStringSoComEspacos(44), bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."));
        }

        [Test]
        public void CriarPeloValor_ComValorContendoLetrasOuCaracteresEspeciais_DeveRetornarResultComErros()
        {
            var bancoServiceMock = new Mock<IBancoService>();

            var result = LinhaDigitavel.Criar(StringHelper.GerarStringComNumerosELetrasOuCaracteresEspeciais(44), bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."));
        }

        [Test]
        [TestCase("34190320101654228000900000000000472800014478322")]
        [TestCase("75691426440100068150003254490331772810000470135")]
        [TestCase("42297115040000195441160020034520268610000054659")]
        [TestCase("08991000360102012100800039830005772830000022000")]
        [TestCase("08991001010109014340300000080002172830000026000")]
        [TestCase("08991001010109014340300002880003472830000026000")]
        [TestCase("08991001010109012000500004080008172830000028000")]
        [TestCase("08991000360102012100800050550003172830000018000")]
        [TestCase("08991000100100034260800001610005472830000002500")]
        [TestCase("08991000690105016840800010570000772830000018000")]
        [TestCase("08991000360102012100800052500006272830000021000")]
        public void CriarPeloValor_ComValorValido_DeveRetornarResultSemErrosComValorIgualAoInformado(string valor)
        {
            var codigoDoBanco = "0" + valor.Substring(0, 3);

            var bancoServiceMock = new Mock<IBancoService>();
            bancoServiceMock.Setup(x => x.ObterBancoPeloCodigoAsync(codigoDoBanco)).ReturnsAsync(new Banco { CodBanco = codigoDoBanco, Active = true });

            var result = LinhaDigitavel.Criar(valor, bancoServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);            
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.AreEqual(result.Value.Valor, valor);
        }

        [Test]
        public void CriarPeloCodigoDeBarras_ComCodigoDeBarrasNulo_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavel.Criar(null);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido."));
        }

        [Test]
        [TestCase("34194728000144783220320116542280000000000000", "34190320101654228000900000000000472800014478322")]
        [TestCase("75697728100004701351426401000681500325449033", "75691426440100068150003254490331772810000470135")]
        [TestCase("42292686100000546597115000001954416002003452", "42297115040000195441160020034520268610000054659")]
        [TestCase("08997728300000220001000301020121000003983000", "08991000360102012100800039830005772830000022000")]
        [TestCase("08991728300000260001001001090143400000008000", "08991001010109014340300000080002172830000026000")]
        [TestCase("08994728300000260001001001090143400000288000", "08991001010109014340300002880003472830000026000")]
        [TestCase("08991728300000280001001001090120000000408000", "08991001010109012000500004080008172830000028000")]
        [TestCase("08991728300000180001000301020121000005055000", "08991000360102012100800050550003172830000018000")]
        [TestCase("08994728300000025001000101000342600000161000", "08991000100100034260800001610005472830000002500")]
        [TestCase("08997728300000180001000601050168400001057000", "08991000690105016840800010570000772830000018000")]
        [TestCase("08992728300000210001000301020121000005250000", "08991000360102012100800052500006272830000021000")]

        public void CriarPeloCodigoDeBarras_ComCodigoDeBarrasValido_DeveRetornarResultSemErrosComValorCorrespondenteAoDoCodigoDeBarras(string codigoDeBarras,
            string linhaDigitavel)
        {
            var codigoDeBarrasMock = new Mock<CodigoDeBarras>();
            codigoDeBarrasMock.SetupGet(x => x.Valor).Returns(codigoDeBarras);

            var result = LinhaDigitavel.Criar(codigoDeBarrasMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.AreEqual(result.Value.Valor, linhaDigitavel);
        }
    }
}
