﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{

    [TestFixture]
    public class CalculoTipo2DeBoletoTests
    {
        [Test]
        public void Calculo_Tipo2SemGrupoDeCalculoInvalido_DeveRetornarComErro()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(Convert.ToDateTime("05-12-2017"));
            _calendario.Setup(s => s.ObterCalendarioEntreDatas(Convert.ToDateTime("02-12-2017"), Convert.ToDateTime("05-12-2017"), "00018")).Returns(new Calendarios.Calendario() { QuantidadeDiasUteis = 2 });

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("05-12-2017");

            var result = CalculoDeBoleto.Calcular(2,
                Convert.ToDateTime("02-12-2017"),
                    280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 5
                },
                new GrupoValores()
                {
                    Codigo = 2,
                    ValorPercentual = 2
                },
                new List<GrupoValores>(),
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.IsSuccess);
        }

        [Test]
        public void Calculo_Tipo2Desconto_DeveRetornarComSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(Convert.ToDateTime("02-12-2017"));

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            DateTime dataPagamento = Convert.ToDateTime("02-12-2017");
            decimal _valorRetorno = 984M;

            var result = CalculoDeBoleto.Calcular(2,
                Convert.ToDateTime("09-12-2017"),
                    1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 5
                },
                new GrupoValores()
                {
                    Codigo = 2,
                    ValorPercentual = 2
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 3,
                        ValorPercentual = 2
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_Tipo2Juros_DeveRetornarComSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("08-12-2017"), "00018")).Returns(Convert.ToDateTime("08-12-2017"));
            _calendario.Setup(s => s.ObterCalendarioEntreDatas(Convert.ToDateTime("08-12-2017"), Convert.ToDateTime("10-12-2017"), "00018")).Returns(new Calendarios.Calendario() { QuantidadeDiasUteis = 2, Feriados = new List<Calendarios.Feriado>() });


            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            DateTime dataPagamento = Convert.ToDateTime("10-12-2017");
            decimal _valorRetorno = 248M;

            var result = CalculoDeBoleto.Calcular(2,
                            Convert.ToDateTime("07-12-2017"),
                             280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            new GrupoValores(),
                            new GrupoValores(),
                            new List<GrupoValores>()
                            {
                                new GrupoValores()
                                {
                                    Codigo = 1,
                                    Data = Convert.ToDateTime("06-12-2017"),
                                    ValorPercentual = 80
                                }
                            },
                            new List<GrupoCalculo>()
                            {
                                new GrupoCalculo()
                                {
                                    DataValidadeCalculo = Convert.ToDateTime("08-12-2017"),
                                    ValorCalculadoJuros = 1,
                                    ValorCalculadoMulta = 5
                                },
                                new GrupoCalculo()
                                {
                                    DataValidadeCalculo = Convert.ToDateTime("09-12-2017"),
                                    ValorCalculadoJuros = 2,
                                    ValorCalculadoMulta = 5
                                },
                                new GrupoCalculo()
                                {
                                    DataValidadeCalculo = Convert.ToDateTime("10-12-2017"),
                                    ValorCalculadoJuros = 3,
                                    ValorCalculadoMulta = 5
                                },
                                new GrupoCalculo()
                                {
                                    DataValidadeCalculo = Convert.ToDateTime("11-12-2017"),
                                    ValorCalculadoJuros = 4,
                                    ValorCalculadoMulta = 5
                                },
                                new GrupoCalculo()
                                {
                                    DataValidadeCalculo = Convert.ToDateTime("12-12-2017"),
                                    ValorCalculadoJuros = 5,
                                    ValorCalculadoMulta = 5
                                }
                            },
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_Tipo2Juros_BoletoSemGrupoJuros_SemGrupoCalculo_DeveRetornarComErro()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("07-12-2017"), "00018")).Returns(Convert.ToDateTime("07-12-2017"));
            _calendario.Setup(s => s.ObterCalendarioEntreDatas(Convert.ToDateTime("07-12-2017"), Convert.ToDateTime("10-12-2017"), "00018")).Returns(new Calendarios.Calendario() { QuantidadeDiasUteis = 3 });

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            DateTime dataPagamento = Convert.ToDateTime("10-12-2017");

            var result = CalculoDeBoleto.Calcular(2,
                            Convert.ToDateTime("07-12-2017"),
                            280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                            null,
                            new GrupoValores(),
                            new List<GrupoValores>()
                            {
                                new GrupoValores()
                                {
                                    Codigo = 1,
                                    Data = Convert.ToDateTime("06-12-2017"),
                                    ValorPercentual = 80
                                }
                            },
                            new List<GrupoCalculo>(),
                            dataPagamento,
                            _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.IsSuccess);
        }
    }
}