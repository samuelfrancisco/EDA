﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Boletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Clientes;
using COP.ESB.Pagamento.Dominio.Clientes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Titulares;
using COP.ESB.Pagamento.Dominio.Titulares.Services.Interfaces;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{
    [TestFixture]
    public class ConsultaDeBoletoTests
    {
        #region Settings

        private long _empresaAplicacaoId = 4;
        private long _empresaAplicacaoTransacaoId = 1;
        private string _codigoDaColigada = "001";
        private string _codigoDaAgencia = "00020";
        private string _codigoDaPraca = "00011";
        private XmlDocument _xmlDocument = new XmlDocument
        {
            InnerXml = @"<DDA0110R1>
<CodMsg>DDA0110R1</CodMsg>
<NumCtrlPart>DDA20171220000049305</NumCtrlPart>
<ISPBPartRecbdrPrincipal>68900810</ISPBPartRecbdrPrincipal>
<ISPBPartRecbdrAdmtd>68900810</ISPBPartRecbdrAdmtd>
<NumCtrlDDA>20171220000080647540</NumCtrlDDA>
<NumIdentcTit>2017061700001844240</NumIdentcTit>
<NumRefAtlCadTit>1511078767417001119</NumRefAtlCadTit>
<NumSeqAtlzCadTit>2</NumSeqAtlzCadTit>
<DtHrSitTit>2017-11-19T06:06:07</DtHrSitTit>
<ISPBPartDestinatario>60701190</ISPBPartDestinatario>
<CodPartDestinatario>341</CodPartDestinatario>
<TpPessoaBenfcrioOr>J</TpPessoaBenfcrioOr>
<CNPJ_CPFBenfcrioOr>60701190000104</CNPJ_CPFBenfcrioOr>
<Nom_RzSocBenfcrioOr>BANCO ITAU S.A.</Nom_RzSocBenfcrioOr>
<NomFantsBenfcrioOr>BANCO ITAU S.A.</NomFantsBenfcrioOr>
<LogradBenfcrioOr>PCA ALFREDO E S ARANHA, 100 BL B 5A</LogradBenfcrioOr>
<CidBenfcrioOr>SAO PAULO</CidBenfcrioOr>
<UFBenfcrioOr>SP</UFBenfcrioOr>
<CEPBenfcrioOr>4344902</CEPBenfcrioOr>
<TpPessoaBenfcrioFinl>J</TpPessoaBenfcrioFinl>
<CNPJ_CPFBenfcrioFinl>60701190000104</CNPJ_CPFBenfcrioFinl>
<Nom_RzSocBenfcrioFinl>BANCO ITAU S.A.</Nom_RzSocBenfcrioFinl>
<NomFantsBenfcrioFinl>BANCO ITAU S.A.</NomFantsBenfcrioFinl>
<TpPessoaPagdr>J</TpPessoaPagdr>
<CNPJ_CPFPagdr>61739003986</CNPJ_CPFPagdr>
<Nom_RzSocPagdr>IND. LUIZ FIGUEIRA</Nom_RzSocPagdr>
<NomFantsPagdr>IND. LUIZ FIGUEIRA</NomFantsPagdr>
<CodMoedaCNAB>09</CodMoedaCNAB>
<NumCodBarras>34194728000144783220320116542280000000000000</NumCodBarras>
<NumLinhaDigtvl>34190320101654228000900000000000472800014478322</NumLinhaDigtvl>
<DtVencTit>2017-09-12</DtVencTit>
<VlrTit>144783.22</VlrTit>
<CodEspTit>99</CodEspTit>
<DtLimPgtoTit>2017-11-11</DtLimPgtoTit>
<IndrBloqPgto>N</IndrBloqPgto>
<IndrPgtoParcl>N</IndrPgtoParcl>
<VlrAbattTit>0.00</VlrAbattTit>
<Grupo_DDA0110R1_JurosTit>
<DtJurosTit>2017-09-13</DtJurosTit>
<CodJurosTit>3</CodJurosTit>
<Vlr_PercJurosTit>2.63000</Vlr_PercJurosTit>
</Grupo_DDA0110R1_JurosTit>
<Grupo_DDA0110R1_MultaTit>
<DtMultaTit>2017-09-13</DtMultaTit>
<CodMultaTit>1</CodMultaTit>
<Vlr_PercMultaTit>2.00</Vlr_PercMultaTit>
</Grupo_DDA0110R1_MultaTit>
<Grupo_DDA0110R1_DesctTit>
<CodDesctTit>0</CodDesctTit>
<Vlr_PercDesctTit>0.00</Vlr_PercDesctTit>
</Grupo_DDA0110R1_DesctTit>
<TpModlCalc>03</TpModlCalc>
<TpAutcRecbtVlrDivgte>3</TpAutcRecbtVlrDivgte>
<Grupo_DDA0110R1_Calc>
<VlrCalcdJuros>0.00</VlrCalcdJuros>
<VlrCalcdMulta>0.00</VlrCalcdMulta>
<VlrCalcdDesct>0.00</VlrCalcdDesct>
<VlrTotCobrar>138300.19</VlrTotCobrar>
<DtValiddCalc>2017-06-19</DtValiddCalc>
</Grupo_DDA0110R1_Calc>
<Grupo_DDA0110R1_BaixaEft>
<NumIdentcBaixaEft>2017111900002588596</NumIdentcBaixaEft>
<NumRefAtlBaixaEft>1511078768664001119</NumRefAtlBaixaEft>
<NumSeqAtlzBaixaEft>1</NumSeqAtlzBaixaEft>
<DtProcBaixaEft>2017-11-19</DtProcBaixaEft>
<DtHrProcBaixaEft>2017-11-19T06:06:08</DtHrProcBaixaEft>
<NumCodBarrasBaixaEft>34194728000144783220320116542280000000000000</NumCodBarrasBaixaEft>
<DtHrSitBaixaEft>2017-11-19T06:06:09</DtHrSitBaixaEft>
</Grupo_DDA0110R1_BaixaEft>
<SitTitPgto>01</SitTitPgto>
<DtHrDDA>2017-12-20T16:10:51</DtHrDDA>
<DtMovto>2017-12-20</DtMovto>
</DDA0110R1>"
        };

        private Mock<ConfiguracoesDaEmpresaAplicacaoTransacao> _configuracoesDaEmpresaAplicacaoTransacaoMock;
        private Mock<ConfiguracoesDeBoletos> _configuracoesDeBoletosMock;
        private Mock<ConfiguracoesDoMotor> _configuracoesDoMotorMock;
        private Mock<IConfiguracoesDoMotorService> _configuracoesDoMotorServiceMock;

        private void IniciarConfiguracoesDoMotor()
        {
            _configuracoesDaEmpresaAplicacaoTransacaoMock = new Mock<ConfiguracoesDaEmpresaAplicacaoTransacao>();
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoTransacaoId).Returns(_empresaAplicacaoTransacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.EmpresaAplicacaoId).Returns(_empresaAplicacaoId);
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDaEmpresaAplicacaoTransacaoMock.SetupGet(x => x.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));

            _configuracoesDeBoletosMock = new Mock<ConfiguracoesDeBoletos>();
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioInicial).Returns(DateTime.Now.TimeOfDay.Subtract(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.HorarioFinal).Returns(DateTime.Now.TimeOfDay.Add(TimeSpan.FromMinutes(1)));
            _configuracoesDeBoletosMock.SetupGet(x => x.ValorMaximoAceitoEmContingencia).Returns(5000);
            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes)
                .Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao> { _configuracoesDaEmpresaAplicacaoTransacaoMock.Object });

            _configuracoesDoMotorMock = new Mock<ConfiguracoesDoMotor>();
            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns(_configuracoesDeBoletosMock.Object);

            _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            _configuracoesDoMotorServiceMock.SetupGet(x => x.ConfiguracoesDoMotor).Returns(_configuracoesDoMotorMock.Object);
        }

        #endregion        

        [Test]
        public void IniciarNovaConsulta_ComCommandoComTodosOsValoresNulos_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaServiceMock = new Mock<IAgenciaService>();

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2();

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Coligada inválida.") == 3);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Agência inválida.") == 3);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 2);            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {command.EmpresaAplicacaoId}."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoValido_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaServiceMock = new Mock<IAgenciaService>();

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2 { EmpresaAplicacaoId = _empresaAplicacaoId };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Coligada inválida.") == 3);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Agência inválida.") == 3);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 2);            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoEColigadaValidos_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaServiceMock = new Mock<IAgenciaService>();

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2 { EmpresaAplicacaoId = _empresaAplicacaoId, Coligada = "001" };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Agência inválida.") == 3);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 2);            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoColigadaEAgenciaValidos_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaServiceMock = new Mock<IAgenciaService>();

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = "001",
                Agencia = "00055"
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);            

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Agência inválida.") == 1);
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 2);            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoColigadaAgenciaValidosEAgenciaExistente_DeveRetornarResultComErros()
        {
            var coligada = "001";
            var agencia = "00055";
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);            

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 2);            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoAgenciaValidaEConta_DeveRetornarResultComErros()
        {
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();

            var titularServiceMock = new Mock<ITitularService>();

            var clienteServiceMock = new Mock<IClienteService>();

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);            

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsTrue(result.ErroMessage.Errors.Count(x => x.Message == "Conta corrente inválida.") == 1);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."));            
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComIdDaEmpresaAplicacaoTransacaoAgenciaEContaValidos_DeveRetornarResultComErros()
        {
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object, 
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);            

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Cliente inválido."));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }        

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEDataDePagamentoNula_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = dataDeProcessamento.AddDays(-1);
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = null
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação x Transação {0}", empresaAplicacaoTransacaoId)));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEDataDePagamentoInvalida_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = dataDeProcessamento.AddDays(-1);
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = "AAAA"
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação x Transação {0}", empresaAplicacaoTransacaoId)));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEDataDePagamentoMenorQueADataAtual_DeveRetornarResultComErros()
        {
            var dataDeProcessamento = DateTime.Today;
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = dataDeProcessamento.AddDays(-1);
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação x Transação {0}", empresaAplicacaoTransacaoId)));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEmContingenciaEBoletoVencido_DeveRetornarResultComErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;            
            var dataDeVencimento = dataDeProcessamento.AddDays(-1);

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var valorDoBoleto = _configuracoesDeBoletosMock.Object.ValorMaximoAceitoEmContingencia;

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação x Transação {0}", empresaAplicacaoTransacaoId)));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Não é permitido consultar boletos vencidos em contingência."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEmContingenciaEValorMaiorQueOAceitoEmContingencia_DeveRetornarResultComErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;            
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var valorDoBoleto = _configuracoesDeBoletosMock.Object.ValorMaximoAceitoEmContingencia + 1;

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Empresa X Aplicação X Transação inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Data de pagamento inválida."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento de boletos não liberado para a transação Boletos."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == string.Format("Pagamento de boletos não liberado para a Empresa x Aplicação x Transação {0}", empresaAplicacaoTransacaoId)));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Não é permitido consultar boletos vencidos em contingência."));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor de pagamento superior ao limite para pagamento em contingência."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEAgenciaInexistente_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var dataDeVencimento = dataDeProcessamento;
            var valorDoBoleto = 0;

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync((Agencia)null);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();            

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);                       
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEAgenciaInativa_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var dataDeVencimento = dataDeProcessamento;
            var valorDoBoleto = 0;

            var agenciaMock = new Mock<Agencia>();            

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEContaInexistente_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync((Conta)null);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEContaInativa_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();            
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidosEContaEmStatusDiferenteDeATI_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente não está ATIVA."));
        }

        [Test]
        public void IniciarNovaConsulta_SemTransacaoBoletosConfiguradaParaAEmpresaAplicacao_DeveRetornarResultComErros()
        {
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes).Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao>());

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {_empresaAplicacaoId}."));
        }

        [Test]
        public void IniciarNovaConsulta_ComTodosOsParametrosValidos_DeveRetornarResultSemErros()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is ConsultaDeBoleto);
            Assert.IsTrue(result.Value?.CodigoDaAgencia == agencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == coligada);
            Assert.IsTrue(result.Value?.DataDePagamento == dataDePagamento);
            Assert.IsTrue(result.Value?.DataDeProcessamento == dataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.Status == ConsultaDeBoletoStatus.EmConsulta);
            Assert.IsTrue(result.Value?.FoiRealizadaEmContingencia == false);
            Assert.IsTrue(result.Value?.EBoletoSemRegistro == false);
        }

        [Test]
        public void IniciarNovaConsulta_ComMotorEmContingencia_DeveRetornarQueFoiRealizadaEmContingencia()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.EstaEmContingencia).Returns(true);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is ConsultaDeBoleto);
            Assert.IsTrue(result.Value?.CodigoDaAgencia == agencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == coligada);
            Assert.IsTrue(result.Value?.DataDePagamento == dataDePagamento);
            Assert.IsTrue(result.Value?.DataDeProcessamento == dataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.Status == ConsultaDeBoletoStatus.Consultado);
            Assert.IsTrue(result.Value?.FoiRealizadaEmContingencia == true);
            Assert.IsTrue(result.Value?.EBoletoSemRegistro == false);
        }

        [Test]
        public void IniciarNovaConsulta_ComLimiteParaBoletosNaoRegistradosEValorMenorQueOLimiteParaBoletosNaoRegistrados_DeveRetornarQueEBoletoSemRegistro()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 5000;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ValorPermitidoSemRegistroNaCIP).Returns(valorDoBoleto + 1);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is ConsultaDeBoleto);
            Assert.IsTrue(result.Value?.CodigoDaAgencia == agencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == coligada);
            Assert.IsTrue(result.Value?.DataDePagamento == dataDePagamento);
            Assert.IsTrue(result.Value?.DataDeProcessamento == dataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.Status == ConsultaDeBoletoStatus.Consultado);
            Assert.IsTrue(result.Value?.EBoletoSemRegistro == true);
        }

        [Test]
        public void IniciarNovaConsulta_ComLimiteParaBoletosNaoRegistradosEValorIgualAoLimiteParaBoletosNaoRegistrados_DeveRetornarQueEBoletoSemRegistro()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 5000;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ValorPermitidoSemRegistroNaCIP).Returns(valorDoBoleto);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is ConsultaDeBoleto);
            Assert.IsTrue(result.Value?.CodigoDaAgencia == agencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == coligada);
            Assert.IsTrue(result.Value?.DataDePagamento == dataDePagamento);
            Assert.IsTrue(result.Value?.DataDeProcessamento == dataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.Status == ConsultaDeBoletoStatus.Consultado);
            Assert.IsTrue(result.Value?.EBoletoSemRegistro == true);
        }

        [Test]
        public void IniciarNovaConsulta_ComLimiteParaBoletosNaoRegistradosEValorMaiorQueOLimiteParaBoletosNaoRegistrados_DeveRetornarQueNaoEBoletoSemRegistro()
        {
            var empresaAplicacaoTransacaoId = 1;
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 5000;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDeBoletosMock.SetupGet(x => x.ValorPermitidoSemRegistroNaCIP).Returns(valorDoBoleto - 1);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is ConsultaDeBoleto);
            Assert.IsTrue(result.Value?.CodigoDaAgencia == agencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == coligada);
            Assert.IsTrue(result.Value?.DataDePagamento == dataDePagamento);
            Assert.IsTrue(result.Value?.DataDeProcessamento == dataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.Status == ConsultaDeBoletoStatus.EmConsulta);
            Assert.IsTrue(result.Value?.EBoletoSemRegistro == false);
        }

        [Test]
        public void IniciarNovaConsulta_SemTransacaoBoletosConfigurada_DeveRetornarResultComErros()
        {            
            var coligada = "001";
            var agencia = "00055";
            var conta = "4358480000";
            var codigoDoCliente = "ABCDEF";
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var valorDoBoleto = 0;
            var dataDeVencimento = dataDeProcessamento;

            var agenciaMock = new Mock<Agencia>();
            agenciaMock.SetupGet(x => x.Active).Returns(true);

            var contaMock = new Mock<Conta>();
            contaMock.SetupGet(x => x.Active).Returns(true);
            contaMock.SetupGet(x => x.CodSituacao).Returns("ATI");

            var titularMock = new Mock<Titular>();
            titularMock.SetupGet(x => x.Active).Returns(true);
            titularMock.SetupGet(x => x.CodigoDoCliente).Returns(codigoDoCliente);

            var clienteMock = new Mock<Cliente>();
            clienteMock.SetupGet(x => x.Active).Returns(true);

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(coligada, agencia))
                .ReturnsAsync(agenciaMock.Object);

            var contaServiceMock = new Mock<IContaService>();
            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(coligada, agencia, conta))
                .ReturnsAsync(contaMock.Object);

            var titularServiceMock = new Mock<ITitularService>();
            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(coligada, agencia, conta))
                .ReturnsAsync(titularMock.Object);

            var clienteServiceMock = new Mock<IClienteService>();
            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(codigoDoCliente))
                .ReturnsAsync(clienteMock.Object);

            var calendarioServiceMock = new Mock<ICalendarioService>();
            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(dataDeVencimento);

            IniciarConfiguracoesDoMotor();

            _configuracoesDoMotorMock.SetupGet(x => x.Boletos).Returns((ConfiguracoesDeBoletos)null);

            var command = new IniciarNovaConsultaDeBoletoCommandV2
            {
                EmpresaAplicacaoId = _empresaAplicacaoId,
                Coligada = coligada,
                Agencia = agencia,
                ContaCorrente = conta,
                DataDePagamento = dataDePagamento.ToString("yyyy-MM-dd")
            };

            var result = ConsultaDeBoleto.Iniciar(command, dataDeProcessamento, valorDoBoleto, dataDeVencimento, agenciaServiceMock.Object,
                contaServiceMock.Object, titularServiceMock.Object, clienteServiceMock.Object,
                calendarioServiceMock.Object, _configuracoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result?.IsFailure);
            Assert.IsTrue(result?.ErroMessage?.Errors?.Any(x => x.Message == "Não existe uma trasação Boletos configurada no sistema."));
        }        

        [Test]
        public void ConcluirComErroNaConsultaACIP_DeveAtualizarValores()
        {
            var codigoDoErro = 500;
            var descricaoDoErro = "Teste.";

            var consultaDeBoleto = Mock.Of<ConsultaDeBoleto>();

            consultaDeBoleto.ConcluirComErroNaConsultaACIP(codigoDoErro, descricaoDoErro);

            Assert.IsTrue(consultaDeBoleto.CodigoDeErro == codigoDoErro);
            Assert.IsTrue(consultaDeBoleto.DescricaoDoErro == descricaoDoErro);
            Assert.IsTrue(consultaDeBoleto.Status == ConsultaDeBoletoStatus.Rejeitado);
            Assert.IsTrue(consultaDeBoleto.FoiConcluidaComErro);
            Assert.IsNull(consultaDeBoleto.XmlRetornado);
            Assert.IsNull(consultaDeBoleto.Calculo);
        }

        [Test]
        [TestCase("S")]
        [TestCase("N")]
        public void ConcluirComErro_DeveAtualizarValores(string permiteAlterarValorTotal)
        {
            var @event = new NovaConsultaDeBoletoConcluidaComErroEvent
            {
                IdDaConsultaDeBoleto = Guid.NewGuid(),
                IdDoCalculoDeBoleto = Guid.NewGuid(),
                ValorASerCalculado = 6000,
                ValorDesconto = 100,
                ValorCalculado = 5000,
                ValorJuros = 200,
                ValorMaximoCalculado = 7000,
                ValorMinimoCalculado = 3000,
                ValorMulta = 300,
                ValorTotal = 8000,
                XmlRetornadoPelaCIP = "XML",
                CodigoDeErro = 5,
                DescricaoDoErro = "Descrição do erro",
                FoiGeradoCalculo = true,
                PermiteAlterarValorTotal = permiteAlterarValorTotal
            };

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>();

            consulta.ConcluirComErro(@event);

            Assert.IsTrue(consulta.XmlRetornado == @event.XmlRetornadoPelaCIP);
            Assert.IsTrue(consulta.Status == ConsultaDeBoletoStatus.Rejeitado);
            Assert.IsTrue(consulta.FoiConcluidaComErro);
            Assert.IsNotNull(consulta.CodigoDeErro);
            Assert.IsNotNull(consulta.DescricaoDoErro);
            Assert.IsNotNull(consulta.Calculo);
            Assert.IsTrue(consulta.Calculo?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(consulta.Calculo?.Id == @event.IdDoCalculoDeBoleto);
            Assert.IsTrue(consulta.Calculo?.ValorASerCalculado == @event.ValorASerCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorDesconto == @event.ValorDesconto);
            Assert.IsTrue(consulta.Calculo?.ValorCalculado == @event.ValorCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorJuros == @event.ValorJuros);
            Assert.IsTrue(consulta.Calculo?.ValorMaximoCalculado == @event.ValorMaximoCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorMinimoCalculado == @event.ValorMinimoCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorMulta == @event.ValorMulta);
            Assert.IsTrue(consulta.Calculo?.PermiteAlterarValorTotal == @event.PermiteAlterarValorTotal);
            Assert.IsTrue(consulta.CodigoDeErro == @event.CodigoDeErro);
            Assert.IsTrue(consulta.DescricaoDoErro == @event.DescricaoDoErro);
        }

        [Test]
        [TestCase("S")]
        [TestCase("N")]
        public void Concluir_DeveAtualizarValores(string permiteAlterarValorTotal)
        {
            var @event = new NovaConsultaDeBoletoConcluidaEvent
            {
                IdDaConsultaDeBoleto = Guid.NewGuid(),
                IdDoCalculoDeBoleto = Guid.NewGuid(),
                ValorASerCalculado = 6000,
                ValorDesconto = 100,
                ValorCalculado = 5000,
                ValorJuros = 200,
                ValorMaximoCalculado = 7000,
                ValorMinimoCalculado = 3000,
                ValorMulta = 300,
                ValorTotal = 8000,
                XmlRetornadoPelaCIP = "XML",
                PermiteAlterarValorTotal = permiteAlterarValorTotal
            };

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>();

            consulta.Concluir(@event);

            Assert.IsTrue(consulta.XmlRetornado == @event.XmlRetornadoPelaCIP);
            Assert.IsTrue(consulta.Status == ConsultaDeBoletoStatus.Consultado);
            Assert.IsFalse(consulta.FoiConcluidaComErro);
            Assert.IsNull(consulta.CodigoDeErro);
            Assert.IsNull(consulta.DescricaoDoErro);
            Assert.IsNotNull(consulta.Calculo);
            Assert.IsTrue(consulta.Calculo?.IdDaConsultaDeBoleto == @event.IdDaConsultaDeBoleto);
            Assert.IsTrue(consulta.Calculo?.Id == @event.IdDoCalculoDeBoleto);
            Assert.IsTrue(consulta.Calculo?.ValorASerCalculado == @event.ValorASerCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorDesconto == @event.ValorDesconto);
            Assert.IsTrue(consulta.Calculo?.ValorCalculado == @event.ValorCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorJuros == @event.ValorJuros);
            Assert.IsTrue(consulta.Calculo?.ValorMaximoCalculado == @event.ValorMaximoCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorMinimoCalculado == @event.ValorMinimoCalculado);
            Assert.IsTrue(consulta.Calculo?.ValorMulta == @event.ValorMulta);
            Assert.IsTrue(consulta.Calculo?.PermiteAlterarValorTotal == @event.PermiteAlterarValorTotal);
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_ComBoletoBloqueado_DeveRetornarRessultComErro()
        {
            var dataDePagamento = DateTime.Today;

            var xml = new XmlDocument { InnerXml = _xmlDocument.InnerXml };

            var node = xml.GetElementsByTagName("IndrBloqPgto").Item(0);
            node.InnerText = "S";

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                XmlRetornadoPelaCIP = xml.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
                _codigoDaAgencia, calendarioService, agenciaServiceMock.Object));

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>(x => x.DataDePagamento == dataDePagamento);

            var result = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is CalculoDeBoleto);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Boleto bloqueado para pagamento."));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_ComDataLimiteExpirada_DeveRetornarRessultComErro()
        {
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;

            var xml = new XmlDocument { InnerXml = _xmlDocument.InnerXml };

            var node = xml.GetElementsByTagName("DtLimPgtoTit").Item(0);
            node.InnerText = dataDeProcessamento.AddDays(-1).ToString("yyyy-MM-dd");

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                XmlRetornadoPelaCIP = xml.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
                _codigoDaAgencia, calendarioService, agenciaServiceMock.Object));

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>(x => x.DataDePagamento == dataDePagamento
            && x.DataDeProcessamento == dataDeProcessamento);

            var result = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is CalculoDeBoleto);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Boleto com data limite expirada."));
        }

        [Test]
        [TestCase(1, "Boleto já baixado")]
        [TestCase(2, "Boleto bloqueado para pagamento")]
        [TestCase(3, "Boleto encontrado na base centralizada e Cliente Beneficiário inapto na Instituição emissora do título.")]
        [TestCase(4, "Boleto encontrado na base e cliente Beneficiário sem cadastro")]
        [TestCase(5, "Boleto encontrado na base centralizada e Cliente Beneficiário em análise na Instituição emissora do título")]
        [TestCase(6, "Boleto excedeu o limite de pagamentos parciais")]
        [TestCase(7, "Baixa operacional integral já registrada")]
        [TestCase(9, "Boleto excedeu o valor de saldo para pagamento parcial para o tipo de modelo de cálculo 04")]
        [TestCase(10, "Boleto encontrado na base centralizada e Cliente Beneficiário inapto em Instituição diferente da emissora.")]
        [TestCase(11, "Boleto encontrado na base centralizada e Cliente Beneficiário em análise em Instituição diferente da emissora.")]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_ComSituacaoDiferenteDeDoze_DeveRetornarRessultComErro(int situacao, string descricao)
        {
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;

            var xml = new XmlDocument { InnerXml = _xmlDocument.InnerXml };

            var node = xml.GetElementsByTagName("SitTitPgto").Item(0);
            node.InnerText = situacao.ToString();

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                XmlRetornadoPelaCIP = xml.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
                _codigoDaAgencia, calendarioService, agenciaServiceMock.Object));

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>(x => x.DataDePagamento == dataDePagamento
            && x.DataDeProcessamento == dataDeProcessamento);

            var result = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is CalculoDeBoleto);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == descricao));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_ComTodasAsParcelasPagas_DeveRetornarRessultComErro()
        {
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var quantidadeDeParcelas = new Random().Next();

            var xml = new XmlDocument { InnerXml = _xmlDocument.InnerXml };

            var node = xml.GetElementsByTagName("QtdPgtoParcl").Item(0);
            if (node == null)
                node = xml.FirstChild.AppendChild(xml.CreateElement("QtdPgtoParcl"));
            node.InnerText = quantidadeDeParcelas.ToString();

            node = xml.GetElementsByTagName("QtdPgtoParclRegtd").Item(0);
            if (node == null)
                node = xml.FirstChild.AppendChild(xml.CreateElement("QtdPgtoParclRegtd"));
            node.InnerText = quantidadeDeParcelas.ToString();

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                XmlRetornadoPelaCIP = xml.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
                _codigoDaAgencia, calendarioService, agenciaServiceMock.Object));

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>(x => x.DataDePagamento == dataDePagamento
            && x.DataDeProcessamento == dataDeProcessamento);

            var result = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is CalculoDeBoleto);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Boleto excedeu a quantidade de pagamento parcial."));
        }

        [Test]
        public void ProcessarORetornoDaConsultaDoBoletoNaCIP_ComTudoCerto_DeveRetornarRessultSemErrosDaConsulta()
        {
            var dataDePagamento = DateTime.Today;
            var dataDeProcessamento = DateTime.Today;
            var quantidadeDeParcelas = new Random().Next();

            var xml = new XmlDocument { InnerXml = _xmlDocument.InnerXml };

            var node = xml.GetElementsByTagName("IndrBloqPgto").Item(0);
            node.InnerText = "N";

            node = xml.GetElementsByTagName("SitTitPgto").Item(0);
            node.InnerText = "12";

            node = xml.GetElementsByTagName("DtLimPgtoTit").Item(0);
            node.InnerText = dataDeProcessamento.AddDays(1).ToString("yyyy-MM-dd");

            node = xml.GetElementsByTagName("QtdPgtoParcl").Item(0);
            if (node == null)
                node = xml.FirstChild.AppendChild(xml.CreateElement("QtdPgtoParcl"));
            node.InnerText = "5";

            node = xml.GetElementsByTagName("QtdPgtoParclRegtd").Item(0);
            if (node == null)
                node = xml.FirstChild.AppendChild(xml.CreateElement("QtdPgtoParclRegtd"));
            node.InnerText = "4";

            var command = new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                XmlRetornadoPelaCIP = xml.InnerXml
            };

            var calendarioService = Mock.Of<ICalendarioService>();

            var agenciaServiceMock = new Mock<IAgenciaService>();
            agenciaServiceMock.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new Agencia { CodAgencia = _codigoDaAgencia, CodColigada = _codigoDaColigada, CodPraca = _codigoDaPraca });

            var servicoDeCalculoDeBoletoMock = new Mock<IServicoDeCalculoDeBoleto>();
            servicoDeCalculoDeBoletoMock.Setup(x => x.CalcularBoleto(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(() => CalculoDeBoleto.Calcular(command.XmlRetornadoPelaCIP, dataDePagamento, _codigoDaColigada,
                _codigoDaAgencia, calendarioService, agenciaServiceMock.Object));

            ConsultaDeBoleto consulta = Mock.Of<ConsultaDeBoleto>(x => x.DataDePagamento == dataDePagamento
            && x.DataDeProcessamento == dataDeProcessamento);

            var result = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoletoMock.Object);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value is CalculoDeBoleto);
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto bloqueado para pagamento."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto com data limite expirada."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto já baixado"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto bloqueado para pagamento"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto encontrado na base centralizada e Cliente Beneficiário inapto na Instituição emissora do título."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto encontrado na base e cliente Beneficiário sem cadastro"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto encontrado na base centralizada e Cliente Beneficiário em análise na Instituição emissora do título"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto excedeu o limite de pagamentos parciais"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Baixa operacional integral já registrada"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto excedeu o valor de saldo para pagamento parcial para o tipo de modelo de cálculo 04"));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto encontrado na base centralizada e Cliente Beneficiário inapto em Instituição diferente da emissora."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto encontrado na base centralizada e Cliente Beneficiário em análise em Instituição diferente da emissora."));
            Assert.IsFalse(result.ErroMessage.Errors.Any(x => x.Message == "Boleto excedeu a quantidade de pagamento parcial."));
        }
    }
}
