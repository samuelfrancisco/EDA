﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{

    [TestFixture]
    public class CalculoTipo4DeBoletoTests
    {
        [Test]
        public void Calculo_SemAbatimentoIsentoJurosIsentoMultaIsentoDesconto_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("02-01-2017");
            decimal _valorRetorno = 1000M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 5,
                    ValorPercentual = 0
                },
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 0
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        ValorPercentual = 0
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_ComAbatimentoIsentoJurosIsentoMultaIsentoDesconto_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("02-01-2017");
            decimal _valorRetorno = 900M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 100, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 5,
                    ValorPercentual = 0
                },
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 0
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        ValorPercentual = 0
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_SemAbatimentoIsentoJurosIsentoMultaComDesconto_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-01-2017"), "00018")).Returns(Convert.ToDateTime("02-01-2017"));

            DateTime dataPagamento = Convert.ToDateTime("02-01-2017");
            decimal _valorRetorno = 980M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 5,
                    ValorPercentual = 0
                },
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 0
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 1,
                        ValorPercentual = 20
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_SemAbatimentoIsentoJurosIsentoMultaComDescontoAteDataVencimento_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("09-01-2017"), "00018")).Returns(Convert.ToDateTime("09-01-2017"));

            DateTime dataPagamento = Convert.ToDateTime("02-01-2017");
            decimal _valorRetorno = 970M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 5,
                    ValorPercentual = 0
                },
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 0
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Data = Convert.ToDateTime("02-01-2017"),
                        Codigo = 1,
                        ValorPercentual = 30
                    },
                    new GrupoValores()
                    {
                        Codigo = 1,
                        ValorPercentual = 20
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_IndicadorPgtoParcialSemAbatimentoIsentoJurosIsentoMultaComDescontoComBaixaOp_SemGrupoCalculado_ComSaldoInformado_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("02-01-2017");
            decimal _valorRetorno = 880M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 880,
                new GrupoValores()
                {
                    Codigo = 5,
                    ValorPercentual = 0
                },
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 0
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 3,
                        ValorPercentual = 2
                    }
                },
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_IndicadorPgtoParcialSemAbatimentoComJurosComMultaSemDescontoComBaixaOp_ComGrupoCalculado_ComSaldoInformado_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("16-01-2017");
            decimal _valorRetorno = 924.13M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 924.13M,
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("10-01-2017"),
                    Codigo = 1,
                    ValorPercentual = 2.59M
                },
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("10-01-2017"),
                    Codigo = 1,
                    ValorPercentual = 26
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        ValorPercentual = 0
                    }
                },
                new List<GrupoCalculo>()
                {
                    new GrupoCalculo()
                    {
                        DataValidadeCalculo = Convert.ToDateTime("16-01-2017"),
                        ValorTotalCobrar = 924.13M
                    }
                },
                dataPagamento,
                _calendario.Object,
                new List<GrupoBaixa>()
                {
                    new GrupoBaixa()
                    {
                        Valor = 120
                    }
                }, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_IndicadorPgtoParcialSemAbatimentoComJurosComMultaSemDescontoComBaixaOp_SemGrupoCalculado_ComSaldoInformado_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("10-01-2017"), "00018")).Returns(Convert.ToDateTime("10-01-2017"));

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("09-01-2017");
            decimal _valorRetorno = 880M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("09-01-2017"),
                1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,// 880M,
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("10-01-2017"),
                    Codigo = 1,
                    ValorPercentual = 2.59M
                },
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("10-01-2017"),
                    Codigo = 1,
                    ValorPercentual = 26
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 0,
                        ValorPercentual = 0
                    }
                },
                new List<GrupoCalculo>()
                {

                },
                dataPagamento,
                _calendario.Object,
                new List<GrupoBaixa>()
                {
                    new GrupoBaixa()
                    {
                        Valor = 120
                    }
                }, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));

        }

        [Test]
        public void Calculo_BoletoVencido_ComGrupoCalculo_CdBarras_75692728200007583321306601000481200866594014_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("13-12-2017");
            decimal _valorRetorno = 7919.36M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("14-09-2017"),
                7583.32M, 3, "N", 0, 0, 15.11M, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("15-09-2017"),
                    Codigo = 3,
                    ValorPercentual = 1.51000M
                },
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("15-09-2017"),
                    Codigo = 2,
                    ValorPercentual = 0.11000M
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {

                        Data = Convert.ToDateTime("11-09-2017"),
                        Codigo = 1,
                        ValorPercentual = 1440.83M
                    }
                },
                new List<GrupoCalculo>()
                {
                    new GrupoCalculo()
                    {
                        ValorCalculadoJuros = 342.83M,
                        ValorCalculadoMulta = 8.32M,
                        ValorCalculadoDesconto = 0M,
                        ValorTotalCobrar = 7919.36M,
                        DataValidadeCalculo =  Convert.ToDateTime("13-12-2017"),
                    }
                },
                dataPagamento,
                _calendario.Object,
                new List<GrupoBaixa>() { }, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_BoletoVencido_SemGrupoCalculo_CdBarras_13696728200000180005651000074476100000001031_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("15-09-2017"), "00018")).Returns(Convert.ToDateTime("15-09-2017"));
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("13-12-2017");
            decimal _valorRetorno = 188.99M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("14-09-2017"),
                180M, 2, "N", 0, 0, 0M, "V", 180, "V", 999999999999.99M, 0,
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("15-09-2017"),
                    Codigo = 3,
                    ValorPercentual = 1.00000M
                },
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("15-09-2017"),
                    Codigo = 2,
                    ValorPercentual = 2.00000M
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo =0,
                        ValorPercentual = 0M
                    }
                },
                new List<GrupoCalculo>() { },
                dataPagamento,
                _calendario.Object,
                    new List<GrupoBaixa>() { }, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_BoletoVencido_ComGrupoCalculo_CdBarras_75691728500015542001306601000481200863076007_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("13-12-2017");
            decimal _valorRetorno = 18952.68M;

            var result = CalculoDeBoleto.Calcular(4,
                Convert.ToDateTime("17-09-2017"),
                15542M, 1, "S", 0, 2, 1985M, "P", 35, "V", 999999999999.99M, 18952.68M,
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("18-09-2017"),
                    Codigo = 3,
                    ValorPercentual = 12.00000M
                },
                new GrupoValores()
                {
                    Data = Convert.ToDateTime("18-09-2017"),
                    Codigo = 2,
                    ValorPercentual = 5.00000M
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo =0,
                        ValorPercentual = 0M
                    }
                },
                new List<GrupoCalculo>()
                {
                    new GrupoCalculo()
                    {
                        ValorCalculadoJuros = 4717.83M,
                        ValorCalculadoMulta = 677.85M,
                        ValorCalculadoDesconto = 0,
                        ValorTotalCobrar    = 18952.68M,
                        DataValidadeCalculo =  Convert.ToDateTime("13-12-2017"),
                    }
                },
                dataPagamento,
                _calendario.Object,
                new List<GrupoBaixa>() { }, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }
    }
}