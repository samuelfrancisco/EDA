﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Tests.Boletos
{

    [TestFixture]
    public class CalculoTipo3DeBoletoTests
    {
        [Test]
        public void Calculo_Tipo3SemGrupoDeCalculoValido_DeveRetornarComErro()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.DiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(true);

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));

            DateTime dataPagamento = Convert.ToDateTime("05-12-2017");

            var result = CalculoDeBoleto.Calcular(3,
                Convert.ToDateTime("02-12-2017"),
                    280, 1, "N", 0, 0, 40, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 3,
                    ValorPercentual = 5
                },
                new GrupoValores()
                {
                    Codigo = 2,
                    ValorPercentual = 2
                },
                new List<GrupoValores>(),
                new List<GrupoCalculo>(),
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.IsFailure);
            Assert.IsFalse(result.IsSuccess);
        }

        [Test]
        public void Calculo_Tipo3AtencipacaoDeBoleto_DeveRetornarComSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("02-12-2017"), "00018")).Returns(Convert.ToDateTime("02-12-2017"));

            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            DateTime dataPagamento = Convert.ToDateTime("02-12-2017");
            decimal _valorRetorno = 990M;

            var result = CalculoDeBoleto.Calcular(3,
                Convert.ToDateTime("09-12-2017"),
                    1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                new GrupoValores()
                {
                    Codigo = 6,
                    ValorPercentual = 2.59M
                },
                new GrupoValores()
                {
                    Codigo = 1,
                    ValorPercentual = 26
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 4,
                        ValorPercentual = 2
                    }
                },
                new List<GrupoCalculo>()
                {
                    new GrupoCalculo()
                    {
                        DataValidadeCalculo = Convert.ToDateTime("02-12-2017"),
                        ValorTotalCobrar = 990
                    }
                },
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));
        }

        [Test]
        public void Calculo_Tipo3DataVencimentoNaoUtil_ComPagamentoNoProximoDiaUtil_DeveIgnorarJuros_Sucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            _calendario.Setup(s => s.ObterProximoDiaUtil(Convert.ToDateTime("09-12-2017"), "00018")).Returns(Convert.ToDateTime("10-12-2017"));
            _calendario.Setup(s => s.DiaUtil(Convert.ToDateTime("09-12-2017"), "00018")).Returns(false);
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            DateTime dataPagamento = Convert.ToDateTime("10-12-2017");
            decimal _valorRetorno = 1000M;

            var result = CalculoDeBoleto.Calcular(3,
                Convert.ToDateTime("09-12-2017"),
                    1000, 1, "N", 0, 0, 0, "V", 0, "V", 0, 0,
                    new GrupoValores()
                    {
                        Codigo = 6,
                        ValorPercentual = 2.59M
                    },
                new GrupoValores()
                {
                    Codigo = 1,
                    ValorPercentual = 26
                },
                new List<GrupoValores>()
                {
                    new GrupoValores()
                    {
                        Codigo = 4,
                        ValorPercentual = 2
                    }
                },
                new List<GrupoCalculo>()
                {
                    new GrupoCalculo()
                    {
                        DataValidadeCalculo = Convert.ToDateTime("10-12-2017"),
                        ValorTotalCobrar = 1028.59M,
                        ValorCalculadoJuros = 2.59M,
                        ValorCalculadoMulta = 26
                    }
                },
                dataPagamento,
                _calendario.Object, null, null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.Value.ValorCalculado.Equals(_valorRetorno));

        }

        [Test]
        public void Calculo_aVencer_ComGrupoCalculoSemDataDeCalculoValida_CdBarras_74592738900000000003600041174013000000011746_DeveRetornarSucesso()
        {
            Mock<ICalendarioService> _calendario = new Mock<ICalendarioService>();
            DateTime dataPagamento = Convert.ToDateTime("14-12-2017");
            Mock<IAgenciaService> _agenciaService = new Mock<IAgenciaService>();
            _agenciaService.Setup(s => s.ObterAgenciaPeloCodColigadaECodAgenciaAsync("1", "1"))
                           .Returns(Task.FromResult(new Agencia { CodAgencia = "1", CodColigada = "1", CodPraca = "00018" }));


            var result = CalculoDeBoleto.Calcular(3,
                    Convert.ToDateTime("30-12-2017"),
                    3105M, 2, "S", 4, 0, 179M, "V", 292.60M, "V", 3105M, 0M,
                    new GrupoValores()
                    {
                        Codigo = 5,
                        ValorPercentual = 0M
                    },
                    new GrupoValores()
                    {
                        Data = Convert.ToDateTime("31-12-2017"),
                        Codigo = 2,
                        ValorPercentual = 10.00000M
                    },
                    new List<GrupoValores>()
                    {
                        new GrupoValores()
                        {
                            Data = Convert.ToDateTime("01-11-2017"),
                            Codigo = 2,
                            ValorPercentual = 8.00000M
                        }
                    },
                    new List<GrupoCalculo>()
                    {
                        new GrupoCalculo()
                        {
                            ValorCalculadoJuros = 0M,
                            ValorCalculadoMulta = 0M,
                            ValorCalculadoDesconto = 843.95M,
                            ValorTotalCobrar    = 9239.84M,
                            DataValidadeCalculo =  Convert.ToDateTime("29-05-2017"),
                        }
                    },
                    dataPagamento,
                    _calendario.Object,
                    new List<GrupoBaixa>() { },  null, "1", "1", _agenciaService.Object);

            Assert.IsTrue(result.IsFailure);
        }

    }
}