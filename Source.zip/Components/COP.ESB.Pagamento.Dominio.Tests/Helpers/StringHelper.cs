﻿using System;
using System.Text;

namespace COP.ESB.Pagamento.Dominio.Tests.Helpers
{
    public class StringHelper
    {
        private static char[] UpperCaseCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
        private static char[] LowerCaseCharacters = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
        private static char[] NumericCharacters = "0123456789".ToCharArray();
        private static char[] SpecialCharacters = ",.;:?!/@#$%^&()=+*-_{}[]<>|~ \\".ToCharArray();
        private static char[] AllChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789,.;:?!/@#$%^&()=+*-_{}[]<>|~ \\".ToCharArray();

        public static string GerarStringComDigitosRandomicos(int tamanho)
        {
            var digitos = new int[tamanho];

            Random random = new Random();

            for (int i = 0; i < digitos.Length; i++)
            {
                digitos[i] = random.Next(10);
            }

            return string.Join("", digitos);
        }

        public static string GerarStringSoComEspacos(int tamanho)
        {
            var stringBuilder = new StringBuilder();

            for (int i = 0; i < tamanho; i++)
            {
                stringBuilder.Append(" ");
            }

            return stringBuilder.ToString();
        }

        public static string GerarStringComNumerosELetrasOuCaracteresEspeciais(int tamanho)
        {
            string result = string.Empty;

            Random random = new Random();

            for (int i = 0; i < tamanho; i++)
            {
                char newChar = AllChars[random.Next(65576) % AllChars.Length];

                result += newChar;
            }

            return result;
        }
    }
}
