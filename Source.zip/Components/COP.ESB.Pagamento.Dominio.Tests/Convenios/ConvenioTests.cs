﻿using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Clientes;
using COP.ESB.Pagamento.Dominio.Clientes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using COP.ESB.Pagamento.Dominio.Convenios.Enums;
using COP.ESB.Pagamento.Dominio.Convenios.Events;
using COP.ESB.Pagamento.Dominio.Convenios.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using COP.ESB.Pagamento.Dominio.Tests.Helpers;
using COP.ESB.Pagamento.Dominio.Titulares;
using COP.ESB.Pagamento.Dominio.Titulares.Services.Interfaces;
using FizzWare.NBuilder;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace COP.ESB.Pagamento.Dominio.Tests.Convenios
{
    [TestFixture]
    public class ConvenioTests
    {
        private const string CPF = "86142670702";
        private const long EmpresaAplicacaoId = 1;
        private const long EmpresaAplicacaoTransacaoId = 1;
        private const string CodigoDoSegmento = "1";
        private const string CodigoDoConvenio = "1234";
        private const string CodigoDoCanalDeProcessamento = CodigosDosCanaisDeProcessamento.CORBAN;
        private const string NomeDoCanalDeProcessamento = CodigosDosCanaisDeProcessamento.CORBAN;
        private static Mock<IConsultaDeConvenioFactory> _consultaDeConvenioFactoryMock;
        private static Mock<IAgenciaService> _agenciaServiceMock;
        private static Mock<IContaService> _contaServiceMock;
        private static Mock<ITitularService> _titularServiceMock;
        private static Mock<IClienteService> _clienteServiceMock;
        private static Mock<ICalendarioService> _calendarioServiceMock;
        private static Mock<IConfiguracoesDoMotorService> _configuracoesDoMotorServiceMock;
        private static Mock<IPagamentoDeConvenioFactory> _pagamentoDeConvenioFactoryMock;
        private static ConfiguracoesDaEmpresaAplicacaoTransacao _empresaAplicacaoTransacao;
        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> _formasDeRecebimento;
        private static ConsultaDeConvenio _consultaDeConvenio;
        private static int[] _canaisDePagamento;
        private static int[] _quantidadesDeFormas;
        private static string[] _duplicidades;
        private static readonly object _lockObject = new object();

        #region Registrar novo Convênio

        [Test]
        [TestCaseSource("RegistrarNovoConvenio_GeradorDeDadosValidos")]
        public void RegistrarNovoConvenio_ComTodosOsDadosValidos_DeveRetornarResultSemErros(RegistrarNovoConvenioCommand command,
            ICodigoDeBarrasDeConvenioFactory codigoDeBarrasDeConvenioFactory, ILinhaDigitavelDeConvenioFactory linhaDigitavelDeConvenioFactory,
            string codigoDeBarras, string linhaDigitavel)
        {
            var result = Convenio.RegistrarNovoConvenio(command, codigoDeBarrasDeConvenioFactory, linhaDigitavelDeConvenioFactory);

            var codigoDoSegmento = ObterOCodigoDoSegmentoConvenioAPartirDoCodigoDeBarras(codigoDeBarras);

            var codigoDoConvenio = ObterOCodigoDoConvenioAPartirDoCodigoDeBarras(codigoDeBarras, codigoDoSegmento);

            var valor = ObterOValorDoConvenioAPartirDoCodigoDeBarras(codigoDeBarras);

            var dataDeVencimento = ObterADataDeVencimentoAPartirDoCodigoDeBarras(codigoDeBarras, codigoDoSegmento);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value?.CodigoDeBarras?.Valor == codigoDeBarras);
            Assert.IsTrue(result.Value?.LinhaDigitavel?.Valor == linhaDigitavel);
            Assert.IsTrue(result.Value?.CodigoDoSegmento == codigoDoSegmento);
            Assert.IsTrue(result.Value?.CodigoDoConvenio == codigoDoConvenio);
            Assert.IsTrue(result.Value?.Valor == valor);
            Assert.IsTrue(result.Value?.DataDeVencimento == dataDeVencimento);
            Assert.IsTrue(result.Value?.UncommittedEvents?.Count == 1);

            var @event = result.Value?.UncommittedEvents?.FirstOrDefault() as NovoConvenioRegistradoEvent;

            Assert.IsNotNull(@event);
            Assert.IsTrue(@event?.CorrelationMessage == command);
            Assert.IsTrue(@event?.OriginalCorrelationMessage == command);
            Assert.IsTrue(@event?.SourceId == result.Value?.Id);
            Assert.IsTrue(@event?.SourceVersion == result.Value?.Version);
            Assert.IsTrue(@event?.IdDoConvenio == result.Value?.Id);
            Assert.IsTrue(@event?.CodigoDeBarras == codigoDeBarras);
            Assert.IsTrue(@event?.LinhaDigitavel == linhaDigitavel);
            Assert.IsTrue(@event?.CodigoDoSegmento == codigoDoSegmento);
            Assert.IsTrue(@event?.CodigoDoConvenio == codigoDoConvenio);
            Assert.IsTrue(@event?.Valor == valor);
            Assert.IsTrue(@event?.DataDeVencimento == dataDeVencimento);
        }

        [Test]
        [TestCaseSource("RegistrarNovoConvenio_GeradorDeCodigoDeBarrasELinhaDigitavelNulos")]
        public void RegistrarNovoConvenio_ComCodigoDeBarrasELinhaDigitavelNulos_DeveRetornarResultComErros(RegistrarNovoConvenioCommand command,
           ICodigoDeBarrasDeConvenioFactory codigoDeBarrasDeConvenioFactory, ILinhaDigitavelDeConvenioFactory linhaDigitavelDeConvenioFactory)
        {
            var result = Convenio.RegistrarNovoConvenio(command, codigoDeBarrasDeConvenioFactory, linhaDigitavelDeConvenioFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe código de barras ou linha digitável."
                && x.Reason == "O código de barras e a linha digitável estão nulos."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para o registro de novo convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RegistrarNovoConvenio_GeradorDeCodigoDeBarrasELinhaDigitavelPreenchidos")]
        public void RegistrarNovoConvenio_ComCodigoDeBarrasELinhaDigitavelPreenchidos_DeveRetornarResultComErros(RegistrarNovoConvenioCommand command,
           ICodigoDeBarrasDeConvenioFactory codigoDeBarrasDeConvenioFactory, ILinhaDigitavelDeConvenioFactory linhaDigitavelDeConvenioFactory)
        {
            var result = Convenio.RegistrarNovoConvenio(command, codigoDeBarrasDeConvenioFactory, linhaDigitavelDeConvenioFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe código de barras ou linha digitável."
                && x.Reason == "O código de barras e a linha digitável foram informados ao mesmo tempo."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para o registro de novo convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        private static IEnumerable<object[]> RegistrarNovoConvenio_GeradorDeDadosValidos()
        {
            var comandos = Builder<RegistrarNovoConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .Build()
                .ToList();

            comandos.AddRange(Builder<RegistrarNovoConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = null)
                .With(x => x.LinhaDigitavel = StringHelper.GerarStringComDigitosRandomicos(48))
                .Build());

            var objetos = (from comando in comandos
                           let codigoDeBarras = string.IsNullOrWhiteSpace(comando.CodigoDeBarras)
                                ? StringHelper.GerarStringComDigitosRandomicos(44)
                                : comando.CodigoDeBarras
                           let linhaDigitavel = string.IsNullOrWhiteSpace(comando.LinhaDigitavel)
                                ? StringHelper.GerarStringComDigitosRandomicos(48)
                                : comando.LinhaDigitavel
                           let codigoDeBarrasDeConvenioFactoryMock = new Mock<ICodigoDeBarrasDeConvenioFactory>()
                           let linhaDigitavelDeConvenioFactoryMock = new Mock<ILinhaDigitavelDeConvenioFactory>()
                           select new
                           {
                               comando,
                               codigoDeBarrasDeConvenioFactoryMock,
                               linhaDigitavelDeConvenioFactoryMock,
                               codigoDeBarras,
                               linhaDigitavel
                           }).ToList();

            objetos.ForEach(x =>
            {
                x.codigoDeBarrasDeConvenioFactoryMock.Setup(y => y.Criar(It.IsAny<string>()))
                    .Returns(new Result<CodigoDeBarrasDeConvenio>(Mock.Of<CodigoDeBarrasDeConvenio>(y => y.Valor == x.codigoDeBarras)));

                x.codigoDeBarrasDeConvenioFactoryMock.Setup(y => y.From(It.IsAny<string>()))
                    .Returns(Mock.Of<CodigoDeBarrasDeConvenio>(y => y.Valor == x.codigoDeBarras));

                x.linhaDigitavelDeConvenioFactoryMock.Setup(y => y.Criar(It.IsAny<string>()))
                    .Returns(new Result<LinhaDigitavelDeConvenio>(Mock.Of<LinhaDigitavelDeConvenio>(y => y.Valor == x.linhaDigitavel)));

                x.linhaDigitavelDeConvenioFactoryMock.Setup(y => y.From(It.IsAny<string>()))
                    .Returns(Mock.Of<LinhaDigitavelDeConvenio>(y => y.Valor == x.linhaDigitavel));
            });

            return objetos.Select(x => new object[] { x.comando, x.codigoDeBarrasDeConvenioFactoryMock.Object, x.linhaDigitavelDeConvenioFactoryMock.Object,
                x.codigoDeBarras, x.linhaDigitavel });
        }

        private static IEnumerable<object[]> RegistrarNovoConvenio_GeradorDeCodigoDeBarrasELinhaDigitavelNulos()
        {
            return new[]
            {
                new object[]
                {
                    new RegistrarNovoConvenioCommand(),
                    new Mock<ICodigoDeBarrasDeConvenioFactory>().Object,
                    new Mock<ILinhaDigitavelDeConvenioFactory>().Object
                }
            };
        }

        private static IEnumerable<object[]> RegistrarNovoConvenio_GeradorDeCodigoDeBarrasELinhaDigitavelPreenchidos()
        {
            var comandos = Builder<RegistrarNovoConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .With(x => x.LinhaDigitavel = StringHelper.GerarStringComDigitosRandomicos(48))
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           let codigoDeBarras = string.IsNullOrWhiteSpace(comando.CodigoDeBarras)
                                ? StringHelper.GerarStringComDigitosRandomicos(44)
                                : comando.CodigoDeBarras
                           let linhaDigitavel = string.IsNullOrWhiteSpace(comando.LinhaDigitavel)
                                ? StringHelper.GerarStringComDigitosRandomicos(48)
                                : comando.LinhaDigitavel
                           let codigoDeBarrasDeConvenioFactoryMock = new Mock<ICodigoDeBarrasDeConvenioFactory>()
                           let linhaDigitavelDeConvenioFactoryMock = new Mock<ILinhaDigitavelDeConvenioFactory>()
                           select new
                           {
                               comando,
                               codigoDeBarrasDeConvenioFactoryMock,
                               linhaDigitavelDeConvenioFactoryMock,
                               codigoDeBarras,
                               linhaDigitavel
                           }).ToList();

            objetos.ForEach(x =>
            {
                x.codigoDeBarrasDeConvenioFactoryMock.Setup(y => y.Criar(It.IsAny<string>()))
                    .Returns(new Result<CodigoDeBarrasDeConvenio>(Mock.Of<CodigoDeBarrasDeConvenio>(y => y.Valor == x.codigoDeBarras)));

                x.codigoDeBarrasDeConvenioFactoryMock.Setup(y => y.From(It.IsAny<string>()))
                    .Returns(Mock.Of<CodigoDeBarrasDeConvenio>(y => y.Valor == x.codigoDeBarras));

                x.linhaDigitavelDeConvenioFactoryMock.Setup(y => y.Criar(It.IsAny<string>()))
                    .Returns(new Result<LinhaDigitavelDeConvenio>(Mock.Of<LinhaDigitavelDeConvenio>(y => y.Valor == x.linhaDigitavel)));

                x.linhaDigitavelDeConvenioFactoryMock.Setup(y => y.From(It.IsAny<string>()))
                    .Returns(Mock.Of<LinhaDigitavelDeConvenio>(y => y.Valor == x.linhaDigitavel));
            });

            return objetos.Select(x => new object[] { x.comando, x.codigoDeBarrasDeConvenioFactoryMock.Object, x.linhaDigitavelDeConvenioFactoryMock.Object });
        }

        #endregion

        #region Realizar nova Consulta

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeDadosValidos")]
        public void RealizarNovaConsulta_ComTodosOsDadosValidos_DeveRetornarResultSemErros(RealizarNovaConsultaDeConvenioCommand command,
            IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
            ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarRealizarNovaConsultaComResultSemErros(command, calendarioService, convenio, result);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioSemTransacaoConveniosCadastrada")]
        public void RealizarNovaConsulta_SemTransacaoConveniosCadastrada_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Transação inválida."
               && x.Reason == "Não existe uma trasação Convênios configurada no sistema."));
            Assert.IsTrue(result.ErroMessage.Message == "Canal de processamento indisponível.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioSemConvenioCadastrado")]
        public void RealizarNovaConsulta_SemConvenioCadastrado_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Convênio inválido."
               && x.Reason == $"O sistema não aceita convênios com o código {CodigoDoConvenio} para o segmento {CodigoDoSegmento}."));
            Assert.IsTrue(result.ErroMessage.Message == "Canal de processamento indisponível.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioSemUmCanalDeProcessamentoCadastrado")]
        public void RealizarNovaConsulta_SemUmCanalDeProcessamentoCadastrado_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Message == "Canal de processamento indisponível.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComCanalDeProcessamentoEmContingenciaESemUmAlternativo")]
        public void RealizarNovaConsulta_ComCanalDeProcessamentoEmContingenciaESemUmAlternativo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Canal de processamento em contingênica."
               && x.Reason.Contains($"O canal de processamento {NomeDoCanalDeProcessamento} está em contingência.")));
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Canal de processamento indisponível."
               && x.Reason == $"Nenhum canal de processamento está disponível para convênios com o código {CodigoDoConvenio}."));
            Assert.IsTrue(result.ErroMessage.Message == "Canal de processamento indisponível.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioSemUmCanalDeProcessamentoDisponivel")]
        public void RealizarNovaConsulta_SemUmCanalDeProcessamentoDisponivel_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Canal de processamento indisponível."
               && x.Reason == $"O canal de processamento {NomeDoCanalDeProcessamento} não está disponível para o convênio com o código {CodigoDoConvenio}."));
            Assert.IsTrue(result.ErroMessage.Message == "Canal de processamento indisponível.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComEmpresaAplicacaoIdInvalido")]
        public void RealizarNovaConsulta_ComEmpresaAplicacaoIdInvalido_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Não existe uma trasação Convênios configurada no sistema para a Empresa X Aplicacao = {EmpresaAplicacaoId}."
               && x.Reason == $"Não existe uma trasação Convênios configurada no sistema para a Empresa X Aplicacao = {EmpresaAplicacaoId}."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDaTransacao")]
        public void RealizarNovaConsulta_AntesDoHorarioInicialDaTransacao_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Operações com convênios não liberadas."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDaTransacao")]
        public void RealizarNovaConsulta_DepoisDoHorarioFinalDaTransacao_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Operações com convênios não liberadas."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDaEmpresaAplicacaoTransacao")]
        public void RealizarNovaConsulta_AntesDoHorarioInicialDaEmpresaAplicacaoTransacao_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para a Empresa x Aplicação {EmpresaAplicacaoId}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDaEmpresaAplicacaoTransacao")]
        public void RealizarNovaConsulta_DepoisDoHorarioFinalDaEmpresaAplicacaoTransacao_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para a Empresa x Aplicação {EmpresaAplicacaoId}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDoCanalDeProcessamento")]
        public void RealizarNovaConsulta_AntesDoHorarioInicialDoCanalDeProcessamento_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para o canal de processamento {NomeDoCanalDeProcessamento}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDoCanalDeProcessamento")]
        public void RealizarNovaConsulta_DepoisDoHorarioFinalDoCanalDeProcessamento_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para o canal de processamento {NomeDoCanalDeProcessamento}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComCodigoDaColigadaNulo")]
        public void RealizarNovaConsulta_ComCodigoDaColigadaNulo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Coligada inválida."
               && x.Reason == "Código da coligada nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComCodigoDaAgenciaNulo")]
        public void RealizarNovaConsulta_ComCodigoDaAgenciaNulo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."
               && x.Reason == "Código da agência nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComNumeroDaContaNulo")]
        public void RealizarNovaConsulta_ComNumeroDaContaNulo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Número da conta corrente nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComAgenciaInvalida")]
        public void RealizarNovaConsulta_ComAgenciaInvalida_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."
               && x.Reason == "Agência não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComAgenciaInativa")]
        public void RealizarNovaConsulta_ComAgenciaInativa_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."
               && x.Reason == "Agência não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComContaInvalida")]
        public void RealizarNovaConsulta_ComContaInvalida_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComContaInativa")]
        public void RealizarNovaConsulta_ComContaInativa_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComContaEmSituacaoDiferenteDeATI")]
        public void RealizarNovaConsulta_ComContaEmSituacaoDiferenteDeATI_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não está ATIVA."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComTitularInvalido")]
        public void RealizarNovaConsulta_ComTitularInvalido_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."
               && x.Reason == "Titular não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComTitularInativo")]
        public void RealizarNovaConsulta_ComTitularInativo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."
               && x.Reason == "Titular não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComClienteInvalido")]
        public void RealizarNovaConsulta_ComClienteInvalido_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Cliente inválido."
               && x.Reason == "Cliente não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComClienteInativo")]
        public void RealizarNovaConsulta_ComClienteInativo_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Cliente inválido."
               && x.Reason == "Cliente não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMenorQueADataAtual")]
        public void RealizarNovaConsulta_ComDataDeVencimentoMenorQueDataAAtual_DeveRetornarResultComErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var dataDeVencimento = DateTime.Today.AddDays(-1);

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Documento vencido em { dataDeVencimento.ToString("dd/MM/yyyy")}."
               && x.Reason == $"Documento vencido em { dataDeVencimento.ToString("dd/MM/yyyy")}."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a realização de nova consulta de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoIgualADataAtual")]
        public void RealizarNovaConsulta_ComDataDeVencimentoIgualADataAtual_DeveRetornarResultSemErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var dataDeVencimento = DateTime.Today;

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarRealizarNovaConsultaComResultSemErros(command, calendarioService, convenio, result);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMaiorQueADataAtual")]
        public void RealizarNovaConsulta_ComDataDeVencimentoMaiorQueADataAtual_DeveRetornarResultSemErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var dataDeVencimento = DateTime.Today;

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarRealizarNovaConsultaComResultSemErros(command, calendarioService, convenio, result);
        }

        [Test]
        [TestCaseSource("RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMenorQueDataAAtualEMaisAntigaQueCincoAnos")]
        public void RealizarNovaConsulta_ComDataDeVencimentoMenorQueDataAAtualEMaisAntigaQueCincoAnos_DeveRetornarResultSemErros(RealizarNovaConsultaDeConvenioCommand command,
           IConsultaDeConvenioFactory consultaDeConvenioFactory, IAgenciaService agenciaService, IContaService contaService,
           ITitularService titularService, IClienteService clienteService, ICalendarioService calendarioService,
           IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var dataDeVencimento = DateTime.Today.AddYears(-5).AddDays(-1);

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDeBarras.Valor == command.CodigoDeBarras
            && x.CodigoDoConvenio == CodigoDoConvenio && x.CodigoDoSegmento == CodigoDoSegmento
            && x.Consultas == new List<ConsultaDeConvenio>() && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.RealizarNovaConsulta(command, consultaDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarRealizarNovaConsultaComResultSemErros(command, calendarioService, convenio, result);
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeDadosValidos()
        {
            RealizarNovaConsulta_Inicilizacao();

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioSemTransacaoConveniosCadastrada()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioSemConvenioCadastrado()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes)
                .Returns(new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioSemUmCanalDeProcessamentoCadastrado()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true && y.Codigo == CodigoDoSegmento);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComCanalDeProcessamentoEmContingenciaESemUmAlternativo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento
            && x.EstaEmContingencia == true);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioSemUmCanalDeProcessamentoDisponivel()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>();

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComEmpresaAplicacaoIdInvalido()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>();

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDaTransacao()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDaTransacao()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDaEmpresaAplicacaoTransacao()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDaEmpresaAplicacaoTransacao()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioAntesDoHorarioInicialDoCanalDeProcessamento()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
            && x.Nome == NomeDoCanalDeProcessamento && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioDepoisDoHorarioFinalDoCanalDeProcessamento()
        {
            RealizarNovaConsulta_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
            && x.Nome == NomeDoCanalDeProcessamento && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
            && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                {
                            Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                            && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay)
                };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComCodigoDaColigadaNulo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .And(x => x.CodigoDaColigada = null)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComCodigoDaAgenciaNulo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .And(x => x.CodigoDaAgencia = null)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComNumeroDaContaNulo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .And(x => x.NumeroDaContaCorrente = null)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComAgenciaInvalida()
        {
            RealizarNovaConsulta_Inicilizacao();

            var agenciaServiceMock = new Mock<IAgenciaService>();

            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                {
                    return null;
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComAgenciaInativa()
        {
            RealizarNovaConsulta_Inicilizacao();

            var agenciaServiceMock = new Mock<IAgenciaService>();

            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                {
                    return Mock.Of<Agencia>(x => x.Active == false && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda);
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComContaInvalida()
        {
            RealizarNovaConsulta_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return null;
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComContaInativa()
        {
            RealizarNovaConsulta_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Conta>(x => x.Active == false && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                    && x.NumeroDaConta == numeroDaConta && x.CodSituacao == "ATI");
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComContaEmSituacaoDiferenteDeATI()
        {
            RealizarNovaConsulta_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Conta>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                    && x.NumeroDaConta == numeroDaConta);
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComTitularInvalido()
        {
            RealizarNovaConsulta_Inicilizacao();

            var titularServiceMock = new Mock<ITitularService>();

            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return null;
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComTitularInativo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var titularServiceMock = new Mock<ITitularService>();

            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Titular>(x => x.Active == false && x.CodigoDaAgencia == codigoDaAgencia && x.CodigoDaColigada == codigoDaColigda
                            && x.NumeroDaContaCorrente == numeroDaConta && x.Titularidade == "01" && x.Cgc_Cpf == CPF
                            && x.CodigoDoCliente == StringHelper.GerarStringComDigitosRandomicos(9));
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComClienteInvalido()
        {
            RealizarNovaConsulta_Inicilizacao();

            var clienteServiceMock = new Mock<IClienteService>();

            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                {
                    return null;
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComClienteInativo()
        {
            RealizarNovaConsulta_Inicilizacao();

            var clienteServiceMock = new Mock<IClienteService>();

            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                {
                    return Mock.Of<Cliente>(x => x.Active == false && x.Cgc_Cpf == CPF && x.CodCliente == codigo);
                });

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMenorQueADataAtual()
        {
            RealizarNovaConsulta_Inicilizacao();

            var calendarioServiceMock = new Mock<ICalendarioService>();

            calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                .Returns<DateTime, string>((data, praca) => data.AddDays(-1));

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoIgualADataAtual()
        {
            RealizarNovaConsulta_Inicilizacao();

            var calendarioServiceMock = new Mock<ICalendarioService>();

            calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                .Returns<DateTime, string>((data, praca) => data);

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMaiorQueADataAtual()
        {
            RealizarNovaConsulta_Inicilizacao();

            var calendarioServiceMock = new Mock<ICalendarioService>();

            calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                .Returns<DateTime, string>((data, praca) => data.AddDays(1));

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> RealizarNovaConsulta_GeradorDeCenarioComDataDeVencimentoMenorQueDataAAtualEMaisAntigaQueCincoAnos()
        {
            RealizarNovaConsulta_Inicilizacao();

            var calendarioServiceMock = new Mock<ICalendarioService>();

            calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

            calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                .Returns<DateTime, string>((data, praca) => data);

            var comandos = Builder<RealizarNovaConsultaDeConvenioCommand>.CreateListOfSize(10)
                .All()
                .With(x => x.CodigoDeBarras = StringHelper.GerarStringComDigitosRandomicos(44))
                .And(x => x.LinhaDigitavel = null)
                .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                .Build()
                .ToList();

            var objetos = (from comando in comandos
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static void ValidarRealizarNovaConsultaComResultSemErros(RealizarNovaConsultaDeConvenioCommand command,
            ICalendarioService calendarioService, Convenio convenio, Result<ConsultaDeConvenio> result)
        {
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(convenio.UncommittedEvents.Any());

            var @event = convenio.UncommittedEvents.FirstOrDefault() as NovaConsultaDeConvenioRealizadaEvent;

            Assert.IsNotNull(@event);
            Assert.IsTrue(@event?.CorrelationMessage == command);
            Assert.IsTrue(@event?.OriginalCorrelationMessage == command);
            Assert.IsTrue(@event?.SourceId == convenio.Id);
            Assert.IsTrue(@event?.SourceVersion == convenio.Version);
            Assert.IsTrue(@event?.IdDoConvenio == convenio.Id);
            Assert.IsTrue(@event?.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(@event?.CodigoDaColigada == command.CodigoDaColigada);
            Assert.IsTrue(@event?.CodigoDaAgencia == command.CodigoDaAgencia);
            Assert.IsTrue(@event?.NumeroDaContaCorrente == command.NumeroDaContaCorrente);
            Assert.IsTrue(@event?.ModoDeEntradaDoCodigoDeBarras == (int)(string.IsNullOrWhiteSpace(command.CodigoDeBarras)
                ? ModoDeEntradaDoCodigoDeBarras.Digitado
                : ModoDeEntradaDoCodigoDeBarras.Escaneado));
            Assert.IsTrue(@event?.FoiIniciadaComDuplicidade == false);
            Assert.IsTrue(@event?.DataDeProcessamento == calendarioService.ObterADataDeProcessamento());

            Assert.IsTrue(result.Value?.CodigoDaAgencia == command.CodigoDaAgencia);
            Assert.IsTrue(result.Value?.CodigoDaColigada == command.CodigoDaColigada);
            Assert.IsTrue(result.Value?.CodigoDoCanalDeProcessamento == @event?.CodigoDoCanalDeProcessamento);
            Assert.IsTrue(result.Value?.DataDaConsulta == @event?.DataDaConsulta);
            Assert.IsTrue(result.Value?.DataDeProcessamento == @event?.DataDeProcessamento);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.FoiIniciadaComDuplicidade == @event.FoiIniciadaComDuplicidade);
            Assert.IsTrue(result.Value?.Id == @event.IdDaConsultaDeConvenio);
            Assert.IsTrue(result.Value?.IdDoConvenio == convenio.Id);
            Assert.IsTrue(result.Value?.ModoDeEntradaDoCodigoDeBarras == @event.ModoDeEntradaDoCodigoDeBarras);
            Assert.IsTrue(result.Value?.NumeroDaContaCorrente == command.NumeroDaContaCorrente);
        }

        #endregion

        #region Iniciar novo Pagamento

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComTodosOsDadosValidos_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioSemUmaTransacaoConveniosConfigurada")]
        public void IniciarNovoPagamento_SemUmaTransacaoConveniosConfigurada_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Não existe uma trasação Convênios configurada no sistema."
               && x.Reason == "Não existe uma trasação Convênios configurada no sistema."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioSemUmaTransacaoConveniosConfiguradaParaAEmpresaAplicacao")]
        public void IniciarNovoPagamento_SemUmaTransacaoConveniosConfiguradaParaAEmpresaAplicacao_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Não existe uma trasação Convênios configurada no sistema para a Empresa X Aplicacao = {EmpresaAplicacaoId}."
               && x.Reason == $"Não existe uma trasação Convênios configurada no sistema para a Empresa X Aplicacao = {EmpresaAplicacaoId}."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDaTransacao")]
        public void IniciarNovoPagamento_AntesDoHorarioInicialDaTransacao_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Operações com convênios não liberadas."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDaTransacao")]
        public void IniciarNovoPagamento_DepoisDoHorarioFinalDaTransacao_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Operações com convênios não liberadas."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDaEmpresaAplicacaoTransacao")]
        public void IniciarNovoPagamento_AntesDoHorarioInicialDaEmpresaAplicacaoTransacao_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
           IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
           IContaService contaService, ITitularService titularService, IClienteService clienteService,
           ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
           ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para a Empresa x Aplicação {EmpresaAplicacaoId}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDaEmpresaAplicacaoTransacao")]
        public void IniciarNovoPagamento_DepoisDoHorarioFinalDaEmpresaAplicacaoTransacao_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para a Empresa x Aplicação {EmpresaAplicacaoId}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDoCanalDeProcessamento")]
        public void IniciarNovoPagamento_AntesDoHorarioInicialDoCanalDeProcessamento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
           IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
           IContaService contaService, ITitularService titularService, IClienteService clienteService,
           ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
           ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para o canal de processamento {NomeDoCanalDeProcessamento}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDoCanalDeProcessamento")]
        public void IniciarNovoPagamento_DepoisDoHorarioFinalDoCanalDeProcessamento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Operações com convênios não liberadas para o canal de processamento {NomeDoCanalDeProcessamento}."
               && x.Reason == "Horário indisponível."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComAgenciaInvalida")]
        public void IniciarNovoPagamento_ComAgenciaInvalida_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."
               && x.Reason == "Agência não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComAgenciaInativa")]
        public void IniciarNovoPagamento_ComAgenciaInativa_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Agência inválida."
               && x.Reason == "Agência não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComContaInvalida")]
        public void IniciarNovoPagamento_ComContaInvalida_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComContaInativa")]
        public void IniciarNovoPagamento_ComContaInativa_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não encontrada."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComContaEmSituacaoDiferenteDeATI")]
        public void IniciarNovoPagamento_ComContaEmSituacaoDiferenteDeATI_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Conta corrente inválida."
               && x.Reason == "Conta corrente não está ATIVA."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTitularInvalido")]
        public void IniciarNovoPagamento_ComTitularInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."
               && x.Reason == "Titular não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTitularInativo")]
        public void IniciarNovoPagamento_ComTitularInativo_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Titular inválido."
               && x.Reason == "Titular não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComClienteInvalido")]
        public void IniciarNovoPagamento_ComClienteInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Cliente inválido."
               && x.Reason == "Cliente não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComClienteInativo")]
        public void IniciarNovoPagamento_ComClienteInativo_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>());

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Cliente inválido."
               && x.Reason == "Cliente não encontrado."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComDataDeVencimentoMenorQueADataAtual_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var dataDeVencimento = DateTime.Today.AddDays(-1);

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == $"Documento vencido em { dataDeVencimento.ToString("dd/MM/yyyy")}."
               && x.Reason == $"Documento vencido em { dataDeVencimento.ToString("dd/MM/yyyy")}."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComDataDeVencimentoIgualADataAtual_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var dataDeVencimento = DateTime.Today;

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComDataDeVencimentoMaiorQueADataAtual_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var dataDeVencimento = DateTime.Today.AddDays(1);

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComDataDeVencimentoMenorQueDataAAtualEMaisAntigaQueCincoAnos_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            var dataDeVencimento = DateTime.Today.AddYears(-5).AddDays(-1);

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio>()
            && x.DataDeVencimento == dataDeVencimento);

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComUmPagamentoJaEfetivado_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            command.AceitaDuplicidade = "N";

            var pagamentoEfetivado = Mock.Of<PagamentoDeConvenio>(x => x.Status == PagamentoDeConvenioStatus.Efetivado
            && x.IdDaConsultaDeConvenio == Guid.NewGuid());

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio> { pagamentoEfetivado });

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento em duplicidade."
               && x.Reason == "Já existe um pagamento válido para esse convênio."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos")]
        public void IniciarNovoPagamento_ComUmPagamentoJaEfetivadoEAceitaDuplicidade_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta)
        {
            command.AceitaDuplicidade = "S";

            var pagamentoEfetivado = Mock.Of<PagamentoDeConvenio>(x => x.Status == PagamentoDeConvenioStatus.Efetivado
            && x.IdDaConsultaDeConvenio == Guid.NewGuid());

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio> { pagamentoEfetivado });

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComUmPagamentoEmStatusValido")]
        public void IniciarNovoPagamento_ComUmPagamentoEmStatusValido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta,
            PagamentoDeConvenioStatus statusDoPagamento)
        {
            command.AceitaDuplicidade = "N";

            var pagamentoEfetivado = Mock.Of<PagamentoDeConvenio>(x => x.Status == statusDoPagamento
            && x.IdDaConsultaDeConvenio == Guid.NewGuid() && x.DataDoPagamento == calendarioService.ObterADataDeProcessamento());

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio> { pagamentoEfetivado });

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Pagamento em duplicidade."
               && x.Reason == "Já existe um pagamento válido para esse convênio."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComUmPagamentoEmStatusValido")]
        public void IniciarNovoPagamento_ComUmPagamentoEmStatusValidoEAceitaDuplicidade_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta,
            PagamentoDeConvenioStatus statusDoPagamento)
        {
            command.AceitaDuplicidade = "S";

            var pagamentoEfetivado = Mock.Of<PagamentoDeConvenio>(x => x.Status == statusDoPagamento
            && x.IdDaConsultaDeConvenio == Guid.NewGuid() && x.DataDoPagamento == calendarioService.ObterADataDeProcessamento());

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio> { pagamentoEfetivado });

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        [Test]
        [TestCaseSource("IniciarNovoPagamento_GeradorDeCenarioComUmPagamentoEmStatusInvalido")]
        public void IniciarNovoPagamento_ComUmPagamentoEmStatusInvalido_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory, IAgenciaService agenciaService,
            IContaService contaService, ITitularService titularService, IClienteService clienteService,
            ICalendarioService calendarioService, IConfiguracoesDoMotorService configuracoesDoMotorService,
            ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao, ConsultaDeConvenio consulta,
            PagamentoDeConvenioStatus statusDoPagamento)
        {
            var pagamentoEfetivado = Mock.Of<PagamentoDeConvenio>(x => x.Status == statusDoPagamento
            && x.IdDaConsultaDeConvenio == Guid.NewGuid() && x.DataDoPagamento == calendarioService.ObterADataDeProcessamento());

            var convenio = Mock.Of<Convenio>(x => x.Active == true && x.CodigoDoConvenio == CodigoDoConvenio
            && x.CodigoDeBarras.Valor == StringHelper.GerarStringComDigitosRandomicos(44)
            && x.LinhaDigitavel.Valor == StringHelper.GerarStringComDigitosRandomicos(48)
            && x.CodigoDoSegmento == CodigoDoSegmento && x.Consultas == new List<ConsultaDeConvenio> { consulta }
            && x.Pagamentos == new List<PagamentoDeConvenio> { pagamentoEfetivado });

            var result = convenio.IniciarNovoPagamento(command, pagamentoDeConvenioFactory, agenciaService, contaService, titularService,
                clienteService, calendarioService, configuracoesDoMotorService);

            ValidarIniciarNovoPagamentoComResultSemErros(command, calendarioService, empresaAplicacaoTransacao, convenio, consulta, result);
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComTodosOsDadosValidos()
        {
            IniciarNovoPagamento_Inicilizacao();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioSemUmaTransacaoConveniosConfigurada()
        {
            IniciarNovoPagamento_Inicilizacao();

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();
            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios).Returns<ConfiguracoesDeConvenios>(null);

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioSemUmaTransacaoConveniosConfiguradaParaAEmpresaAplicacao()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == new List<ConfiguracoesDaEmpresaAplicacaoTransacao>()));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDaTransacao()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDaTransacao()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDaEmpresaAplicacaoTransacao()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDaEmpresaAplicacaoTransacao()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioAntesDoHorarioInicialDoCanalDeProcessamento()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento && x.HorarioInicial == DateTime.Now.AddMinutes(5).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioDepoisDoHorarioFinalDoCanalDeProcessamento()
        {
            IniciarNovoPagamento_Inicilizacao();

            var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay);

            var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

            var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                    && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                    && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

            var configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

            var empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                 && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                 && x.HorarioFinal == DateTime.Now.AddMinutes(-5).TimeOfDay);

            var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        empresaAplicacaoTransacao
                    };

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                    && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                    && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(new List<ConfiguracoesDoConvenio>
                {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                });

            configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                {
                            canalDeProcessamento
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComAgenciaInvalida()
        {
            IniciarNovoPagamento_Inicilizacao();

            var agenciaServiceMock = new Mock<IAgenciaService>();

            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                {
                    return null;
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComAgenciaInativa()
        {
            IniciarNovoPagamento_Inicilizacao();

            var agenciaServiceMock = new Mock<IAgenciaService>();

            agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                {
                    return Mock.Of<Agencia>(x => x.Active == false && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda);
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComContaInvalida()
        {
            IniciarNovoPagamento_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return null;
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComContaInativa()
        {
            IniciarNovoPagamento_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Conta>(x => x.Active == false && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                    && x.NumeroDaConta == numeroDaConta && x.CodSituacao == "ATI");
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComContaEmSituacaoDiferenteDeATI()
        {
            IniciarNovoPagamento_Inicilizacao();

            var contaServiceMock = new Mock<IContaService>();

            contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Conta>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                    && x.NumeroDaConta == numeroDaConta);
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComTitularInvalido()
        {
            IniciarNovoPagamento_Inicilizacao();

            var titularServiceMock = new Mock<ITitularService>();

            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return null;
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComTitularInativo()
        {
            IniciarNovoPagamento_Inicilizacao();

            var titularServiceMock = new Mock<ITitularService>();

            titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                {
                    return Mock.Of<Titular>(x => x.Active == false && x.CodigoDaAgencia == codigoDaAgencia && x.CodigoDaColigada == codigoDaColigda
                    && x.NumeroDaContaCorrente == numeroDaConta && x.Titularidade == "01" && x.Cgc_Cpf == CPF
                    && x.CodigoDoCliente == StringHelper.GerarStringComDigitosRandomicos(9));
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComClienteInvalido()
        {
            IniciarNovoPagamento_Inicilizacao();

            var clienteServiceMock = new Mock<IClienteService>();

            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                {
                    return null;
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComClienteInativo()
        {
            IniciarNovoPagamento_Inicilizacao();

            var clienteServiceMock = new Mock<IClienteService>();

            clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                {
                    return Mock.Of<Cliente>(x => x.Active == false && x.Cgc_Cpf == CPF && x.CodCliente == codigo && x.TipoPessoa == "F");
                });

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComUmPagamentoEmStatusValido()
        {
            IniciarNovoPagamento_Inicilizacao();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           from status in new[]
                           {
                               PagamentoDeConvenioStatus.DebitadoPelaAplicacao,
                               PagamentoDeConvenioStatus.DebitadoPeloMotor,
                               PagamentoDeConvenioStatus.EmEstorno,
                               PagamentoDeConvenioStatus.EmPagamento,
                               PagamentoDeConvenioStatus.EstornoRecusado,
                               PagamentoDeConvenioStatus.PendenteDeLiquidacao
                           }
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio,
                               status
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> IniciarNovoPagamento_GeradorDeCenarioComUmPagamentoEmStatusInvalido()
        {
            IniciarNovoPagamento_Inicilizacao();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           from status in new[]
                           {
                               PagamentoDeConvenioStatus.Estornado,
                               PagamentoDeConvenioStatus.LiquidacaoRecusada,
                               PagamentoDeConvenioStatus.Recusado
                           }
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _pagamentoDeConvenioFactoryMock.Object,
                               _agenciaServiceMock.Object,
                               _contaServiceMock.Object,
                               _titularServiceMock.Object,
                               _clienteServiceMock.Object,
                               _calendarioServiceMock.Object,
                               _configuracoesDoMotorServiceMock.Object,
                               _empresaAplicacaoTransacao,
                               _consultaDeConvenio,
                               status
                           })
                           .ToList();

            return objetos;
        }

        private static string ObterOCodigoDoSegmentoConvenioAPartirDoCodigoDeBarras(string codigoDeBarras)
        {
            if (string.IsNullOrWhiteSpace(codigoDeBarras))
                return null;

            if (codigoDeBarras.Length != 44)
                return null;

            return codigoDeBarras.Substring(1, 1);
        }

        private static string ObterOCodigoDoConvenioAPartirDoCodigoDeBarras(string codigoDeBarras, string codigoDoSegmentoDeConvenio)
        {
            if (string.IsNullOrWhiteSpace(codigoDeBarras))
                return null;

            if (codigoDeBarras.Length != 44)
                return null;

            if (string.IsNullOrWhiteSpace(codigoDoSegmentoDeConvenio))
                return null;

            if (codigoDoSegmentoDeConvenio == "6")
                return codigoDeBarras.Substring(15, 8);

            return codigoDeBarras.Substring(15, 4);
        }

        public static decimal? ObterOValorDoConvenioAPartirDoCodigoDeBarras(string codigoDeBarras)
        {
            var bloco = codigoDeBarras.Substring(4, 11);

            var separadorDeDecimais = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;

            if (!decimal.TryParse(string.Format("{0}{1}{2}", bloco.Substring(0, 9), separadorDeDecimais, bloco.Substring(9, 2)), out decimal valor))
                return null;

            return valor;
        }

        public static DateTime? ObterADataDeVencimentoAPartirDoCodigoDeBarras(string codigoDeBarras, string codigoDoSegmentoDeConvenio)
        {
            var campoLivre = codigoDoSegmentoDeConvenio == "6"
                ? codigoDeBarras.Substring(23, 21)
                : codigoDeBarras.Substring(19, 25);

            if (string.IsNullOrWhiteSpace(campoLivre))
                return null;

            var blocoDaData = campoLivre.Substring(0, 8);

            if (DateTime.TryParseExact(blocoDaData, "yyyyMMdd", new CultureInfo("pt-BR"), DateTimeStyles.None, out DateTime dataDeVencimento)
                && dataDeVencimento >= DateTime.Today.AddYears(-5) && dataDeVencimento <= DateTime.Today.AddYears(+5))
                return dataDeVencimento;

            if (DateTime.TryParseExact(blocoDaData, "ddMMyyyy", new CultureInfo("pt-BR"), DateTimeStyles.None, out dataDeVencimento)
                && dataDeVencimento >= DateTime.Today.AddYears(-5) && dataDeVencimento <= DateTime.Today.AddYears(+5))
                return dataDeVencimento;

            blocoDaData = campoLivre.Substring(0, 6);

            if (DateTime.TryParseExact(blocoDaData, "yyMMdd", new CultureInfo("pt-BR"), DateTimeStyles.None, out dataDeVencimento)
                && dataDeVencimento >= DateTime.Today.AddYears(-5) && dataDeVencimento <= DateTime.Today.AddYears(+5))
                return dataDeVencimento;

            if (DateTime.TryParseExact(blocoDaData, "ddMMyy", new CultureInfo("pt-BR"), DateTimeStyles.None, out dataDeVencimento)
                && dataDeVencimento >= DateTime.Today.AddYears(-5) && dataDeVencimento <= DateTime.Today.AddYears(+5))
                return dataDeVencimento;

            blocoDaData = campoLivre.Substring(0, 5);

            if (DateTimeExtensions.TryParseFromJulianFormat(blocoDaData, out dataDeVencimento)
                && dataDeVencimento >= DateTime.Today.AddYears(-5) && dataDeVencimento <= DateTime.Today.AddYears(+5))
                return dataDeVencimento;

            return null;
        }

        private static void RealizarNovaConsulta_Inicilizacao()
        {
            lock (_lockObject)
            {
                if (_consultaDeConvenioFactoryMock == null)
                {
                    _consultaDeConvenioFactoryMock = new Mock<IConsultaDeConvenioFactory>();

                    _consultaDeConvenioFactoryMock.Setup(x => x.RealizarNovaConsultaDeConvenio(It.IsAny<RealizarNovaConsultaDeConvenioCommand>(),
                        It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<long>(), It.IsAny<bool>(), It.IsAny<DateTime>()))
                        .Returns<RealizarNovaConsultaDeConvenioCommand, Guid, string, long, bool, DateTime>((command, idDoConvenio, codigoDoCanalDeProcessamento,
                        empresaAplicacaoTransacaoId, foiIniciadaComDuplicidade, dataDeProcessamento) =>
                        {
                            return Mock.Of<ConsultaDeConvenio>(x => x.CodigoDaAgencia == command.CodigoDaAgencia && x.CodigoDaColigada == command.CodigoDaColigada
                            && x.CodigoDoCanalDeProcessamento == codigoDoCanalDeProcessamento && x.DataDeProcessamento == dataDeProcessamento
                            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacaoId && x.FoiIniciadaComDuplicidade == foiIniciadaComDuplicidade
                            && x.IdDoConvenio == idDoConvenio && x.ModoDeEntradaDoCodigoDeBarras == (int)(string.IsNullOrWhiteSpace(command.CodigoDeBarras)
                            ? ModoDeEntradaDoCodigoDeBarras.Digitado
                            : ModoDeEntradaDoCodigoDeBarras.Escaneado)
                            && x.NumeroDaContaCorrente == command.NumeroDaContaCorrente);
                        });
                }

                if (_agenciaServiceMock == null)
                {
                    _agenciaServiceMock = new Mock<IAgenciaService>();

                    _agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                        {
                            return Mock.Of<Agencia>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda);
                        });
                }

                if (_contaServiceMock == null)
                {
                    _contaServiceMock = new Mock<IContaService>();

                    _contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                        {
                            return Mock.Of<Conta>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                            && x.NumeroDaConta == numeroDaConta && x.CodSituacao == "ATI");
                        });
                }

                if (_titularServiceMock == null)
                {
                    _titularServiceMock = new Mock<ITitularService>();

                    _titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                        {
                            return Mock.Of<Titular>(x => x.Active == true && x.CodigoDaAgencia == codigoDaAgencia && x.CodigoDaColigada == codigoDaColigda
                            && x.NumeroDaContaCorrente == numeroDaConta && x.Titularidade == "01" && x.Cgc_Cpf == CPF
                            && x.CodigoDoCliente == StringHelper.GerarStringComDigitosRandomicos(9));
                        });
                }

                if (_clienteServiceMock == null)
                {
                    _clienteServiceMock = new Mock<IClienteService>();

                    _clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                        .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                        {
                            return Mock.Of<Cliente>(x => x.Active == true && x.Cgc_Cpf == CPF && x.CodCliente == codigo && x.TipoPessoa == "F");
                        });
                }

                if (_calendarioServiceMock == null)
                {
                    _calendarioServiceMock = new Mock<ICalendarioService>();

                    _calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

                    _calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                        .Returns<DateTime, string>((data, praca) => data);
                }

                if (_configuracoesDoMotorServiceMock == null)
                {
                    var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

                    var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

                    var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                            && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                            && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

                    _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

                    _empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                        && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                        && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

                    var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        _empresaAplicacaoTransacao
                    };

                    _configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                        .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                            && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

                    _configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                        .Returns(new List<ConfiguracoesDoConvenio>
                        {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                        });
                }
            }
        }

        private static void IniciarNovoPagamento_Inicilizacao()
        {
            lock (_lockObject)
            {
                if (_pagamentoDeConvenioFactoryMock == null)
                {
                    _pagamentoDeConvenioFactoryMock = new Mock<IPagamentoDeConvenioFactory>();

                    _pagamentoDeConvenioFactoryMock.Setup(x => x.IniciarNovoPagamentoDeConvenio(It.IsAny<IniciarNovoPagamentoDeConvenioCommandV2>(),
                        It.IsAny<ConsultaDeConvenio>(), It.IsAny<Titular>(), It.IsAny<Cliente>(), It.IsAny<ConfiguracoesDaEmpresaAplicacaoTransacao>()))
                        .Returns<IniciarNovoPagamentoDeConvenioCommandV2, ConsultaDeConvenio, Titular, Cliente, ConfiguracoesDaEmpresaAplicacaoTransacao>(
                        (command, consulta, titular, cliente, empresaAplicacaoTransacao) =>
                        {
                            var idDoPagamentoDeConvenio = Guid.NewGuid();

                            var formasDeRecebimento = command.FormasDeRecebimento.Select(y => Mock.Of<PagamentoDeConvenioFormaDeRecebimento>
                            (z => z.CVV2 == y.CVV2 && z.DadosDoCheque == y.DadosDoCheque && z.IdDoPagamentoDeConvenio == idDoPagamentoDeConvenio
                            && z.MeioDePagamento == y.MeioDePagamento && z.ModoDeEntradaDaTransacao == y.ModoDeEntradaDaTransacao
                            && z.NumeroDeSerieDoPINPAD == y.NumeroDeSerieDoPINPAD && z.TipoDaConta == y.TipoDaConta
                            && z.TipoDeCapturaDoCheque == y.TipoDeCapturaDoCheque && z.Trilha2DoCartaoMagnetico == y.Trilha2DoCartaoMagnetico
                            && z.Valor == y.Valor)).ToList();

                            return new Result<PagamentoDeConvenio>(Mock.Of<PagamentoDeConvenio>(x => x.CanalDoPagamento == command.CanalDoPagamento
                            && x.CodigoDeErro == null && x.Consulta == consulta && x.Convenio == consulta.Convenio
                            && x.DebitarContaCorrente == empresaAplicacaoTransacao.DebitarContaCorrente && x.DescricaoDoErro == null
                            && x.DocumentoDoPagadorFinal == cliente.Cgc_Cpf && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacao.EmpresaAplicacaoTransacaoId
                            && x.EstornarAutomaticamente == empresaAplicacaoTransacao.EstornarAutomaticamente
                            && x.FormasDeRecebimento == formasDeRecebimento && x.Id == idDoPagamentoDeConvenio
                            && x.IdDaConsultaDeConvenio == consulta.Id && x.IdDoConvenio == consulta.IdDoConvenio
                            && x.IdentificadorDoPagamentoNoCliente == command.IdentificadorDoPagamentoNoCliente
                            && x.Status == (empresaAplicacaoTransacao.DebitarContaCorrente == true
                                ? PagamentoDeConvenioStatus.EmPagamento
                                : PagamentoDeConvenioStatus.DebitadoPelaAplicacao)
                            && x.TipoDePessoaDoPagadorFinal == cliente.TipoPessoa && x.ValorDoPagamento == command.ValorDoPagamento));
                        });
                }

                if (_agenciaServiceMock == null)
                {
                    _agenciaServiceMock = new Mock<IAgenciaService>();

                    _agenciaServiceMock.Setup(x => x.ObterAgenciaPeloCodColigadaECodAgenciaAsync(It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, IAgenciaService, Agencia>((codigoDaColigda, codigoDaAgencia) =>
                        {
                            return Mock.Of<Agencia>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda);
                        });
                }

                if (_contaServiceMock == null)
                {
                    _contaServiceMock = new Mock<IContaService>();

                    _contaServiceMock.Setup(x => x.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, string, IContaService, Conta>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                        {
                            return Mock.Of<Conta>(x => x.Active == true && x.CodAgencia == codigoDaAgencia && x.CodColigada == codigoDaColigda
                            && x.NumeroDaConta == numeroDaConta && x.CodSituacao == "ATI");
                        });
                }

                if (_titularServiceMock == null)
                {
                    _titularServiceMock = new Mock<ITitularService>();

                    _titularServiceMock.Setup(x => x.ObterPrimeiroTitularDaConta(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                        .ReturnsAsync<string, string, string, ITitularService, Titular>((codigoDaColigda, codigoDaAgencia, numeroDaConta) =>
                        {
                            return Mock.Of<Titular>(x => x.Active == true && x.CodigoDaAgencia == codigoDaAgencia && x.CodigoDaColigada == codigoDaColigda
                            && x.NumeroDaContaCorrente == numeroDaConta && x.Titularidade == "01" && x.Cgc_Cpf == CPF
                            && x.CodigoDoCliente == StringHelper.GerarStringComDigitosRandomicos(9));
                        });
                }

                if (_clienteServiceMock == null)
                {
                    _clienteServiceMock = new Mock<IClienteService>();

                    _clienteServiceMock.Setup(x => x.ObterClientePeloCodigoAsync(It.IsAny<string>()))
                        .ReturnsAsync<string, IClienteService, Cliente>((codigo) =>
                        {
                            return Mock.Of<Cliente>(x => x.Active == true && x.Cgc_Cpf == CPF && x.CodCliente == codigo && x.TipoPessoa == "F");
                        });
                }

                if (_calendarioServiceMock == null)
                {
                    _calendarioServiceMock = new Mock<ICalendarioService>();

                    _calendarioServiceMock.Setup(x => x.ObterADataDeProcessamento()).Returns(DateTime.Today);

                    _calendarioServiceMock.Setup(x => x.ObterProximoDiaUtil(It.IsAny<DateTime>(), It.IsAny<string>()))
                        .Returns<DateTime, string>((data, praca) => data);
                }

                if (_configuracoesDoMotorServiceMock == null)
                {
                    var canalDeProcessamento = Mock.Of<ConfiguracoesDoCanalDeProcessamento>(x => x.Active == true && x.Codigo == CodigoDoCanalDeProcessamento
                    && x.Nome == NomeDoCanalDeProcessamento);

                    var canaisDeProcessamentoDisponiveis = new List<ConfiguracoesDosConveniosCanaisDisponiveis>
                            {
                                Mock.Of<ConfiguracoesDosConveniosCanaisDisponiveis>(y => y.CanalDeProcessamento == canalDeProcessamento
                                && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id)
                            };

                    var segmentoDeConvenio = Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(y => y.Active == true
                            && y.CanalDeProcessamento == canalDeProcessamento && y.Codigo == CodigoDoSegmento
                            && y.IdDoCanalDeProcessamento == canalDeProcessamento.Id);

                    _configuracoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

                    _empresaAplicacaoTransacao = Mock.Of<ConfiguracoesDaEmpresaAplicacaoTransacao>(x => x.Active == true && x.EmpresaAplicacaoId == EmpresaAplicacaoId
                         && x.EmpresaAplicacaoTransacaoId == EmpresaAplicacaoTransacaoId && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                         && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay);

                    var empresasAplicacoesTransacoes = new List<ConfiguracoesDaEmpresaAplicacaoTransacao>
                    {
                        _empresaAplicacaoTransacao
                    };

                    _configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDaTransacao)
                        .Returns(Mock.Of<ConfiguracoesDaTransacao>(x => x.Active == true && x.HorarioInicial == DateTime.Now.AddHours(-1).TimeOfDay
                            && x.HorarioFinal == DateTime.Now.AddHours(1).TimeOfDay
                            && x.EmpresasAplicacoesTransacoes == empresasAplicacoesTransacoes));

                    _configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                        .Returns(new List<ConfiguracoesDoConvenio>
                        {
                            Mock.Of<ConfiguracoesDoConvenio>(x => x.Active == true
                            && x.CanaisDeProcessamentoDisponiveis == canaisDeProcessamentoDisponiveis
                            && x.Codigo == CodigoDoConvenio && x.SegmentoDeConvenio == segmentoDeConvenio)
                        });

                    _configuracoesDoMotorServiceMock.Setup(x => x.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento)
                        .Returns(new List<ConfiguracoesDoCanalDeProcessamento>
                        {
                            canalDeProcessamento
                        });
                }

                if (_formasDeRecebimento == null)
                    _formasDeRecebimento = GerarFormasDeRecebimento();

                if (_canaisDePagamento == null)
                    _canaisDePagamento = new[] { 1, 2, 3, 4, 5, 6, 7, 8 };

                if (_quantidadesDeFormas == null)
                    _quantidadesDeFormas = new[] { 1, 2, 3 };

                if (_duplicidades == null)
                    _duplicidades = new[] { "S", "N" };

                if (_consultaDeConvenio == null)
                    _consultaDeConvenio = Mock.Of<ConsultaDeConvenio>(x => x.CodigoDoCanalDeProcessamento == CodigoDoCanalDeProcessamento
                    && x.Id == Guid.NewGuid()
                    && x.EmpresaAplicacaoTransacaoId == _empresaAplicacaoTransacao.EmpresaAplicacaoTransacaoId
                    && x.CodigoDaColigada == StringHelper.GerarStringComDigitosRandomicos(3)
                    && x.CodigoDaAgencia == StringHelper.GerarStringComDigitosRandomicos(5)
                    && x.NumeroDaContaCorrente == StringHelper.GerarStringComDigitosRandomicos(10));
            }
        }

        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> GerarFormasDeRecebimento()
        {
            var meiosDePagamento = new[] { 1, 3, 4 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var formasDeRecebimento = (from meioDePagamento in meiosDePagamento
                                       from tipoDeConta in tiposDeConta
                                       from modoDeEntrada in modosDeEntrada
                                       from tipoDeCaptura in tiposDeCaptura
                                       from valor in valores
                                       let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                                           .With(x => x.MeioDePagamento = meioDePagamento)
                                           .And(x => x.Valor = valor)
                                           .And(x => x.TipoDaConta = tipoDeConta)
                                           .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                                           .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                                           .Build()
                                       where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                                       || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                                       || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                                       select comando).ToList();

            return formasDeRecebimento;
        }

        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> SelecionarFormasDeRecebimento(
            IEnumerable<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> formasDeRecebimento, int quantidade)
        {
            switch (quantidade)
            {
                case 1:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Take(1).ToList();
                    }
                case 2:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Distinct(new FormaDeRecebimentoComparer()).Take(2).ToList();
                    }
                case 3:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Distinct(new FormaDeRecebimentoComparer()).Take(3).ToList();
                    }
                default:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Take(1).ToList();
                    }
            }
        }

        private class FormaDeRecebimentoComparer : IEqualityComparer<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>
        {
            public bool Equals(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 x, IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 y)
            {
                return x.MeioDePagamento == y.MeioDePagamento;
            }

            public int GetHashCode(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 obj)
            {
                return obj.MeioDePagamento.GetHashCode();
            }
        }

        private void ValidarIniciarNovoPagamentoComResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
           ICalendarioService calendarioService, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
           Convenio convenio, ConsultaDeConvenio consulta, Result<PagamentoDeConvenio> result)
        {
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(convenio.UncommittedEvents.Any());

            var @event = convenio.UncommittedEvents.FirstOrDefault() as NovoPagamentoDeConvenioIniciadoEventV2;

            Assert.IsNotNull(@event);
            Assert.IsTrue(@event?.CorrelationMessage == command);
            Assert.IsTrue(@event?.OriginalCorrelationMessage == command);
            Assert.IsTrue(@event?.SourceId == convenio.Id);
            Assert.IsTrue(@event?.SourceVersion == convenio.Version);
            Assert.IsTrue(@event?.IdDoConvenio == consulta.IdDoConvenio);
            Assert.IsTrue(@event?.IdDaConsultaDeConvenio == consulta.Id);
            Assert.IsTrue(@event?.EmpresaAplicacaoTransacaoId == consulta.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(@event?.IdentificadorDoPagamentoNoCliente == command.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(@event?.CodigoDaColigada == consulta.CodigoDaColigada);
            Assert.IsTrue(@event?.CodigoDaAgencia == consulta.CodigoDaAgencia);
            Assert.IsTrue(@event?.NumeroDaContaCorrente == consulta.NumeroDaContaCorrente);
            Assert.IsTrue(@event?.DocumentoDoPagadorFinal == CPF);
            Assert.IsTrue(@event?.TipoDePessoaDoPagadorFinal == "F");
            Assert.IsTrue(@event?.CodigoDeBarrasDoConvenio == convenio.CodigoDeBarras.Valor);
            Assert.IsTrue(@event?.LinhaDigitavelDoConvenio == convenio.LinhaDigitavel.Valor);
            Assert.IsTrue(@event?.ModoDeEntradaDoCodigoDeBarras == consulta.ModoDeEntradaDoCodigoDeBarras);
            Assert.IsTrue(@event?.ValorOriginalDoConvenio == convenio.Valor);
            Assert.IsTrue(@event?.DataDeVencimentoDoConvenio == convenio.DataDeVencimento);
            Assert.IsTrue(@event?.CodigoDoSegmento == convenio.CodigoDoSegmento);
            Assert.IsTrue(@event?.CodigoDoConvenio == convenio.CodigoDoConvenio);
            Assert.IsTrue(@event?.CodigoDoCanalDeProcessamento == consulta.CodigoDoCanalDeProcessamento);
            Assert.IsTrue(@event?.DataDeProcessamento == consulta.DataDeProcessamento);
            Assert.IsTrue(@event?.ValorDoPagamento == command.ValorDoPagamento);
            Assert.IsTrue(@event?.DataDoPagamento == result.Value?.DataDoPagamento);
            Assert.IsTrue(@event?.CanalDoPagamento == command.CanalDoPagamento);
            Assert.IsTrue(@event?.DebitarContaCorrente == empresaAplicacaoTransacao.DebitarContaCorrente);
            Assert.IsTrue(@event?.ValidarSaldoDaContaCorrente == empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(@event?.EstornarAutomaticamente == empresaAplicacaoTransacao.EstornarAutomaticamente);
            Assert.IsTrue(@event?.FormasDeRecebimento?.Count() == command.FormasDeRecebimento.Count());

            foreach (var formaDePagamento in @event?.FormasDeRecebimento)
            {
                var formaDePagamentoDoComando = command.FormasDeRecebimento.FirstOrDefault(x => x.MeioDePagamento == formaDePagamento.MeioDePagamento);

                Assert.IsNotNull(formaDePagamentoDoComando);
                Assert.IsTrue(formaDePagamento.CVV2 == formaDePagamentoDoComando?.CVV2);
                Assert.IsTrue(formaDePagamento.DadosDoCheque == formaDePagamentoDoComando?.DadosDoCheque);
                Assert.IsTrue(formaDePagamento.MeioDePagamento == formaDePagamentoDoComando?.MeioDePagamento);
                Assert.IsTrue(formaDePagamento.ModoDeEntradaDaTransacao == formaDePagamentoDoComando?.ModoDeEntradaDaTransacao);
                Assert.IsTrue(formaDePagamento.NumeroDeSerieDoPINPAD == formaDePagamentoDoComando?.NumeroDeSerieDoPINPAD);
                Assert.IsTrue(formaDePagamento.TipoDaConta == formaDePagamentoDoComando?.TipoDaConta);
                Assert.IsTrue(formaDePagamento.Trilha2DoCartaoMagnetico == formaDePagamentoDoComando?.Trilha2DoCartaoMagnetico);
                Assert.IsTrue(formaDePagamento.Valor == formaDePagamentoDoComando?.Valor);
            }

            Assert.IsTrue(result.Value?.Id == @event?.IdDoPagamentoDeConvenio);
            Assert.IsTrue(result.Value?.IdDoConvenio == @event?.IdDoConvenio);
            Assert.IsTrue(result.Value?.IdDaConsultaDeConvenio == @event?.IdDaConsultaDeConvenio);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == @event?.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.IdentificadorDoPagamentoNoCliente == @event?.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(result.Value?.DocumentoDoPagadorFinal == @event?.DocumentoDoPagadorFinal);
            Assert.IsTrue(result.Value?.TipoDePessoaDoPagadorFinal == @event?.TipoDePessoaDoPagadorFinal);
            Assert.IsTrue(result.Value?.DataDoPagamento == @event?.DataDoPagamento);
            Assert.IsTrue(result.Value?.ValorDoPagamento == @event?.ValorDoPagamento);
            Assert.IsTrue(result.Value?.CanalDoPagamento == @event?.CanalDoPagamento);
            Assert.IsTrue(result.Value?.DebitarContaCorrente == @event?.DebitarContaCorrente);
            Assert.IsTrue(result.Value?.ValidarSaldoDaContaCorrente == @event?.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(result.Value?.EstornarAutomaticamente == @event?.EstornarAutomaticamente);
            Assert.IsNull(result.Value?.CodigoDeErro);
            Assert.IsNull(result.Value?.DescricaoDoErro);
            Assert.IsTrue(result.Value?.Status == (@event?.DebitarContaCorrente == true
                ? PagamentoDeConvenioStatus.EmPagamento : PagamentoDeConvenioStatus.DebitadoPelaAplicacao));
            Assert.IsTrue(result.Value?.FormasDeRecebimento.Count == @event.FormasDeRecebimento.Count);

            foreach (var formaDePagamento in result.Value?.FormasDeRecebimento)
            {
                var formaDePagamentoDoEvento = @event?.FormasDeRecebimento.FirstOrDefault(x => x.MeioDePagamento == formaDePagamento.MeioDePagamento);

                Assert.IsNotNull(formaDePagamentoDoEvento);
                Assert.IsTrue(formaDePagamento.CVV2 == formaDePagamentoDoEvento?.CVV2);
                Assert.IsTrue(formaDePagamento.DadosDoCheque == formaDePagamentoDoEvento?.DadosDoCheque);
                Assert.IsTrue(formaDePagamento.MeioDePagamento == formaDePagamentoDoEvento?.MeioDePagamento);
                Assert.IsTrue(formaDePagamento.ModoDeEntradaDaTransacao == formaDePagamentoDoEvento?.ModoDeEntradaDaTransacao);
                Assert.IsTrue(formaDePagamento.NumeroDeSerieDoPINPAD == formaDePagamentoDoEvento?.NumeroDeSerieDoPINPAD);
                Assert.IsTrue(formaDePagamento.TipoDaConta == formaDePagamentoDoEvento?.TipoDaConta);
                Assert.IsTrue(formaDePagamento.Trilha2DoCartaoMagnetico == formaDePagamentoDoEvento?.Trilha2DoCartaoMagnetico);
                Assert.IsTrue(formaDePagamento.Valor == formaDePagamentoDoEvento?.Valor);
            }
        }

        #endregion       
    }
}
