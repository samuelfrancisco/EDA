﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using COP.ESB.Pagamento.Dominio.Tests.Helpers;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Convenios
{
    [TestFixture]
    public class LinhaDigitavelDeConvenioTests
    {
        private Mock<IConfiguracoesDoMotorService> _configurecoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

        [Test]
        public void Criar_ComValorNulo_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavelDeConvenio.Criar(null, _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável não pode ser nula."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorEmBranco_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavelDeConvenio.Criar(string.Empty, _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável não pode ser nula."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorComMenosCaracteres_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavelDeConvenio.Criar(StringHelper.GerarStringComDigitosRandomicos(47), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável deve conter 48 caracteres."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorSoComEspacos_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavelDeConvenio.Criar(StringHelper.GerarStringSoComEspacos(48), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável não pode ser nula."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorContendoLetrasOuCaracteresEspeciais_DeveRetornarResultComErros()
        {
            var result = LinhaDigitavelDeConvenio.Criar(StringHelper.GerarStringComNumerosELetrasOuCaracteresEspeciais(48), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável contém dígitos não numéricos."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeDigitosDiferenteDeOito")]
        public void Criar_ComOPrimeiroDigitoDiferenteDeOito_DeveRetornarResultComErros(string primeiroDigito)
        {
            var result = LinhaDigitavelDeConvenio.Criar($"{primeiroDigito}{StringHelper.GerarStringComDigitosRandomicos(47)}", _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "A linha digitável não pertence a um convênio."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeSegmentoDeConvenioNaoCadastrado")]
        public void Criar_ComOSegmentoDeConvenioNaoCadastrado_DeveRetornarResultComErros(string segundoDigito, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar($"8{segundoDigito}{StringHelper.GerarStringComDigitosRandomicos(46)}", configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == $"Segmento {segundoDigito} inválido."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeIdentificacaoDoValorRealOuReferenciaInvalida")]
        public void Criar_ComAIdentificacaoDoValorRealOuReferenciaInvalida_DeveRetornarResultComErros(string segundoDigito,
            string terceiroDigito, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar($"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(45)}",
                configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."
                && x.Reason == "A identificação do valor real ou referência deve ser igual a 6, 7, 8 ou 9."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeConvenioNaoCadastrado")]
        public void Criar_ComOConvenioNaoCadastrado_DeveRetornarResultComErros(string segundoDigito, string codigoDoConvenio, string valor,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida."
                && x.Reason == $"O sistema não aceita convênios com o código {codigoDoConvenio} para o segmento {segundoDigito}."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDePrimeiroDigitoVerificadorInvalido")]
        public void Criar_ComOPrimeiroDigitoVerificadorInvalido_DeveRetornarResultComErros(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "O primeiro dígito verificador não é válido."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeSegundoDigitoVerificadorInvalido")]
        public void Criar_ComOSegundoDigitoVerificadorInvalido_DeveRetornarResultComErros(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "O segundo dígito verificador não é válido."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeTerceiroDigitoVerificadorInvalido")]
        public void Criar_ComOTerceiroDigitoVerificadorInvalido_DeveRetornarResultComErros(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "O terceiro dígito verificador não é válido."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeQuartoDigitoVerificadorInvalido")]
        public void Criar_ComOQuartoDigitoVerificadorInvalido_DeveRetornarResultComErros(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Linha digitável inválida." && x.Reason == "O quarto dígito verificador não é válido."));
            Assert.IsTrue(result.ErroMessage.Message == "Linha digitável inválida.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValoresValidos")]
        public void Criar_ComValorValido_DeveRetornarResultSemErrosComValorIgualAoInformado(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = LinhaDigitavelDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.AreEqual(result.Value.Valor, valor);
        }

        private static IEnumerable<string> GeradorDeDigitosDiferenteDeOito()
        {
            return new[] { "0", "1", "2", "3", "4", "5", "6", "7", "9" }.OrderBy(x => Guid.NewGuid());
        }

        private static IEnumerable<object[]> GeradorDeSegmentoDeConvenioNaoCadastrado()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }.OrderBy(x => Guid.NewGuid());

            var objetos = (from digito in digitos
                           let mock = new Mock<IConfiguracoesDoMotorService>()
                           select new
                           {
                               digito,
                               mock
                           }).ToList();

            objetos.ForEach(x => x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Where(z => objetos.All(k => k.digito != z))
                .Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList()));

            return objetos.Select(x => new object[] { x.digito, x.mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeIdentificacaoDoValorRealOuReferenciaInvalida()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }.OrderBy(x => Guid.NewGuid());

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x != "6" && x != "7" && x != "8" && x != "9")
                           select new
                           {
                               segundoDigito,
                               terceiroDigito
                           }).ToList();

            return objetos.Select(x => new object[] { x.segundoDigito, x.terceiroDigito, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeConvenioNaoCadastrado()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let valorFinal = $"{valor.Substring(0, 11)}0{valor.Substring(11, 11)}0{valor.Substring(22, 11)}0{valor.Substring(33, 11)}0"
                           let mock = new Mock<IConfiguracoesDoMotorService>()
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               segundoDigito,
                               codigoDoConvenio,
                               valorFinal,
                               mock
                           }).ToList();

            objetos.ForEach(x =>
            {
                x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

                x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(codigosDeConvenios.Where(y => y != x.codigoDoConvenio)
                .Select(y => Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == y && z.SegmentoDeConvenio.Codigo == x.segundoDigito)).ToList());
            });

            return objetos.Select(x => new object[] { x.segundoDigito, x.codigoDoConvenio, x.valorFinal, x.mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDePrimeiroDigitoVerificadorInvalido()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let primeiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(0, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(0, 11))
                           let primeiroDigitoVerificadorInvalido = primeiroDigitoVerificador + 1 >= 10
                                ? 0
                                : primeiroDigitoVerificador + 1
                           let segundoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(11, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(11, 11))
                           let terceiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(22, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(22, 11))
                           let quartoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(33, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(33, 11))
                           let valorFinal = $"{valor.Substring(0, 11)}{primeiroDigitoVerificadorInvalido}{valor.Substring(11, 11)}{segundoDigitoVerificador}" +
                                $"{valor.Substring(22, 11)}{terceiroDigitoVerificador}{valor.Substring(33, 11)}{quartoDigitoVerificador}"
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               valorFinal
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeSegundoDigitoVerificadorInvalido()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let primeiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(0, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(0, 11))
                           let segundoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(11, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(11, 11))
                           let segundoDigitoVerificadorInvalido = segundoDigitoVerificador + 1 >= 10
                               ? 0
                               : segundoDigitoVerificador + 1
                           let terceiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(22, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(22, 11))
                           let quartoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(33, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(33, 11))
                           let valorFinal = $"{valor.Substring(0, 11)}{primeiroDigitoVerificador}{valor.Substring(11, 11)}{segundoDigitoVerificadorInvalido}" +
                                $"{valor.Substring(22, 11)}{terceiroDigitoVerificador}{valor.Substring(33, 11)}{quartoDigitoVerificador}"
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               valorFinal
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeTerceiroDigitoVerificadorInvalido()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let primeiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(0, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(0, 11))
                           let segundoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(11, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(11, 11))
                           let terceiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(22, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(22, 11))
                           let terceiroDigitoVerificadorInvalido = terceiroDigitoVerificador + 1 >= 10
                               ? 0
                               : terceiroDigitoVerificador + 1
                           let quartoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(33, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(33, 11))
                           let valorFinal = $"{valor.Substring(0, 11)}{primeiroDigitoVerificador}{valor.Substring(11, 11)}{segundoDigitoVerificador}" +
                                $"{valor.Substring(22, 11)}{terceiroDigitoVerificadorInvalido}{valor.Substring(33, 11)}{quartoDigitoVerificador}"
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               valorFinal
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeQuartoDigitoVerificadorInvalido()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let primeiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(0, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(0, 11))
                           let segundoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(11, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(11, 11))
                           let terceiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(22, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(22, 11))
                           let quartoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(33, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(33, 11))
                           let quartoDigitoVerificadorInvalido = quartoDigitoVerificador + 1 >= 10
                               ? 0
                               : quartoDigitoVerificador + 1
                           let valorFinal = $"{valor.Substring(0, 11)}{primeiroDigitoVerificador}{valor.Substring(11, 11)}{segundoDigitoVerificador}" +
                                $"{valor.Substring(22, 11)}{terceiroDigitoVerificador}{valor.Substring(33, 11)}{quartoDigitoVerificadorInvalido}"
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               valorFinal
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeValoresValidos()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(12)}"
                           let segundoTrecho = codigoDoConvenio.Length == 4
                                ? StringHelper.GerarStringComDigitosRandomicos(25)
                                : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}"
                           let primeiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(0, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(0, 11))
                           let segundoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(11, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(11, 11))
                           let terceiroDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(22, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(22, 11))
                           let quartoDigitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                                ? CalcularODigitoVerificadorDoBlocoParaModulo10(valor.Substring(33, 11))
                                : CalcularODigitoVerificadorDoBlocoParaModulo11(valor.Substring(33, 11))
                           let valorFinal = $"{valor.Substring(0, 11)}{primeiroDigitoVerificador}{valor.Substring(11, 11)}{segundoDigitoVerificador}" +
                                $"{valor.Substring(22, 11)}{terceiroDigitoVerificador}{valor.Substring(33, 11)}{quartoDigitoVerificador}"
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               valorFinal
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static int CalcularODigitoVerificadorDoBlocoParaModulo10(string bloco)
        {
            var multiplicadoresDoModulo10 = new int[] { 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2 };

            var caracteres = bloco.ToCharArray();

            var resultadoDaMultiplicacao = 0;

            for (int i = 0; i < caracteres.Length; i++)
            {
                var produto = (int.Parse(caracteres[i].ToString()) * multiplicadoresDoModulo10[i]);

                if (produto >= 10)
                {
                    resultadoDaMultiplicacao += produto.SomarDigitos();
                }
                else
                {
                    resultadoDaMultiplicacao += produto;
                }
            }

            var restoDaDivisao = resultadoDaMultiplicacao % 10;

            var digitoVerificador = restoDaDivisao == 0 ? 0 : 10 - restoDaDivisao;

            return digitoVerificador;
        }

        private static int CalcularODigitoVerificadorDoBlocoParaModulo11(string bloco)
        {
            var multiplicadoresDoModulo11 = new int[] { 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            var caracteres = bloco.ToCharArray();

            var resultadoDoProduto = 0;

            for (int i = 0; i < caracteres.Length; i++)
            {
                resultadoDoProduto += (int.Parse(caracteres[i].ToString()) * multiplicadoresDoModulo11[i]);
            }

            var restoDaDivisao = resultadoDoProduto % 11;

            var digitoVerificadorCalculado = restoDaDivisao == 0 || restoDaDivisao == 1
                ? 1
                : 11 - restoDaDivisao;

            return digitoVerificadorCalculado;
        }
    }
}
