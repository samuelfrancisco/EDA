﻿using COP.ESB.Pagamento.Dominio.Clientes;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using COP.ESB.Pagamento.Dominio.Convenios.Enums;
using COP.ESB.Pagamento.Dominio.Convenios.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using COP.ESB.Pagamento.Dominio.Titulares;
using FizzWare.NBuilder;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Convenios
{
    [TestFixture]
    public class PagamentoDeConvenioTests
    {
        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> _formasDeRecebimento;
        private static ConsultaDeConvenio _consultaDeConvenio;
        private static Cliente _cliente;
        private static Titular _titular;
        private static ConfiguracoesDaEmpresaAplicacaoTransacao _empresaAplicacaoTransacao;
        private static Mock<IPagamentoDeConvenioFormaDeRecebimentoFactory> _pagamentoDeConvenioFormaDeRecebimentoFactoryMock;
        private static int[] _canaisDePagamento;
        private static int[] _quantidadesDeFormas;
        private static string[] _duplicidades;
        private static readonly object _lockObject = new object();

        public static void Inicializar()
        {
            lock (_lockObject)
            {
                if (_formasDeRecebimento == null)
                    _formasDeRecebimento = GerarFormasDeRecebimento();

                if (_consultaDeConvenio == null)
                    _consultaDeConvenio = Builder<ConsultaDeConvenio>.CreateNew().Build();

                if (_cliente == null)
                    _cliente = Builder<Cliente>.CreateNew().Build();

                if (_titular == null)
                    _titular = Builder<Titular>.CreateNew()
                        .With(x => x.CodigoDaColigada = _consultaDeConvenio.CodigoDaColigada)
                        .And(x => x.CodigoDaAgencia = _consultaDeConvenio.CodigoDaAgencia)
                        .And(x => x.NumeroDaContaCorrente = _consultaDeConvenio.NumeroDaContaCorrente)
                        .And(x => x.CodigoDoCliente = _cliente.CodCliente)
                        .Build();

                if (_empresaAplicacaoTransacao == null)
                    _empresaAplicacaoTransacao = Builder<ConfiguracoesDaEmpresaAplicacaoTransacao>.CreateNew()
                        .With(x => x.EmpresaAplicacaoTransacaoId = _consultaDeConvenio.EmpresaAplicacaoTransacaoId)
                        .And(x => x.ValorLimiteParaPagamento = null)
                        .Build();

                if (_pagamentoDeConvenioFormaDeRecebimentoFactoryMock == null)
                {
                    _pagamentoDeConvenioFormaDeRecebimentoFactoryMock = new Mock<IPagamentoDeConvenioFormaDeRecebimentoFactory>();

                    _pagamentoDeConvenioFormaDeRecebimentoFactoryMock
                        .Setup(x => x.From(It.IsAny<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>(), It.IsAny<Guid>()))
                        .Returns<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2, Guid>((command, id) =>
                        {
                            return new Result<PagamentoDeConvenioFormaDeRecebimento>(Mock.Of<PagamentoDeConvenioFormaDeRecebimento>(x => x.CVV2 == command.CVV2
                            && x.DadosDoCheque == command.DadosDoCheque && x.IdDoPagamentoDeConvenio == id && x.MeioDePagamento == command.MeioDePagamento
                            && x.ModoDeEntradaDaTransacao == command.ModoDeEntradaDaTransacao && x.NumeroDeSerieDoPINPAD == command.NumeroDeSerieDoPINPAD
                            && x.TipoDaConta == command.TipoDaConta && x.TipoDeCapturaDoCheque == command.TipoDeCapturaDoCheque
                            && x.Trilha2DoCartaoMagnetico == command.Trilha2DoCartaoMagnetico && x.Valor == command.Valor));
                        });
                }

                if (_canaisDePagamento == null)
                    _canaisDePagamento = new[] { 1, 2, 3, 4, 5, 6, 7, 8 };

                if (_quantidadesDeFormas == null)
                    _quantidadesDeFormas = new[] { 1, 2, 3 };

                if (_duplicidades == null)
                    _duplicidades = new[] { "S", "N" };
            }
        }

        #region Iniciar novo Pagamento

        [Test]
        [TestCaseSource("GeradorDeDadosValidos")]
        public void IniciarNovoPagamento_ComTodosOsDadosValidos_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.IsTrue(result.Value?.CanalDoPagamento == command.CanalDoPagamento);
            Assert.IsTrue(result.Value?.DebitarContaCorrente == empresaAplicacaoTransacao.DebitarContaCorrente);
            Assert.IsTrue(result.Value?.DocumentoDoPagadorFinal == titular.Cgc_Cpf);
            Assert.IsTrue(result.Value?.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacao.EmpresaAplicacaoTransacaoId);
            Assert.IsTrue(result.Value?.EstornarAutomaticamente == empresaAplicacaoTransacao.EstornarAutomaticamente);
            Assert.IsTrue(result.Value?.FormasDeRecebimento?.Count == command.FormasDeRecebimento.Count());

            foreach (var formaDeRecebimento in command.FormasDeRecebimento)
            {
                var forma = result.Value?.FormasDeRecebimento?.FirstOrDefault(x => x.MeioDePagamento == formaDeRecebimento.MeioDePagamento);

                Assert.IsNotNull(forma);
                Assert.IsTrue(forma?.CVV2 == formaDeRecebimento.CVV2);
                Assert.IsTrue(forma?.DadosDoCheque == formaDeRecebimento.DadosDoCheque);
                Assert.IsTrue(forma?.IdDoPagamentoDeConvenio == result.Value?.Id);
                Assert.IsTrue(forma?.ModoDeEntradaDaTransacao == formaDeRecebimento.ModoDeEntradaDaTransacao);
                Assert.IsTrue(forma?.NumeroDeSerieDoPINPAD == formaDeRecebimento.NumeroDeSerieDoPINPAD);
                Assert.IsTrue(forma?.TipoDaConta == formaDeRecebimento.TipoDaConta);
                Assert.IsTrue(forma?.TipoDeCapturaDoCheque == formaDeRecebimento.TipoDeCapturaDoCheque);
                Assert.IsTrue(forma?.Trilha2DoCartaoMagnetico == formaDeRecebimento.Trilha2DoCartaoMagnetico);
                Assert.IsTrue(forma?.Valor == formaDeRecebimento.Valor);
            }

            Assert.IsTrue(result.Value?.IdDaConsultaDeConvenio == command.IdDaConsultaDeConvenio);
            Assert.IsTrue(result.Value?.IdDoConvenio == consulta.IdDoConvenio);
            Assert.IsTrue(result.Value?.IdentificadorDoPagamentoNoCliente == command.IdentificadorDoPagamentoNoCliente);
            Assert.IsTrue(result.Value?.Status == (empresaAplicacaoTransacao.DebitarContaCorrente == true
                ? PagamentoDeConvenioStatus.EmPagamento
                : PagamentoDeConvenioStatus.DebitadoPelaAplicacao));
            Assert.IsTrue(result.Value?.TipoDePessoaDoPagadorFinal == cliente.TipoPessoa);
            Assert.IsTrue(result.Value?.ValidarSaldoDaContaCorrente == empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente);
            Assert.IsTrue(result.Value?.ValorDoPagamento == command.ValorDoPagamento);
        }

        [Test]
        [TestCaseSource("GeradorDeCanalDePagamentoInvalido")]
        public void IniciarNovoPagamento_ComCanalDePagamentoInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Canal do Pagamento deve estar entre 1 e 8."
                && x.Reason == "Canal do Pagamento deve estar entre 1 e 8."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorMenorQueOTotalDasFormasDeRecebimento")]
        public void IniciarNovoPagamento_ComValorMenorQueOTotalDasFormasDeRecebimento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento inválido."
                && x.Reason == "O total recebido deve ser igual ao informado no campo valor do pagamento."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorMaiorQueOTotalDasFormasDeRecebimento")]
        public void IniciarNovoPagamento_ComValorMaiorQueOTotalDasFormasDeRecebimento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento inválido."
                && x.Reason == "O total recebido deve ser igual ao informado no campo valor do pagamento."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorMenorQueZero")]
        public void IniciarNovoPagamento_ComValorMenorQueZero_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento inválido."
                && x.Reason == "Valor do pagamento deve ser maior que 0."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorIgualAZero")]
        public void IniciarNovoPagamento_ComValorIgualAZero_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento inválido."
                && x.Reason == "Valor do pagamento deve ser maior que 0."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorMaiorQueOValorLimiteParaPagamento")]
        public void IniciarNovoPagamento_ComValorMaiorQueOValorLimiteParaPagamento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento inválido."
                && x.Reason == $"Valor do pagamento {command.ValorDoPagamento.ToString("N2")} superior ao limite permitido" +
                    $" {empresaAplicacaoTransacao.ValorLimiteParaPagamento.Value.ToString("N2")}."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeComandoSemNenhumaFormaDeRecebimento")]
        public void IniciarNovoPagamento_SemNenhumaFormaDeRecebimento_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandV2 command,
            ConsultaDeConvenio consulta, Titular titular, Cliente cliente, ConfiguracoesDaEmpresaAplicacaoTransacao empresaAplicacaoTransacao,
            IPagamentoDeConvenioFormaDeRecebimentoFactory pagamentoDeConvenioFormaDeRecebimentoFactory)
        {
            var result = PagamentoDeConvenio.IniciarNovoPagamento(command, consulta, titular, cliente, empresaAplicacaoTransacao,
                pagamentoDeConvenioFormaDeRecebimentoFactory);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Selecione pelo menos uma forma de recebimento."
                && x.Reason == "Selecione pelo menos uma forma de recebimento."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a iniciar novo pagamento de convênio.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        private static IEnumerable<object[]> GeradorDeDadosValidos()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeCanalDePagamentoInvalido()
        {
            Inicializar();

            var canaisDePagamento = new[] { 0, 9, 10, 11, 12, 13, 14, 15 };

            var objetos = (from canalDePagamento in canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorMenorQueOTotalDasFormasDeRecebimento()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor) - 1)
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorMaiorQueOTotalDasFormasDeRecebimento()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor) + 1)
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorMenorQueZero()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = -recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorIgualAZero()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = 0)
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorMaiorQueOValorLimiteParaPagamento()
        {
            Inicializar();     

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = SelecionarFormasDeRecebimento(_formasDeRecebimento, quantidade)
                           let empresaAplicacaoTransacao = Builder<ConfiguracoesDaEmpresaAplicacaoTransacao>.CreateNew()
                               .With(x => x.EmpresaAplicacaoTransacaoId = _consultaDeConvenio.EmpresaAplicacaoTransacaoId)
                               .And(x => x.ValorLimiteParaPagamento = recebimento.Sum(y => y.Valor) - 1)
                               .Build()
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()                          
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeComandoSemNenhumaFormaDeRecebimento()
        {
            Inicializar();

            var objetos = (from canalDePagamento in _canaisDePagamento
                           from quantidade in _quantidadesDeFormas
                           from aceitaDuplicidade in _duplicidades
                           let recebimento = Enumerable.Empty<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>()
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandV2>.CreateNew()
                               .With(x => x.CanalDoPagamento = canalDePagamento)
                               .And(x => x.EmpresaAplicacaoId = _empresaAplicacaoTransacao.EmpresaAplicacaoId)
                               .And(x => x.IdDaConsultaDeConvenio = _consultaDeConvenio.Id)
                               .And(x => x.ValorDoPagamento = recebimento.Sum(y => y.Valor))
                               .And(x => x.FormasDeRecebimento = recebimento)
                               .And(x => x.AceitaDuplicidade = aceitaDuplicidade)
                               .Build()
                           select new object[]
                           {
                               comando,
                               _consultaDeConvenio,
                               _titular,
                               _cliente,
                               _empresaAplicacaoTransacao,
                               _pagamentoDeConvenioFormaDeRecebimentoFactoryMock.Object
                           })
                           .ToList();

            return objetos;
        }

        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> GerarFormasDeRecebimento()
        {
            var meiosDePagamento = new[] { 1, 3, 4 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var formasDeRecebimento = (from meioDePagamento in meiosDePagamento
                                       from tipoDeConta in tiposDeConta
                                       from modoDeEntrada in modosDeEntrada
                                       from tipoDeCaptura in tiposDeCaptura
                                       from valor in valores
                                       let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                                           .With(x => x.MeioDePagamento = meioDePagamento)
                                           .And(x => x.Valor = valor)
                                           .And(x => x.TipoDaConta = tipoDeConta)
                                           .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                                           .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                                           .Build()
                                       where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                                       || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                                       || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                                       select comando).ToList();

            return formasDeRecebimento;
        }

        private static List<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> SelecionarFormasDeRecebimento(
            IEnumerable<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2> formasDeRecebimento, int quantidade)
        {
            switch (quantidade)
            {
                case 1:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Take(1).ToList();
                    }
                case 2:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Distinct(new FormaDeRecebimentoComparer()).Take(2).ToList();
                    }
                case 3:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Distinct(new FormaDeRecebimentoComparer()).Take(3).ToList();
                    }
                default:
                    {
                        return formasDeRecebimento.OrderBy(x => Guid.NewGuid()).Take(1).ToList();
                    }
            }
        }

        private class FormaDeRecebimentoComparer : IEqualityComparer<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>
        {
            public bool Equals(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 x, IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 y)
            {
                return x.MeioDePagamento == y.MeioDePagamento;
            }

            public int GetHashCode(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 obj)
            {
                return obj.MeioDePagamento.GetHashCode();
            }
        }

        #endregion

        #region Validar saldo disponível da conta corrente

        [Test]
        [TestCaseSource("GeradorDeSaldosDisponiveis")]
        public void ValidarSaldoDisponivelDaContaCorrente_ComSaldoMaiorQueOValorDoPagamento_DeveRetornarResultSemErros(decimal saldoDisponivel)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>(x => x.ValorDoPagamento == saldoDisponivel - 1);

            var result = pagamento.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
        }

        [Test]
        [TestCaseSource("GeradorDeSaldosDisponiveis")]
        public void ValidarSaldoDisponivelDaContaCorrente_ComSaldoIgualAoValorDoPagamento_DeveRetornarResultSemErros(decimal saldoDisponivel)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>(x => x.ValorDoPagamento == saldoDisponivel);

            var result = pagamento.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
        }

        [Test]
        [TestCaseSource("GeradorDeSaldosDisponiveis")]
        public void ValidarSaldoDisponivelDaContaCorrente_ComSaldoMenorQueOValorDoPagamento_DeveRetornarResultComErros(decimal saldoDisponivel)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>(x => x.ValorDoPagamento == saldoDisponivel + 1);

            var result = pagamento.ValidarSaldoDisponivelDaContaCorrente(saldoDisponivel);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Valor do pagamento superior ao saldo disponível na conta corrente." 
                && x.Reason == $"Saldo disponível {saldoDisponivel} insuficiente."));
        }

        private static IEnumerable<decimal> GeradorDeSaldosDisponiveis()
        {
            var random = new Random();

            var valores = new List<decimal>();

            while (valores.Count < 10)
            {
                var valor = random.NextDecimal();

                if (valor <= 0)
                    continue;

                valores.Add(valor);
            }

            return valores;
        }

        #endregion
        
        #region Recusar

        [Test]
        [TestCaseSource("GeradorDeErros")]
        public void Recusar_DeveAlterarOStatusESalvarCodigoEDescricaoDoErro(int codigoDeErro, string descricaoDoErro)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.Recusar(codigoDeErro, descricaoDoErro);

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.Recusado);
            Assert.IsTrue(pagamento.CodigoDeErro == codigoDeErro);
            Assert.IsTrue(pagamento.DescricaoDoErro == descricaoDoErro);
        }

        private static IEnumerable<object[]> GeradorDeErros()
        {
            var gerador = new RandomGenerator();

            var descricoes = new List<string>();

            for (int i = 0; i < 10; i++)
            {
                descricoes.Add(gerador.Phrase(30));
            }

            var objetos = (from codigoDeErro in Builder<int>.CreateListOfSize(10).Build()
                           from descricaoDoErro in descricoes
                           select new object[]
                           {
                               codigoDeErro, 
                               descricaoDoErro
                           })
                           .ToList();

            return objetos;
        }

        #endregion

        #region Marcar como pendente de Liquidação

        [Test]        
        public void MarcarComoPendenteDeLiquidacao_DeveAlterarOStatus()
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.MarcarComoPendenteDeLiquidacao();

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.PendenteDeLiquidacao);            
        }

        #endregion

        #region Recusar na Liquidação

        [Test]
        [TestCaseSource("GeradorDeErros")]
        public void RecusarNaLiquidacao_DeveAlterarOStatusESalvarCodigoEDescricaoDoErro(int codigoDeErro, string descricaoDoErro)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.RecusarNaLiquidacao(codigoDeErro, descricaoDoErro);

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.LiquidacaoRecusada);
            Assert.IsTrue(pagamento.CodigoDeErro == codigoDeErro);
            Assert.IsTrue(pagamento.DescricaoDoErro == descricaoDoErro);
        }

        #endregion

        #region Efetivar

        [Test]
        public void Efetivar_DeveAlterarOStatus()
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.Efetivar();

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.Efetivado);
        }

        #endregion

        #region Marcar como Em Estorno

        [Test]
        public void MarcarComoEmEstorno_DeveAlterarOStatus()
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.MarcarComoEmEstorno();

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.EmEstorno);
        }

        #endregion

        #region Marcar como Estornado

        [Test]
        public void MarcarComoEstornado_DeveAlterarOStatus()
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.MarcarComoEstornado();

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.Estornado);
        }

        #endregion

        #region Recusar na Liquidação

        [Test]
        [TestCaseSource("GeradorDeErros")]
        public void MarcarComoEstornoRecusado_DeveAlterarOStatusESalvarCodigoEDescricaoDoErro(int codigoDeErro, string descricaoDoErro)
        {
            var pagamento = Mock.Of<PagamentoDeConvenio>();

            pagamento.MarcarComoEstornoRecusado(codigoDeErro, descricaoDoErro);

            Assert.IsTrue(pagamento.Status == PagamentoDeConvenioStatus.EstornoRecusado);
            Assert.IsTrue(pagamento.CodigoDeErro == codigoDeErro);
            Assert.IsTrue(pagamento.DescricaoDoErro == descricaoDoErro);
        }

        #endregion
    }
}
