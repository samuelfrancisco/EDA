﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using COP.ESB.Pagamento.Dominio.Tests.Helpers;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Convenios
{
    [TestFixture]
    public class CodigoDeBarrasDeConvenioTests
    {
        private Mock<IConfiguracoesDoMotorService> _configurecoesDoMotorServiceMock = new Mock<IConfiguracoesDoMotorService>();

        [Test]
        public void Criar_ComValorNulo_DeveRetornarResultComErros()
        {
            var result = CodigoDeBarrasDeConvenio.Criar(null, _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras não pode ser nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorEmBranco_DeveRetornarResultComErros()
        {
            var result = CodigoDeBarrasDeConvenio.Criar(string.Empty, _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras não pode ser nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorComMenosCaracteres_DeveRetornarResultComErros()
        {
            var result = CodigoDeBarrasDeConvenio.Criar(StringHelper.GerarStringComDigitosRandomicos(43), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras deve conter 44 caracteres."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorSoComEspacos_DeveRetornarResultComErros()
        {
            var result = CodigoDeBarrasDeConvenio.Criar(StringHelper.GerarStringSoComEspacos(44), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras não pode ser nulo."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        public void Criar_ComValorContendoLetrasOuCaracteresEspeciais_DeveRetornarResultComErros()
        {
            var result = CodigoDeBarrasDeConvenio.Criar(StringHelper.GerarStringComNumerosELetrasOuCaracteresEspeciais(44), _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras contém dígitos não numéricos."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeDigitosDiferenteDeOito")]
        public void Criar_ComOPrimeiroDigitoDiferenteDeOito_DeveRetornarResultComErros(string primeiroDigito)
        {
            var result = CodigoDeBarrasDeConvenio.Criar($"{primeiroDigito}{StringHelper.GerarStringComDigitosRandomicos(43)}", _configurecoesDoMotorServiceMock.Object);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == "O código de barras não pertence a um convênio."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeSegmentoDeConvenioNaoCadastrado")]
        public void Criar_ComOSegmentoDeConvenioNaoCadastrado_DeveRetornarResultComErros(string segundoDigito, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = CodigoDeBarrasDeConvenio.Criar($"8{segundoDigito}{StringHelper.GerarStringComDigitosRandomicos(42)}", configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido." && x.Reason == $"Segmento {segundoDigito} inválido."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeIdentificacaoDoValorRealOuReferenciaInvalida")]
        public void Criar_ComAIdentificacaoDoValorRealOuReferenciaInvalida_DeveRetornarResultComErros(string segundoDigito,
            string terceiroDigito, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = CodigoDeBarrasDeConvenio.Criar($"8{segundoDigito}{terceiroDigito}{StringHelper.GerarStringComDigitosRandomicos(41)}",
                configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido."
                && x.Reason == "A identificação do valor real ou referência deve ser igual a 6, 7, 8 ou 9."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeDigitoVerificadorInvalido")]
        public void Criar_ComDigitoVerificadorInvalido_DeveRetornarResultComErros(string primeiroTrecho, string digitoVerificador, string segundoTrecho,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = CodigoDeBarrasDeConvenio.Criar($"{primeiroTrecho}{digitoVerificador}{segundoTrecho}", configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido."
                && x.Reason == "Dígito verificador do código de barras é inválido."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeConvenioNaoCadastrado")]
        public void Criar_ComOConvenioNaoCadastrado_DeveRetornarResultComErros(string segundoDigito, string primeiroTrecho, string codigoDoConvenio,
            string segundoTrecho, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = CodigoDeBarrasDeConvenio.Criar($"8{segundoDigito}{primeiroTrecho}{codigoDoConvenio}{segundoTrecho}", configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Código de barras inválido."
                && x.Reason == $"O sistema não aceita convênios com o código {codigoDoConvenio} para o segmento {segundoDigito}."));
            Assert.IsTrue(result.ErroMessage.Message == "Código de barras inválido.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValoresValidos")]
        public void Criar_ComValorValido_DeveRetornarResultSemErrosComValorIgualAoInformado(string valor, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = CodigoDeBarrasDeConvenio.Criar(valor, configuracoesDoMotorService);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.AreEqual(result.Value.Valor, valor);
        }

        private static IEnumerable<string> GeradorDeDigitosDiferenteDeOito()
        {
            return new[] { "0", "1", "2", "3", "4", "5", "6", "7", "9" }.OrderBy(x => Guid.NewGuid());
        }

        private static IEnumerable<object[]> GeradorDeSegmentoDeConvenioNaoCadastrado()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }.OrderBy(x => Guid.NewGuid());

            var objetos = (from digito in digitos
                           let mock = new Mock<IConfiguracoesDoMotorService>()
                           select new
                           {
                               digito,
                               mock
                           }).ToList();

            objetos.ForEach(x => x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Where(z => objetos.All(k => k.digito != z))
                .Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList()));

            return objetos.Select(x => new object[] { x.digito, x.mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeIdentificacaoDoValorRealOuReferenciaInvalida()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }.OrderBy(x => Guid.NewGuid());

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x != "6" && x != "7" && x != "8" && x != "9")                           
                           select new
                           {
                               segundoDigito,
                               terceiroDigito                               
                           }).ToList();           

            return objetos.Select(x => new object[] { x.segundoDigito, x.terceiroDigito, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeDigitoVerificadorInvalido()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}"
                           let segundoTrecho = $"{StringHelper.GerarStringComDigitosRandomicos(11)}{codigoDoConvenio}" 
                               + (codigoDoConvenio.Length == 4 
                               ? StringHelper.GerarStringComDigitosRandomicos(25) 
                               : StringHelper.GerarStringComDigitosRandomicos(21))
                           let valor = $"{primeiroTrecho}0{segundoTrecho}"
                           let digitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                               ? CalcularODigitoVerificadorAPartirDoValorParaModulo10(valor)
                               : CalcularODigitoVerificadorAPartirDoValorParaModulo11(valor)
                           let digitoVerificadorInvalido = (digitoVerificador + 1 >= 10 ? 0 : digitoVerificador + 1).ToString()                           
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               segundoDigito,
                               primeiroTrecho,
                               digitoVerificadorInvalido,
                               segundoTrecho                               
                           }).ToList();

            return objetos.Select(x => new object[] { x.primeiroTrecho, x.digitoVerificadorInvalido, x.segundoTrecho, mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeConvenioNaoCadastrado()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let parte1 = StringHelper.GerarStringComDigitosRandomicos(11)
                           let segundoTrecho = codigoDoConvenio.Length == 4 ? StringHelper.GerarStringComDigitosRandomicos(25) : StringHelper.GerarStringComDigitosRandomicos(21)
                           let valor = $"8{segundoDigito}{terceiroDigito}0{parte1}{codigoDoConvenio}{segundoTrecho}"
                           let digitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                               ? CalcularODigitoVerificadorAPartirDoValorParaModulo10(valor)
                               : CalcularODigitoVerificadorAPartirDoValorParaModulo11(valor)
                           let primeiroTrecho = $"{terceiroDigito}{digitoVerificador}{parte1}"
                           let mock = new Mock<IConfiguracoesDoMotorService>()
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {
                               segundoDigito,
                               primeiroTrecho,
                               codigoDoConvenio,
                               segundoTrecho,
                               mock
                           }).ToList();

            objetos.ForEach(x =>
            {
                x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

                x.mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns(codigosDeConvenios.Where(y => y != x.codigoDoConvenio)
                .Select(y => Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == y && z.SegmentoDeConvenio.Codigo == x.segundoDigito)).ToList());
            });

            return objetos.Select(x => new object[] { x.segundoDigito, x.primeiroTrecho, x.codigoDoConvenio, x.segundoTrecho, x.mock.Object }).ToList();
        }

        private static IEnumerable<object[]> GeradorDeValoresValidos()
        {
            var digitos = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            var codigosDeConvenios = new List<string>();
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(4)));
            codigosDeConvenios.AddRange(Enumerable.Range(1, 10).Select(x => StringHelper.GerarStringComDigitosRandomicos(8)));

            var mock = new Mock<IConfiguracoesDoMotorService>();

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio)
                .Returns(digitos.Select(z => Mock.Of<ConfiguracoesDoSegmentoDeConvenio>(k => k.Active == true && k.Codigo == z)).ToList());

            mock.Setup(y => y.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios)
                .Returns((from segmento in digitos
                          from convenio in codigosDeConvenios
                          select Mock.Of<ConfiguracoesDoConvenio>(z => z.Active == true && z.Codigo == convenio && z.SegmentoDeConvenio.Codigo == segmento))
                          .ToList());

            var objetos = (from segundoDigito in digitos
                           from terceiroDigito in digitos.Where(x => x == "6" || x == "7" || x == "8" || x == "9")
                           from codigoDoConvenio in codigosDeConvenios
                           let primeiroTrecho = $"8{segundoDigito}{terceiroDigito}"
                           let segundoTrecho = $"{StringHelper.GerarStringComDigitosRandomicos(11)}{codigoDoConvenio}"
                               + (codigoDoConvenio.Length == 4
                               ? StringHelper.GerarStringComDigitosRandomicos(25)
                               : StringHelper.GerarStringComDigitosRandomicos(21))
                           let valor = $"{primeiroTrecho}0{segundoTrecho}"
                           let digitoVerificador = terceiroDigito == "6" || terceiroDigito == "7"
                               ? CalcularODigitoVerificadorAPartirDoValorParaModulo10(valor)
                               : CalcularODigitoVerificadorAPartirDoValorParaModulo11(valor)
                           let valorFinal = $"{primeiroTrecho}{digitoVerificador}{segundoTrecho}"                           
                           where (segundoDigito == "6" && codigoDoConvenio.Length == 8) || (segundoDigito != "6" && codigoDoConvenio.Length == 4)
                           select new
                           {                               
                               valorFinal                               
                           }).ToList();

            return objetos.Select(x => new object[] { x.valorFinal, mock.Object }).ToList();
        }

        private static int CalcularODigitoVerificadorAPartirDoValorParaModulo10(string valor)
        {
            var multiplicadoresDoModulo10 = new int[] { 2, 1, 2, 0, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2 };

            var caracteres = valor.ToCharArray();

            var resultadoDaMultiplicacao = 0;

            for (int i = 0; i < caracteres.Length; i++)
            {
                var produto = (int.Parse(caracteres[i].ToString()) * multiplicadoresDoModulo10[i]);

                if (produto >= 10)
                {
                    resultadoDaMultiplicacao += produto.SomarDigitos();
                }
                else
                {
                    resultadoDaMultiplicacao += produto;
                }
            }

            var restoDaDivisao = resultadoDaMultiplicacao % 10;

            var digitoVerificador = restoDaDivisao == 0 ? 0 : 10 - restoDaDivisao;

            return digitoVerificador;
        }

        private static int CalcularODigitoVerificadorAPartirDoValorParaModulo11(string valor)
        {
            var multiplicadoresDoModulo11 = new int[] { 4, 3, 2, 0, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            var caracteres = valor.ToCharArray();

            var resultadoDoProduto = 0;

            for (int i = 0; i < caracteres.Length; i++)
            {
                resultadoDoProduto += (int.Parse(caracteres[i].ToString()) * multiplicadoresDoModulo11[i]);
            }

            var restoDaDivisao = resultadoDoProduto % 11;

            var digitoVerificadorCalculado = restoDaDivisao == 0 || restoDaDivisao == 1
                ? 1
                : 11 - restoDaDivisao;

            return digitoVerificadorCalculado;
        }
    }
}
