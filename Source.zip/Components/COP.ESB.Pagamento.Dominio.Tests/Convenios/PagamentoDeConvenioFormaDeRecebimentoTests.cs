﻿using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using FizzWare.NBuilder;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Tests.Convenios
{
    [TestFixture]
    public class PagamentoDeConvenioFormaDeRecebimentoTests
    {
        [Test]
        [TestCaseSource("GeradorDeDadosValidos")]
        public void Criar_ComTodosOsDadosValidos_DeveRetornarResultSemErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsSuccess);
            Assert.IsFalse(result.ErroMessage.Errors.Any());
            Assert.IsNotNull(result.Value);
            Assert.AreEqual(command.CVV2, result.Value?.CVV2);
            Assert.AreEqual(command.DadosDoCheque, result.Value?.DadosDoCheque);
            Assert.AreEqual(command.MeioDePagamento, result.Value?.MeioDePagamento);
            Assert.AreEqual(command.ModoDeEntradaDaTransacao, result.Value?.ModoDeEntradaDaTransacao);
            Assert.AreEqual(command.NumeroDeSerieDoPINPAD, result.Value?.NumeroDeSerieDoPINPAD);
            Assert.AreEqual(command.TipoDaConta, result.Value?.TipoDaConta);
            Assert.AreEqual(command.TipoDeCapturaDoCheque, result.Value?.TipoDeCapturaDoCheque);
            Assert.AreEqual(command.Trilha2DoCartaoMagnetico, result.Value?.Trilha2DoCartaoMagnetico);
            Assert.AreEqual(command.Valor, result.Value?.Valor);
            Assert.AreEqual(idDoPagamentoDeConvenio, result.Value?.IdDoPagamentoDeConvenio);
        }

        [Test]
        [TestCaseSource("GeradorDeMeioDePagamentoInvalido")]
        public void Criar_ComUmMeioDePagamentoInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Meio de pagamento deve ter um dos seguintes valores: 1, 3, 4, 5 ou 6."
                && x.Reason == "Meio de pagamento deve ter um dos seguintes valores: 1, 3, 4, 5 ou 6."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeValorMenorOuIgualAZero")]
        public void Criar_ComUmValorMenorOuIgualAZero_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "O valor deve ser maior que zero."
                && x.Reason == "O valor deve ser maior que zero."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeTipoDaContaInvalido")]
        public void Criar_ComUmTipoDaContaInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Tipo da conta do cartão deve estar entre 1 e 5."
                && x.Reason == "Tipo da conta do cartão deve estar entre 1 e 5."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeModoDeEntradaDaTransacaoInvalido")]
        public void Criar_ComUmModoDeEntradaDaTransacaoInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Modo de entrada da transação deve estar entre 0 e 4."
                && x.Reason == "Modo de entrada da transação deve estar entre 0 e 4."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeTrilha2DoCartaoMagneticoInvalida")]
        public void Criar_ComUmaTrilha2DoCartaoMagneticoInvalida_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe a trilha 2 do cartão magnético."
                && x.Reason == "Informe a trilha 2 do cartão magnético."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeCVV2Invalido")]
        public void Criar_ComUmCVV2Invalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe o CVV2 do cartão magnético."
                && x.Reason == "Informe o CVV2 do cartão magnético."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeNumeroDeSerieDoPINPADInvalido")]
        public void Criar_ComUmNumeroDeSerieDoPINPADInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe o número de série do PINPAD."
                && x.Reason == "Informe o número de série do PINPAD."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeTipoDeCapturaDoChequeInvalido")]
        public void Criar_ComUmTipoDeCapturaDoChequeInvalido_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Tipo de captura do cheque deve estar entre 0 e 1."
                && x.Reason == "Tipo de captura do cheque deve estar entre 0 e 1."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        [Test]
        [TestCaseSource("GeradorDeDadosDoChequeInvalidos")]
        public void Criar_ComDadosDoChequeInvalidos_DeveRetornarResultComErros(IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2 command, Guid idDoPagamentoDeConvenio)
        {
            var result = PagamentoDeConvenioFormaDeRecebimento.From(command, idDoPagamentoDeConvenio);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsFailure);
            Assert.IsTrue(result.ErroMessage.Errors.Any(x => x.Message == "Informe o CMC7 do cheque."
                && x.Reason == "Informe o CMC7 do cheque."));
            Assert.IsTrue(result.ErroMessage.Message == "Dados inválidos para a forma de recebimento.");
            Assert.IsTrue(result.ErroMessage.StatusCode == 400);
        }

        private static IEnumerable<object[]> GeradorDeDadosValidos()
        {
            var meiosDePagamento = new[] { 1, 3, 4, 5, 6 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeMeioDePagamentoInvalido()
        {
            var meiosDePagamento = new[] { 0, 2, 7, 8, 9 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeValorMenorOuIgualAZero()
        {
            var meiosDePagamento = new[] { 1, 3, 4, 5, 6 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(-10, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeTipoDaContaInvalido()
        {
            var meiosDePagamento = new[] { 3 };

            var tiposDeConta = new[] { 0, 6, 7, 8, 9, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeModoDeEntradaDaTransacaoInvalido()
        {
            var meiosDePagamento = new[] { 3 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 5, 6, 7, 8, 9, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeTrilha2DoCartaoMagneticoInvalida()
        {
            var meiosDePagamento = new[] { 3 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var trilhas = new[] { null, string.Empty, " " };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           from trilha in trilhas
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .And(x => x.Trilha2DoCartaoMagnetico = trilha)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeCVV2Invalido()
        {
            var meiosDePagamento = new[] { 3 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var cvv2s = new[] { null, string.Empty, " " };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           from cvv2 in cvv2s
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .And(x => x.CVV2 = cvv2)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeNumeroDeSerieDoPINPADInvalido()
        {
            var meiosDePagamento = new[] { 3 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var pinPADs = new[] { null, string.Empty, " " };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           from pinPAD in pinPADs
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .And(x => x.NumeroDeSerieDoPINPAD = pinPAD)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeTipoDeCapturaDoChequeInvalido()
        {
            var meiosDePagamento = new[] { 4 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 2, 3, (int?)null };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }

        private static IEnumerable<object[]> GeradorDeDadosDoChequeInvalidos()
        {
            var meiosDePagamento = new[] { 4 };

            var tiposDeConta = new[] { 1, 2, 3, 4, 5, (int?)null };

            var modosDeEntrada = new[] { 0, 1, 2, 3, 4, (int?)null };

            var tiposDeCaptura = new[] { 0, 1, (int?)null };

            var dadosDosCheques = new[] { null, string.Empty, " " };

            var valores = Enumerable.Range(1, 10);

            var objetos = (from meioDePagamento in meiosDePagamento
                           from tipoDeConta in tiposDeConta
                           from modoDeEntrada in modosDeEntrada
                           from tipoDeCaptura in tiposDeCaptura
                           from valor in valores
                           from dadosDoCheque in dadosDosCheques
                           let comando = Builder<IniciarNovoPagamentoDeConvenioCommandFormaDeRecebimentoV2>.CreateNew()
                               .With(x => x.MeioDePagamento = meioDePagamento)
                               .And(x => x.Valor = valor)
                               .And(x => x.TipoDaConta = tipoDeConta)
                               .And(x => x.ModoDeEntradaDaTransacao = modoDeEntrada)
                               .And(x => x.TipoDeCapturaDoCheque = tipoDeCaptura)
                               .And(x => x.DadosDoCheque = dadosDoCheque)
                               .Build()
                           let id = Guid.NewGuid()
                           where (meioDePagamento == 3 && tipoDeConta != null && modoDeEntrada != null && tipoDeCaptura == null)
                           || (meioDePagamento == 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura != null)
                           || (meioDePagamento != 3 && meioDePagamento != 4 && tipoDeConta == null && modoDeEntrada == null && tipoDeCaptura == null)
                           select new object[]
                           {
                               comando,
                               id
                           })
                           .ToList();

            return objetos;
        }
    }
}
