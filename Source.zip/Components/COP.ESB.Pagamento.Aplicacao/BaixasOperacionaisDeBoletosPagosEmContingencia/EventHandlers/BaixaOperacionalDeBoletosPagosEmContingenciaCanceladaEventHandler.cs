﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixasOperacionaisDeBoletosPagosEmContingencia.EventHandlers
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent>
    {
        private readonly IBaixaOperacionalDeBoletosPagosEmContingenciaRepository _baixaOperacionalDeBoletosPagosEmContingenciaRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEventHandler(IUnitOfWork unityOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IBaixaOperacionalDeBoletosPagosEmContingenciaRepository baixaOperacionalDeBoletosPagosEmContingenciaRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unityOfWork, eventHandlerRepository)
        {
            _baixaOperacionalDeBoletosPagosEmContingenciaRepository = baixaOperacionalDeBoletosPagosEmContingenciaRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent @event, CancellationToken cancellationToken)
        {
            var baixa = await _baixaOperacionalDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.SourceId).ConfigureAwait(false);

            if (baixa == null) return;

            var to = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Geração de arquivo de baixa operacional de boletos pagos contingência.";

            var corpoDoEmail = await GerarCorpoDoEmail(baixa, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(BaixaOperacionalDeBoletosPagosEmContingencia baixa, string assuntoDoEmail)
        {            
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var model = new ConsultaEBaixaEmContingenciaCancelamentoDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Cancelamento do processo de geração automática de arquivos de baixa operacional de boletos pagos contingência:",
                DataDeReferencia = baixa.DataDeProcessamento.ToString("dd/MM/yyyy"),
                DataEHoraDaGeracao = baixa.DataDeInicio.ToString("dd/MM/yyyy HH:mm:ss"),
                QuantidadeTotalDePagamentos = baixa.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Count().ToString(),
                ValorTotalDosPagamentos = baixa.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Sum(x => x.VlrBaixaOperacTit).ToString("C2"),
                MotivoDoCancelamento = $"A baixa foi cancelada, pois: {baixa.MotivoDoCancelamento}"
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\ConsultaEBaixaEmContingenciaCancelamento.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }        
    }
}
