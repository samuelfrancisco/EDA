﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace COP.ESB.Pagamento.Aplicacao.BaixasOperacionaisDeBoletosPagosEmContingencia.CommandHandlers
{
    public class IniciarBaixaOperacionalDosPagamentosSelecionadosCommandHandler : CommandRequestHandler<IniciarBaixaOperacionalDosPagamentosSelecionadosCommand>
    {
        private readonly IBaixaOperacionalDeBoletosPagosEmContingenciaRepository _baixaOperacionalDeBoletosPagosEmContingenciaRepository;
        private readonly IBoletoRepository _boletoRepository;
        private readonly ICalendarioService _calendarioService;
        private readonly IBancoService _bancoService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IBaixaOperacionalDeBoletosPagosEmContingenciaService _baixaOperacionalDeBoletosPagosEmContingenciaService;

        public IniciarBaixaOperacionalDosPagamentosSelecionadosCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalDeBoletosPagosEmContingenciaRepository baixaOperacionalDeBoletosPagosEmContingenciaRepository,
            IBoletoRepository boletoRepository,
            ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IBaixaOperacionalDeBoletosPagosEmContingenciaService baixaOperacionalDeBoletosPagosEmContingenciaService,
            IBancoService bancoService,
            IEnvioDeEmailService envioDeEmailService)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalDeBoletosPagosEmContingenciaRepository = baixaOperacionalDeBoletosPagosEmContingenciaRepository;
            _boletoRepository = boletoRepository;
            _calendarioService = calendarioService;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _baixaOperacionalDeBoletosPagosEmContingenciaService = baixaOperacionalDeBoletosPagosEmContingenciaService;
            _bancoService = bancoService;
        }

        protected override async Task DoHandleAsync(IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command, CancellationToken cancellationToken)
        {
            var baixa = await _baixaOperacionalDeBoletosPagosEmContingenciaRepository
                .ObterPeloIdDoProcessoDeConsultaEBaixaAsync(command.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (baixa != null)
                return;

            var dataDeProcessamento = _calendarioService.ObterADataDeProcessamento();

            var pagamentos = await ObterPagamentosEmContingenciaPendentesDeBaixaOperacionalAsync(command).ConfigureAwait(false);

            baixa = new BaixaOperacionalDeBoletosPagosEmContingencia(command, dataDeProcessamento, pagamentos, _baixaOperacionalDeBoletosPagosEmContingenciaService,
                _configuracoesDoMotorService, _bancoService);

            if (baixa.Status == BaixaOperacionalDeBoletosPagosEmContingenciaStatus.Iniciada)
            {
                var result = await EnviarArquivosDaBaixaOperacionalAsync(command, baixa).ConfigureAwait(false);

                if (result.IsFailure)
                    baixa.Cancelar(new CancelarBaixaOperacionalDeBoletosPagosEmContingenciaCommand
                    {
                        IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                        MotivoDoCancelamento = string.Join(Environment.NewLine, result.ErroMessage.Errors.Select(x => x.Message)),
                        CorrelationMessage = command,
                        OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                    });
            }

            await _baixaOperacionalDeBoletosPagosEmContingenciaRepository.SaveAsync(baixa, command.Id).ConfigureAwait(false);
        }

        private async Task<IEnumerable<PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO>> ObterPagamentosEmContingenciaPendentesDeBaixaOperacionalAsync(IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command)
        {
            var idsDosPagamentos = command.Pagamentos.Select(x => x.IdDoPagamentoDeBoleto).Distinct().ToList();

            var pagamentos = await _boletoRepository.ObterPagamentosPelosIdsAsync(idsDosPagamentos).ConfigureAwait(false);

            return pagamentos.Select(x => new PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO
            {
                EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId,
                IdDoBoleto = x.IdDoBoleto,
                IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = x.Id,
                NumCodBarrasBaixaOperac = x.Boleto.CodigoDeBarras.Valor,
                CanalPagamento = x.CanalDoPagamento,
                CNPJ_CPFPort = x.DocumentoDoPagadorFinal,
                DtHrProcBaixaOperac = x.DataDoPagamento,
                DtProcBaixaOperac = x.DataDoPagamento,
                MeioPagamento = x.MeioDePagamento,
                TpBaixaOperac = x.TipoDeBaixaOperacional,
                TpPessoaPort = x.TipoDePessoaDoPagadorFinal,
                VlrBaixaOperacTit = x.ValorDoPagamento,
            }).ToList();
        }

        private Task<Result> EnviarArquivosDaBaixaOperacionalAsync(IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command,
            BaixaOperacionalDeBoletosPagosEmContingencia baixaOperacional)
        {
            return Task.Run(() =>
            {
                var result = new Result();

                var arquivosSalvos = new Dictionary<Guid, string>();

                foreach (var arquivoGerado in baixaOperacional.ArquivosGerados)
                {
                    try
                    {
                        var caminhoDoArquivo = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia;

                        var nomeCompletoDoArquivo = $"{caminhoDoArquivo}\\{arquivoGerado.NomeDoArquivo}.xml";

                        var xml = new XmlDocument
                        {
                            InnerXml = arquivoGerado.XmlGerado
                        };

                        xml.Save(nomeCompletoDoArquivo);

                        arquivosSalvos.Add(arquivoGerado.Id, nomeCompletoDoArquivo);
                    }
                    catch (Exception ex)
                    {
                        result.AddError(ex.Message, ex.Source, GetType().FullName);
                    }
                }

                if (result.IsSuccess)
                {
                    baixaOperacional.EnviarArquivos(new EnviarArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand
                    {
                        IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                        NomesCompletosDosArquivosNoEnvio = arquivosSalvos,
                        CorrelationMessage = command,
                        OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                    });
                }

                return result;
            });
        }
    }
}
