﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixasOperacionaisDeBoletosPagosEmContingencia.CommandHandlers
{
    public class ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommandHandler
    : CommandRequestHandler<ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand>
    {
        private readonly IBaixaOperacionalDeBoletosPagosEmContingenciaRepository _baixaOperacionalDeBoletosPagosEmContingenciaRepository;

        public ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalDeBoletosPagosEmContingenciaRepository baixaOperacionalDeBoletosPagosEmContingenciaRepository)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalDeBoletosPagosEmContingenciaRepository = baixaOperacionalDeBoletosPagosEmContingenciaRepository;
        }

        protected override async Task DoHandleAsync(ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command, CancellationToken cancellationToken)
        {
            var baixa = await _baixaOperacionalDeBoletosPagosEmContingenciaRepository
                .ObterPeloIdDoProcessoDeConsultaEBaixaAsync(command.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (baixa == null)
                return;

            var xmlRetornadoResult = await ObterXmlDoArquivoDeRetornoAsync(command.NomeCompletoDoArquivo).ConfigureAwait(false);

            if (xmlRetornadoResult.IsSuccess)
            {
                baixa.ProcessarErroDeArquivo(command, xmlRetornado: xmlRetornadoResult.Value);
            }
            else
            {
                baixa.ProcessarErroDeArquivo(command, erro: xmlRetornadoResult.ErroMessage.Message);
            }

            await _baixaOperacionalDeBoletosPagosEmContingenciaRepository.SaveAsync(baixa, command.Id).ConfigureAwait(false);
        }

        private async Task<Result<string>> ObterXmlDoArquivoDeRetornoAsync(string nomeCompletoDoArquivo)
        {
            try
            {
                using (var fs = new FileStream(nomeCompletoDoArquivo, FileMode.Open, FileAccess.Read))
                using (var sw = new StreamReader(fs))
                {
                    var xml = await sw.ReadToEndAsync().ConfigureAwait(false);

                    return new Result<string>(xml);
                }
            }
            catch (Exception ex)
            {
                var result = new Result();
                result.AddError(ex.Message, ex.Source, GetType().FullName);
                result.ErroMessage.Message = $"Não foi possível ler o arquivo de retorno: {ex.Message}.";
                return result.ToResult<string>();
            }
        }
    }
}
