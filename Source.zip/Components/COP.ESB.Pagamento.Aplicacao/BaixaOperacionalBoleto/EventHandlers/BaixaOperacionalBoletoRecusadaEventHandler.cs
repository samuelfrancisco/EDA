﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalBoletos.EventHandlers
{
    public class BaixaOperacionalBoletoRecusadaEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<BaixaOperacionalBoletoRecusadaEvent>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IBoletoRepository _boletoRepository;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public BaixaOperacionalBoletoRecusadaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IBoletoRepository boletoRepository,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _boletoRepository = boletoRepository;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalBoletoRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(BaixaOperacionalBoletoRecusadaEvent @event, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(_configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeBaixaOperacional))
                return;

            var consulta = await _boletoRepository.ObterConsultaDeBoletoPeloIdAsync(@event.IdDaConsultaDeBoleto).ConfigureAwait(false);

            if (consulta == null)
                return;

            var to = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeBaixaOperacional?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Baixa Operacional Recusada";

            var corpoDoEmail = await GerarCorpoDoEmail(consulta, @event.MensagemDeRecusa, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConsultaDeBoleto consulta, string mensagemDeRecusa, string assuntoDoEmail)
        {
            var model = new BaixaOperacionalBoletoRejeitadaRecusadaDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Segue os dados da Baixa Operacional recusada no envio:",
                CodigoDaAgencia = consulta.CodigoDaAgencia,
                NumeroDaContaCorrente = consulta.NumeroDaContaCorrente,
                Valor = consulta.Boleto.CodigoDeBarras.Valor,
                MensagemDeRecusa = $"A baixa foi recusada, pois: {mensagemDeRecusa}"
            };

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\BaixaOperacionalBoletoRejeitadaRecusada.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
