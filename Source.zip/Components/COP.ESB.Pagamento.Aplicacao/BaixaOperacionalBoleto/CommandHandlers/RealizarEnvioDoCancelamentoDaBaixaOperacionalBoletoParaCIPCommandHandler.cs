﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalBoletos.CommandHandlers
{
    public class RealizarEnvioDoCancelamentoDaBaixaOperacionalBoletoParaCIPCommandHandler
        : CommandRequestHandler<RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIPCommandV2>
    {
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalRepository;
        private readonly IServicoDeBaixaOperacionalDeBoleto _baixaOperacionalPendenteService;

        public RealizarEnvioDoCancelamentoDaBaixaOperacionalBoletoParaCIPCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalRepository,
            IServicoDeBaixaOperacionalDeBoleto baixaOperacionalPendenteService)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalRepository = baixaOperacionalRepository;
            _baixaOperacionalPendenteService = baixaOperacionalPendenteService;
        }

        protected override async Task DoHandleAsync(RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIPCommandV2 command, CancellationToken cancellationToken)
        {
            var baixaOperacional = await _baixaOperacionalRepository.ObterPorCodigoDoPagamentoAsync(command.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (baixaOperacional == null)
                throw new Exception("Baixa Operacional não encontrada.");

            var envioCIP = await _baixaOperacionalPendenteService.EnviarEstornoDaBaixaOperacionalCIPAsync(command).ConfigureAwait(false);

            if (envioCIP.IsFailure)
                throw new Exception(envioCIP.ErroMessage.Message);

            var statusRetorno = (StatusRetornoTransacaoBaixaOperacional)envioCIP.ErroMessage.StatusCode;

            if (envioCIP.IsFailure &&
                 (statusRetorno == StatusRetornoTransacaoBaixaOperacional.ErrosDeSQL || statusRetorno == StatusRetornoTransacaoBaixaOperacional.ErrosGenericos))
                throw new Exception(envioCIP.ErroMessage.Message);

            command.Sucesso = envioCIP.IsSuccess;

            baixaOperacional.RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIP(command, statusRetorno);

            await _baixaOperacionalRepository.SaveAsync(baixaOperacional, command.Id).ConfigureAwait(false);
        }
    }
}
