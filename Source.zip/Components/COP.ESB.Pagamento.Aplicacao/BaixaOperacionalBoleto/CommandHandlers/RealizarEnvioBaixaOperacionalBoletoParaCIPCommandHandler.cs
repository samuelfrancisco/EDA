﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalBoletos.CommandHandlers
{
    public class RealizarEnvioBaixaOperacionalBoletoParaCIPCommandHandler
        : CommandRequestHandler<RealizarEnvioBaixaOperacionalBoletoParaCIPCommand>
    {
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalRepository;
        private readonly IServicoDeBaixaOperacionalDeBoleto _baixaOperacionalPendenteService;

        public RealizarEnvioBaixaOperacionalBoletoParaCIPCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalRepository,
            IServicoDeBaixaOperacionalDeBoleto baixaOperacionalPendenteService)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalRepository = baixaOperacionalRepository;
            _baixaOperacionalPendenteService = baixaOperacionalPendenteService;
        }

        protected override async Task DoHandleAsync(RealizarEnvioBaixaOperacionalBoletoParaCIPCommand command, CancellationToken cancellationToken)
        {
            var envioCIP = await _baixaOperacionalPendenteService.EnviarBaixaOperacionalCIPAsync(command).ConfigureAwait(false);

            if (envioCIP.IsFailure)
                throw new Exception(envioCIP.ErroMessage.Message);

            var statusRetorno = (StatusRetornoTransacaoBaixaOperacional)envioCIP.ErroMessage.StatusCode;

            if (envioCIP.IsFailure &&
                 (statusRetorno == StatusRetornoTransacaoBaixaOperacional.ErrosDeSQL || statusRetorno == StatusRetornoTransacaoBaixaOperacional.ErrosGenericos))
                throw new Exception(envioCIP.ErroMessage.Message);

            command.Sucesso = envioCIP.IsSuccess;
            command.StatusRetornoTransacao = statusRetorno;

            var baixaOperacional = new BaixaOperacionalBoleto(command);

            await _baixaOperacionalRepository.SaveAsync(baixaOperacional, command.Id).ConfigureAwait(false);
        }
    }
}
