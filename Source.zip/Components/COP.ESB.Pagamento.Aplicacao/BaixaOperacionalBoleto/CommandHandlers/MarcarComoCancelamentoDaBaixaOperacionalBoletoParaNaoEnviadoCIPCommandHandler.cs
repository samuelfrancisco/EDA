﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalBoletos.CommandHandlers
{
    public class MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIPCommandHandler
        : CommandRequestHandler<MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIPCommandV2>
    {
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalRepository;

        public MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIPCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalRepository)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalRepository = baixaOperacionalRepository;
        }

        protected override async Task DoHandleAsync(MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIPCommandV2 command, CancellationToken cancellationToken)
        {
            var baixaOperacional = await _baixaOperacionalRepository.ObterPorCodigoDoPagamentoAsync(command.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (baixaOperacional == null)
                throw new Exception("Baixa Operacional não encontrada.");

            baixaOperacional.MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIP();

            await _baixaOperacionalRepository.SaveAsync(baixaOperacional, command.Id).ConfigureAwait(false);
        }
    }
}
