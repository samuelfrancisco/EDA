﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalBoletos.CommandHandlers
{
    public class BaixaOperacionalBoletoNaoEnviadaParaCIPCommandHandler
        : CommandRequestHandler<MarcarBaixaOperacionalBoletoNaoEnviadaParaCIPCommand>
    {
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalRepository;

        public BaixaOperacionalBoletoNaoEnviadaParaCIPCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalRepository)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalRepository = baixaOperacionalRepository;
        }

        protected override async Task DoHandleAsync(MarcarBaixaOperacionalBoletoNaoEnviadaParaCIPCommand command, CancellationToken cancellationToken)
        {
            var baixaOperacional = new BaixaOperacionalBoleto(command);

            await _baixaOperacionalRepository.SaveAsync(baixaOperacional, command.Id).ConfigureAwait(false);
        }
    }
}
