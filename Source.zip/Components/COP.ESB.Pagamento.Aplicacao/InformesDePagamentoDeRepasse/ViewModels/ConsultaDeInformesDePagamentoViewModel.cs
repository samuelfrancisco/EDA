﻿using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels
{
    /// <summary>
    /// View model dos filtros para consulta dos informes de pagamento
    /// </summary>
    public class ConsultaDeInformesDePagamentoViewModel : FiltrosComPaginacaoViewModel
    {
        /// <summary>
        /// Códigos dos canais de processamento
        /// </summary>
        public IEnumerable<string> CodigosDosCanaisDeProcessamento { get; set; }

        /// <summary>
        /// Ids dos tipos de repasse
        /// </summary>
        public IEnumerable<int> IdsDosTiposDeRepasse { get; set; }

        /// <summary>
        /// Ids dos meios de pagamento
        /// </summary>
        public IEnumerable<int> IdsDosMeiosDePagamento { get; set; }

        /// <summary>
        /// Valor mínimo dos pagamentos
        /// </summary>
        public decimal? ValorMinimoDoPagamento { get; set; }

        /// <summary>
        /// Valor máximo dos pagamentos
        /// </summary>
        public decimal? ValorMaximoDoPagamento { get; set; }

        /// <summary>
        /// Data mínima dos pagamentos
        /// </summary>
        public DateTime? DataMinimaDePagamento { get; set; }

        /// <summary>
        /// Data máxima dos pagamentos
        /// </summary>
        public DateTime? DataMaximaDePagamento { get; set; }        
    }
}
