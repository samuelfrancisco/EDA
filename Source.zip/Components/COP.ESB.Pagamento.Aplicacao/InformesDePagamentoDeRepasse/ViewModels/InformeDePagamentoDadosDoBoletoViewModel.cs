﻿using System;
using System.Globalization;
using System.Text;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels
{
    /// <summary>
    /// View model dos dados do boleto
    /// </summary>
    public class InformeDePagamentoDadosDoBoletoViewModel
    {
        private string _dadosDoBoleto;

        /// <summary>
        /// Id do informe de pagamento
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Dados do boleto
        /// </summary>
        public string DadosDoBoleto
        {
            get
            {
                return _dadosDoBoleto;
            }
            set
            {
                DefinirOsValoresDosCampos(value);

                _dadosDoBoleto = value;
            }
        }

        /// <summary>
        /// Código do banco
        /// </summary>
        public string CodigoDoBanco { get; set; }

        /// <summary>
        /// Nome do banco
        /// </summary>
        public string NomeDoBanco { get; set; }

        /// <summary>
        /// Local de pagamento
        /// </summary>
        public string LocalDePagamento { get; set; }

        /// <summary>
        /// Dados do beneficiário
        /// </summary>
        public string Beneficiario1 { get; set; }

        /// <summary>
        /// Agência e código do cedente
        /// </summary>
        public string AgenciaECodigoDoCedente { get; set; }

        /// <summary>
        /// Nosso número
        /// </summary>
        public string NossoNumero { get; set; }

        /// <summary>
        /// Data de vencimento do boleto
        /// </summary>
        public string DataDeVencimento { get; set; }

        /// <summary>
        /// Valor do documento
        /// </summary>
        public string ValorDoDocumento { get; set; }

        /// <summary>
        /// Data do documento
        /// </summary>
        public string DataDoDocumento { get; set; }

        /// <summary>
        /// Número do documento
        /// </summary>
        public string NumeroDoDocumento { get; set; }

        /// <summary>
        /// Espécie do documento
        /// </summary>
        public string EspecieDoDocumento { get; set; }

        /// <summary>
        /// Aceite
        /// </summary>
        public string Aceite { get; set; }

        /// <summary>
        /// Data de processamento
        /// </summary>
        public string DataDeProcessamento { get; set; }

        /// <summary>
        /// Campo para uso do banco
        /// </summary>
        public string UsoDoBanco { get; set; }

        /// <summary>
        /// Carteira
        /// </summary>
        public string Carteira { get; set; }

        /// <summary>
        /// Espécie da moeda
        /// </summary>
        public string EspecieDaMoeda { get; set; }

        /// <summary>
        /// Quantidade
        /// </summary>
        public string Quantidade { get; set; }

        /// <summary>
        /// Valor
        /// </summary>
        public string Valor { get; set; }

        /// <summary>
        /// Instruções 1
        /// </summary>
        public string Instrucoes1 { get; set; }

        /// <summary>
        /// Instruções 2
        /// </summary>
        public string Instrucoes2 { get; set; }

        /// <summary>
        /// Instruções 3
        /// </summary>
        public string Instrucoes3 { get; set; }

        /// <summary>
        /// Dados do pagador
        /// </summary>
        public string Pagador1 { get; set; }

        /// <summary>
        /// Mais dados do pagador
        /// </summary>
        public string Pagador2 { get; set; }

        /// <summary>
        /// Dados do sacador
        /// </summary>
        public string Sacador1 { get; set; }

        /// <summary>
        /// Código de barras do boleto
        /// </summary>
        public string CodigoDeBarras { get; set; }

        /// <summary>
        /// Desconto
        /// </summary>
        public string Desconto { get; set; }

        /// <summary>
        /// Outras deduções
        /// </summary>
        public string OutrasDeducoes { get; set; }

        /// <summary>
        /// Mora e multa
        /// </summary>
        public string MoraEMulta { get; set; }

        /// <summary>
        /// Outros acrécismos
        /// </summary>
        public string OutrosAcrescimos { get; set; }

        /// <summary>
        /// Valor cobrado
        /// </summary>
        public string ValorCobrado { get; set; }

        /// <summary>
        /// Mais dados do beneficiário
        /// </summary>
        public string Beneficiario2 { get; set; }

        /// <summary>
        /// CPF ou CNPJ do beneficiário
        /// </summary>
        public string CPFOuCNPJDoBeneficiario { get; set; }

        /// <summary>
        /// Mais dados do sacador
        /// </summary>
        public string Sacador2 { get; set; }

        private void DefinirOsValoresDosCampos(string valor)
        {
            if (string.IsNullOrWhiteSpace(valor))
                return;

            var campos = valor.Split('|');

            for (int i = 0; i < campos.Length; i++)
            {
                var indice = i + 1;

                switch (indice)
                {
                    case 1:
                        {
                            if (string.IsNullOrWhiteSpace(CodigoDoBanco))
                            {
                                CodigoDoBanco = campos[i];
                            }

                            break;
                        }
                    case 2:
                        {
                            if (string.IsNullOrWhiteSpace(NomeDoBanco))
                            {
                                NomeDoBanco = campos[i];
                            }

                            break;
                        }
                    case 3:
                        {
                            if (string.IsNullOrWhiteSpace(LocalDePagamento))
                            {
                                LocalDePagamento = campos[i];
                            }

                            break;
                        }
                    case 4:
                        {
                            if (string.IsNullOrWhiteSpace(Beneficiario1))
                            {
                                Beneficiario1 = campos[i];
                            }

                            break;
                        }
                    case 5:
                        {
                            if (string.IsNullOrWhiteSpace(AgenciaECodigoDoCedente))
                            {
                                AgenciaECodigoDoCedente = campos[i];
                            }

                            break;
                        }
                    case 6:
                        {
                            if (string.IsNullOrWhiteSpace(NossoNumero))
                            {
                                NossoNumero = campos[i];
                            }

                            break;
                        }
                    case 7:
                        {
                            if (string.IsNullOrWhiteSpace(DataDeVencimento))
                            {
                                DataDeVencimento = campos[i];
                            }

                            break;
                        }
                    case 8:
                        {
                            if (string.IsNullOrWhiteSpace(ValorDoDocumento))
                            {
                                ValorDoDocumento = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 9:
                        {
                            if (string.IsNullOrWhiteSpace(DataDoDocumento))
                            {
                                DataDoDocumento = campos[i];
                            }

                            break;
                        }
                    case 10:
                        {
                            if (string.IsNullOrWhiteSpace(NumeroDoDocumento))
                            {
                                NumeroDoDocumento = campos[i];
                            }

                            break;
                        }
                    case 11:
                        {
                            if (string.IsNullOrWhiteSpace(EspecieDoDocumento))
                            {
                                EspecieDoDocumento = campos[i];
                            }

                            break;
                        }
                    case 12:
                        {
                            if (string.IsNullOrWhiteSpace(Aceite))
                            {
                                Aceite = campos[i];
                            }

                            break;
                        }
                    case 13:
                        {
                            if (string.IsNullOrWhiteSpace(DataDeProcessamento))
                            {
                                DataDeProcessamento = campos[i];
                            }

                            break;
                        }
                    case 14:
                        {
                            if (string.IsNullOrWhiteSpace(UsoDoBanco))
                            {
                                UsoDoBanco = campos[i];
                            }

                            break;
                        }
                    case 15:
                        {
                            if (string.IsNullOrWhiteSpace(Carteira))
                            {
                                Carteira = campos[i];
                            }

                            break;
                        }
                    case 16:
                        {
                            if (string.IsNullOrWhiteSpace(EspecieDaMoeda))
                            {
                                EspecieDaMoeda = campos[i];
                            }

                            break;
                        }
                    case 17:
                        {
                            if (string.IsNullOrWhiteSpace(Quantidade))
                            {
                                Quantidade = campos[i];
                            }

                            break;
                        }
                    case 18:
                        {
                            if (string.IsNullOrWhiteSpace(Valor))
                            {
                                Valor = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 19:
                        {
                            if (string.IsNullOrWhiteSpace(Instrucoes1))
                            {
                                Instrucoes1 = campos[i];
                            }

                            break;
                        }
                    case 20:
                        {
                            if (string.IsNullOrWhiteSpace(Instrucoes2))
                            {
                                Instrucoes2 = campos[i];
                            }

                            break;
                        }
                    case 21:
                        {
                            if (string.IsNullOrWhiteSpace(Instrucoes3))
                            {
                                Instrucoes3 = campos[i];
                            }

                            break;
                        }
                    case 22:
                        {
                            if (string.IsNullOrWhiteSpace(Pagador1))
                            {
                                Pagador1 = campos[i];
                            }

                            break;
                        }
                    case 23:
                        {
                            if (string.IsNullOrWhiteSpace(Pagador2))
                            {
                                Pagador2 = campos[i];
                            }

                            break;
                        }
                    case 24:
                        {
                            if (string.IsNullOrWhiteSpace(Sacador1))
                            {
                                Sacador1 = campos[i];
                            }

                            break;
                        }
                    case 25:
                        {
                            if (string.IsNullOrWhiteSpace(CodigoDeBarras))
                            {
                                CodigoDeBarras = campos[i];
                            }

                            break;
                        }
                    case 26:
                        {
                            if (string.IsNullOrWhiteSpace(Desconto))
                            {
                                Desconto = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 27:
                        {
                            if (string.IsNullOrWhiteSpace(OutrasDeducoes))
                            {
                                OutrasDeducoes = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 28:
                        {
                            if (string.IsNullOrWhiteSpace(MoraEMulta))
                            {
                                MoraEMulta = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 29:
                        {
                            if (string.IsNullOrWhiteSpace(OutrosAcrescimos))
                            {
                                OutrosAcrescimos = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 30:
                        {
                            if (string.IsNullOrWhiteSpace(ValorCobrado))
                            {
                                ValorCobrado = ObterValorDecimalFormatado(campos[i]);
                            }

                            break;
                        }
                    case 31:
                        {
                            if (string.IsNullOrWhiteSpace(Beneficiario2))
                            {
                                Beneficiario2 = campos[i];
                            }

                            break;
                        }
                    case 32:
                        {
                            if (string.IsNullOrWhiteSpace(CPFOuCNPJDoBeneficiario))
                            {
                                CPFOuCNPJDoBeneficiario = campos[i];
                            }

                            break;
                        }
                    case 33:
                        {
                            if (string.IsNullOrWhiteSpace(Sacador2))
                            {
                                Sacador2 = campos[i];
                            }

                            break;
                        }
                    default:
                        break;
                }
            }
        }

        private string ObterValorDecimalFormatado(string valor)
        {
            if (string.IsNullOrWhiteSpace(valor) || valor?.Length < 3)
                return null;

            var valorMontado = $"{valor.Substring(0, valor.Length - 2)},{valor.Substring(valor.Length - 2)}";

            if (!decimal.TryParse(valorMontado, NumberStyles.Number, new CultureInfo("pt-BR"), out decimal valorDecimal))
                return null;

            return valorDecimal.ToString("C", new CultureInfo("pt-BR"));
        }
    }
}
