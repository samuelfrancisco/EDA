﻿using COP.ESB.Pagamento.Aplicacao.Core.Attributes;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels
{
    /// <summary>
    /// View model para registro de informe de pagamento para reposição parcial do saldo
    /// </summary>
    public class RegistrarInformeDePagamentoDeRepasseParaReposicaoParcialDoSaldoViewModel
    {
        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        [Required(ErrorMessage = "Canal de processamento inválido.")]
        [AcceptedValues("Corban", ErrorMessage = "Canal de processamento inválido.")]
        public string CodigoDoCanalDeProcessamento { get; set; }       

        /// <summary>
        /// Meio de pagamento
        /// </summary>
        [Range(1, 2, ErrorMessage = "Meio de pagamento inválido.")]
        public int IdDoMeioDePagamento { get; set; }

        /// <summary>
        /// Valor pago
        /// </summary>
        [Required(ErrorMessage = "Valor pago inválido.")]
        public string ValorDoPagamento { get; set; }

        /// <summary>
        /// Id do usuário efetuando o registro
        /// </summary>
        [Required(ErrorMessage = "Id do usuário inválido.")]
        public string IdDoUsuario { get; set; }

        /// <summary>
        /// Nome do usuário efetuando o registro
        /// </summary>
        [Required(ErrorMessage = "Nome do usuário inválido.")]
        public string NomeDoUsuario { get; set; }
    }
}
