﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels
{
    /// <summary>
    /// View model do informe de pagamento
    /// </summary>
    public class InformeDePagamentoViewModel
    {
        /// <summary>
        /// Id do informe de pagamento
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Tipo de repasse
        /// </summary>
        public string TipoDeRepasse { get; set; }

        /// <summary>
        /// >Data / Hora do pagamento do repasse 
        /// </summary>
        public string DataEHoraDoPagamento { get; set; }

        /// <summary>
        /// Meio de pagamento
        /// </summary>
        public string MeioDePagamento { get; set; }

        /// <summary>
        /// Valor pago
        /// </summary>
        public string ValorPago { get; set; }

        /// <summary>
        /// Data / Hora do envio da transação de fechamento
        /// </summary>
        public string DataEHoraDoEnvioDaTransacao { get; set; }

        /// <summary>
        /// Valor total da transação de fechamento
        /// </summary>
        public string ValorTotalDaTransacao { get; set; }

        /// <summary>
        /// Boleto da transação de fechamento
        /// </summary>
        public string BoletoDaTransacao { get; set; }

        /// <summary>
        /// Comprovante da transação de fechamento
        /// </summary>
        public string ComprovanteDaTransacao { get; set; }

        /// <summary>
        /// Canal de processamento
        /// </summary>
        public string Canal { get; set; }

        /// <summary>
        /// Flag indicando se o informe de pagamento pode ser editado
        /// </summary>
        public bool PodeSerEditado { get; set; }

        /// <summary>
        /// Flag indicando se o informe de pagamento pode ser excluído
        /// </summary>
        public bool PodeSerExcluido { get; set; }
    }
}
