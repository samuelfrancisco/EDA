﻿using COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels;
using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.DTOs;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Enums;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Repositories.Interfaces;
using System;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.Services
{
    public class ServicoDeConsultaDeInformesDePagamentos : IServicoDeConsultaDeInformesDePagamentos
    {
        private readonly IInformeDePagamentoDeRepasseParaOCorbanRepository _informeDePagamentoDeRepasseParaOCorbanRepository;

        public ServicoDeConsultaDeInformesDePagamentos(IInformeDePagamentoDeRepasseParaOCorbanRepository informeDePagamentoDeRepasseParaOCorbanRepository)
        {
            _informeDePagamentoDeRepasseParaOCorbanRepository = informeDePagamentoDeRepasseParaOCorbanRepository;
        }

        public async Task<PaginaViewModel<InformeDePagamentoViewModel>> ObterOsInformesDePagamentoAsync(ConsultaDeInformesDePagamentoViewModel filtros)
        {
            var filtrosDTO = ObterADTODosFiltros(filtros);

            var pagina = await _informeDePagamentoDeRepasseParaOCorbanRepository.ConsultaAsync(filtrosDTO).ConfigureAwait(false);

            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var paginaViewModel = new PaginaViewModel<InformeDePagamentoViewModel>
            {
                PaginaAtual = pagina.PaginaAtual,
                RegistrosPorPagina = pagina.RegistrosPorPagina,
                TotalDeRegistros = pagina.TotalDeRegistros,
                Registros = pagina.Registros.Select(x => ObterAViewModelDoRegistro(x)).ToList()
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            return paginaViewModel;
        }        

        private ConsultaDeInformesDePagamentoDTO ObterADTODosFiltros(ConsultaDeInformesDePagamentoViewModel filtros)
        {
            return new ConsultaDeInformesDePagamentoDTO
            {
                CodigosDosCanaisDeProcessamento = filtros?.CodigosDosCanaisDeProcessamento,
                IdsDosTiposDeRepasse = filtros?.IdsDosTiposDeRepasse,
                IdsDosMeiosDePagamento = filtros?.IdsDosMeiosDePagamento,
                ValorMinimoDoPagamento = filtros?.ValorMinimoDoPagamento,
                ValorMaximoDoPagamento = filtros?.ValorMaximoDoPagamento,
                DataMinimaDePagamento = filtros?.DataMinimaDePagamento,
                DataMaximaDePagamento = filtros?.DataMaximaDePagamento,
                PaginaAtual = filtros?.PaginaAtual,
                RegistrosPorPagina = filtros?.RegistrosPorPagina
            };
        }

        private InformeDePagamentoViewModel ObterAViewModelDoRegistro(Dominio.Corban.InformesDePagamentoDeRepasse.InformeDePagamentoDeRepasseParaOCorban registro)
        {
            return new InformeDePagamentoViewModel
            {
                Id = registro.Id,
                TipoDeRepasse = registro.TipoDeRepasse == InformeDePagamentoDeRepasseParaOCorbanTipoDeRepasse.TransacaoDeFechamentoDeRepasse
                               ? "Transação de Fechamento de Repasse"
                               : "Reposição Parcial de Saldo",
                DataEHoraDoPagamento = registro.DataDoPagamento.ToString("dd/MM/yyyy HH:mm:ss"),
                MeioDePagamento = registro.MeioDePagamento == InformeDePagamentoDeRepasseParaOCorbanMeioDePagamento.TED
                               ? "TED"
                               : "Boleto",
                ValorPago = registro.ValorDoPagamento.ToString("C2"),
                DataEHoraDoEnvioDaTransacao = registro.DataDeEnvioDoRepasse.HasValue
                               ? registro.DataDeEnvioDoRepasse.Value.ToString("dd/MM/yyyy HH:mm:ss")
                               : null,
                ValorTotalDaTransacao = registro.ValorDoRepasse.HasValue
                               ? registro.ValorDoRepasse.Value.ToString("C2")
                               : null,
                BoletoDaTransacao = registro.DadosDoBoletoDoRepasse,
                ComprovanteDaTransacao = registro.ComprovanteDoRepasse,
                Canal = "Corban",
                PodeSerEditado = registro.TipoDeRepasse == InformeDePagamentoDeRepasseParaOCorbanTipoDeRepasse.ReposicaoParcialDoSaldo
                                && registro.DataDoPagamento.Date == DateTime.Today,
                PodeSerExcluido = registro.TipoDeRepasse == InformeDePagamentoDeRepasseParaOCorbanTipoDeRepasse.ReposicaoParcialDoSaldo
                                && registro.DataDoPagamento.Date == DateTime.Today
            };
        }

        public async Task<InformeDePagamentoDadosDoBoletoViewModel> ObterOsDadosDoBoletoDoInformeDePagamentoAsync(Guid idDoInformeDePagamento)
        {
            var informeDePagamento = await _informeDePagamentoDeRepasseParaOCorbanRepository.GetByIdAsync(idDoInformeDePagamento).ConfigureAwait(false);

            if (informeDePagamento == null || string.IsNullOrWhiteSpace(informeDePagamento?.DadosDoBoletoDoRepasse))
                return null;

            return new InformeDePagamentoDadosDoBoletoViewModel
            {
                Id = informeDePagamento.Id,
                DadosDoBoleto = informeDePagamento.DadosDoBoletoDoRepasse
            };
        }
    }
}
