﻿using COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels;
using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.Services.Interfaces
{
    public interface IServicoDeConsultaDeInformesDePagamentos
    {
        Task<PaginaViewModel<InformeDePagamentoViewModel>> ObterOsInformesDePagamentoAsync(ConsultaDeInformesDePagamentoViewModel filtros);
        Task<InformeDePagamentoDadosDoBoletoViewModel> ObterOsDadosDoBoletoDoInformeDePagamentoAsync(Guid idDoInformeDePagamento);
    }
}
