﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.EstornosDePagamentosDeBoletos.CommandHandlers
{
    public class RealizarEstornoDePagamentoDeBoletoCommandHandler
        : CommandRequestHandler<RealizarEstornoDePagamentoDeBoletoCommand>
    {
        private readonly IEstornoDePagamentoDeBoletoRepository _estornoDePagamentoDeBoletoRepository;       

        public RealizarEstornoDePagamentoDeBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IEstornoDePagamentoDeBoletoRepository estornoDePagamentoDeBoletoRepository)
            : base(commandHandlerRepository)
        {
            _estornoDePagamentoDeBoletoRepository = estornoDePagamentoDeBoletoRepository;            
        }

        protected override async Task DoHandleAsync(RealizarEstornoDePagamentoDeBoletoCommand command, CancellationToken cancellationToken)
        {
            EstornoDePagamentoDeBoleto estorno;

            //var result = await _servicoDeCreditoDeContaCorrente.CreditarValorNaContaCorrenteAsync(new CreditoNaContaCorrenteDTO
            //{
            //    CodigoDaColigada = command.CodigoDaColigada,
            //    CodigoDaAgencia = command.CodigoDaAgencia,
            //    NumeroDaContaCorrente = command.NumeroDaContaCorrente,
            //    DocumentoDoPagadorFinal = command.DocumentoDoPagadorFinal,
            //    ValorDoCredito = command.ValorDoPagamento,
            //    DataDoCredito = command.DataDoPagamento.DateTime
            //}).ConfigureAwait(false);

            //if (result.IsFailure)
            //{
            //    estorno = new EstornoDePagamentoDeBoleto(command, codigoDeErro: result.ErroMessage.StatusCode, descricaoDoErro: result.ErroMessage.Message);

            //    await _estornoDePagamentoDeBoletoRepository.SaveAsync(estorno, command.Id).ConfigureAwait(false);

            //    return;
            //}

            estorno = new EstornoDePagamentoDeBoleto(command, codigoDeErro: 0);

            await _estornoDePagamentoDeBoletoRepository.SaveAsync(estorno, command.Id).ConfigureAwait(false);
        }
    }
}
