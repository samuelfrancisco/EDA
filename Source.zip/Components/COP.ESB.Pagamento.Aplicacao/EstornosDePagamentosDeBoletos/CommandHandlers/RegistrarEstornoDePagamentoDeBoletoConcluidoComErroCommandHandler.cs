﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.EstornosDePagamentosDeBoletos.CommandHandlers
{
    public class RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommandHandler
        : CommandRequestHandler<RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommand>
    {
        private readonly IEstornoDePagamentoDeBoletoRepository _estornoDePagamentoDeBoletoRepository;       

        public RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IEstornoDePagamentoDeBoletoRepository estornoDePagamentoDeBoletoRepository            )
            : base(commandHandlerRepository)
        {
            _estornoDePagamentoDeBoletoRepository = estornoDePagamentoDeBoletoRepository;
            
        }

        protected override async Task DoHandleAsync(RegistrarEstornoDePagamentoDeBoletoConcluidoComErroCommand command, CancellationToken cancellationToken)
        {
            var debito = new EstornoDePagamentoDeBoleto(command);

            await _estornoDePagamentoDeBoletoRepository.SaveAsync(debito, command.Id).ConfigureAwait(false);            
        }
    }
}
