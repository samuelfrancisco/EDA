﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Contas.Events
{
    public class ContaRemovida : IntegrationEvent
    {
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }
        public string NROCONTA { get; set; }
    }
}
