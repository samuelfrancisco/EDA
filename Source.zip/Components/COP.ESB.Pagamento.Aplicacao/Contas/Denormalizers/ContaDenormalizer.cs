﻿using COP.ESB.Pagamento.Aplicacao.Contas.Events;
using COP.ESB.Pagamento.Dominio.Contas;
using COP.ESB.Pagamento.Dominio.Contas.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Contas.Denormalizers
{
    public class ContaDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovaContaRegistrada>,
        IAsyncEventHandler<ContaRemovida>
    {
        private readonly IContaRepository _contaRepository;

        public ContaDenormalizer(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository, IContaRepository contaRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _contaRepository = contaRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovaContaRegistrada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovaContaRegistrada @event, CancellationToken cancellationToken)
        {
            var conta = await _contaRepository.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(@event.CODCOLIGADA, @event.CODAGENCIA, @event.NROCONTA)
                .ConfigureAwait(false);

            if (conta != null)
                return;

            conta = new Conta { CodColigada = @event.CODCOLIGADA, CodAgencia = @event.CODAGENCIA, NumeroDaConta = @event.NROCONTA, CodSituacao = @event.CODSITUACAO };

            await _contaRepository.SaveAsync(conta).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ContaRemovida> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ContaRemovida @event, CancellationToken cancellationToken)
        {
            var conta = await _contaRepository.ObterContaPeloCodColigadaCodAgenciaENumeroDaContaAsync(@event.CODCOLIGADA, @event.CODAGENCIA, @event.NROCONTA)
                .ConfigureAwait(false);

            if (conta == null)
                return;

            conta.Disable();

            await _contaRepository.SaveAsync(conta).ConfigureAwait(false);
        }
    }
}
