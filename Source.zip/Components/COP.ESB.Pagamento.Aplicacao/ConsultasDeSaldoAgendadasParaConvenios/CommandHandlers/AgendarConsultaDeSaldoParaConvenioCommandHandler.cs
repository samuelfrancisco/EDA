﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaConvenios;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoAgendadasParaConvenios.CommandHandlers
{
    public class AgendarConsultaDeSaldoParaConvenioCommandHandler : CommandRequestHandler<AgendarConsultaDeSaldoParaConvenioCommand>
    {
        private readonly IConsultaDeSaldoAgendadaParaConvenioRepository _consultaDeSaldoAgendadaParaConvenioRepository;

        public AgendarConsultaDeSaldoParaConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoAgendadaParaConvenioRepository consultaDeSaldoAgendadaParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoAgendadaParaConvenioRepository = consultaDeSaldoAgendadaParaConvenioRepository;
        }

        protected override async Task DoHandleAsync(AgendarConsultaDeSaldoParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var consultaDoSaldoAgendada = new ConsultaDeSaldoAgendadaParaConvenio(command);

            await _consultaDeSaldoAgendadaParaConvenioRepository.SaveAsync(consultaDoSaldoAgendada).ConfigureAwait(false);
        }
    }
}
