﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services
{
    public class ConfiguracoesDoConvenioAppService : IConfiguracoesDoConvenioAppService
    {
        private readonly IConfiguracoesDoConvenioRepository _configuracoesDoConvenioRepository;

        public ConfiguracoesDoConvenioAppService(IConfiguracoesDoConvenioRepository configuracoesDoConvenioRepository)
        {
            _configuracoesDoConvenioRepository = configuracoesDoConvenioRepository;
        }

        public async Task<IEnumerable<ConvenioViewModel>> ObterTodosAsync()
        {
            var result = new Result();
            result.ErroMessage.StatusCode = 200;

            var lista = await _configuracoesDoConvenioRepository.ObterTodosAsync().ConfigureAwait(false);

            var listaViewModel = lista.Select(ToViewModel).ToList();

            return listaViewModel;
        }

        public async Task<IEnumerable<ConvenioViewModel>> ObterTodosAtivosAsync()
        {
            var lista = await _configuracoesDoConvenioRepository.ObterAtivosAsync().ConfigureAwait(false);

            var listaViewModel = lista.Select(ToViewModel).ToList();

            return listaViewModel;
        }

        public async Task<IEnumerable<ConvenioViewModel>> FiltrarAsync(ConvenioFiltroViewModel model)
        {
            var lista = await _configuracoesDoConvenioRepository.ObterAtivosAsync().ConfigureAwait(false);

            if (!string.IsNullOrWhiteSpace(model?.Nome))
                lista = lista.Where(w => w.Nome.ToUpper().Contains(model.Nome.ToUpper()));

            if (!string.IsNullOrWhiteSpace(model?.Codigo))
                lista = lista.Where(w => w.Codigo.ToUpper().Contains(model.Codigo.ToUpper()));

            if (model?.IdDoSegmentoDeConvenio.HasValue == true)
                lista = lista.Where(w => w.IdDoSegmentoDeConvenio == model.IdDoSegmentoDeConvenio);

            var listaViewModel = lista.Select(ToViewModel).ToList();

            return listaViewModel;
        }

        public async Task<ConvenioViewModel> ObterPorIdAsync(Guid id)
        {
            var convenio = await _configuracoesDoConvenioRepository.GetByIdAsync(id).ConfigureAwait(false);

            ConvenioViewModel convenioViewModel = ToViewModel(convenio);

            return convenioViewModel;
        }

        private ConvenioViewModel ToViewModel(ConfiguracoesDoConvenio convenio)
        {
            CanalDeProcessamentoViewModel canalDeProcessamento = null;

            if (convenio.CanalDeProcessamento != null)
            {
                canalDeProcessamento = new CanalDeProcessamentoViewModel()
                {
                    Codigo = convenio.CanalDeProcessamento.Codigo,
                    Id = convenio.CanalDeProcessamento.Id,
                    Nome = convenio.CanalDeProcessamento.Nome,
                    IdDoCanalDeProcessamentoAlternativo = convenio.CanalDeProcessamento.IdDoCanalDeProcessamentoAlternativo
                };
            }
            else if(convenio.CanaisDeProcessamentoDisponiveis.Any(y => y.IdDoCanalDeProcessamento == convenio.SegmentoDeConvenio.IdDoCanalDeProcessamento))
            {
                canalDeProcessamento = new CanalDeProcessamentoViewModel
                {
                    Codigo = convenio.SegmentoDeConvenio.CanalDeProcessamento.Codigo,
                    Id = convenio.SegmentoDeConvenio.CanalDeProcessamento.Id,
                    Nome = convenio.SegmentoDeConvenio.CanalDeProcessamento.Nome,
                    IdDoCanalDeProcessamentoAlternativo = convenio.SegmentoDeConvenio.CanalDeProcessamento.IdDoCanalDeProcessamentoAlternativo
                };
            }

            return new ConvenioViewModel
            {
                IdDoConvenio = convenio.Id,
                Codigo = convenio.Codigo,
                Nome = convenio.Nome,
                IdDoCanalDeProcessamento = convenio.IdDoCanalDeProcessamento.HasValue
                    ? convenio.IdDoCanalDeProcessamento
                    : convenio.SegmentoDeConvenio.IdDoCanalDeProcessamento,
                CanalDeProcessamento = canalDeProcessamento,
                IdDoSegmentoDeConvenio = convenio.IdDoSegmentoDeConvenio,
                SegmentoDeConvenio = new SegmentoDeConvenioViewModel()
                {
                    Id = convenio.SegmentoDeConvenio.Id,
                    IdDoCanalDeProcessamento = convenio.SegmentoDeConvenio.IdDoCanalDeProcessamento,
                    Codigo = convenio.SegmentoDeConvenio.Codigo,
                    ContextoDeTransacoesId = convenio.SegmentoDeConvenio.ContextoDeTransacoesId,
                    TransacaoId = convenio.SegmentoDeConvenio.TransacaoId,
                    Nome = convenio.SegmentoDeConvenio.Nome,
                },
                IdsDosCanaisDeProcessamentoDisponiveis = convenio.CanaisDeProcessamentoDisponiveis.Select(s => s.IdDoCanalDeProcessamento).ToList(),
            };
        }
    }
}