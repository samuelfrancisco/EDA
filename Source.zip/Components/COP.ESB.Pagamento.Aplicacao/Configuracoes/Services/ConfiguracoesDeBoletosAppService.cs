﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services
{
    public class ConfiguracoesDeBoletosAppService : IConfiguracoesDeBoletosAppService
    {
        private readonly IConfiguracoesDeBoletosRepository _configuracoesDeBoletosRepository;

        public ConfiguracoesDeBoletosAppService(IConfiguracoesDeBoletosRepository configuracoesDeBoletosRepository)
        {
            _configuracoesDeBoletosRepository = configuracoesDeBoletosRepository;
        }

        public async Task<ConfiguracoesDeContingenciaDeBoletosViewModel> ObterAsConfiguracoesDeContingenciaAsync()
        {
            var configuracoesDeBoletos = await _configuracoesDeBoletosRepository.ObterAsConfiguracoesDeBoletosAtiva().ConfigureAwait(false);

            if (configuracoesDeBoletos == null)
                return new ConfiguracoesDeContingenciaDeBoletosViewModel();

            return new ConfiguracoesDeContingenciaDeBoletosViewModel
            {
                ABaixaOperacionalEmContingenciaDeveSerAutomatica = configuracoesDeBoletos.ABaixaOperacionalEmContingenciaDeveSerAutomatica,
                AConsultaDePagamentosEmContingenciaDeveSerAutomatica = configuracoesDeBoletos.AConsultaDePagamentosEmContingenciaDeveSerAutomatica,
                DataDaUltimaAlteracaoDoStatusDaContingencia = configuracoesDeBoletos.DataDaUltimaAlteracaoDoStatusDaContingencia,
                EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia = configuracoesDeBoletos.EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia,
                EmailsParaNotificacoesDeBaixaOperacionalEmContingencia = configuracoesDeBoletos.EmailsParaNotificacoesDeBaixaOperacionalEmContingencia,
                EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia = configuracoesDeBoletos.EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia,
                EmailsParaNotificacoesDeContingencia = configuracoesDeBoletos.EmailsParaNotificacoesDeContingencia,
                EstaEmContingencia = configuracoesDeBoletos.EstaEmContingencia,
                HistoricosDeContingencia = configuracoesDeBoletos.HistoricoDeContingencia
                .Select(x => new HistoricoDeContingenciaDeBoletosViewModel
                {
                    ABaixaOperacionalEmContingenciaDeveSerAutomatica = x.ABaixaOperacionalEmContingenciaDeveSerAutomatica,
                    AConsultaDePagamentosEmContingenciaDeveSerAutomatica = x.AConsultaDePagamentosEmContingenciaDeveSerAutomatica,
                    Data = x.Data,
                    EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia = x.EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia,
                    EmailsParaNotificacoesDeBaixaOperacionalEmContingencia = x.EmailsParaNotificacoesDeBaixaOperacionalEmContingencia,
                    EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia = x.EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia,
                    EmailsParaNotificacoesDeContingencia = x.EmailsParaNotificacoesDeContingencia,
                    EstaEmContingencia = x.EstaEmContingencia,
                    HorarioLimiteParaConsultaAposContingencia = x.HorarioLimiteParaConsultaAposContingencia,
                    LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia = x.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia,
                    LocalParaArquivosDeEnvioDeConsultaEmContingencia = x.LocalParaArquivosDeEnvioDeConsultaEmContingencia,
                    LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia = x.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia,
                    LocalParaArquivosDeRetornoDeConsultaEmContingencia = x.LocalParaArquivosDeRetornoDeConsultaEmContingencia,
                    Usuario = new HistoricoDeContingenciaDeBoletosUsuarioViewModel
                    {
                        Nome = x.NomeDoUsuario,
                        UsuarioId = x.IdDoUsuario
                    },
                    ValorMaximoAceitoEmContingencia = x.ValorMaximoAceitoEmContingencia

                }).ToList(),
                HorarioLimiteParaConsultaAposContingencia = configuracoesDeBoletos.HorarioLimiteParaConsultaAposContingencia.ToString(),
                LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia = configuracoesDeBoletos.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia,
                LocalParaArquivosDeEnvioDeConsultaEmContingencia = configuracoesDeBoletos.LocalParaArquivosDeEnvioDeConsultaEmContingencia,
                LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia = configuracoesDeBoletos.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia,
                LocalParaArquivosDeRetornoDeConsultaEmContingencia = configuracoesDeBoletos.LocalParaArquivosDeRetornoDeConsultaEmContingencia,
                ValorMaximoAceitoEmContingencia = configuracoesDeBoletos.ValorMaximoAceitoEmContingencia
            };
        }

        public async Task<OutrosParametrosDeBoletosViewModel> ObterOsOutrosParametrosAsync()
        {
            var configuracoesDeBoletos = await _configuracoesDeBoletosRepository.ObterAsConfiguracoesDeBoletosAtiva().ConfigureAwait(false);

            if (configuracoesDeBoletos == null)
                return new OutrosParametrosDeBoletosViewModel();

            return new OutrosParametrosDeBoletosViewModel
            {
                EmailsParaNotificacoesDeBaixaOperacional = configuracoesDeBoletos.EmailsParaNotificacoesDeBaixaOperacional,
                ValorMinimoParaVRBoleto = configuracoesDeBoletos.ValorMinimoParaVRBoleto,
                ValorPermitidoSemRegistroNaCIP = configuracoesDeBoletos.ValorPermitidoSemRegistroNaCIP
            };
        }
    }
}
