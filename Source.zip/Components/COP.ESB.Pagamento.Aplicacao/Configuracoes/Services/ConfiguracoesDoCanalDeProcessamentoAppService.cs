﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services
{
    public class ConfiguracoesDoCanalDeProcessamentoAppService : IConfiguracoesDoCanalDeProcessamentoAppService
    {
        private readonly IConfiguracoesDoCanalDeProcessamentoRepository _configuracoesDoCanalDeProcessamentoRepository;

        public ConfiguracoesDoCanalDeProcessamentoAppService(IConfiguracoesDoCanalDeProcessamentoRepository configuracoesDoCanalDeProcessamentoRepository)
        {
            _configuracoesDoCanalDeProcessamentoRepository = configuracoesDoCanalDeProcessamentoRepository;
        }

        public async Task<CanalDeProcessamentoViewModel> ObterPeloIdParaEdicaoAsync(Guid id)
        {
            var canalDeProcessamento = await _configuracoesDoCanalDeProcessamentoRepository.ObterPeloIdParaEdicaoAsync(id).ConfigureAwait(false);

            var canalDeProcessamentoViewModel = new CanalDeProcessamentoViewModel
            {
                Id = canalDeProcessamento.Id,                
                Codigo = canalDeProcessamento.Codigo,
                Nome = canalDeProcessamento.Nome,                
                HorarioInicial = canalDeProcessamento.HorarioInicial?.ToString("hh\\:mm"),
                HorarioFinal = canalDeProcessamento.HorarioFinal?.ToString("hh\\:mm"),
                EstaEmContingencia = canalDeProcessamento.EstaEmContingencia,
                EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia = canalDeProcessamento.EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia,
                IdDoCanalDeProcessamentoAlternativo = canalDeProcessamento.IdDoCanalDeProcessamentoAlternativo,
                DataDaUltimaAlteracaoDoStatusDaContingencia = canalDeProcessamento.DataDaUltimaAlteracaoDoStatusDaContingencia?.ToString("dd/MM/yyyy HH:mm:ss"),
                CanaisDisponiveis = canalDeProcessamento.CanaisDisponiveis.Select(x => new CanalDeProcessamentoCanalDisponivelViewModel
                {
                    Id = x.Id,
                    Codigo = x.Codigo,
                    Nome = x.Nome
                })
            };

            return canalDeProcessamentoViewModel;
        }

        public async Task<IEnumerable<CanalDeProcessamentoViewModel>> ObterTodosAtivosAsync(string nome = "")
        {
            var result = new Result();
            result.ErroMessage.StatusCode = 200;

            var lista = await _configuracoesDoCanalDeProcessamentoRepository.ObterCanalDeProcessamentoAtivosAsync(nome).ConfigureAwait(false);

            var listaViewModel = lista.Select(x => new CanalDeProcessamentoViewModel
            {
                Id = x.Id,
                Codigo = x.Codigo,
                Nome = x.Nome,
                HorarioInicial = x.HorarioInicial?.ToString("hh\\:mm"),
                HorarioFinal = x.HorarioFinal?.ToString("hh\\:mm"),
                EstaEmContingencia = x.EstaEmContingencia,
                IdDoCanalDeProcessamentoAlternativo = x.IdDoCanalDeProcessamentoAlternativo,                
                EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia = x.EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia,
                DataDaUltimaAlteracaoDoStatusDaContingencia = x.DataDaUltimaAlteracaoDoStatusDaContingencia?.ToString("dd/MM/yyyy HH:mm:ss")                
            }).ToList();

            return listaViewModel;
        }
    }
}