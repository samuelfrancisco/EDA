﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services
{
    public class ConfiguracoesDoSegmentoDeConvenioAppService : IConfiguracoesDoSegmentoDeConvenioAppService
    {
        private readonly IConfiguracoesDoSegmentoDeConvenioRepository _configuracoesDoSegmentoDeConvenioRepository;

        public ConfiguracoesDoSegmentoDeConvenioAppService(IConfiguracoesDoSegmentoDeConvenioRepository configuracoesDoSegmentoDeConvenio)
        {
            _configuracoesDoSegmentoDeConvenioRepository = configuracoesDoSegmentoDeConvenio;
        }

        public async Task<SegmentoDeConvenioViewModel> ObterPeloIdAsync(Guid idDoSegmentoDeConvenio)
        {
            var configuracoesDoSegmentoDeConvenio = await _configuracoesDoSegmentoDeConvenioRepository.GetByIdAsync(idDoSegmentoDeConvenio).ConfigureAwait(false);

            if (configuracoesDoSegmentoDeConvenio == null)
                return null;

            return new SegmentoDeConvenioViewModel
            {
                Id = configuracoesDoSegmentoDeConvenio.Id,
                Codigo = configuracoesDoSegmentoDeConvenio.Codigo,
                Nome = configuracoesDoSegmentoDeConvenio.Nome,
                ContextoDeTransacoesId = configuracoesDoSegmentoDeConvenio.ContextoDeTransacoesId,
                TransacaoId = configuracoesDoSegmentoDeConvenio.TransacaoId,
                IdDoCanalDeProcessamento = configuracoesDoSegmentoDeConvenio.IdDoCanalDeProcessamento,
                Transacao = new SegmentoDeConvenioTransacaoViewModel
                {
                    Codigo = configuracoesDoSegmentoDeConvenio.ConfiguracoesDaTransacao.Codigo,
                    ContextoDeTransacoesId = configuracoesDoSegmentoDeConvenio.ConfiguracoesDaTransacao.ContextoDeTransacoesId,
                    Nome = configuracoesDoSegmentoDeConvenio.ConfiguracoesDaTransacao.Nome,
                    TransacaoId = configuracoesDoSegmentoDeConvenio.ConfiguracoesDaTransacao.TransacaoId
                },
                CanalDeProcessamento = new SegmentoDeConvenioCanalDeProcessamentoViewModel
                {
                    Id = configuracoesDoSegmentoDeConvenio.CanalDeProcessamento.Id,
                    Codigo = configuracoesDoSegmentoDeConvenio.CanalDeProcessamento.Codigo,
                    Nome = configuracoesDoSegmentoDeConvenio.CanalDeProcessamento.Nome
                }
            };
        }

        public async Task<IEnumerable<SegmentoDeConvenioViewModel>> ObterTodosAtivosAsync(string nomeDoSegmento = null)
        {
            var configuracoesDosSegmentosDeConvenio = await _configuracoesDoSegmentoDeConvenioRepository.ObterTodosAtivosAsync(nomeDoSegmento).ConfigureAwait(false);

            return configuracoesDosSegmentosDeConvenio.Select(x => new SegmentoDeConvenioViewModel
            {
                Id = x.Id,
                Codigo = x.Codigo,
                Nome = x.Nome,
                ContextoDeTransacoesId = x.ContextoDeTransacoesId,
                TransacaoId = x.TransacaoId,
                IdDoCanalDeProcessamento = x.IdDoCanalDeProcessamento,
                Transacao = new SegmentoDeConvenioTransacaoViewModel
                {
                    Codigo = x.ConfiguracoesDaTransacao.Codigo,
                    ContextoDeTransacoesId = x.ConfiguracoesDaTransacao.ContextoDeTransacoesId,
                    Nome = x.ConfiguracoesDaTransacao.Nome,
                    TransacaoId = x.ConfiguracoesDaTransacao.TransacaoId
                },
                CanalDeProcessamento = new SegmentoDeConvenioCanalDeProcessamentoViewModel
                {
                    Codigo = x.CanalDeProcessamento.Codigo,
                    Id = x.CanalDeProcessamento.Id,
                    Nome = x.CanalDeProcessamento.Nome
                }
            })
            .ToList();
        }
    }
}
