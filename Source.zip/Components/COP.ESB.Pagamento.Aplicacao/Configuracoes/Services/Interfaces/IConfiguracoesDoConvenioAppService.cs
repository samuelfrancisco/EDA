﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces
{
    public interface IConfiguracoesDoConvenioAppService
    {
        Task<IEnumerable<ConvenioViewModel>> ObterTodosAsync();
        Task<IEnumerable<ConvenioViewModel>> ObterTodosAtivosAsync();
        Task<IEnumerable<ConvenioViewModel>> FiltrarAsync(ConvenioFiltroViewModel model);
        Task<ConvenioViewModel> ObterPorIdAsync(Guid id);
    }
}
