﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces
{
    public interface IConfiguracoesDeBoletosAppService
    {
        Task<ConfiguracoesDeContingenciaDeBoletosViewModel> ObterAsConfiguracoesDeContingenciaAsync();
        Task<OutrosParametrosDeBoletosViewModel> ObterOsOutrosParametrosAsync();
    }
}
