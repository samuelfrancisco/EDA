﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces
{
    public interface IConfiguracoesDeRepasseAppService
    {
        Task<IEnumerable<ConfiguracoesDeRepasseViewModel>> ObterTodosAsync();
        Task<ConfiguracoesDeRepasseViewModel> ObterPeloIdAsync(Guid id);
        Task<ConfiguracoesDeRepasseViewModel> ObterPeloIdDoCanalDeProcessamentoAsync(Guid idDoCanalDeProcessamento);
        Task<ConfiguracoesDeRepasseViewModel> ObterPeloCodigoDoCanalDeProcessamentoAsync(string codigoDoCanalDeProcessamento);
    }
}
