﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces
{
    public interface IConfiguracoesDoCanalDeProcessamentoAppService
    {
        Task<CanalDeProcessamentoViewModel> ObterPeloIdParaEdicaoAsync(Guid id);
        Task<IEnumerable<CanalDeProcessamentoViewModel>> ObterTodosAtivosAsync(string nome = "");                
    }
}
