﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces
{
    public interface IConfiguracoesDoSegmentoDeConvenioAppService
    {
        Task<IEnumerable<SegmentoDeConvenioViewModel>> ObterTodosAtivosAsync(string nomeDoSegmento = null);
        Task<SegmentoDeConvenioViewModel> ObterPeloIdAsync(Guid idDoSegmentoDeConvenio);
    }
}
