﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.DTOs;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Services
{
    public class ConfiguracoesDeRepasseAppService : IConfiguracoesDeRepasseAppService
    {
        private readonly IConfiguracoesDeRepasseRepository _configuracoesDeRepasseRepository;

        public ConfiguracoesDeRepasseAppService(IConfiguracoesDeRepasseRepository configuracoesDeRepasseRepository)
        {
            _configuracoesDeRepasseRepository = configuracoesDeRepasseRepository;
        }

        public async Task<IEnumerable<ConfiguracoesDeRepasseViewModel>> ObterTodosAsync()
        {
            var lista = await _configuracoesDeRepasseRepository.ObterTodosAsync().ConfigureAwait(false);

            return lista.Select(ToViewModel).ToList();
        }

        public async Task<ConfiguracoesDeRepasseViewModel> ObterPeloIdAsync(Guid id)
        {
            var configuracoesDeRepasse = await _configuracoesDeRepasseRepository.GetByIdAsync(id).ConfigureAwait(false);

            if (configuracoesDeRepasse == null)
                return new ConfiguracoesDeRepasseViewModel();

            return ToViewModel(configuracoesDeRepasse);
        }

        public async Task<ConfiguracoesDeRepasseViewModel> ObterPeloIdDoCanalDeProcessamentoAsync(Guid idDoCanalDeProcessamento)
        {
            var configuracoesDeRepasse = await _configuracoesDeRepasseRepository.ObterPeloIdDoCanalDeProcessamentoAsync(idDoCanalDeProcessamento)
                .ConfigureAwait(false);

            if (configuracoesDeRepasse == null)
                return new ConfiguracoesDeRepasseViewModel();

            return ToViewModel(configuracoesDeRepasse);
        }

        public async Task<ConfiguracoesDeRepasseViewModel> ObterPeloCodigoDoCanalDeProcessamentoAsync(string codigoDoCanalDeProcessamento)
        {
            var configuracoesDeRepasse = await _configuracoesDeRepasseRepository.ObterDTOPeloCodigoDoCanalDeProcessamentoAsync(codigoDoCanalDeProcessamento)
                .ConfigureAwait(false);

            if (configuracoesDeRepasse == null)
                return new ConfiguracoesDeRepasseViewModel();

            return ToViewModel(configuracoesDeRepasse);
        }

        private ConfiguracoesDeRepasseViewModel ToViewModel(ConfiguracoesDeRepasse configuracoesDeRepasse)
        {
            return new ConfiguracoesDeRepasseViewModel
            {
                LimiteMaximoDiarioDeOperacoes = configuracoesDeRepasse.LimiteMaximoDiarioDeOperacoes,
                EmailParaNotificacao = configuracoesDeRepasse.EmailParaNotificacao,
                PercentualParaPrimeiroAlerta = configuracoesDeRepasse.PercentualParaPrimeiroAlerta,
                PercentualParaSegundoAlerta = configuracoesDeRepasse.PercentualParaSegundoAlerta
            };
        }

        private ConfiguracoesDeRepasseViewModel ToViewModel(ConfiguracoesDeRepasseDTO configuracoesDeRepasse)
        {
            return new ConfiguracoesDeRepasseViewModel
            {
                LimiteMaximoDiarioDeOperacoes = configuracoesDeRepasse.LimiteMaximoDiarioDeOperacoes,
                SaldoDisponivel = configuracoesDeRepasse.SaldoDisponivel,
                EmailParaNotificacao = configuracoesDeRepasse.EmailParaNotificacao,
                PercentualParaPrimeiroAlerta = configuracoesDeRepasse.PercentualParaPrimeiroAlerta,
                PercentualParaSegundoAlerta = configuracoesDeRepasse.PercentualParaSegundoAlerta,
                CodigoDoCanalDeProcessamento = configuracoesDeRepasse.CodigoDoCanalDeProcessamento,
                CanalDeProcessamento = new CanalDeProcessamentoViewModel()
                {
                    Codigo = configuracoesDeRepasse.CodigoDoCanalDeProcessamento,
                    Id = configuracoesDeRepasse.IdDoCanalDeProcessamento,
                    Nome = configuracoesDeRepasse.NomeDoCanalDeProcessamento,
                    IdDoCanalDeProcessamentoAlternativo = configuracoesDeRepasse.IdDoCanalDeProcessamentoAlternativo
                },
                HistoricoDeConfiguracoesDeRepasse = configuracoesDeRepasse.HistoricoDeConfiguracoes.Select(s => new HistoricoDeConfiguracoesDeRepasseViewModel()
                {
                    Data = s.Data,
                    EmailParaNotificacao = s.EmailParaNotificacao,
                    Id = s.Id,
                    IdDasConfiguracoesDeRepasse = s.IdDasConfiguracoesDeRepasse,
                    IdDoCanalDeProcessamento = s.IdDoCanalDeProcessamento,
                    IdDoUsuario = s.IdDoUsuario,
                    LimiteMaximoDiarioDeOperacoes = s.LimiteMaximoDiarioDeOperacoes,
                    PercentualParaPrimeiroAlerta = s.PercentualParaPrimeiroAlerta,
                    PercentualParaSegundoAlerta = s.PercentualParaSegundoAlerta,
                    NomeDoUsuario = s.NomeDoUsuario,
                })
            };
        }
    }
}