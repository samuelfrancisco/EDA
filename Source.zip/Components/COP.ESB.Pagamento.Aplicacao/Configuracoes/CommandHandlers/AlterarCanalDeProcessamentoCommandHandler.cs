﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class AlterarCanalDeProcessamentoCommandHandler
        : PrimaryCommandRequestHandler<AlterarCanalDeProcessamentoCommand, Result>
    {
        private readonly IConfiguracoesDoCanalDeProcessamentoRepository _configuracoesDoCanalDeProcessamentoRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public AlterarCanalDeProcessamentoCommandHandler
            (IUnitOfWork unitOfWork,
             ICommandHandlerRepository commandHandlerRepository,
             IConfiguracoesDoCanalDeProcessamentoRepository configuracoesDoCanalDeProcessamentoRepository,
             IConfiguracoesDoMotorService configuracoesDoMotorService,
             IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoCanalDeProcessamentoRepository = configuracoesDoCanalDeProcessamentoRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(AlterarCanalDeProcessamentoCommand command, CancellationToken cancellationToken)
        {
            var canalDeProcessamento = await _configuracoesDoCanalDeProcessamentoRepository.GetByIdAsync(command.IdDoCanalDeProcessamento).ConfigureAwait(false);

            Result result;

            if(canalDeProcessamento == null)
            {
                result = new Result();
                result.AddError("Canal de processamento inválido.",
                    $"Não existe um canal de processamento com o id = {command.IdDoCanalDeProcessamento}.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Canal de processamento inválido: não existe um canal de processamento com o id = {command.IdDoCanalDeProcessamento}.";
                result.ErroMessage.StatusCode = 404;

                return result;
            }

            result = canalDeProcessamento.Alterar(command, _configuracoesDoMotorService, _servicoDeValidacaoDeEmails);

            if (result.IsSuccess)
                await _configuracoesDoCanalDeProcessamentoRepository.SaveAsync(canalDeProcessamento, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
