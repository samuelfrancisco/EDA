﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class InativarSegmentoDeConvenioCommandHandler : PrimaryCommandRequestHandler<InativarSegmentoDeConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoSegmentoDeConvenioRepository _configuracoesDoSegmentoDeConvenioRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public InativarSegmentoDeConvenioCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDoSegmentoDeConvenioRepository configuracoesDoSegmentoDeConvenioRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService) 
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoSegmentoDeConvenioRepository = configuracoesDoSegmentoDeConvenioRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(InativarSegmentoDeConvenioCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDoSegmentoDeConvenio = await _configuracoesDoSegmentoDeConvenioRepository.GetByIdAsync(command.IdDoSegmentoDeConvenio)
                .ConfigureAwait(false);

            Result result = new Result();

            if (configuracoesDoSegmentoDeConvenio == null)
            {                
                result.AddError("Segmento de convênio inválido.",
                    $"Não existe um segmento de convênio com o id = {command.IdDoSegmentoDeConvenio}.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Segmento de convênio inválido: não existe um segmento de convênio com o id = {command.IdDoSegmentoDeConvenio}.";
                result.ErroMessage.StatusCode = 404;
            }

            result = configuracoesDoSegmentoDeConvenio.Inativar(command, _configuracoesDoMotorService);

            await _configuracoesDoSegmentoDeConvenioRepository.SaveAsync(configuracoesDoSegmentoDeConvenio, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
