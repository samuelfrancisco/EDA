﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class InativarConvenioCommandHandler : PrimaryCommandRequestHandler<InativarConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoConvenioRepository _configuracoesDoConvenioRepository;

        public InativarConvenioCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDoConvenioRepository configuracoesDoConvenioRepository)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoConvenioRepository = configuracoesDoConvenioRepository;
        }

        protected override async Task<Result> DoHandleAsync(InativarConvenioCommand command, CancellationToken cancellationToken)
        {
            var convenio = await _configuracoesDoConvenioRepository.GetByIdAsync(command.IdDoConvenio).ConfigureAwait(false);

            Result result = new Result();

            if (convenio == null)
            {                
                result.AddError("Convênio inválido.",
                    $"Não existe um convênio com o id = {command.IdDoConvenio}.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Convênio inválido: não existe um convênio com o id = {command.IdDoConvenio}.";
                result.ErroMessage.StatusCode = 404;
            }

            convenio.Inativar(command);

            await _configuracoesDoConvenioRepository.SaveAsync(convenio, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
