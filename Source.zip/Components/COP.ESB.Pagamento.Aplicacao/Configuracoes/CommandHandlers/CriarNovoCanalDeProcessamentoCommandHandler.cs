﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class CriarNovoCanalDeProcessamentoCommandHandler : PrimaryCommandRequestHandler<CriarNovoCanalDeProcessamentoCommand, Result>
    {
        private readonly IConfiguracoesDoCanalDeProcessamentoRepository _configuracoesDoCanalDeProcessamentoRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public CriarNovoCanalDeProcessamentoCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDoCanalDeProcessamentoRepository configuracoesDoCanalDeProcessamentoRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoCanalDeProcessamentoRepository = configuracoesDoCanalDeProcessamentoRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(CriarNovoCanalDeProcessamentoCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDoCanalDeProcessamento = await _configuracoesDoCanalDeProcessamentoRepository.ObterPeloCodigoAsync(command.Codigo)
                .ConfigureAwait(false);

            if (configuracoesDoCanalDeProcessamento != null)
            {
                var result = new Result();
                result.AddError("Código inválido.", $"Já existe um canal de processamento com o código {command.Codigo}.", GetType().FullName);
                result.ErroMessage.Message = $"Codigo inválido: já existe um canal de processamento com o código {command.Codigo}.";
                result.ErroMessage.StatusCode = 400;
            }

            var configuracoesDoCanalDeProcessamentoResult = ConfiguracoesDoCanalDeProcessamento
                .CriarNovoCanalDeProcessamento(command, _configuracoesDoMotorService, _servicoDeValidacaoDeEmails);

            if (configuracoesDoCanalDeProcessamentoResult.IsSuccess)
                await _configuracoesDoCanalDeProcessamentoRepository.SaveAsync(configuracoesDoCanalDeProcessamentoResult.Value, command.Id)
                    .ConfigureAwait(false);

            return configuracoesDoCanalDeProcessamentoResult;
        }
    }
}
