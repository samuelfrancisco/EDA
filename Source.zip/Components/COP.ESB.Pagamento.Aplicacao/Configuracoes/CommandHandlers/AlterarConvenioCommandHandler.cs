﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class AlterarConvenioCommandHandler
        : PrimaryCommandRequestHandler<AlterarConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoConvenioRepository _configuracoesDoConvenioRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public AlterarConvenioCommandHandler
            (IUnitOfWork unitOfWork,
             ICommandHandlerRepository commandHandlerRepository,
             IConfiguracoesDoConvenioRepository configuracoesDoConvenioRepository,
             IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoConvenioRepository = configuracoesDoConvenioRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(AlterarConvenioCommand command, CancellationToken cancellationToken)
        {
            var convenio = await _configuracoesDoConvenioRepository.GetByIdAsync(command.IdDoConvenio).ConfigureAwait(false);

            Result result;

            if (convenio == null)
            {
                result = new Result();
                result.AddError("Convênio inválido.",
                    $"Não existe um convênio com o id = {command.IdDoConvenio}.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Convênio inválido: não existe um convênio com o id = {command.IdDoConvenio}.";
                result.ErroMessage.StatusCode = 404;

                return result;
            }

            result = convenio.Alterar(command, _configuracoesDoMotorService);

            if (result.IsSuccess)
                await _configuracoesDoConvenioRepository.SaveAsync(convenio, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
