﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class CriarNovoConvenioCommandHandler
        : PrimaryCommandRequestHandler<CriarNovoConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoConvenioRepository _configuracoesDoConvenioRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public CriarNovoConvenioCommandHandler
            (IUnitOfWork unitOfWork,
             ICommandHandlerRepository commandHandlerRepository,
             IConfiguracoesDoConvenioRepository configuracoesDoConvenioRepository,
             IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoConvenioRepository = configuracoesDoConvenioRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(CriarNovoConvenioCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDoConvenio = await _configuracoesDoConvenioRepository.ObterPeloCodigoEPorIdDoSegmentoAsync(command.Codigo, command.IdDoSegmentoDeConvenio)
                .ConfigureAwait(false);

            if (configuracoesDoConvenio != null)
            {
                var result = new Result();
                result.AddError("Código inválido.", $"Já existe um convênio com o código {command.Codigo} para o segmento {configuracoesDoConvenio.SegmentoDeConvenio.Codigo}.", GetType().FullName);
                result.ErroMessage.Message = $"Codigo inválido: já existe um convênio com o código {command.Codigo} para o segmento {configuracoesDoConvenio.SegmentoDeConvenio.Codigo}.";
                result.ErroMessage.StatusCode = 400;
            }

            var configuracoesDoConvenioResult = ConfiguracoesDoConvenio.CriarNovoConvenio(command, _configuracoesDoMotorService);

            if (configuracoesDoConvenioResult.IsSuccess)
                await _configuracoesDoConvenioRepository.SaveAsync(configuracoesDoConvenioResult.Value, command.Id)
                    .ConfigureAwait(false);

            return configuracoesDoConvenioResult;
        }
    }
}
