﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class CriarNovoSegmentoDeConvenioCommandHandler : PrimaryCommandRequestHandler<CriarNovoSegmentoDeConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoSegmentoDeConvenioRepository _configuracoesDoSegmentoDeConvenioRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public CriarNovoSegmentoDeConvenioCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDoSegmentoDeConvenioRepository configuracoesDoSegmentoDeConvenioRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoSegmentoDeConvenioRepository = configuracoesDoSegmentoDeConvenioRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(CriarNovoSegmentoDeConvenioCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDoSegmentoDeConvenio = await _configuracoesDoSegmentoDeConvenioRepository.ObterPeloCodigoAsync(command.Codigo)
                .ConfigureAwait(false);

            if (configuracoesDoSegmentoDeConvenio != null)
            {
                var result = new Result();
                result.AddError("Código inválido.", $"Já existe um segmento de convênio com o código {command.Codigo}.", GetType().FullName);
                result.ErroMessage.Message = $"Codigo inválido: já existe um segmento de convênio com o código {command.Codigo}.";
                result.ErroMessage.StatusCode = 400;
            }

            var configuracoesDoSegmentoDeConvenioResult = ConfiguracoesDoSegmentoDeConvenio.CriarNovoSegmentoDeConvenio(command, _configuracoesDoMotorService);

            if (configuracoesDoSegmentoDeConvenioResult.IsSuccess)
                await _configuracoesDoSegmentoDeConvenioRepository.SaveAsync(configuracoesDoSegmentoDeConvenioResult.Value, command.Id)
                    .ConfigureAwait(false);

            return configuracoesDoSegmentoDeConvenioResult;
        }
    }
}
