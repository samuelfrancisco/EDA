﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class LigarContingenciaDeBoletosCommandHandler : PrimaryCommandRequestHandler<LigarContingenciaDeBoletosCommand, Result>
    {
        private readonly IConfiguracoesDeBoletosRepository _configuracoesDeBoletoRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public LigarContingenciaDeBoletosCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDeBoletosRepository configuracoesDeBoletoRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDeBoletoRepository = configuracoesDeBoletoRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(LigarContingenciaDeBoletosCommand command, CancellationToken cancellationToken)
        {
            Result result;

            var configuracoesDeBoletos = await _configuracoesDeBoletoRepository.ObterAsConfiguracoesDeBoletosAtiva().ConfigureAwait(false);

            if (configuracoesDeBoletos == null)
            {
                var transacaoDeBoletos = _configuracoesDoMotorService.ConfiguracoesDoMotor.Transacoes.FirstOrDefault(x => x.Codigo == "Boletos");

                if (transacaoDeBoletos == null)
                {
                    result = new Result();
                    result.AddError("Não existe uma transação Boletos ativa no sistema.", "Não existe uma transação Boletos ativa no sistema.", GetType().FullName);
                    result.ErroMessage.Message = "Não existe uma transação Boletos ativa no sistema.";
                    result.ErroMessage.StatusCode = 400;

                    return result;
                }

                configuracoesDeBoletos = ConfiguracoesDeBoletos.RegistrarNovaTransacaoBoletos(new RegistrarNovaTransacaoBoletosCommand
                {
                    ContextoDeTransacoesId = transacaoDeBoletos.ContextoDeTransacoesId,
                    TransacaoId = transacaoDeBoletos.TransacaoId,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }

            result = configuracoesDeBoletos.LigarContingencia(command);

            if (result.IsSuccess)
                await _configuracoesDeBoletoRepository.SaveAsync(configuracoesDeBoletos, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
