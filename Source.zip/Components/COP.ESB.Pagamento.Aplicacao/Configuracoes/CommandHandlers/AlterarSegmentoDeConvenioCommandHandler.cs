﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class AlterarSegmentoDeConvenioCommandHandler : PrimaryCommandRequestHandler<AlterarSegmentoDeConvenioCommand, Result>
    {
        private readonly IConfiguracoesDoSegmentoDeConvenioRepository _configuracoesDoSegmentoDeConvenioRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public AlterarSegmentoDeConvenioCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDoSegmentoDeConvenioRepository configuracoesDoSegmentoDeConvenioRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDoSegmentoDeConvenioRepository = configuracoesDoSegmentoDeConvenioRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(AlterarSegmentoDeConvenioCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDoSegmentoDeConvenio = await _configuracoesDoSegmentoDeConvenioRepository.GetByIdAsync(command.IdDoSegmentoDeConvenio)
                .ConfigureAwait(false);

            Result result;

            if (configuracoesDoSegmentoDeConvenio == null)
            {
                result = new Result();
                result.AddError("Segmento de convênio inválido.",
                    $"Não existe um segmento de convênio com o id = {command.IdDoSegmentoDeConvenio}.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Segmento de convênio inválido: não existe um segmento de convênio com o id = {command.IdDoSegmentoDeConvenio}.";
                result.ErroMessage.StatusCode = 404;

                return result;
            }

            result = configuracoesDoSegmentoDeConvenio.Alterar(command, _configuracoesDoMotorService);

            if (result.IsSuccess)
                await _configuracoesDoSegmentoDeConvenioRepository.SaveAsync(configuracoesDoSegmentoDeConvenio, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
