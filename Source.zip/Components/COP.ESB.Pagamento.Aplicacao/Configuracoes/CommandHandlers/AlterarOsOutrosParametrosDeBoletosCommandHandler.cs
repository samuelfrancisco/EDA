﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class AlterarOsOutrosParametrosDeBoletosCommandHandler : PrimaryCommandRequestHandler<AlterarOsOutrosParametrosDeBoletosCommand, Result>
    {
        private readonly IConfiguracoesDeBoletosRepository _configuracoesDeBoletoRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public AlterarOsOutrosParametrosDeBoletosCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDeBoletosRepository configuracoesDeBoletoRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails)
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDeBoletoRepository = configuracoesDeBoletoRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(AlterarOsOutrosParametrosDeBoletosCommand command, CancellationToken cancellationToken)
        {
            Result result;

            var configuracoesDeBoletos = await _configuracoesDeBoletoRepository.ObterAsConfiguracoesDeBoletosAtiva().ConfigureAwait(false);

            if (configuracoesDeBoletos == null)
            {
                var transacaoDeBoletos = _configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos?.ConfiguracoesDaTransacao;

                if (transacaoDeBoletos == null)
                {
                    result = new Result();
                    result.AddError("Não existe uma transação Boletos ativa no sistema.", "Não existe uma transação Boletos ativa no sistema.", GetType().FullName);
                    result.ErroMessage.Message = "Não existe uma transação Boletos ativa no sistema.";
                    result.ErroMessage.StatusCode = 400;

                    return result;
                }

                configuracoesDeBoletos = ConfiguracoesDeBoletos.RegistrarNovaTransacaoBoletos(new RegistrarNovaTransacaoBoletosCommand
                {
                    ContextoDeTransacoesId = transacaoDeBoletos.ContextoDeTransacoesId,
                    TransacaoId = transacaoDeBoletos.TransacaoId,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }

            result = configuracoesDeBoletos.AlterarOsOutrosParametros(command, _servicoDeValidacaoDeEmails);

            if (result.IsSuccess)
                await _configuracoesDeBoletoRepository.SaveAsync(configuracoesDeBoletos, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
