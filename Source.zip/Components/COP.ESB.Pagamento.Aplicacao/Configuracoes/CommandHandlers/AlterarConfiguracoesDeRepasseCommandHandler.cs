﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.CommandHandlers
{
    public class AlterarConfiguracoesDeRepasseCommandHandler : PrimaryCommandRequestHandler<AlterarConfiguracoesDeRepasseCommand, Result>
    {
        private readonly IConfiguracoesDeRepasseRepository _configuracoesDeRepasseRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public AlterarConfiguracoesDeRepasseCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IConfiguracoesDeRepasseRepository configuracoesDeRepasseRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails) 
            : base(unitOfWork, commandHandlerRepository)
        {
            _configuracoesDeRepasseRepository = configuracoesDeRepasseRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(AlterarConfiguracoesDeRepasseCommand command, CancellationToken cancellationToken)
        {
            var configuracoesDeRepasse = await _configuracoesDeRepasseRepository
                .ObterPeloCodigoDoCanalDeProcessamentoAsync(command.CodigoDoCanalDeProcessamento).ConfigureAwait(false);

            if(configuracoesDeRepasse == null)
            {
                var newCommand = new DefinirConfiguracoesDeRepasseCommand
                {
                    CodigoDoCanalDeProcessamento = command.CodigoDoCanalDeProcessamento,
                    EmailParaNotificacao = command.EmailParaNotificacao,
                    LimiteMaximoDiarioDeOperacoes = command.LimiteMaximoDiarioDeOperacoes,
                    PercentualParaPrimeiroAlerta = command.PercentualParaPrimeiroAlerta,
                    PercentualParaSegundoAlerta = command.PercentualParaSegundoAlerta,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command,
                    IdDoUsuario = command.IdDoUsuario,
                    NomeDoUsuario = command.NomeDoUsuario
                };

                var configuracoesDeRepasseResult = ConfiguracoesDeRepasse
                    .DefinirConfiguracoesDeRepasse(newCommand, _configuracoesDoMotorService, _servicoDeValidacaoDeEmails);

                if (configuracoesDeRepasseResult.IsSuccess)
                    await _configuracoesDeRepasseRepository.SaveAsync(configuracoesDeRepasseResult.Value, newCommand.Id)
                        .ConfigureAwait(false);

                return configuracoesDeRepasseResult;
            }

            var alteracaoResult = configuracoesDeRepasse.Alterar(command, _configuracoesDoMotorService, _servicoDeValidacaoDeEmails);

            if(alteracaoResult.IsSuccess)
                await _configuracoesDeRepasseRepository.SaveAsync(configuracoesDeRepasse, command.Id)
                        .ConfigureAwait(false);

            return alteracaoResult;
        }
    }
}
