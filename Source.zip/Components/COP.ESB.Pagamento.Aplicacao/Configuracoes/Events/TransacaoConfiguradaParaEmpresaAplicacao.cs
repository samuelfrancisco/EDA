﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class TransacaoConfiguradaParaEmpresaAplicacao : IntegrationEvent
    {
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public long EmpresaAplicacaoId { get; set; }
        public long EmpresaId { get; set; }
        public string NomeDaEmpresa { get; set; }
        public long AplicacaoId { get; set; }
        public string NomeDaAplicacao { get; set; }
        public long ContextoDeTransacoesId { get; set; }
        public long TransacaoId { get; set; }
        public TimeSpan? HorarioInicial { get; set; }
        public TimeSpan? HorarioFinal { get; set; }
        public bool DebitarContaCorrente { get; set; }
        public bool ValidarSaldoDaContaCorrente { get; set; }
        public bool EstornarAutomaticamente { get; set; }
        public decimal? ValorLimiteParaPagamento { get; set; }
        public List<long> IdsDosServicosDeProvedoresLiberados { get; set; }
    }
}
