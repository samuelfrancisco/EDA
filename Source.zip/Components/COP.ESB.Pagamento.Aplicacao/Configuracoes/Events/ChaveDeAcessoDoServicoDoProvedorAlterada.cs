﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ChaveDeAcessoDoServicoDoProvedorAlterada : IntegrationEvent
    {
        public long ProvedorServicoSegurancaId { get; set; }
        public long ProvedorServicoId { get; set; }
        public string Descricao { get; set; }
        public byte[] ChavePublica { get; set; }
        public string Usuario { get; set; }
        public byte[] Senha { get; set; }
        public byte[] Certificado { get; set; }
        public byte[] SenhaCertificado { get; set; }
        public DateTime? DataValidadeDe { get; set; }
        public DateTime? DataValidadeAte { get; set; }
        public DateTime? DataAtivacao { get; set; }
    }
}
