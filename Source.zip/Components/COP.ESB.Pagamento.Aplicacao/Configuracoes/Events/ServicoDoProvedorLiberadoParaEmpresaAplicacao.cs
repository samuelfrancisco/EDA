﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ServicoDoProvedorLiberadoParaEmpresaAplicacao : IntegrationEvent
    {
        public long ProvedorServicoId { get; set; }
        public long EmpresaAplicacaoId { get; set; }
    }
}
