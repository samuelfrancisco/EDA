﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class LiberacaoDoServicoDoProvedorParaEmpresaAplicacaoRevogada : IntegrationEvent
    {
        public long ProvedorServicoId { get; set; }
        public long EmpresaAplicacaoId { get; set; }
    }
}
