﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ExcluidaConfiguracaoDeTransacaoDaEmpresaAplicacao : IntegrationEvent
    {
        public long EmpresaAplicacaoTransacaoId { get; set; }
    }
}
