﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class EmpresaAlterada : IntegrationEvent
    {
        public long EmpresaId { get; set; }
        public string Codigo { get; set; }
        public string Nome { get; set; }
    }
}
