﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ServicoDoProvedorAlterado : IntegrationEvent
    {
        public long ProvedorServicoId { get; set; }
        public long TipoServicoId { get; set; }
        public string CodigoDoTipoDeServico { get; set; }
        public string DescricaoDoTipoDeServico { get; set; }
        public long ProvedorId { get; set; }
        public string CodigoDoProvedor { get; set; }
        public string NomeDoProvedor { get; set; }
        public bool? Contingencia { get; set; }
        public bool? UtilizaEstoque { get; set; }
        public string Url { get; set; }
        public int? Porta { get; set; }
        public IDictionary<string, string> Parametros { get; set; } = new Dictionary<string, string>();
    }
}
