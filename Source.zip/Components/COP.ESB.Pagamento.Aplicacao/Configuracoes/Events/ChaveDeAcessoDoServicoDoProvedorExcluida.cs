﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ChaveDeAcessoDoServicoDoProvedorExcluida : IntegrationEvent
    {
        public long ProvedorServicoSegurancaId { get; set; }
    }
}
