﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class TransacaoAlterada : IntegrationEvent
    {
        public long ContextoDeTransacoesId { get; set; }
        public long TransacaoId { get; set; }        
        public string Codigo { get; set; }
        public string Nome { get; set; }
        public TimeSpan? HorarioInicial { get; set; }
        public TimeSpan? HorarioFinal { get; set; }
        public TimeSpan? HorarioInicialBackOffice { get; set; }
        public TimeSpan? HorarioFinalBackOffice { get; set; }        
    }
}
