﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class TransacaoExcluida : IntegrationEvent
    {
        public long ContextoDeTransacoesId { get; set; }
        public long TransacaoId { get; set; }
    }
}
