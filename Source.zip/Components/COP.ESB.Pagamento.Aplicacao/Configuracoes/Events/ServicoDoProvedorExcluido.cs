﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class ServicoDoProvedorExcluido : IntegrationEvent
    {
        public long ProvedorServicoId { get; set; }
    }
}
