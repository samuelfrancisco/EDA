﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Events
{
    public class AplicacaoAlterada : IntegrationEvent
    {
        public long AplicacaoId { get; set; }
        public long FornecedorId { get; set; }
        public string Codigo { get; set; }
        public string Nome { get; set; }
    }
}
