﻿using System;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model para edição do segmento de convênio
    /// </summary>
    public class SegmentoDeConvenioEdicaoViewModel
    {
        /// <summary>
        /// Código do segmento de convênio
        /// </summary>
        [Required(ErrorMessage = "Código inválido.")]
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do segmento de convênio
        /// </summary>
        [Required(ErrorMessage = "Nome inválido.")]
        public string Nome { get; set; }

        /// <summary>
        /// Id do contexto de transações
        /// </summary>
        [Required(ErrorMessage = "Id do Contexto de Transações inválido.")]
        public long ContextoDeTrancacoesId { get; set; }

        /// <summary>
        /// Id da transação
        /// </summary>
        [Required(ErrorMessage = "Id da Transação inválido.")]
        public long TransacaoId { get; set; }

        /// <summary>
        /// Id do canal de processamento
        /// </summary>
        [Required(ErrorMessage = "Id do Canal de Processamento inválido.")]
        public Guid IdDoCanalDeProcessamento { get; set; }
    }
}
