﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model do histórico das configurações de repasse de convênios
    /// </summary>
    public class HistoricoDeConfiguracoesDeRepasseViewModel
    {
        /// <summary>
        /// Id do histórico
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Id das configurações de repasse
        /// </summary>
        public Guid IdDasConfiguracoesDeRepasse { get; set; }

        /// <summary>
        /// Id do canal de processamento
        /// </summary>
        public Guid IdDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// E-mails para notificações de alterações nas configurações de repasse de convênios
        /// </summary>
        public string EmailParaNotificacao { get; set; }

        /// <summary>
        /// Valor máximo de pagamentos realizados pelo canal de processamento
        /// </summary>
        public decimal? LimiteMaximoDiarioDeOperacoes { get; set; }

        /// <summary>
        /// Percentual do valor máximo de pagamentos para disparar o primeiro alerta
        /// </summary>
        public decimal? PercentualParaPrimeiroAlerta { get; set; }

        /// <summary>
        /// Percentual do valor máximo de pagamentos para disparar o segundo alerta
        /// </summary>
        public decimal? PercentualParaSegundoAlerta { get; set; }

        /// <summary>
        /// Dados do canal de processamento
        /// </summary>
        public CanalDeProcessamentoViewModel CanalDeProcessamento { get; set; }

        /// <summary>
        /// Id do usuário no ESB que realizou a alteração
        /// </summary>
        public string IdDoUsuario { get; set; }

        /// <summary>
        /// Nome do usuário que realizou a alteração
        /// </summary>
        public string NomeDoUsuario { get; set; }

        /// <summary>
        /// Data da alteração
        /// </summary>
        public DateTimeOffset Data { get; set; }
    }
}
