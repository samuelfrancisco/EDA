﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model das configurações de contingência de boletos
    /// </summary>
    public class ConfiguracoesDeContingenciaDeBoletosViewModel
    {
        /// <summary>
        /// E-mails para notificações de alteração no estado de contingência de boletos
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
          ErrorMessage = "Os e-mails informados não são válidos.")]
        public string EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia { get; set; }

        /// <summary>
        /// Maior valor aceito em contingência
        /// </summary>
        [Required(ErrorMessage = "O valor máximo aceito em contingência é obrigatório.")]
        public decimal ValorMaximoAceitoEmContingencia { get; set; }

        /// <summary>
        /// Horário limite para realização da consulta de boletos pagos em contengência
        /// </summary>
        [Required(ErrorMessage = "O horário limite para consulta após contingência é obrigatório.")]
        [RegularExpression("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "O horário limite para consulta após contingência não é válido.")]
        public string HorarioLimiteParaConsultaAposContingencia { get; set; }

        /// <summary>
        /// E-mails para notificações de contingência
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
            ErrorMessage = "Os e-mails informados não são válidos.")]
        public string EmailsParaNotificacoesDeContingencia { get; set; }

        /// <summary>
        /// Flag indicando se a consulta de boletos pagos em contingência será realizada automaticamente após o fim da contingência
        /// </summary>
        public bool AConsultaDePagamentosEmContingenciaDeveSerAutomatica { get; set; }

        /// <summary>
        /// E-mails para notificações de consulta de boletos pagos em contingência
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
            ErrorMessage = "Os e-mails informados não são válidos.")]
        public string EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia { get; set; }

        /// <summary>
        /// Local para gravação dos arquivos de envio da consulta de boletos pagos em contingência
        /// </summary>
        public string LocalParaArquivosDeEnvioDeConsultaEmContingencia { get; set; }

        /// <summary>
        /// Local para leitura de arquivos de retorno da consulta de boletos pagos em contingência
        /// </summary>
        public string LocalParaArquivosDeRetornoDeConsultaEmContingencia { get; set; }

        /// <summary>
        /// Flag indicando se a baixa operacional de boletos pagos em contingência será realizada automaticamente após o fim da contingência
        /// </summary>
        public bool ABaixaOperacionalEmContingenciaDeveSerAutomatica { get; set; }

        /// <summary>
        /// E-mails para notificações de baixa operacional de boletos pagos em contingência
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
            ErrorMessage = "Os e-mails informados não são válidos.")]
        public string EmailsParaNotificacoesDeBaixaOperacionalEmContingencia { get; set; }

        /// <summary>
        /// Local para gravação dos arquivos de envio da baixa operacional de boletos pagos em contingência
        /// </summary>
        public string LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia { get; set; }

        /// <summary>
        /// Local para leitura de arquivos de retorno da baixa operacional de boletos pagos em contingência
        /// </summary>
        public string LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia { get; set; }

        /// <summary>
        /// Flag indicando se boletos está em contingência
        /// </summary>
        public bool EstaEmContingencia { get; set; }

        /// <summary>
        /// Data da última alteração no status da contingência de boletos
        /// </summary>
        public DateTimeOffset? DataDaUltimaAlteracaoDoStatusDaContingencia { get; set; }

        /// <summary>
        /// Histórico de alterações no status da contingência de boletos
        /// </summary>
        public IEnumerable<HistoricoDeContingenciaDeBoletosViewModel> HistoricosDeContingencia { get; set; } = Enumerable.Empty<HistoricoDeContingenciaDeBoletosViewModel>();

        /// <summary>
        /// Status da contingência de boletos
        /// </summary>
        public string StatusAtualDoMotor
        {
            get
            {
                return EstaEmContingencia
                    ? "OFF LINE"
                    : "ON LINE";
            }
        }

        /// <summary>
        /// Status da contingência de boletos em formato de texto
        /// </summary>
        public string MensagemDoStatusAtualDoMotor
        {
            get
            {
                return EstaEmContingencia
                    ? string.Format("Modo OFF LINE ativado em {0} às {1}",
                    DataDaUltimaAlteracaoDoStatusDaContingencia?.DateTime.ToShortDateString(),
                    DataDaUltimaAlteracaoDoStatusDaContingencia?.DateTime.ToShortTimeString())
                    : string.Empty;
            }
        }
    }
}
