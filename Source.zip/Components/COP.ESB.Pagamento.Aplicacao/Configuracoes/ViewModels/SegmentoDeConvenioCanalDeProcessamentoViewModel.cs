﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model do canal de processamento do segmento de convênio
    /// </summary>
    public class SegmentoDeConvenioCanalDeProcessamentoViewModel
    {
        /// <summary>
        /// Id do canal de processamento
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>
        public string Nome { get; set; }
    }
}
