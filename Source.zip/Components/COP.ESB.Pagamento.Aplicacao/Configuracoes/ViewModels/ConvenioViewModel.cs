﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model das configurações do convênio
    /// </summary>
    public class ConvenioViewModel
    {
        /// <summary>
        /// Id do convênio
        /// </summary>
        [Required(ErrorMessage = "Id inválido.")]        
        public Guid IdDoConvenio { get; set; }

        /// <summary>
        /// Código do convênio
        /// </summary>
        [Required(ErrorMessage = "Código inválido.")]        
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        [Required(ErrorMessage = "Nome inválido.")]        
        public string Nome { get; set; }

        /// <summary>
        /// Id do canal de processamento
        /// </summary>
        //[Required(ErrorMessage = "Id do Canal de Processamento inválido.")]
        [DisplayName("Id do Canal de Processamento")]
        public Guid? IdDoCanalDeProcessamento { get; set; }        

        /// <summary>
        /// Id do segmento de convênio
        /// </summary>
        [Required(ErrorMessage = "Id do Segmento inválido.")]        
        public Guid IdDoSegmentoDeConvenio { get; set; }        

        /// <summary>
        /// Ids dos canais de processamento que podem ser usados para o convênio
        /// </summary>
        [Required(ErrorMessage = "Informe ao menos um Canal de Processamento.")]        
        public IList<Guid> IdsDosCanaisDeProcessamentoDisponiveis { set; get; }

        /// <summary>
        /// View model do canal de processamento
        /// </summary>
        public CanalDeProcessamentoViewModel CanalDeProcessamento { get; set; }

        /// <summary>
        /// View model do segmento de convênio
        /// </summary>
        public SegmentoDeConvenioViewModel SegmentoDeConvenio { get; set; }
    }
}
