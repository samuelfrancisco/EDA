﻿using System;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model para cadastro das configurações do canal de processamento
    /// </summary>
    public class CanalDeProcessamentoCadastroViewModel
    {
        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        [Required(ErrorMessage = "Código inválido.")]
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>
        [Required(ErrorMessage = "Nome inválido.")]
        public string Nome { get; set; }

        /// <summary>
        /// Horário de início do funcionamento do canal de processamento
        /// </summary>
        [RegularExpression("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "O horário inicial inválido.")]
        public string HorarioInicial { get; set; }

        /// <summary>
        /// Horário de término do funcionamento do canal de processamento
        /// </summary>
        [RegularExpression("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "O horário final inválido.")]
        public string HorarioFinal { get; set; }

        /// <summary>
        /// Id do canal de processamento alternativo
        /// </summary>
        public Guid? IdDoCanalDeProcessamentoAlternativo { get; set; }

        /// <summary>
        /// Emails para notificação de alteração no status da contingência
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
          ErrorMessage = "Os e-mails informados não são válidos.")]
        [Required(ErrorMessage = "E-mails para notificação inválidos: É necessário informar pelo menos um e-mail para notificação.")]
        public string EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia { get; set; }
    }
}
