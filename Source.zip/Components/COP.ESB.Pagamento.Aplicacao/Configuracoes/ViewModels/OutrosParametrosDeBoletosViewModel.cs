﻿using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model dos Outros Parâmetros de Boletos
    /// </summary>
    public class OutrosParametrosDeBoletosViewModel
    {
        /// <summary>
        /// E-mails para notificações de baixa operacional
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
            ErrorMessage = "Os e-mails informados não são válidos.")]
        public string EmailsParaNotificacoesDeBaixaOperacional { get; set; }
        
        /// <summary>
        /// Menor valor para um boleto ser considerado VR Boleto
        /// </summary>
        public decimal? ValorMinimoParaVRBoleto { get; set; }

        /// <summary>
        /// Maior valor permitido para um boleto sem registro na CIP
        /// </summary>
        public decimal? ValorPermitidoSemRegistroNaCIP { get; set; }
    }
}
