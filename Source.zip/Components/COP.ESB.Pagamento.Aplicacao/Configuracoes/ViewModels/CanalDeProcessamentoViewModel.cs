﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model das configurações do canal de processamento
    /// </summary>
    public class CanalDeProcessamentoViewModel
    {
        /// <summary>
        /// Id do canal de processamento
        /// </summary>        
        public Guid Id { get; set; }

        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>       
        public string Nome { get; set; }

        /// <summary>
        /// Horário de início do funcionamento do canal de processamento
        /// </summary>        
        public string HorarioInicial { get; set; }

        /// <summary>
        /// Horário de término do funcionamento do canal de processamento
        /// </summary>
        public string HorarioFinal { get; set; }

        /// <summary>
        /// Flag indicando se o canal de processamento está em contingência
        /// </summary>
        public bool EstaEmContingencia { get; set; }        

        /// <summary>
        /// Id do canal de processamento alternativo
        /// </summary>
        public Guid? IdDoCanalDeProcessamentoAlternativo { get; set; }

        /// <summary>
        /// Emails para notificação de alteração no status da contingência
        /// </summary>
        public string EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia { get; set; }

        /// <summary>
        /// Data da última alteração do status de contingência
        /// </summary>
        public string DataDaUltimaAlteracaoDoStatusDaContingencia { get; set; }

        /// <summary>
        /// Canais de processamento disponíveis para usar como canal de processamento alternativo
        /// </summary>
        public IEnumerable<CanalDeProcessamentoCanalDisponivelViewModel> CanaisDisponiveis { get; set; } = Enumerable.Empty<CanalDeProcessamentoCanalDisponivelViewModel>();
    }
}
