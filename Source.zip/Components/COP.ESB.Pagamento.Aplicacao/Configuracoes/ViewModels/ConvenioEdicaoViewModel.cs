﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model para edição das configurações do convênio
    /// </summary>
    public class ConvenioEdicaoViewModel
    {
        /// <summary>
        /// Código do convênio
        /// </summary>
        [Required(ErrorMessage = "Código inválido.")]        
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        [Required(ErrorMessage = "Nome inválida.")]        
        public string Nome { get; set; }

        /// <summary>
        /// Id do canal de processamento
        /// </summary>        
        public Guid? IdDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Id do segmento de convênio
        /// </summary>
        [Required(ErrorMessage = "Id do Segmento inválido.")]        
        public Guid IdDoSegmentoDeConvenio { get; set; }

        /// <summary>
        /// Ids dos canais de processamento que podem ser usados para o convênio
        /// </summary>
        [Required(ErrorMessage = "Informe ao menos um Canal de Processamento.")]
        public IList<Guid> IdsDosCanaisDeProcessamentoDisponiveis { set; get; }
    }
}
