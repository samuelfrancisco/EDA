﻿namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model da transação do segmento de convênio
    /// </summary>
    public class SegmentoDeConvenioTransacaoViewModel
    {
        /// <summary>
        /// Id do contexto de transações
        /// </summary>
        public long ContextoDeTransacoesId { get; set; }

        /// <summary>
        /// Id da transação
        /// </summary>
        public long TransacaoId { get; set; }

        /// <summary>
        /// Código da transação
        /// </summary>
        public string Codigo { get; set; }

        /// <summary>
        /// Nome da transação
        /// </summary>
        public string Nome { get; set; }
    }
}
