﻿namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model do usuário que realizou a alteração do status de contingência de boletos
    /// </summary>
    public class HistoricoDeContingenciaDeBoletosUsuarioViewModel
    {
        /// <summary>
        /// Id do usuário no ESB
        /// </summary>
        public string UsuarioId { get; set; }

        /// <summary>
        /// Nome de usuário
        /// </summary>
        public string Nome { get; set; }
    }
}
