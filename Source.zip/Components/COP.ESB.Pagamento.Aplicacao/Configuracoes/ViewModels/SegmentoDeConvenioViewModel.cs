﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model das configurações do segmento de convênio
    /// </summary>
    public class SegmentoDeConvenioViewModel
    {
        /// <summary>
        /// Id do segmento de convênio
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Código do segmento de convênio
        /// </summary>        
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do segmento de convênio
        /// </summary>        
        public string Nome { get; set; }

        /// <summary>
        /// Id do contexto de transações
        /// </summary>
        public long ContextoDeTransacoesId { get; set; }

        /// <summary>
        /// Id da transação
        /// </summary>
        public long TransacaoId { get; set; }

        /// <summary>
        /// Id do canal de processamento
        /// </summary>
        public Guid IdDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// View model da transação
        /// </summary>
        public SegmentoDeConvenioTransacaoViewModel Transacao { get; set; }

        /// <summary>
        /// View model do canal de processamento
        /// </summary>
        public SegmentoDeConvenioCanalDeProcessamentoViewModel CanalDeProcessamento { get; set; }
    }
}
