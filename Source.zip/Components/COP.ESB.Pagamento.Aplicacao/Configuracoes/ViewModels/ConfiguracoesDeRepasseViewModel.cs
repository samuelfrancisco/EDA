﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model das configurações de repasse de convênios
    /// </summary>
    public class ConfiguracoesDeRepasseViewModel
    {
        /// <summary>
        /// Código do Canal de Processamento.
        /// </summary>
        [Required(ErrorMessage = "Código do Canal de Processamento inválido.")]
        [DisplayName("Código do Canal de Processamento")]
        public string CodigoDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// E-mails para Notificação
        /// </summary>
        [RegularExpression(@"^(([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*$",
           ErrorMessage = "E-mails para notificação inválidos: Os e-mails informados não são válidos.")]
        [Required(ErrorMessage = "E-mails para notificação inválidos: É necessário informar pelo menos um e-mail para notificação.")]
        public string EmailParaNotificacao { get; set; }

        /// <summary>
        /// Limite Máximo diários de Operações
        /// </summary>
        public decimal? LimiteMaximoDiarioDeOperacoes { get; set; }

        /// <summary>
        /// Limite disponível para operações no dia
        /// </summary>
        public decimal? SaldoDisponivel { get; set; }

        /// <summary>
        /// Valor Percentual do Primeiro Alerta
        /// </summary>
        [Required(ErrorMessage = "Percentual para primeiro alerta inválido: O percentual deve ser um valor maior que 0% e menor que 100%.")]
        public decimal PercentualParaPrimeiroAlerta { get; set; }

        /// <summary>
        /// Valor Percentual do Segundos Alerta
        /// </summary>
        public decimal? PercentualParaSegundoAlerta { get; set; }

        /// <summary>
        /// View model do Canal de Porcessamento
        /// </summary>
        public CanalDeProcessamentoViewModel CanalDeProcessamento { get; set; }

        /// <summary>
        /// Id do usuário efetuando a alteração
        /// </summary>
        [Required(ErrorMessage = "Id do usuário inválido: O id do usuário não pode ser nulo ou em branco.")]
        public string IdDoUsuario { get; set; }

        /// <summary>
        /// Nome do usuário efetuando a alteração
        /// </summary>
        [Required(ErrorMessage = "Nome do usuário inválido: O nome do usuário não pode ser nulo ou em branco.")]
        public string NomeDoUsuario { get; set; }

        /// <summary>
        /// Históricos de alterações das configurações de repasse
        /// </summary>
        public IEnumerable<HistoricoDeConfiguracoesDeRepasseViewModel> HistoricoDeConfiguracoesDeRepasse { set; get; } = new List<HistoricoDeConfiguracoesDeRepasseViewModel>();
    }
}
