﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels
{
    /// <summary>
    /// View model do filtro para consulta das configurações dos convênios
    /// </summary>
    public class ConvenioFiltroViewModel
    {
        /// <summary>
        /// Código do convênio
        /// </summary>
        public string Codigo { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// Id do segmento de convênio
        /// </summary>
        public Guid? IdDoSegmentoDeConvenio { get; set; }
    }
}
