﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Commands;
using COP.ESB.Pagamento.Dominio.Configuracoes.DTOs;
using COP.ESB.Pagamento.Dominio.Configuracoes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.Denormalizers
{
    public class ConfiguracoesDoMotorDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovaTransacaoRegistrada>,
        IAsyncEventHandler<NovaTransacaoRegistradaV2>,
        IAsyncEventHandler<TransacaoAlterada>,
        IAsyncEventHandler<TransacaoAlteradaV2>,
        IAsyncEventHandler<TransacaoExcluida>,
        IAsyncEventHandler<TransacaoConfiguradaParaEmpresaAplicacao>,
        IAsyncEventHandler<ExcluidaConfiguracaoDeTransacaoDaEmpresaAplicacao>,
        IAsyncEventHandler<EmpresaAlterada>,
        IAsyncEventHandler<AplicacaoAlterada>,
        IAsyncEventHandler<EmpresaAplicacaoExcluida>,
        IAsyncEventHandler<NovoServicoDoProvedorConfigurado>,
        IAsyncEventHandler<ServicoDoProvedorAlterado>,
        IAsyncEventHandler<ServicoDoProvedorExcluido>,
        IAsyncEventHandler<ChaveDeAcessoDoServicoDoProvedorAlterada>,
        IAsyncEventHandler<ChaveDeAcessoDoServicoDoProvedorExcluida>,
        IAsyncEventHandler<ProvedorAlterado>,
        IAsyncEventHandler<ServicoDoProvedorLiberadoParaEmpresaAplicacao>,
        IAsyncEventHandler<LiberacaoDoServicoDoProvedorParaEmpresaAplicacaoRevogada>
    {
        private readonly IConfiguracoesDoMotorRepository _configuracoesDoMotorRepository;
        private readonly IConfiguracoesDeBoletosRepository _configuracoesDeBoletosRepository;
        private readonly IEventNotificationBus _eventNotificationBus;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public ConfiguracoesDoMotorDenormalizer(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorRepository configuracoesDoMotorRepository,
            IConfiguracoesDeBoletosRepository configuracoesDeBoletosRepository,
            IEventNotificationBus eventNotificationBus,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorRepository = configuracoesDoMotorRepository;
            _configuracoesDeBoletosRepository = configuracoesDeBoletosRepository;
            _eventNotificationBus = eventNotificationBus;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        public Task HandleAsync(IEventEnvelop<NovaTransacaoRegistrada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovaTransacaoRegistrada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            if (@event.NomeDoContextoDeTransacoes != "Pagamentos")
                return;

            var configuracoesDaTransacao = configuracoesDoMotor.NovaTransacaoRegistrada(new TransacaoDTO
            {
                Codigo = @event.Codigo,
                ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                HorarioFinal = @event.HorarioFinal,
                HorarioFinalDeBackOffice = @event.HorarioFinalBackOffice,
                HorarioInicial = @event.HorarioInicial,
                HorarioInicialDeBackOffice = @event.HorarioInicialBackOffice,
                Nome = @event.Nome,                
                TransacaoId = @event.TransacaoId
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            if (@event.Codigo == "Boletos")
            {
                await ConfigurarTransacaoDeBoletosAsync(@event).ConfigureAwait(false);
            }

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        private async Task ConfigurarTransacaoDeBoletosAsync(dynamic @event)
        {
            var configuracoesDeBoletos = await _configuracoesDeBoletosRepository
                .ObterAsConfiguracoesDeBoletosPeloIdDoContextoDeTransacoesEIdDaTransacao(@event.ContextoDeTransacoesId, @event.TransacaoId)
                .ConfigureAwait(false);

            if (configuracoesDeBoletos != null)
                return;

            var comando = new RegistrarNovaTransacaoBoletosCommand
            {
                TransacaoId = @event.TransacaoId,
                ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                CorrelationMessage = @event,
                OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
            };

            configuracoesDeBoletos = ConfiguracoesDeBoletos.RegistrarNovaTransacaoBoletos(comando);

            await _configuracoesDeBoletosRepository.SaveAsync(configuracoesDeBoletos, comando.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovaTransacaoRegistradaV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovaTransacaoRegistradaV2 @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            if (@event.NomeDoContextoDeTransacoes != "Pagamentos")
                return;

            var configuracoesDaTransacao = configuracoesDoMotor.NovaTransacaoRegistrada(new TransacaoDTO
            {
                Codigo = @event.Codigo,
                ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                HorarioFinal = @event.HorarioFinal,
                HorarioFinalDeBackOffice = @event.HorarioFinalBackOffice,
                HorarioInicial = @event.HorarioInicial,
                HorarioInicialDeBackOffice = @event.HorarioInicialBackOffice,
                EmailsParaNotificacaoDeAlteracoes = @event.EmailsParaNotificacaoDeAlteracoes,
                Nome = @event.Nome,
                TransacaoId = @event.TransacaoId
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            if (@event.Codigo == "Boletos")
            {
                await ConfigurarTransacaoDeBoletosAsync(@event).ConfigureAwait(false);
            }

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<TransacaoAlterada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TransacaoAlterada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.TransacaoBoletosAlterada(new TransacaoDTO
            {
                Codigo = @event.Codigo,
                HorarioFinal = @event.HorarioFinal,
                HorarioFinalDeBackOffice = @event.HorarioFinalBackOffice,
                HorarioInicial = @event.HorarioInicial,
                HorarioInicialDeBackOffice = @event.HorarioInicialBackOffice,
                Nome = @event.Nome,
                TransacaoId = @event.TransacaoId
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<TransacaoAlteradaV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TransacaoAlteradaV2 @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.TransacaoBoletosAlterada(new TransacaoDTO
            {
                Codigo = @event.Codigo,
                HorarioFinal = @event.HorarioFinal,
                HorarioFinalDeBackOffice = @event.HorarioFinalBackOffice,
                HorarioInicial = @event.HorarioInicial,
                HorarioInicialDeBackOffice = @event.HorarioInicialBackOffice,
                Nome = @event.Nome,
                TransacaoId = @event.TransacaoId,
                EmailsParaNotificacaoDeAlteracoes = @event.EmailsParaNotificacaoDeAlteracoes
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<TransacaoExcluida> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TransacaoExcluida @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.TransacaoExcluida(@event.TransacaoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            var configuracoesDeBoletos = await _configuracoesDeBoletosRepository
                .ObterAsConfiguracoesDeBoletosPeloIdDoContextoDeTransacoesEIdDaTransacao(@event.ContextoDeTransacoesId, @event.TransacaoId)
                .ConfigureAwait(false);

            if (configuracoesDeBoletos != null)
            {
                var comando = new InativarTransacaoBoletosCommand
                {
                    ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                    TransacaoId = @event.TransacaoId,
                    CorrelationMessage = @event,
                    OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                };

                configuracoesDeBoletos.Inativar(comando);

                await _configuracoesDeBoletosRepository.SaveAsync(configuracoesDeBoletos, comando.Id).ConfigureAwait(false);
            }

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }        

        public Task HandleAsync(IEventEnvelop<TransacaoConfiguradaParaEmpresaAplicacao> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TransacaoConfiguradaParaEmpresaAplicacao @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.TransacaoConfiguradaParaEmpresaAplicacao(new EmpresaAplicacaoTransacaoDTO
            {
                AplicacaoId = @event.AplicacaoId,
                DebitarContaCorrente = @event.DebitarContaCorrente,
                EmpresaAplicacaoId = @event.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                EmpresaId = @event.EmpresaId,
                EstornarAutomaticamente = @event.EstornarAutomaticamente,
                HorarioFinal = @event.HorarioFinal,
                HorarioInicial = @event.HorarioInicial,
                NomeDaAplicacao = @event.NomeDaAplicacao,
                NomeDaEmpresa = @event.NomeDaEmpresa,
                ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                TransacaoId = @event.TransacaoId,
                ValidarSaldoDaContaCorrente = @event.ValidarSaldoDaContaCorrente,
                ValorLimiteParaPagamento = @event.ValorLimiteParaPagamento,
                IdsDosServicosDeProvedoresLiberados = @event.IdsDosServicosDeProvedoresLiberados
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ExcluidaConfiguracaoDeTransacaoDaEmpresaAplicacao> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ExcluidaConfiguracaoDeTransacaoDaEmpresaAplicacao @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ExcluidaConfiguracaoDeTransacaoDaEmpresaAplicacao(@event.EmpresaAplicacaoTransacaoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<EmpresaAlterada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(EmpresaAlterada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.EmpresaAlterada(@event.EmpresaId, @event.Nome);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<AplicacaoAlterada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(AplicacaoAlterada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.AplicacaoAlterada(@event.AplicacaoId, @event.Nome);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<EmpresaAplicacaoExcluida> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(EmpresaAplicacaoExcluida @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.EmpresaAplicacaoExcluida(@event.EmpresaAplicacaoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<NovoServicoDoProvedorConfigurado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovoServicoDoProvedorConfigurado @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.NovoServicoDoProvedorConfigurado(new ServicoDoProvedorDTO
            {
                CodigoDoProvedor = @event.CodigoDoProvedor,
                CodigoDoTipoDeServico = @event.CodigoDoTipoDeServico,
                DescricaoDoTipoDeServico = @event.DescricaoDoTipoDeServico,
                NomeDoProvedor = @event.NomeDoProvedor,
                Parametros = @event.Parametros,
                ProvedorId = @event.ProvedorId,
                ProvedorServicoId = @event.ProvedorServicoId,
                TipoServicoId = @event.TipoServicoId,
                Url = @event.Url,
                Porta = @event.Porta
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ServicoDoProvedorAlterado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ServicoDoProvedorAlterado @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ServicoDoProvedorAlterado(new ServicoDoProvedorDTO
            {
                CodigoDoProvedor = @event.CodigoDoProvedor,
                CodigoDoTipoDeServico = @event.CodigoDoTipoDeServico,
                DescricaoDoTipoDeServico = @event.DescricaoDoTipoDeServico,
                NomeDoProvedor = @event.NomeDoProvedor,
                Parametros = @event.Parametros,
                ProvedorId = @event.ProvedorId,
                ProvedorServicoId = @event.ProvedorServicoId,
                TipoServicoId = @event.TipoServicoId,
                Url = @event.Url,
                Porta = @event.Porta
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ServicoDoProvedorExcluido> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ServicoDoProvedorExcluido @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ServicoDoProvedorExcluido(@event.ProvedorServicoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ChaveDeAcessoDoServicoDoProvedorAlterada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ChaveDeAcessoDoServicoDoProvedorAlterada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ChaveDeAcessoDoServicoDoProvedorAlterada(new ConfiguracoesDoServicoChaveDTO
            {
                Certificado = @event.Certificado,
                ChavePublica = @event.ChavePublica,
                DataAtivacao = @event.DataAtivacao,
                DataValidadeAte = @event.DataValidadeAte,
                DataValidadeDe = @event.DataValidadeDe,
                Descricao = @event.Descricao,
                ProvedorServicoId = @event.ProvedorServicoId,
                IdDoProvedorServicoSeguranca = @event.ProvedorServicoSegurancaId,
                Senha = @event.Senha,
                SenhaCertificado = @event.SenhaCertificado,
                Usuario = @event.Usuario
            });

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ChaveDeAcessoDoServicoDoProvedorExcluida> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ChaveDeAcessoDoServicoDoProvedorExcluida @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ChaveDeAcessoDoServicoDoProvedorExcluida(@event.ProvedorServicoSegurancaId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ProvedorAlterado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ProvedorAlterado @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ProvedorAlterado(@event.ProvedorId, @event.Codigo, @event.Nome);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<ServicoDoProvedorLiberadoParaEmpresaAplicacao> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ServicoDoProvedorLiberadoParaEmpresaAplicacao @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.ServicoDoProvedorLiberadoParaEmpresaAplicacao(@event.EmpresaAplicacaoId, @event.ProvedorServicoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }

        public Task HandleAsync(IEventEnvelop<LiberacaoDoServicoDoProvedorParaEmpresaAplicacaoRevogada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(LiberacaoDoServicoDoProvedorParaEmpresaAplicacaoRevogada @event, CancellationToken cancellationToken)
        {
            var configuracoesDoMotor = await _configuracoesDoMotorRepository.ObterAsConfiguracoesDoMotorParaAtualizacaoAsync().ConfigureAwait(false);

            configuracoesDoMotor.LiberacaoDoServicoDoProvedorParaEmpresaAplicacaoRevogada(@event.EmpresaAplicacaoId, @event.ProvedorServicoId);

            await _configuracoesDoMotorRepository.SaveAsync(configuracoesDoMotor).ConfigureAwait(false);

            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }
    }
}
