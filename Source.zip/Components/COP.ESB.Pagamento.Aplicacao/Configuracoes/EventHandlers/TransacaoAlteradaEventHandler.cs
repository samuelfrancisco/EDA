﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.EventHandlers
{
    public class TransacaoAlteradaEventHandler : PrimaryEventHandler, IAsyncEventHandler<TransacaoAlteradaV2>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public TransacaoAlteradaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<TransacaoAlteradaV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TransacaoAlteradaV2 @event, CancellationToken cancellationToken)
        {
            var to = @event.EmailsParaNotificacaoDeAlteracoes?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Novas configurações da Transação.";

            var corpoDoEmail = await GerarCorpoDoEmail(@event, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(TransacaoAlteradaV2 @event, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");          

            var model = new NovasConfiguracoesDaTransacaoDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Seguem as novas configurações da Transação:",
                ContextoDeTransacoesId = @event.ContextoDeTransacoesId,
                TransacaoId = @event.TransacaoId,
                Codigo = @event.Codigo,
                Nome = @event.Nome,
                HorarioInicial = @event.HorarioInicial.HasValue
                ? @event.HorarioInicial.Value.ToString(@"hh\:mm")
                : " - ",
                HorarioFinal = @event.HorarioFinal.HasValue
                ? @event.HorarioFinal.Value.ToString(@"hh\:mm")
                : " - ",
                HorarioInicialBackOffice = @event.HorarioInicialBackOffice.HasValue
                ? @event.HorarioInicialBackOffice.Value.ToString(@"hh\:mm")
                : " - ",
                HorarioFinalBackOffice = @event.HorarioFinalBackOffice.HasValue
                ? @event.HorarioFinalBackOffice.Value.ToString(@"hh\:mm")
                : " - ",
                EmailsParaNotificacaoDeAlteracoes = !string.IsNullOrWhiteSpace(@event.EmailsParaNotificacaoDeAlteracoes)
                ? @event.EmailsParaNotificacaoDeAlteracoes
                : " - "
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\NovasConfiguracoesDaTransacao.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
