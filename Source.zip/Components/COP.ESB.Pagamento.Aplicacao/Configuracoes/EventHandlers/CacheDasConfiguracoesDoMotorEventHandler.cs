﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.EventHandlers
{
    public class CacheDasConfiguracoesDoMotorEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<CanalDeProcessamentoAlteradoEvent>,
        IInternalAsyncEventHandler<ConfiguracoesDeContingenciaDeBoletosAlteradasEvent>,
        IInternalAsyncEventHandler<ConfiguracoesDeRepasseAlteradasEvent>,
        IInternalAsyncEventHandler<ConfiguracoesDeRepasseDefinidasEvent>,
        IInternalAsyncEventHandler<ContingenciaDeBoletosDesligadaEvent>,
        IInternalAsyncEventHandler<ContingenciaDeBoletosLigadaEvent>,
        IInternalAsyncEventHandler<ContingenciaDoCanalDeProcessamentoDesligadaEvent>,
        IInternalAsyncEventHandler<ContingenciaDoCanalDeProcessamentoLigadaEvent>,
        IInternalAsyncEventHandler<ConvenioAlteradoEvent>,
        IInternalAsyncEventHandler<ConvenioInativadoEvent>,
        IInternalAsyncEventHandler<NovaTransacaoBoletosRegistradaEvent>,
        IInternalAsyncEventHandler<NovoCanalDeProcessamentoCriadoEvent>,
        IInternalAsyncEventHandler<NovoConvenioCriadoEvent>,
        IInternalAsyncEventHandler<NovoSegmentoDeConvenioCriadoEvent>,
        IInternalAsyncEventHandler<OutrosParametrosDeBoletosAlteradosEvent>,
        IInternalAsyncEventHandler<SegmentoDeConvenioAlteradoEvent>,
        IInternalAsyncEventHandler<SegmentoDeConvenioInativadoEvent>,
        IInternalAsyncEventHandler<TransacaoBoletosInativadaEvent>

    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public CacheDasConfiguracoesDoMotorEventHandler(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }       

        public Task HandleAsync(IEventEnvelop<CanalDeProcessamentoAlteradoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ConfiguracoesDeContingenciaDeBoletosAlteradasEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ConfiguracoesDeRepasseAlteradasEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ConfiguracoesDeRepasseDefinidasEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDeBoletosDesligadaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDeBoletosLigadaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDoCanalDeProcessamentoDesligadaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDoCanalDeProcessamentoLigadaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ConvenioAlteradoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<ConvenioInativadoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<NovaTransacaoBoletosRegistradaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<NovoCanalDeProcessamentoCriadoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<NovoConvenioCriadoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<NovoSegmentoDeConvenioCriadoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<OutrosParametrosDeBoletosAlteradosEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<SegmentoDeConvenioAlteradoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<SegmentoDeConvenioInativadoEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        public Task HandleAsync(IEventEnvelop<TransacaoBoletosInativadaEvent> envelope, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelope, DoHandle, cancellationToken);
        }

        private Task DoHandle(dynamic @event, CancellationToken cancellationToken)
        {
            ResetarAsConfiguracoesDoMotor();

            return Task.FromResult(0);
        }

        private void ResetarAsConfiguracoesDoMotor()
        {
            _configuracoesDoMotorService.ResetarAsConfiguracoesDoMotor();
        }
    }
}
