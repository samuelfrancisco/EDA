﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.EventHandlers
{
    public class ConfiguracoesDeContingenciaDeBoletosAlteradasEventHandler : PrimaryEventHandler, IInternalAsyncEventHandler<ConfiguracoesDeContingenciaDeBoletosAlteradasEvent>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public ConfiguracoesDeContingenciaDeBoletosAlteradasEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<ConfiguracoesDeContingenciaDeBoletosAlteradasEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ConfiguracoesDeContingenciaDeBoletosAlteradasEvent @event, CancellationToken cancellationToken)
        {
            var to = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeContingencia?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Novas configurações de contingência de boletos.";

            var corpoDoEmail = await GerarCorpoDoEmail(_configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConfiguracoesDeBoletos configuracoes, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var status = configuracoes?.EstaEmContingencia == true ? "OFF LINE" : "ON LINE";

            var model = new NovasConfiguracoesDeContingenciaDeBoletosDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Seguem as novas configurações de contingência de boletos:",
                StatusAtualDoMotor = status,
                ValorMaximoAceitoEmContingencia = $"R$ {configuracoes?.ValorMaximoAceitoEmContingencia.ToString("N2")}.",
                HorarioLimiteParaConsultaEmContingencia = configuracoes?.HorarioLimiteParaConsultaAposContingencia.ToString(@"hh\:mm")
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\NovasConfiguracoesDeContingenciaDeBoletos.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
