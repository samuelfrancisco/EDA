﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Configuracoes.EventHandlers
{
    public class ContingenciaDoCanalDeProcessamentoLigadaEventHandler : PrimaryEventHandler, IInternalAsyncEventHandler<ContingenciaDoCanalDeProcessamentoLigadaEvent>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public ContingenciaDoCanalDeProcessamentoLigadaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDoCanalDeProcessamentoLigadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ContingenciaDoCanalDeProcessamentoLigadaEvent @event, CancellationToken cancellationToken)
        {
            var canalDeProcessamento = _configuracoesDoMotorService.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosCanaisDeProcessamento
                .FirstOrDefault(x => x.Id == @event.IdDoCanalDeProcessamento);

            if (canalDeProcessamento == null)
                return;

            var to = canalDeProcessamento.EmailsParaNotificacaoDeAlteracaoNoStatusDaContingencia?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Contingência do Canal de Processamento Ligada";

            var corpoDoEmail = await GerarCorpoDoEmail(canalDeProcessamento, @event, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConfiguracoesDoCanalDeProcessamento canalDeProcessamento,
            ContingenciaDoCanalDeProcessamentoLigadaEvent @event, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var status = canalDeProcessamento.EstaEmContingencia ? "OFF LINE" : "ON LINE";

            var model = new AlteracaoNoStatusDaContingenciaDoCanalDeProcessamentoDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "A Contingência do Canal de Processamento foi Ligada:",
                CodigoDoCanal = canalDeProcessamento.Codigo,
                NomeDoCanal = canalDeProcessamento.Nome,
                StatusAtualDoCanal = status,
                DataDaAlteracao = @event.Date.ToString("dd/MM/yyyy HH:mm:ss"),
                IdDoUsuario = @event.IdDoUsuario,
                NomeDoUsuario = @event.NomeDoUsuario
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\AlteracaoNoStatusDaContingenciaDoCanalDeProcessamento.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
