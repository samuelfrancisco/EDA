﻿using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeBoletosPagosEmContingencia.CommandHandlers
{
    public class ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommandHandler
    : CommandRequestHandler<ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand>
    {
        private readonly IConsultaDeBoletosPagosEmContingenciaRepository _consultaDeBoletosPagosEmContingenciaRepository;

        public ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeBoletosPagosEmContingenciaRepository consultaDeBoletosPagosEmContingenciaRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeBoletosPagosEmContingenciaRepository = consultaDeBoletosPagosEmContingenciaRepository;
        }

        protected override async Task DoHandleAsync(ProcessarErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeBoletosPagosEmContingenciaRepository
                .ObterPeloIdDoProcessoDeConsultaEBaixaAsync(command.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (consulta == null)
                return;

            var xmlRetornadoResult = await ObterXmlDoArquivoDeRetornoAsync(command.NomeCompletoDoArquivo).ConfigureAwait(false);

            if (xmlRetornadoResult.IsSuccess)
            {
                consulta.ProcessarErroDeArquivo(command, xmlRetornado: xmlRetornadoResult.Value);
            }
            else
            {
                consulta.ProcessarErroDeArquivo(command, erro: xmlRetornadoResult.ErroMessage.Message);
            }

            await _consultaDeBoletosPagosEmContingenciaRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }

        private async Task<Result<string>> ObterXmlDoArquivoDeRetornoAsync(string nomeCompletoDoArquivo)
        {
            try
            {
                using (var fs = new FileStream(nomeCompletoDoArquivo, FileMode.Open, FileAccess.Read))
                using (var sw = new StreamReader(fs))
                {
                    var xml = await sw.ReadToEndAsync().ConfigureAwait(false);

                    return new Result<string>(xml);
                }
            }
            catch (Exception ex)
            {
                var result = new Result();
                result.AddError(ex.Message, ex.Source, GetType().FullName);
                result.ErroMessage.Message = $"Não foi possível ler o arquivo de retorno: {ex.Message}.";
                return result.ToResult<string>();
            }
        }
    }
}
