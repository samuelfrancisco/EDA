﻿using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.DTOs;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeBoletosPagosEmContingencia.CommandHandlers
{
    public class IniciarConsultaDeBoletosPagosEmContingenciaCommandHandler : CommandRequestHandler<IniciarConsultaDeBoletosPagosEmContingenciaCommand>
    {
        private readonly IConsultaDeBoletosPagosEmContingenciaRepository _consultaDeBoletosPagosEmContingenciaRepository;
        private readonly IBoletoRepository _boletoRepository;
        private readonly ICalendarioService _calendarioService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IConsultaDeBoletosPagosEmContingenciaService _consultaDeBoletosPagosEmContingenciaService;

        public IniciarConsultaDeBoletosPagosEmContingenciaCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeBoletosPagosEmContingenciaRepository consultaDeBoletosPagosEmContingenciaRepository,
            IBoletoRepository boletoRepository,
            ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IConsultaDeBoletosPagosEmContingenciaService consultaDeBoletosPagosEmContingenciaService)
            : base(commandHandlerRepository)
        {
            _consultaDeBoletosPagosEmContingenciaRepository = consultaDeBoletosPagosEmContingenciaRepository;
            _boletoRepository = boletoRepository;
            _calendarioService = calendarioService;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _consultaDeBoletosPagosEmContingenciaService = consultaDeBoletosPagosEmContingenciaService;
        }

        protected override async Task DoHandleAsync(IniciarConsultaDeBoletosPagosEmContingenciaCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeBoletosPagosEmContingenciaRepository
                .ObterPeloIdDoProcessoDeConsultaEBaixaAsync(command.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (consulta != null)
                return;

            var dataDeProcessamento = _calendarioService.ObterADataDeProcessamento();

            var pagamentos = await ObterPagamentosDoDiaRealizadosEmContingenciaPendentesDeBaixaOperacionalAsync(dataDeProcessamento).ConfigureAwait(false);

            consulta = new ConsultaDeBoletosPagosEmContingencia(command, dataDeProcessamento, pagamentos, _consultaDeBoletosPagosEmContingenciaService,
                _configuracoesDoMotorService);

            if (consulta.Status == ConsultaDeBoletosPagosEmContingenciaStatus.Iniciada)
            {
                var result = await EnviarArquivosDaConsultaAsync(command, consulta).ConfigureAwait(false);

                if (result.IsFailure)
                    consulta.Cancelar(new CancelarConsultaDeBoletosPagosEmContingenciaCommand
                    {
                        IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                        MotivoDoCancelamento = string.Join(Environment.NewLine, result.ErroMessage.Errors.Select(x => x.Message)),
                        CorrelationMessage = command,
                        OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                    });
            }

            await _consultaDeBoletosPagosEmContingenciaRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }

        private async Task<IEnumerable<PagamentoDeBoletoDTO>> ObterPagamentosDoDiaRealizadosEmContingenciaPendentesDeBaixaOperacionalAsync(DateTime dataDeProcessamento)
        {
            var pagamentos = await _boletoRepository.ObterPagamentosDoDiaRealizadosEmContingenciaPendentesDeBaixaOperacionalAsync(dataDeProcessamento)
                .ConfigureAwait(false);

            return pagamentos.Select(x => new PagamentoDeBoletoDTO
            {
                EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId,
                IdDoBoleto = x.IdDoBoleto,
                IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = x.Id,
                CodigoDeBarrasDoBoleto = x.Boleto.CodigoDeBarras.Valor,
                ValorDoPagamento = x.ValorDoPagamento
            }).ToList();
        }

        private Task<Result> EnviarArquivosDaConsultaAsync(IniciarConsultaDeBoletosPagosEmContingenciaCommand command,
            ConsultaDeBoletosPagosEmContingencia consulta)
        {
            return Task.Run(() =>
            {
                var result = new Result();

                var arquivosSalvos = new Dictionary<Guid, string>();

                foreach (var arquivoGerado in consulta.ArquivosGerados)
                {
                    try
                    {
                        var caminhoDoArquivo = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeEnvioDeConsultaEmContingencia;

                        var nomeCompletoDoArquivo = $"{caminhoDoArquivo}\\{arquivoGerado.NomeDoArquivo}.xml";

                        var xml = new XmlDocument
                        {
                            InnerXml = arquivoGerado.XmlGerado
                        };

                        xml.Save(nomeCompletoDoArquivo);

                        arquivosSalvos.Add(arquivoGerado.Id, nomeCompletoDoArquivo);
                    }
                    catch (Exception ex)
                    {
                        result.AddError(ex.Message, ex.Source, GetType().FullName);
                    }
                }

                if (result.IsSuccess)
                {
                    consulta.EnviarArquivos(new EnviarArquivosDeConsultaDeBoletosPagosEmContingenciaCommand
                    {
                        IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                        NomesCompletosDosArquivosNoEnvio = arquivosSalvos,
                        CorrelationMessage = command,
                        OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                    });
                }

                return result;
            });
        }
    }
}
