﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeBoletosPagosEmContingencia.EventHandlers
{
    public class ArquivosDeConsultaDeBoletosPagosEmContingenciaEnviadosEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<ArquivosDeConsultaDeBoletosPagosEmContingenciaEnviadosEvent>
    {
        private readonly IConsultaDeBoletosPagosEmContingenciaRepository _consultaDeBoletosPagosEmContingenciaRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public ArquivosDeConsultaDeBoletosPagosEmContingenciaEnviadosEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConsultaDeBoletosPagosEmContingenciaRepository consultaDeBoletosPagosEmContingenciaRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _consultaDeBoletosPagosEmContingenciaRepository = consultaDeBoletosPagosEmContingenciaRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<ArquivosDeConsultaDeBoletosPagosEmContingenciaEnviadosEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ArquivosDeConsultaDeBoletosPagosEmContingenciaEnviadosEvent @event, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.SourceId).ConfigureAwait(false);

            if (consulta == null) return;

            var to = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Geração de arquivo de consulta de boletos pagos contingência.";

            var corpoDoEmail = await GerarCorpoDoEmail(consulta, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConsultaDeBoletosPagosEmContingencia consulta, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var model = new ConsultaEBaixaEmContingenciaEnvioDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Início do processo de geração automática de arquivos de consulta de boletos pagos contingência:",
                DataDeReferencia = consulta.DataDeProcessamento.ToString("dd/MM/yyyy"),
                DataEHoraDaGeracao = consulta.DataDeInicio.ToString("dd/MM/yyyy HH:mm:ss"),
                QuantidadeTotalDePagamentos = consulta.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Count().ToString(),
                ValorTotalDosPagamentos = consulta.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Sum(x => x.ValorDoPagamento).ToString("C2"),
                Arquivos = consulta.ArquivosGerados.Select(arquivo => new ConsultaEBaixaEmContingenciaEnvioArquivoDTO
                {
                    Nome = arquivo.NomeDoArquivo,
                    QuantidadeDePagamentos = arquivo.PagamentosEnviados.Count().ToString(),
                    ValorDosPagamentos = arquivo.PagamentosEnviados.Sum(x => x.ValorDoPagamento).ToString("C2")
                }).ToList()
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\ConsultaEBaixaEmContingenciaEnvio.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
