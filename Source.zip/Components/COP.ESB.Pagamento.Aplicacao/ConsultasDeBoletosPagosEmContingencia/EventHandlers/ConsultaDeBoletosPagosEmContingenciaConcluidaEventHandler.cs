﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeBoletosPagosEmContingencia.EventHandlers
{
    public class ConsultaDeBoletosPagosEmContingenciaConcluidaEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent>
    {
        private readonly IConsultaDeBoletosPagosEmContingenciaRepository _consultaDeBoletosPagosEmContingenciaRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public ConsultaDeBoletosPagosEmContingenciaConcluidaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConsultaDeBoletosPagosEmContingenciaRepository consultaDeBoletosPagosEmContingenciaRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _consultaDeBoletosPagosEmContingenciaRepository = consultaDeBoletosPagosEmContingenciaRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ConsultaDeBoletosPagosEmContingenciaConcluidaEvent @event, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.SourceId).ConfigureAwait(false);

            if (consulta == null) return;

            var to = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.EmailsParaNotificacoesDeConsultaDePagamentosEmContingencia?.Split(';');

            if (to == null || to?.Any() != true) return;

            var assunto = "Motor de Pagamentos - Geração de arquivo de consulta de boletos pagos contingência.";

            var corpoDoEmail = await GerarCorpoDoEmail(consulta, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConsultaDeBoletosPagosEmContingencia consulta, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var model = new ConsultaEBaixaEmContingenciaConclusaoDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "Conclusão do processo de geração automática de arquivos de consulta de boletos pagos contingência:",
                DataDeReferencia = consulta.DataDeProcessamento.ToString("dd/MM/yyyy"),
                DataEHoraDaGeracao = consulta.DataDeInicio.ToString("dd/MM/yyyy HH:mm:ss"),
                QuantidadeTotalDePagamentos = consulta.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Count().ToString(),
                ValorTotalDosPagamentos = consulta.ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Sum(x => x.ValorDoPagamento).ToString("C2"),
                Arquivos = consulta.ArquivosGerados.Select(arquivo => new ConsultaEBaixaEmContingenciaConclusaoArquivoDTO
                {
                    Nome = arquivo.NomeDoArquivo,
                    QuantidadeDePagamentosAceitos = arquivo.PagamentosEnviados.Count(x => x.Status == PagamentoEnviadoNaConsultaDeBoletosPagosEmContingenciaStatus.Aceito).ToString(),
                    QuantidadeDePagamentosRecusados = arquivo.PagamentosEnviados.Count(x => x.Status == PagamentoEnviadoNaConsultaDeBoletosPagosEmContingenciaStatus.Recusado).ToString(),
                    QuantidadeDePagamentos = arquivo.PagamentosEnviados.Count().ToString(),
                    ValorDosPagamentosAceitos = arquivo.PagamentosEnviados.Where(x => x.Status == PagamentoEnviadoNaConsultaDeBoletosPagosEmContingenciaStatus.Aceito).Sum(x => x.ValorDoPagamento).ToString("C2"),
                    ValorDosPagamentosRecusados = arquivo.PagamentosEnviados.Where(x => x.Status == PagamentoEnviadoNaConsultaDeBoletosPagosEmContingenciaStatus.Recusado).Sum(x => x.ValorDoPagamento).ToString("C2"),
                    ValorDosPagamentos = arquivo.PagamentosEnviados.Sum(x => x.ValorDoPagamento).ToString("C2"),
                    FoiProcessadoComSucesso = arquivo.FoiProcessadoComSucesso,
                    XmlDoRetorno = arquivo.XmlDoRetorno,
                    ErroNoProcessamentoDoRetorno = arquivo.ErroNoProcessamentoDoRetorno
                }).ToList()
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\ConsultaEBaixaEmContingenciaConclusao.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
