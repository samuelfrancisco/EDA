﻿using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeBoletos.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeBoletos.ViewModels;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeBoletos.Services
{
    public class ComprovanteDePagamentoDeBoletoAppService : IComprovanteDePagamentoDeBoletoAppService
    {
        private readonly IComprovanteDePagamentoDeBoletoRepository _comprovanteDePagamentoDeBoletoRepository;

        public ComprovanteDePagamentoDeBoletoAppService(IComprovanteDePagamentoDeBoletoRepository comprovanteDePagamentoDeBoletoRepository)
        {
            _comprovanteDePagamentoDeBoletoRepository = comprovanteDePagamentoDeBoletoRepository;
        }

        public async Task<Result<ComprovanteDePagamentoDeBoletoViewModel>> ConsultarComprovanteDoPagamentoDeBoletoPeloIdDoPagamentoAsync(long empresaAplicacaoId, 
            Guid idDoPagamentoDeBoleto)
        {
            var comprovante = await _comprovanteDePagamentoDeBoletoRepository.ConsultarComprovantePeloIdDoPagamentoAsync(empresaAplicacaoId, idDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            Result result = new Result();

            if (comprovante == null)
            {
                var mensagem = $"Comprovante do pagamento de boleto {idDoPagamentoDeBoleto} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;

                return result.ToResult<ComprovanteDePagamentoDeBoletoViewModel>();
            }

            var retorno = new ComprovanteDePagamentoDeBoletoViewModel
            {
                Abatimento = comprovante.Abatimento,
                CodigoDaAgencia = comprovante.CodigoDaAgencia,
                CodigoDaColigada = comprovante.CodigoDaColigada,
                CodigoDeBarrasDoBoleto = comprovante.CodigoDeBarrasDoBoleto,
                CodigoDoBancoDestinatario = comprovante.CodigoDoBancoDestinatario,
                Data = comprovante.Data,
                DataDeVencimento = comprovante.DataDeVencimento,
                DataDoPagamento = comprovante.DataDoPagamento,
                Descontos = comprovante.Descontos,
                DocumentoDoBeneficiario = comprovante.DocumentoDoBeneficiario,
                DocumentoDoPagador = comprovante.DocumentoDoPagador,
                DocumentoDoPagadorFinal = comprovante.DocumentoDoPagadorFinal,
                DocumentoDoSacadorOuAvalista = comprovante.DocumentoDoSacadorOuAvalista,
                EmpresaAplicacaoId = comprovante.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = comprovante.EmpresaAplicacaoTransacaoId,
                Encargos = comprovante.Encargos,                
                FoiRealizadoEmContingencia = comprovante.FoiRealizadoEmContingencia,
                IdDaConsultaDeBoleto = comprovante.IdDaConsultaDeBoleto,
                IdDoBoleto = comprovante.IdDoBoleto,
                IdDoComprovanteDoPagamentoDeBoleto = comprovante.IdDoComprovanteDoPagamentoDeBoleto,
                IdDoPagamentoDeBoleto = comprovante.IdDoPagamentoDeBoleto,
                Juros = comprovante.Juros,
                LinhaDigitavelDoBoleto = comprovante.LinhaDigitavelDoBoleto,
                Multa = comprovante.Multa,
                NomeDoBancoDestinatario = comprovante.NomeDoBancoDestinatario,
                NomeFantasiaDoBeneficiario = comprovante.NomeFantasiaDoBeneficiario,
                NomeFantasiaDoPagador = comprovante.NomeFantasiaDoPagador,
                NomeFantasiaDoSacadorOuAvalista = comprovante.NomeFantasiaDoSacadorOuAvalista,
                NomeDoPagadorFinal = comprovante.NomeDoPagadorFinal,
                NumeroDaContaCorrente = comprovante.NumeroDaContaCorrente,
                RazaoSocialDoBeneficiario = comprovante.RazaoSocialDoBeneficiario,
                RazaoSocialDoPagador = comprovante.RazaoSocialDoPagador,
                RazaoSocialDoSacadorOuAvalista = comprovante.RazaoSocialDoSacadorOuAvalista,
                TipoDePagamento = comprovante.TipoDePagamento,
                TipoDeTransacao = comprovante.TipoDeTransacao,
                ValorDoPagamento = comprovante.ValorDoPagamento,
                ValorNominal = comprovante.ValorNominal,
                FoiEfetivadoOuEstornado = comprovante.FoiEfetivadoOuEstornado
            };

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(retorno);
        }
    }
}
