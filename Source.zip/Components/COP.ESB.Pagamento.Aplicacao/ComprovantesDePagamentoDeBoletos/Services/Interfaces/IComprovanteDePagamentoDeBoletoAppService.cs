﻿using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeBoletos.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeBoletos.Services.Interfaces
{
    public interface IComprovanteDePagamentoDeBoletoAppService
    {
        Task<Result<ComprovanteDePagamentoDeBoletoViewModel>> ConsultarComprovanteDoPagamentoDeBoletoPeloIdDoPagamentoAsync(long empresaAplicacaoId, Guid idDoPagamentoDeBoleto);
    }
}
