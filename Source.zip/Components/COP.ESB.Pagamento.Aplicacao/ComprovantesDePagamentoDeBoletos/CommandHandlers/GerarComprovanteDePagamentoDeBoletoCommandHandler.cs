﻿using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentosDeBoletos.CommandHandlers
{
    public class GerarComprovanteDePagamentoDeBoletoCommandHandler : CommandRequestHandler<GerarComprovanteDePagamentoDeBoletoCommand>
    {
        private readonly IComprovanteDePagamentoDeBoletoRepository _comprovanteDePagamentoDeBoletoRepository;

        public GerarComprovanteDePagamentoDeBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IComprovanteDePagamentoDeBoletoRepository comprovanteDePagamentoDeBoletoRepository)
            : base(commandHandlerRepository)
        {
            _comprovanteDePagamentoDeBoletoRepository = comprovanteDePagamentoDeBoletoRepository;
        }

        protected override async Task DoHandleAsync(GerarComprovanteDePagamentoDeBoletoCommand command, CancellationToken cancellationToken)
        {
            var comprovante = await _comprovanteDePagamentoDeBoletoRepository.ObterComprovantePeloIdDoPagamentoAsync(command.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (comprovante != null)
                return;

            comprovante = new ComprovanteDePagamentoDeBoleto(command);

            await _comprovanteDePagamentoDeBoletoRepository.SaveAsync(comprovante, command.Id).ConfigureAwait(false);
        }
    }
}
