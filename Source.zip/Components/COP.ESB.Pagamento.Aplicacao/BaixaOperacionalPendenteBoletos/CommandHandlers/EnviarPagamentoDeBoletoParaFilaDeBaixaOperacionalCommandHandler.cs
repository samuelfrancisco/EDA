﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.BaixaOperacionalPendenteBoletos.CommandHandlers
{
    public class EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommandHandler
        : CommandRequestHandler<EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand>
    {
        private readonly IBaixaOperacionalPendenteBoletoRepository _baixaOperacionalRepository;
        private readonly ICalendarioService _calendarioService;

        public EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBaixaOperacionalPendenteBoletoRepository baixaOperacionalRepository,
            ICalendarioService calendarioService)
            : base(commandHandlerRepository)
        {
            _baixaOperacionalRepository = baixaOperacionalRepository;
            _calendarioService = calendarioService;
        }

        protected override async Task DoHandleAsync(EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand command, CancellationToken cancellationToken)
        {
            var baixa = new BaixaOperacionalPendenteBoleto(command);

            await _baixaOperacionalRepository.SaveAsync(baixa).ConfigureAwait(false);
        }
    }
}
