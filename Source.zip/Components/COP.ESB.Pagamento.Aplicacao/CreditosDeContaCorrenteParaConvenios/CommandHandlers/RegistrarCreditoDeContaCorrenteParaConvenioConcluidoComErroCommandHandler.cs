﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.CreditosDeContaCorrenteParaConvenios.CommandHandlers
{
    public class RegistrarCreditoDeContaCorrenteParaConvenioConcluidoComErroCommandHandler
        : CommandRequestHandler<RegistrarCreditoDeContaCorrenteParaConvenioConcluidoComErroCommand>
    {
        private readonly ICreditoDeContaCorrenteParaConvenioRepository _creditoDeContaCorrenteParaConvenioRepository;
        public RegistrarCreditoDeContaCorrenteParaConvenioConcluidoComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ICreditoDeContaCorrenteParaConvenioRepository creditoDeContaCorrenteParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _creditoDeContaCorrenteParaConvenioRepository = creditoDeContaCorrenteParaConvenioRepository;
        }

        protected override async Task DoHandleAsync(RegistrarCreditoDeContaCorrenteParaConvenioConcluidoComErroCommand command,
            CancellationToken cancellationToken)
        {
            var credito = new CreditoDeContaCorrenteParaConvenio(command);

            await _creditoDeContaCorrenteParaConvenioRepository.SaveAsync(credito, command.Id).ConfigureAwait(false);
        }
    }
}
