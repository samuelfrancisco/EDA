﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrente.DTOs;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrente.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Enums;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.CreditosDeContaCorrenteParaConvenios.CommandHandlers
{
    public class RealizarCreditoDeContaCorrenteParaConvenioCommandHandler : CommandRequestHandler<RealizarCreditoDeContaCorrenteParaConvenioCommand>
    {
        private readonly IUnitOfWork _unityOfWork;
        private readonly ICreditoDeContaCorrenteParaConvenioRepository _creditoDeContaCorrenteParaConvenioRepository;
        private readonly IServicoDeCreditoDeContaCorrente _servicoDeCreditoDeContaCorrente;

        public RealizarCreditoDeContaCorrenteParaConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IUnitOfWork unityOfWork,
            ICreditoDeContaCorrenteParaConvenioRepository creditoDeContaCorrenteParaConvenioRepository,
            IServicoDeCreditoDeContaCorrente servicoDeCreditoDeContaCorrente)
            : base(commandHandlerRepository)
        {
            _unityOfWork = unityOfWork;
            _creditoDeContaCorrenteParaConvenioRepository = creditoDeContaCorrenteParaConvenioRepository;
            _servicoDeCreditoDeContaCorrente = servicoDeCreditoDeContaCorrente;
        }

        protected override async Task DoHandleAsync(RealizarCreditoDeContaCorrenteParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var creditosDeContaCorrenteParaConvenio = await _creditoDeContaCorrenteParaConvenioRepository
                .ObterPeloIdDoPagamentoDeConvenio(command.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (creditosDeContaCorrenteParaConvenio.Any(x => x.Status == CreditoDeContaCorrenteParaConvenioStatus.Iniciado
                || x.Status == CreditoDeContaCorrenteParaConvenioStatus.Concluido))
                throw new InvalidOperationException($"Já existe um crédito de conta corrente para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            var comandoDeInicializacao = new IniciarCreditoDeContaCorrenteParaConvenioCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CodigoDaColigada = command.CodigoDaColigada,
                CodigoDaAgencia = command.CodigoDaAgencia,
                NumeroDaContaCorrente = command.NumeroDaContaCorrente,
                DocumentoDoPagadorFinal = command.DocumentoDoPagadorFinal,
                TipoDePessoaDoPagadorFinal = command.TipoDePessoaDoPagadorFinal,
                ValorDoCredito = command.ValorDoCredito,
                DataDoCredito = command.DataDoCredito,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            var creditoDeContaCorrenteParaConvenio = new CreditoDeContaCorrenteParaConvenio(comandoDeInicializacao);

            await _creditoDeContaCorrenteParaConvenioRepository.SaveAsync(creditoDeContaCorrenteParaConvenio, comandoDeInicializacao.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);

            Result result;

            try
            {
                result = await _servicoDeCreditoDeContaCorrente.CreditarValorNaContaCorrenteAsync(new CreditoNaContaCorrenteDTO
                {
                    EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                    CodigoDaColigada = command.CodigoDaColigada,
                    CodigoDaAgencia = command.CodigoDaAgencia,
                    NumeroDaContaCorrente = command.NumeroDaContaCorrente,
                    DocumentoDoPagadorFinal = command.DocumentoDoPagadorFinal,
                    ValorDoCredito = command.ValorDoCredito,
                    DataDoCredito = command.DataDoCredito
                }).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                await RecusarCreditoAsync(command, creditoDeContaCorrenteParaConvenio, CodigosDeErro.Excecao, ex.Message).ConfigureAwait(false);

                throw ex;
            }

            if (result.IsFailure)
            {
                await RecusarCreditoAsync(command, creditoDeContaCorrenteParaConvenio, result.ErroMessage.StatusCode, result.ErroMessage.Message)
                    .ConfigureAwait(false);

                return;
            }

            await ConcluirCreditoAsync(command, creditoDeContaCorrenteParaConvenio).ConfigureAwait(false);
        }

        private async Task ConcluirCreditoAsync(RealizarCreditoDeContaCorrenteParaConvenioCommand command, CreditoDeContaCorrenteParaConvenio creditoDeContaCorrenteParaConvenio)
        {
            var comandoDeConclusao = new ConcluirCreditoDeContaCorrenteParaConvenioComSucessoCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            creditoDeContaCorrenteParaConvenio.ConcluirCreditoDeContaCorrenteParaConvenioComSucesso(comandoDeConclusao);

            await _creditoDeContaCorrenteParaConvenioRepository.SaveAsync(creditoDeContaCorrenteParaConvenio, comandoDeConclusao.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);
        }

        private async Task RecusarCreditoAsync(RealizarCreditoDeContaCorrenteParaConvenioCommand command,
            CreditoDeContaCorrenteParaConvenio creditoDeContaCorrenteParaConvenio, int codigoDeErro, string descricaoDoErro)
        {
            var comandoDeRecusa = new RecusarCreditoDeContaCorrenteParaConvenioCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            creditoDeContaCorrenteParaConvenio.RecusarCreditoDeContaCorrenteParaConvenio(comandoDeRecusa);

            await _creditoDeContaCorrenteParaConvenioRepository.SaveAsync(creditoDeContaCorrenteParaConvenio, comandoDeRecusa.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);            
        }
    }
}
