﻿namespace COP.ESB.Pagamento.Aplicacao.Shared.ViewModels
{
    public class FiltrosComPaginacaoViewModel
    {
        private const int MAXIMO_DE_REGISTROS_POR_PAGINA = 100;
        private int? _registrosPorPagina;

        /// <summary>
        /// Página atual
        /// </summary>
        public int? PaginaAtual { get; set; }

        /// <summary>
        /// Quantidade de registros por página
        /// </summary>
        public int? RegistrosPorPagina
        {
            get => _registrosPorPagina;
            set => _registrosPorPagina = value == null || value < MAXIMO_DE_REGISTROS_POR_PAGINA ? value : MAXIMO_DE_REGISTROS_POR_PAGINA;
        }
    }
}
