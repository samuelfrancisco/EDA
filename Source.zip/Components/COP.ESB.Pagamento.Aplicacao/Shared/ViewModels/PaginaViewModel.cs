﻿using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.Shared.ViewModels
{
    /// <summary>
    /// View model para retorno com paginação
    /// </summary>
    /// <typeparam name="T">Tipo dos objetos da listagem</typeparam>
    public class PaginaViewModel<T>
    {
        /// <summary>
        /// Página atual
        /// </summary>
        public int PaginaAtual { get; set; } = 1;

        /// <summary>
        /// Quantidade de registros por página
        /// </summary>
        public int? RegistrosPorPagina { get; set; }

        /// <summary>
        /// Quantidade total de registros
        /// </summary>
        public int TotalDeRegistros { get; set; }

        /// <summary>
        /// Quantidade total de páginas
        /// </summary>
        public int TotalDePaginas
        {
            get
            {
                if (!RegistrosPorPagina.HasValue || RegistrosPorPagina == 0 || TotalDeRegistros == 0)
                    return 1;

                if ((TotalDeRegistros % RegistrosPorPagina.Value) == 0)
                    return TotalDeRegistros / RegistrosPorPagina.Value;

                return (TotalDeRegistros / RegistrosPorPagina.Value) + 1;
            }
        }

        /// <summary>
        /// Registros
        /// </summary>
        public IEnumerable<T> Registros { get; set; }
    }
}
