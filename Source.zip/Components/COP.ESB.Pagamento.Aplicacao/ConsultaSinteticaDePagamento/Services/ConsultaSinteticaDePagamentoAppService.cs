﻿using COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.ViewModels;
using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using COP.ESB.Pagamento.Dominio.Boletos.DTOs;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.PagamentosSinteticos.DTOs;
using COP.ESB.Pagamento.Dominio.PagamentosSinteticos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Enums;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.Services
{
    public class ConsultaSinteticaDePagamentoAppService : IConsultaSinteticaDePagamentoAppService
    {
        private readonly IPagamentoSinteticoRepository _consultaSinteticaDePagamentoRepository;

        public ConsultaSinteticaDePagamentoAppService(IPagamentoSinteticoRepository consultaSinteticaDePagamentoRepository)
        {
            _consultaSinteticaDePagamentoRepository = consultaSinteticaDePagamentoRepository;
        }

        public async Task<Result<PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>>> ConsultaParaVisualizacaoExternaAsync(RealizarConsultaSinteticaDePagamentoViewModel filtros, 
            int paginaAtual, int registrosPorPagina)
        {
            var result = new Result();
            result.ErroMessage.StatusCode = 200;

            var filtrosDTO = ObterADTODosFiltros(filtros, paginaAtual, registrosPorPagina);

            var pagina = await _consultaSinteticaDePagamentoRepository.ConsultaAsync(filtrosDTO).ConfigureAwait(false);

            var paginaViewModel = new PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>
            {
                PaginaAtual = pagina.PaginaAtual,
                RegistrosPorPagina = pagina.RegistrosPorPagina,
                TotalDeRegistros = pagina.TotalDeRegistros,
                Registros = pagina.Registros.Select(x => ObterAViewModelDoRegistroParaVisualizacaoExterna(x)).ToList()
            };

            return result.ToResult(paginaViewModel);
        }

        public async Task<Result<PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>>> ConsultaParaVisualizacaoInternaAsync(RealizarConsultaSinteticaDePagamentoViewModel filtros,
            int? paginaAtual, int? registrosPorPagina)
        {
            var result = new Result();
            result.ErroMessage.StatusCode = 200;

            var filtrosDTO = ObterADTODosFiltros(filtros, paginaAtual, registrosPorPagina);

            var pagina = await _consultaSinteticaDePagamentoRepository.ConsultaAsync(filtrosDTO).ConfigureAwait(false);

            var paginaViewModel = new PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>
            {
                PaginaAtual = pagina.PaginaAtual,
                RegistrosPorPagina = pagina.RegistrosPorPagina,
                TotalDeRegistros = pagina.TotalDeRegistros,
                Registros = pagina.Registros.Select(x => ObterAViewModelDoRegistroParaVisualizacaoInterna(x)).ToList()
            };

            return result.ToResult(paginaViewModel);
        }

        private RealizarConsultaSinteticaDePagamentoDTO ObterADTODosFiltros(RealizarConsultaSinteticaDePagamentoViewModel filtros, int? paginaAtual, 
            int? registrosPorPagina)
        {
            var filtrosDTO = new RealizarConsultaSinteticaDePagamentoDTO();

            if (filtros != null)
            {
                if (filtros.DataDePagamentoMaximo.HasValue)
                    filtros.DataDePagamentoMaximo = filtros.DataDePagamentoMaximo.Value.Date.AddDays(1);

                if (filtros.DataDePagamentoMinimo.HasValue)
                    filtros.DataDePagamentoMinimo = filtros.DataDePagamentoMinimo.Value.Date;

                filtrosDTO = new RealizarConsultaSinteticaDePagamentoDTO
                {
                    EmpresaAplicacaoId = filtros.EmpresaAplicacaoId,
                    DataDePagamentoMaximo = filtros.DataDePagamentoMaximo,
                    DataDePagamentoMinimo = filtros.DataDePagamentoMinimo,
                    HorarioDePagamentoMaximo = filtros.HorarioDePagamentoMaximo,
                    HorarioDePagamentoMinimo = filtros.HorarioDePagamentoMinimo,
                    IdsDosTiposDePagamento = filtros.IdsDosTiposDePagamento,
                    IdDoPagamento = filtros.IdDoPagamento,
                    CodigoDeBarras = filtros.CodigoDeBarras,
                    LinhaDigitavel = filtros.LinhaDigitavel,
                    IdsDosStatusDoPagamento = filtros.IdsDosStatusDoPagamento,
                    ValorDoPagamentoMaximo = filtros.ValorDoPagamentoMaximo,
                    ValorDoPagamentoMinimo = filtros.ValorDoPagamentoMinimo,
                    CodigosDosCanaisDeProcessamento = filtros.CodigosDosCanaisDeProcessamento,
                    PaginaAtual = paginaAtual,
                    RegistrosPorPagina = registrosPorPagina
                };
            }

            return filtrosDTO;
        }

        private RetornoDaConsultaSinteticaDePagamentoViewModel ObterAViewModelDoRegistroParaVisualizacaoInterna(PagamentoSinteticoDTO registro)
        {
            var xmlDaCIP = !string.IsNullOrWhiteSpace(registro.XmlRetornadoDaCIP)
                ? RetornoDaCIPXmlDTO.FromXml(registro.XmlRetornadoDaCIP)
                : null;

            return new RetornoDaConsultaSinteticaDePagamentoViewModel
            {
                EmpresaAplicacaoId = registro.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = registro.EmpresaAplicacaoTransacaoId,
                EmpresaId = registro.EmpresaId,
                NomeDaEmpresa = registro.NomeDaEmpresa,
                AplicacaoId = registro.AplicacaoId,
                NomeDaAplicacao = registro.NomeDaAplicacao,
                IdDoPagamento = registro.IdDoPagamento,
                TipoDeTransacao = registro.TipoDeTransacao,
                TipoDePagamento = registro.TipoDePagamento,
                StatusDoPagamento = registro.StatusDoPagamento,
                CodigoDaColigada = registro.CodigoDaColigada,
                CodigoDaAgencia = registro.CodigoDaAgencia,
                NumeroDaContaCorrente = registro.NumeroDaContaCorrente,
                CodigoDoCliente = registro.CodigoDoCliente,
                DocumentoDoCliente = registro.DocumentoDoCliente,
                NomeDoCliente = registro.NomeDoCliente,
                CodigoDoSegmento = registro.CodigoDoSegmento,
                NomeDoSegmento = registro.NomeDoSegmento,
                CodigoDoConvenio = registro.CodigoDoConvenio,
                NomeDoConvenio = registro.NomeDoConvenio,
                CodigoDoCanalDeProcessamento = registro.CodigoDoCanalDeProcessamento,
                NomeDoCanalDeProcessamento = registro.NomeDoCanalDeProcessamento,
                CodigoDeBarras = registro.CodigoDeBarras,
                LinhaDigitavel = registro.LinhaDigitavel,
                DataDeVencimento = registro.DataDeVencimento,
                ValorNominal = registro.ValorNominal,
                Encargos = registro.Encargos,
                Descontos = registro.Descontos,
                ValorTotal = registro.ValorTotal,
                NomeOuRazaoSocialDoBeneficiario = xmlDaCIP?.Nom_RzSocBenfcrioOr,
                CPFOuCNPJDoBeneficiario = xmlDaCIP?.CNPJ_CPFBenfcrioOr,
                NomeOuRazaoSocialDoPagador = xmlDaCIP?.Nom_RzSocPagdr,
                CPFOuCNPJDoPagador = xmlDaCIP?.CNPJ_CPFPagdr,
                ValorDoPagamento = registro.ValorDoPagamento,
                DataDoPagamento = registro.DataDoPagamento,
                DataDoEstorno = registro.DataDoEstorno,
                DataDoUltimoEvento = registro.DataDoUltimoEvento,
                AutenticacaoDoRendimento = registro.AutenticacaoDoRendimento,
                AutenticacaoDoLiquidante = registro.AutenticacaoDoLiquidante,
                PossuiComprovante = registro.PossuiComprovante,
                PodeSerCancelado = registro.PodeSerCancelado
            };
        }

        private RetornoDaConsultaSinteticaDePagamentoViewModel ObterAViewModelDoRegistroParaVisualizacaoExterna(PagamentoSinteticoDTO registro)
        {
            var viewModel = ObterAViewModelDoRegistroParaVisualizacaoInterna(registro);

            viewModel.StatusDoPagamento = ObterStatus(registro.IdDoStatusDoPagamento);

            return viewModel;
        }

        private string ObterStatus(int status)
        {
            switch ((StatusDoPagamentoEnum)status)
            {
                case StatusDoPagamentoEnum.EmPagamento:
                case StatusDoPagamentoEnum.DebitadoPelaAplicacao:
                case StatusDoPagamentoEnum.DebitadoPeloMotor:
                case StatusDoPagamentoEnum.PendenteDeBaixaOperacional:
                case StatusDoPagamentoEnum.PendenteDeBaixaOperacionalContingencia:
                case StatusDoPagamentoEnum.PendenteDeLiquidacao:
                    return "Em Pagamento";
                case StatusDoPagamentoEnum.Efetivado:
                    return "Efetivado";
                case StatusDoPagamentoEnum.BaixaOperacionalRecusada:
                case StatusDoPagamentoEnum.LiquidacaoRecusada:
                case StatusDoPagamentoEnum.Recusado:
                    return "Recusado";
                case StatusDoPagamentoEnum.EmEstorno:
                case StatusDoPagamentoEnum.PendenteDeCancelamentoDeBaixaOperacional:
                case StatusDoPagamentoEnum.EstornoRecusado:
                    return "Em Estorno";
                case StatusDoPagamentoEnum.Estornado:
                    return "Estornado";
                default:
                    return "Em Pagamento";
            }
        }
    }
}