﻿using COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.ViewModels;
using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.Services.Interfaces
{
    public interface IConsultaSinteticaDePagamentoAppService
    {
        Task<Result<PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>>> ConsultaParaVisualizacaoExternaAsync(RealizarConsultaSinteticaDePagamentoViewModel filtros, int paginaAtual, int registrosPorPagina);
        Task<Result<PaginaViewModel<RetornoDaConsultaSinteticaDePagamentoViewModel>>> ConsultaParaVisualizacaoInternaAsync(RealizarConsultaSinteticaDePagamentoViewModel filtros, int? paginaAtual, int? registrosPorPagina);
    }
}
