﻿using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Convenios.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosSinteticos;
using COP.ESB.Pagamento.Dominio.PagamentosSinteticos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Enums;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.Denormalizers
{
    public class PagamentoSinteticoDenormalizer : PrimaryEventHandler,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEventV2>,
        IInternalAsyncEventHandler<PagamentoDeBoletoRecusadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoEfetivadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent>,
        IInternalAsyncEventHandler<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent>,
        IInternalAsyncEventHandler<CancelamentoDePagamentoDeBoletoConcluidoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeConvenioIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeConvenioIniciadoEventV2>,
        IInternalAsyncEventHandler<PagamentoDeConvenioRecusadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioMarcadoComoPendenteDeLiquidacaoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioRecusadoNaLiquidacaoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioEfetivadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioMarcadoComoEmEstornoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioMarcadoComoEstornadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioMarcadoComoEstornoRecusadoEvent>
    {
        private readonly IPagamentoSinteticoRepository _pagamentoSinteticoRepository;

        public PagamentoSinteticoDenormalizer(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IPagamentoSinteticoRepository pagamentoSinteticoRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _pagamentoSinteticoRepository = pagamentoSinteticoRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = false,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = true,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeBoleto,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Boletos,
                IdDoTipoDePagamento = (int)(@event.EBoletoDoBancoRendimento ? TipoDePagamentoEnum.BoletoRendimento : TipoDePagamentoEnum.BoletoDeOutrosBancos),
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoBoleto,
                LinhaDigitavel = @event.LinhaDigitavelDoBoleto,
                DataDeVencimento = @event.DataDeVencimento,
                ValorNominal = @event.ValorNominal,
                Encargos = @event.Encargos,
                Descontos = @event.Descontos,
                ValorTotal = @event.ValorTotal,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                FoiRealizadoEmContingencia = false,
                EBoletoSemRegistro = true,
                DataDoUltimoEvento = @event.Date
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Recusado;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = pagamentoSintetico.FoiRealizadoEmContingencia == true
                ? (int)StatusDoPagamentoEnum.PendenteDeBaixaOperacionalContingencia
                : (int)StatusDoPagamentoEnum.PendenteDeBaixaOperacional;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoEfetivadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoEfetivadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Efetivado;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.BaixaOperacionalRecusada;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EmEstorno;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EmEstorno;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EmEstorno;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EmEstorno;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.PendenteDeCancelamentoDeBaixaOperacional;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoDePagamentoDeBoletoConcluidoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoDePagamentoDeBoletoConcluidoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Estornado;            
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeConvenioIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeConvenioIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeConvenio,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Convenios,
                IdDoTipoDePagamento = int.Parse(@event.CodigoDoSegmento) + 1,
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoConvenio,
                LinhaDigitavel = @event.LinhaDigitavelDoConvenio,
                DataDeVencimento = @event.DataDeVencimentoDoConvenio,
                ValorNominal = @event.ValorOriginalDoConvenio,
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,
                DataDoUltimoEvento = @event.Date,
                CodigoDoSegmento = @event.CodigoDoSegmento,
                CodigoDoConvenio = @event.CodigoDoConvenio,
                CodigoDoCanalDeProcessamento = @event.CodigoDoCanalDeProcessamento
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeConvenioIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeConvenioIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico != null)
                return;

            pagamentoSintetico = new PagamentoSintetico
            {
                EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = @event.IdDoPagamentoDeConvenio,
                IdDoTipoDeTransacao = (int)TipoDeTransacaoEnum.Convenios,
                IdDoTipoDePagamento = int.Parse(@event.CodigoDoSegmento) + 1,
                IdDoStatusDoPagamento = (int)(@event.DebitarContaCorrente ? StatusDoPagamentoEnum.EmPagamento : StatusDoPagamentoEnum.DebitadoPelaAplicacao),
                CodigoDaColigada = @event.CodigoDaColigada,
                CodigoDaAgencia = @event.CodigoDaAgencia,
                NumeroDaContaCorrente = @event.NumeroDaContaCorrente,
                DocumentoDoCliente = @event.DocumentoDoPagadorFinal,
                CodigoDeBarras = @event.CodigoDeBarrasDoConvenio,
                LinhaDigitavel = @event.LinhaDigitavelDoConvenio,
                DataDeVencimento = @event.DataDeVencimentoDoConvenio,
                ValorNominal = @event.ValorOriginalDoConvenio,                
                ValorDoPagamento = @event.ValorDoPagamento,
                DataDoPagamento = @event.DataDoPagamento,                
                DataDoUltimoEvento = @event.Date,
                CodigoDoSegmento = @event.CodigoDoSegmento,
                CodigoDoConvenio = @event.CodigoDoConvenio,
                CodigoDoCanalDeProcessamento = @event.CodigoDoCanalDeProcessamento                
            };

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Recusado;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioMarcadoComoPendenteDeLiquidacaoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioMarcadoComoPendenteDeLiquidacaoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.PendenteDeLiquidacao;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioRecusadoNaLiquidacaoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioRecusadoNaLiquidacaoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.LiquidacaoRecusada;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioEfetivadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioEfetivadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Efetivado;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioMarcadoComoEmEstornoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioMarcadoComoEmEstornoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EmEstorno;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioMarcadoComoEstornadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioMarcadoComoEstornadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.Estornado;
            pagamentoSintetico.DataDoEstorno = @event.Date;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioMarcadoComoEstornoRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeConvenioMarcadoComoEstornoRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentoSintetico = await _pagamentoSinteticoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (pagamentoSintetico == null)
                return;

            pagamentoSintetico.IdDoStatusDoPagamento = (int)StatusDoPagamentoEnum.EstornoRecusado;
            pagamentoSintetico.DataDoUltimoEvento = @event.Date;

            await _pagamentoSinteticoRepository.SaveAsync(pagamentoSintetico).ConfigureAwait(false);
        }
    }
}
