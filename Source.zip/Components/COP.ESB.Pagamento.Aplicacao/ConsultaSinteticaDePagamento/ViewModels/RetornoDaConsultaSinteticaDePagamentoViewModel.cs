﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.ViewModels
{
    /// <summary>
    /// View model do retorno da consulta sintética de pagamentos
    /// </summary>
    public class RetornoDaConsultaSinteticaDePagamentoViewModel
    {
        /// <summary>
        /// Id da empresa X aplicação
        /// </summary>
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Id da empresa X aplicação X transação
        /// </summary>
        public long EmpresaAplicacaoTransacaoId { get; set; }

        /// <summary>
        /// Id da empresa
        /// </summary>
        public long EmpresaId { get; set; }

        /// <summary>
        /// Nome da Empresa
        /// </summary>
        public string NomeDaEmpresa { get; set; }

        /// <summary>
        /// Id da aplicação
        /// </summary>
        public long AplicacaoId { get; set; }

        /// <summary>
        /// Nome da aplicação
        /// </summary>
        public string NomeDaAplicacao { get; set; }

        /// <summary>
        /// Id do pagamento
        /// </summary>
        public Guid IdDoPagamento { get; set; }

        /// <summary>
        /// Tipo de transação
        /// </summary>
        public string TipoDeTransacao { get; set; }

        /// <summary>
        /// Tipo de pagamento
        /// </summary>
        public string TipoDePagamento { get; set; }

        /// <summary>
        /// Status do pagamento
        /// </summary>
        public string StatusDoPagamento { get; set; }

        /// <summary>
        /// Código da coligada
        /// </summary>
        public string CodigoDaColigada { get; set; }

        /// <summary>
        /// Código da agência
        /// </summary>
        public string CodigoDaAgencia { get; set; }

        /// <summary>
        /// Número da conta corrente
        /// </summary>
        public string NumeroDaContaCorrente { get; set; }

        /// <summary>
        /// Código do cliente
        /// </summary>
        public string CodigoDoCliente { get; set; }

        /// <summary>
        /// Documento do cliente
        /// </summary>
        public string DocumentoDoCliente { get; set; }

        /// <summary>
        /// Nome do cliente
        /// </summary>
        public string NomeDoCliente { get; set; }

        /// <summary>
        /// Código do segmento
        /// </summary>
        public string CodigoDoSegmento { get; set; }

        /// <summary>
        /// Nome do segmento
        /// </summary>
        public string NomeDoSegmento { get; set; }

        /// <summary>
        /// Código do convênio
        /// </summary>
        public string CodigoDoConvenio { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        public string NomeDoConvenio { get; set; }

        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        public string CodigoDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>
        public string NomeDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Código de barras
        /// </summary>
        public string CodigoDeBarras { get; set; }

        /// <summary>
        /// Linha digitável
        /// </summary>
        public string LinhaDigitavel { get; set; }

        /// <summary>
        /// Data de vencimento
        /// </summary>
        public DateTime? DataDeVencimento { get; set; }

        /// <summary>
        /// Valor nominal
        /// </summary>
        public decimal? ValorNominal { get; set; }

        /// <summary>
        /// Encargos
        /// </summary>
        public decimal? Encargos { get; set; }

        /// <summary>
        /// Descontos
        /// </summary>
        public decimal? Descontos { get; set; }

        /// <summary>
        /// Valor total
        /// </summary>
        public decimal? ValorTotal { get; set; }

        /// <summary>
        /// Nome ou Razão Social do Beneficiário
        /// </summary>
        public string NomeOuRazaoSocialDoBeneficiario { get; set; }

        /// <summary>
        /// CPF ou CNPJ do Beneficiário
        /// </summary>
        public string CPFOuCNPJDoBeneficiario { get; set; }

        /// <summary>
        /// Nome ou Razão Social do Pagador
        /// </summary>
        public string NomeOuRazaoSocialDoPagador { get; set; }

        /// <summary>
        /// CPF ou CNPJ do Pagador
        /// </summary>
        public string CPFOuCNPJDoPagador { get; set; }

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Data do pagamento
        /// </summary>
        public DateTimeOffset DataDoPagamento { get; set; }

        /// <summary>
        /// Data do estorno do pagamento
        /// </summary>
        public DateTimeOffset? DataDoEstorno { get; set; }

        /// <summary>
        /// Data do último evento ocorrido no pagamento
        /// </summary>
        public DateTimeOffset DataDoUltimoEvento { get; set; }

        /// <summary>
        /// Autenticação gerada pelo Banco Rendimento
        /// </summary>
        public Guid? AutenticacaoDoRendimento { get; set; }

        /// <summary>
        /// Autenticação gerada pelo liquidante
        /// </summary>
        public string AutenticacaoDoLiquidante { get; set; }

        /// <summary>
        /// Flag indicando de já foi geraado um comprovante do pagamento
        /// </summary>
        public bool PossuiComprovante { get; set; }

        /// <summary>
        /// Flag indicando se o pagamento pode ser cancelado ou não
        /// </summary>
        public bool PodeSerCancelado { get; set; }        
    }
}
