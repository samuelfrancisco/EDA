﻿using COP.ESB.Pagamento.Aplicacao.Shared.ViewModels;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.ViewModels
{
    /// <summary>
    /// View model do filtro da consulta sintética de pagamentos
    /// </summary>
    public class RealizarConsultaSinteticaDePagamentoViewModel
    {
        /// <summary>
        /// Id da Empresa X Aplicação
        /// </summary>
        public long? EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Ids dos Status dos pagamentos
        /// </summary>
        public IList<int> IdsDosStatusDoPagamento { get; set; } = new List<int>();

        /// <summary>
        /// Ids dos tipos dos pagamentos
        /// </summary>
        public IList<int> IdsDosTiposDePagamento { get; set; } = new List<int>();

        /// <summary>
        /// Códigos dos canais de processamento
        /// </summary>
        public IList<string> CodigosDosCanaisDeProcessamento { get; set; } = new List<string>();

        /// <summary>
        /// Valor mínimo dos pagamentos
        /// </summary>
        public decimal? ValorDoPagamentoMinimo { get; set; }

        /// <summary>
        /// Valor máximo dos pagamentos
        /// </summary>
        public decimal? ValorDoPagamentoMaximo { get; set; }

        /// <summary>
        /// Data mínima dos pagamentos
        /// </summary>
        public DateTime? DataDePagamentoMinimo { get; set; }

        /// <summary>
        /// Data máxima dos pagamentos
        /// </summary>
        public DateTime? DataDePagamentoMaximo { get; set; }

        /// <summary>
        /// Horário mínimo dos pagamentos
        /// </summary>
        public TimeSpan? HorarioDePagamentoMinimo { get; set; }

        /// <summary>
        /// Horário máximo dos pagamentos
        /// </summary>
        public TimeSpan? HorarioDePagamentoMaximo { get; set; }

        /// <summary>
        /// Id do pagamento
        /// </summary>
        public Guid? IdDoPagamento { get; set; }

        /// <summary>
        /// Código de barras do documento
        /// </summary>
        public string CodigoDeBarras { get; set; }

        /// <summary>
        /// Linha digitável do documento
        /// </summary>
        public string LinhaDigitavel { get; set; }
    }
}
