﻿using COP.ESB.Pagamento.Aplicacao.Feriados.Events;
using COP.ESB.Pagamento.Dominio.Calendarios;
using COP.ESB.Pagamento.Dominio.Calendarios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Feriados.Denormalizers
{
    public class FeriadoDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovoFeriadoRegistrado>,
        IAsyncEventHandler<InformacoesDoFeriadoAtualizadas>,
        IAsyncEventHandler<FeriadoRemovido>
    {
        private readonly IFeriadoRepository _feriadoRepository;

        public FeriadoDenormalizer(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository,
            IFeriadoRepository feriadoRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _feriadoRepository = feriadoRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoFeriadoRegistrado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovoFeriadoRegistrado @event, CancellationToken cancellationToken)
        {
            var feriado = await _feriadoRepository.ObterFeriadoPelaDataFeriadoECodPracaAsync(@event.DATAFERIADO, @event.CODPRACA).ConfigureAwait(false);

            if (feriado != null)
                return;

            feriado = new Feriado { DataFeriado = @event.DATAFERIADO, CodigoPraca = @event.CODPRACA, Descricao = @event.DESCRICAO, TipoFeriado = @event.TIPOFERIADO };

            await _feriadoRepository.SaveAsync(feriado).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<InformacoesDoFeriadoAtualizadas> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformacoesDoFeriadoAtualizadas @event, CancellationToken cancellationToken)
        {
            var feriado = await _feriadoRepository.ObterFeriadoPelaDataFeriadoECodPracaAsync(@event.DATAFERIADO, @event.CODPRACA).ConfigureAwait(false);

            if (feriado == null)
                return;

            feriado.DataFeriado = @event.DATAFERIADO;
            feriado.CodigoPraca = @event.CODPRACA;
            feriado.Active = true;

            await _feriadoRepository.SaveAsync(feriado).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<FeriadoRemovido> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(FeriadoRemovido @event, CancellationToken cancellationToken)
        {
            var feriado = await _feriadoRepository.ObterFeriadoPelaDataFeriadoECodPracaAsync(@event.DATAFERIADO, @event.CODPRACA).ConfigureAwait(false);

            if (feriado == null)
                return;

            feriado.Disable();

            await _feriadoRepository.SaveAsync(feriado).ConfigureAwait(false);
        }
    }
}
