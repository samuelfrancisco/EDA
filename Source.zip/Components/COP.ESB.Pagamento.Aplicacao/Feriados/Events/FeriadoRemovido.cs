﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Feriados.Events
{
    public class FeriadoRemovido : IntegrationEvent
    {
        public DateTime DATAFERIADO { get; set; }
        public string CODPRACA { get; set; }
    }
}
