﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoParaBoletos.CommandHandlers
{
    public class RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommandHandler
        : CommandRequestHandler<RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommand>
    {
        private readonly IConsultaDeSaldoParaBoletoRepository _consultaDeSaldoParaBoletoRepository;        

        public RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoParaBoletoRepository consultaDeSaldoParaBoletoRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoParaBoletoRepository = consultaDeSaldoParaBoletoRepository;            
        }

        protected override async Task DoHandleAsync(RegistrarConsultaDeSaldoParaBoletoConcluidaComErroCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeSaldoParaBoletoRepository.ObterConsultaDeSaldoPeloIdDoPagamentoAsync(command.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (consulta != null)
                return;            

            consulta = new ConsultaDeSaldoParaBoleto(command);

            await _consultaDeSaldoParaBoletoRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
