﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoDaContaCorrente.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoParaBoletos.CommandHandlers
{
    public class RealizarConsultaDeSaldoParaBoletoCommandHandler
        : CommandRequestHandler<RealizarConsultaDeSaldoParaBoletoCommand>
    {
        private readonly IConsultaDeSaldoParaBoletoRepository _consultaDeSaldoParaBoletoRepository;
        private readonly IServicoDeConsultaDeSaldoDaContaCorrente _servicoDeConsultaDeSaldoDaContaCorrente;

        public RealizarConsultaDeSaldoParaBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoParaBoletoRepository consultaDeSaldoParaBoletoRepository,
            IServicoDeConsultaDeSaldoDaContaCorrente servicoDeConsultaDeSaldoDaContaCorrente)
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoParaBoletoRepository = consultaDeSaldoParaBoletoRepository;
            _servicoDeConsultaDeSaldoDaContaCorrente = servicoDeConsultaDeSaldoDaContaCorrente;
        }

        protected override async Task DoHandleAsync(RealizarConsultaDeSaldoParaBoletoCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeSaldoParaBoletoRepository.ObterConsultaDeSaldoPeloIdDoPagamentoAsync(command.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (consulta != null)
                return;

            var saldoDisponivel = await _servicoDeConsultaDeSaldoDaContaCorrente
                .ObterSaldoDisponivelDaContaCorrenteAsync(command.EmpresaAplicacaoTransacaoId, command.CodigoDaColigada, command.CodigoDaAgencia, command.NumeroDaContaCorrente)
                .ConfigureAwait(false);

            consulta = new ConsultaDeSaldoParaBoleto(command, saldoDisponivel);

            await _consultaDeSaldoParaBoletoRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
