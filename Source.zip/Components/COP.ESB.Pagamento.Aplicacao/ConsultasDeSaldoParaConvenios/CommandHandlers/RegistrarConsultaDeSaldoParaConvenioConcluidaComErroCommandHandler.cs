﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoParaConvenios.CommandHandlers
{
    public class RegistrarConsultaDeSaldoParaConvenioConcluidaComErroCommandHandler
        : CommandRequestHandler<RegistrarConsultaDeSaldoParaConvenioConcluidaComErroCommand>
    {
        private readonly IConsultaDeSaldoParaConvenioRepository _consultaDeSaldoParaConvenioRepository;

        public RegistrarConsultaDeSaldoParaConvenioConcluidaComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoParaConvenioRepository consultaDeSaldoParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoParaConvenioRepository = consultaDeSaldoParaConvenioRepository;
        }

        protected override async Task DoHandleAsync(RegistrarConsultaDeSaldoParaConvenioConcluidaComErroCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeSaldoParaConvenioRepository.ObterConsultaDeSaldoPeloIdDoPagamentoAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (consulta != null)
                return;

            consulta = new ConsultaDeSaldoParaConvenio(command);

            await _consultaDeSaldoParaConvenioRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
