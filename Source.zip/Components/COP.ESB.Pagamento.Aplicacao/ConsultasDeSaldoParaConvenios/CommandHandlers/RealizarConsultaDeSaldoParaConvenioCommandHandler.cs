﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoDaContaCorrente.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoParaConvenios.CommandHandlers
{
    public class RealizarConsultaDeSaldoParaConvenioCommandHandler : CommandRequestHandler<RealizarConsultaDeSaldoParaConvenioCommand>
    {
        private readonly IConsultaDeSaldoParaConvenioRepository _consultaDeSaldoParaConvenioRepository;
        private readonly IServicoDeConsultaDeSaldoDaContaCorrente _servicoDeConsultaDeSaldoDaContaCorrente;

        public RealizarConsultaDeSaldoParaConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoParaConvenioRepository consultaDeSaldoParaConvenioRepository,
            IServicoDeConsultaDeSaldoDaContaCorrente servicoDeConsultaDeSaldoDaContaCorrente)
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoParaConvenioRepository = consultaDeSaldoParaConvenioRepository;
            _servicoDeConsultaDeSaldoDaContaCorrente = servicoDeConsultaDeSaldoDaContaCorrente;
        }

        protected override async Task DoHandleAsync(RealizarConsultaDeSaldoParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeSaldoParaConvenioRepository.ObterConsultaDeSaldoPeloIdDoPagamentoAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (consulta != null)
                return;

            var saldoDisponivel = await _servicoDeConsultaDeSaldoDaContaCorrente
                .ObterSaldoDisponivelDaContaCorrenteAsync(command.EmpresaAplicacaoTransacaoId, command.CodigoDaColigada, command.CodigoDaAgencia,
                command.NumeroDaContaCorrente).ConfigureAwait(false);

            consulta = new ConsultaDeSaldoParaConvenio(command, saldoDisponivel);

            await _consultaDeSaldoParaConvenioRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
