﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamentoAgendadas.Events;
using COP.ESB.Pagamento.Dominio.PagNet.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class OperacaoDePagamentoNoPagNetAgendadaConcluidaComErroEventHandler : EventNotificationHandler<OperacaoDePagamentoNoPagNetAgendadaConcluidaComErroEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository;

        public OperacaoDePagamentoNoPagNetAgendadaConcluidaComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository)
            : base(eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository = sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository;
        }

        protected override async Task DoHandleAsync(OperacaoDePagamentoNoPagNetAgendadaConcluidaComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.GetByIdAsync(@event.IdDoProcessoDeLiquidacaoDePagamentoDeConvenioPeloPagNet)
              .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
