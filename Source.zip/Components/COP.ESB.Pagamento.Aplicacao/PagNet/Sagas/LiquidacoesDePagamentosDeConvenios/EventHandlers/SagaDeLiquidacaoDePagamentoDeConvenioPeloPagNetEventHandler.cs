﻿using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento.Events;
using COP.ESB.Pagamento.Dominio.PagNet.Sagas.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.PagNet.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class SagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloPagNetIniciadaEvent>,
        IInternalAsyncEventHandler<OperacaoDePagamentoNoPagNetConcluidaComErroEvent>,
        IInternalAsyncEventHandler<OperacaoDePagamentoNoPagNetConcluidaComSucessoEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository;

        public SagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository = sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository;
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloPagNetIniciadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloPagNetIniciadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDeLiquidacaoDePagamentoDeConvenioPeloPagNet(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<OperacaoDePagamentoNoPagNetConcluidaComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(OperacaoDePagamentoNoPagNetConcluidaComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<OperacaoDePagamentoNoPagNetConcluidaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(OperacaoDePagamentoNoPagNetConcluidaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
