﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.ComprovantesDePagamentoDeConvenios;
using COP.ESB.Pagamento.Dominio.PagNet.ComprovantesDePagamentoDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.PagNet.ComprovantesDePagamentoDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.ComprovantesDePagamentoDeConvenios.CommandHandlers
{
    public class GerarComprovanteDePagamentoDeConvenioPeloPagNetCommandHandler : CommandRequestHandler<GerarComprovanteDePagamentoDeConvenioPeloPagNetCommand>
    {
        private readonly IComprovanteDePagamentoDeConvenioPeloPagNetRepository _comprovanteDePagamentoDeConvenioPeloPagNetRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public GerarComprovanteDePagamentoDeConvenioPeloPagNetCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IComprovanteDePagamentoDeConvenioPeloPagNetRepository comprovanteDePagamentoDeConvenioPeloPagNetRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _comprovanteDePagamentoDeConvenioPeloPagNetRepository = comprovanteDePagamentoDeConvenioPeloPagNetRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(GerarComprovanteDePagamentoDeConvenioPeloPagNetCommand command, CancellationToken cancellationToken)
        {
            var comprovante = await _comprovanteDePagamentoDeConvenioPeloPagNetRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (comprovante != null)
                throw new InvalidOperationException($"Já existe um comprovante para o pagamento {command.IdDoPagamentoDeConvenio}.");

            comprovante = ComprovanteDePagamentoDeConvenioPeloPagNet.GerarComprovanteDePagamentoDeConvenioPeloPagNet(command, _configuracoesDoMotorService);

            await _comprovanteDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(comprovante, command.Id).ConfigureAwait(false);
        }
    }
}
