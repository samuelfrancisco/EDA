﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class IniciarLiquidacaoDePagamentoDeConvenioPeloPagNetCommandHandler
        : CommandRequestHandler<IniciarLiquidacaoDePagamentoDeConvenioPeloPagNetCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloPagNetRepository _liquidacaoDePagamentoDeConvenioPeloPagNetRepository;

        public IniciarLiquidacaoDePagamentoDeConvenioPeloPagNetCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloPagNetRepository liquidacaoDePagamentoDeConvenioPeloPagNetRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloPagNetRepository = liquidacaoDePagamentoDeConvenioPeloPagNetRepository;
        }

        protected override async Task DoHandleAsync(IniciarLiquidacaoDePagamentoDeConvenioPeloPagNetCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloPagNetRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (liquidacao != null)
                throw new InvalidOperationException($"Já existe uma liquidação para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            liquidacao = LiquidacaoDePagamentoDeConvenioPeloPagNet.IniciarLiquidacaoDePagamentoDeConvenioPeloPagNet(command);

            await _liquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
