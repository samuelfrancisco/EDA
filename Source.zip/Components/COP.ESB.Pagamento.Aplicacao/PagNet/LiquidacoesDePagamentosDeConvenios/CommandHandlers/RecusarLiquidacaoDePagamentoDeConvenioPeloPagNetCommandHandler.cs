﻿using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class RecusarLiquidacaoDePagamentoDeConvenioPeloPagNetCommandHandler
        : CommandRequestHandler<RecusarLiquidacaoDePagamentoDeConvenioPeloPagNetCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloPagNetRepository _liquidacaoDePagamentoDeConvenioPeloPagNetRepository;

        public RecusarLiquidacaoDePagamentoDeConvenioPeloPagNetCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloPagNetRepository liquidacaoDePagamentoDeConvenioPeloPagNetRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloPagNetRepository = liquidacaoDePagamentoDeConvenioPeloPagNetRepository;
        }

        protected override async Task DoHandleAsync(RecusarLiquidacaoDePagamentoDeConvenioPeloPagNetCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloPagNetRepository.GetByIdAsync(command.IdDaLiquidacaoDePagamentoDeConvenioPeloPagNet)
                .ConfigureAwait(false);

            if (liquidacao == null)
                throw new InvalidOperationException($"Liquidação do pagamento de convênio {command.IdDaLiquidacaoDePagamentoDeConvenioPeloPagNet} não encontrada.");

            liquidacao.Recusar(command);

            await _liquidacaoDePagamentoDeConvenioPeloPagNetRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
