﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento.Commands;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento.DTOs;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamento.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.OperacoesDePagamento.CommandHandlers
{
    public class IniciarOperacaoDePagamentoNoPagNetCommandHandler : CommandRequestHandler<IniciarOperacaoDePagamentoNoPagNetCommand>
    {
        private readonly IUnitOfWork _unityOfWork;
        private readonly IOperacaoDePagamentoNoPagNetRepository _operacaoDePagamentoNoPagNetRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDeGeracaoDoProximoNumeroDaOperacao _servicoDeGeracaoDoProximoNumeroDaOperacao;
        private readonly IServicoDeOperacaoDePagamentoNoPagNet _servicoDeOperacaoDePagamentoNoPagNet;

        public IniciarOperacaoDePagamentoNoPagNetCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IUnitOfWork unityOfWork,
            IOperacaoDePagamentoNoPagNetRepository operacaoDePagamentoNoPagNetRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IServicoDeGeracaoDoProximoNumeroDaOperacao servicoDeGeracaoDoProximoNumeroDaOperacao,
            IServicoDeOperacaoDePagamentoNoPagNet servicoDeOperacaoDePagamentoNoPagNet)
            : base(commandHandlerRepository)
        {
            _unityOfWork = unityOfWork;
            _operacaoDePagamentoNoPagNetRepository = operacaoDePagamentoNoPagNetRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDeGeracaoDoProximoNumeroDaOperacao = servicoDeGeracaoDoProximoNumeroDaOperacao;
            _servicoDeOperacaoDePagamentoNoPagNet = servicoDeOperacaoDePagamentoNoPagNet;
        }

        protected override async Task DoHandleAsync(IniciarOperacaoDePagamentoNoPagNetCommand command, CancellationToken cancellationToken)
        {
            var operacoesExistentes = await _operacaoDePagamentoNoPagNetRepository.ObterTodasAsOperacoesPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (operacoesExistentes.Any(x => !x.FoiConcluidaComSucesso.HasValue))
                throw new InvalidOperationException($"Já existe uma operação pendente para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            if (operacoesExistentes.Any(x => x.FoiConcluidaComSucesso == true))
                throw new InvalidOperationException($"Já existe uma operação concluída com sucesso para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            var codigoDoParceiro = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Provedores?.PagNet?.CodigoDoParceiro;

            if (string.IsNullOrWhiteSpace(codigoDoParceiro))
                throw new InvalidOperationException("Não existe um código do parceiro configurado para o PagNet.");

            var dataDaOperacao = DateTime.Today;

            var numeroDaOperacao = await _servicoDeGeracaoDoProximoNumeroDaOperacao.ObterOProximoNumeroDaOperacaoAsync().ConfigureAwait(false);

            var operacao = OperacaoDePagamentoNoPagNet.IniciarOperacaoDePagamentoNoPagNet(command, codigoDoParceiro, numeroDaOperacao);

            await _operacaoDePagamentoNoPagNetRepository.SaveAsync(operacao, command.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);

            try
            {
                var result = await _servicoDeOperacaoDePagamentoNoPagNet.RealizarOperacaoDePagamentoAsync(new OperacaoDePagamentoNoPagNetDTO
                {
                    EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                    IdentificacaoDaOperacao = operacao.IdentificacaoDaOperacao
                }).ConfigureAwait(false);

                try
                {
                    if (result.IsFailure)
                    {
                        await ConcluirOperacaoComErroAsync(operacao, command, result.ErroMessage.StatusCode, result.ErroMessage.Message).ConfigureAwait(false);

                        return;
                    }

                    await ConcluirOperacaoComSucessoAsync(operacao, command, result.Value.AutenticacaoDoPagNet, result.Value.ComprovanteDoPagNet).ConfigureAwait(false);
                }
                catch (Exception)
                {
                }
            }
            catch (Exception ex)
            {
                try
                {
                    await ConcluirOperacaoComErroAsync(operacao, command, CodigosDeErro.Excecao, ex.Message).ConfigureAwait(false);
                }
                catch (Exception)
                {
                }

                throw ex;
            }
        }

        private async Task ConcluirOperacaoComSucessoAsync(OperacaoDePagamentoNoPagNet operacao, IniciarOperacaoDePagamentoNoPagNetCommand command,
            string autenticacaoDoPagNet, string comprovanteDoPagNet)
        {
            operacao.ConcluirComSucesso(new ConcluirOperacaoDePagamentoNoPagNetComSucessoCommand
            {
                IdentificacaoDaOperacao = operacao.IdentificacaoDaOperacao,
                AutenticacaoDoPagNet = autenticacaoDoPagNet,
                ComprovanteDoPagNet = comprovanteDoPagNet,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);
        }

        private async Task ConcluirOperacaoComErroAsync(OperacaoDePagamentoNoPagNet operacao, IniciarOperacaoDePagamentoNoPagNetCommand command,
            int codigoDeErro, string descricaoDoErro)
        {
            operacao.ConcluirComErro(new ConcluirOperacaoDePagamentoNoPagNetComErroCommand
            {
                IdentificacaoDaOperacao = operacao.IdentificacaoDaOperacao,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}
