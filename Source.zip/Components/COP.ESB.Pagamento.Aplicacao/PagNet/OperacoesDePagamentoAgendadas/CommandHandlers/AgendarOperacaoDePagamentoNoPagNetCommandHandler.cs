﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamentoAgendadas;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamentoAgendadas.Commands;
using COP.ESB.Pagamento.Dominio.PagNet.OperacoesDePagamentoAgendadas.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagNet.OperacoesDePagamentoAgendadas.CommandHandlers
{
    public class AgendarOperacaoDePagamentoNoPagNetCommandHandler : CommandRequestHandler<AgendarOperacaoDePagamentoNoPagNetCommand>
    {
        private readonly IOperacaoDePagamentoNoPagNetAgendadaRepository _operacaoDePagamentoNoPagNetAgendadaRepository;

        public AgendarOperacaoDePagamentoNoPagNetCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IOperacaoDePagamentoNoPagNetAgendadaRepository operacaoDePagamentoNoPagNetAgendadaRepository) 
            : base(commandHandlerRepository)
        {
            _operacaoDePagamentoNoPagNetAgendadaRepository = operacaoDePagamentoNoPagNetAgendadaRepository;
        }

        protected override async Task DoHandleAsync(AgendarOperacaoDePagamentoNoPagNetCommand command, CancellationToken cancellationToken)
        {
            var operacao = new OperacaoDePagamentoNoPagNetAgendada(command);

            await _operacaoDePagamentoNoPagNetAgendadaRepository.SaveAsync(operacao).ConfigureAwait(false);
        }
    }
}
