﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletosAgendados;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletosAgendados.Commands;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletosAgendados.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.EstornosDePagamentosDeBoletosAgendados.CommandHandlers
{
    public class AgendarEstornoDePagamentoDeBoletoCommandHandler
         : CommandRequestHandler<AgendarEstornoDePagamentoDeBoletoCommand>
    {
        private readonly IEstornoDePagamentoDeBoletoAgendadoRepository _estornoDePagamentoDeBoletoAgendadoRepository;

        public AgendarEstornoDePagamentoDeBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IEstornoDePagamentoDeBoletoAgendadoRepository estornoDePagamentoDeBoletoAgendadoRepository)
            : base(commandHandlerRepository)
        {
            _estornoDePagamentoDeBoletoAgendadoRepository = estornoDePagamentoDeBoletoAgendadoRepository;
        }

        protected override async Task DoHandleAsync(AgendarEstornoDePagamentoDeBoletoCommand command, CancellationToken cancellationToken)
        {
            var estornoDePagamentoDeBoletoAgendado = new EstornoDePagamentoDeBoletoAgendado(command);            

            await _estornoDePagamentoDeBoletoAgendadoRepository.SaveAsync(estornoDePagamentoDeBoletoAgendado).ConfigureAwait(false);
        }
    }
}
