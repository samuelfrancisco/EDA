﻿namespace COP.ESB.Pagamento.Aplicacao.AutoMapper
{
    using COP.ESB.Pagamento.Aplicacao.Configuracoes.ViewModels;
    using COP.ESB.Pagamento.Aplicacao.ConsultaSinteticaDePagamento.ViewModels;
    using COP.ESB.Pagamento.Dominio.Configuracoes.DTOs;
    using COP.ESB.Pagamento.Dominio.PagamentosSinteticos.DTOs;
    using global::AutoMapper;

    public class DomainToViewModelMappingProfile : Profile
    {

        public DomainToViewModelMappingProfile()
        {
            CreateMap<PagamentoSinteticoDTO, RetornoDaConsultaSinteticaDePagamentoViewModel>();
            CreateMap<CanalDeProcessamentoDTO, CanalDeProcessamentoViewModel>();
        }

        public override string ProfileName
        {
            get { return "DomainToViewModelMappings"; }
        }
    }
}
