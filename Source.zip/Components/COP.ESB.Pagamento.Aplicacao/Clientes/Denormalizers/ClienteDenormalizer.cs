﻿using COP.ESB.Pagamento.Aplicacao.Clientes.Events;
using COP.ESB.Pagamento.Dominio.Clientes;
using COP.ESB.Pagamento.Dominio.Clientes.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;
          
namespace COP.ESB.Pagamento.Aplicacao.Clientes.Denormalizers
{
    public class ClienteDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovoClienteRegistrado>,
        IAsyncEventHandler<InformacoesDoClienteAtualizadas>,
        IAsyncEventHandler<ClienteRemovido>
    {
        private readonly IClienteRepository _clienteRepository;

        public ClienteDenormalizer(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository,
            IClienteRepository clienteRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _clienteRepository = clienteRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoClienteRegistrado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovoClienteRegistrado @event, CancellationToken cancellationToken)
        {
            var cliente = await _clienteRepository.ObterClientePeloCodigoAsync(@event.CODCLIENTE).ConfigureAwait(false);

            if (cliente != null)
                return;

            cliente = new Cliente { CodCliente = @event.CODCLIENTE, Cgc_Cpf = @event.CGC_CPF, Nome = @event.NOME, TipoPessoa = @event.TIPOPESSOA, Status = @event.STATUS };

            await _clienteRepository.SaveAsync(cliente).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<InformacoesDoClienteAtualizadas> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformacoesDoClienteAtualizadas @event, CancellationToken cancellationToken)
        {
            var cliente = await _clienteRepository.ObterClientePeloCodigoAsync(@event.CODCLIENTE).ConfigureAwait(false);

            if (cliente == null)
                return;

            cliente.Cgc_Cpf = @event.CGC_CPF;
            cliente.Nome = @event.NOME;
            cliente.TipoPessoa = @event.TIPOPESSOA;
            cliente.Status = @event.STATUS;
            cliente.Active = true;

            await _clienteRepository.SaveAsync(cliente).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ClienteRemovido> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ClienteRemovido @event, CancellationToken cancellationToken)
        {
            var cliente = await _clienteRepository.ObterClientePeloCodigoAsync(@event.CODCLIENTE).ConfigureAwait(false);

            if (cliente == null)
                return;

            cliente.Disable();

            await _clienteRepository.SaveAsync(cliente).ConfigureAwait(false);
        }
    }
}
