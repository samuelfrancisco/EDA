﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Clientes.Events
{
    public class ClienteRemovido : IntegrationEvent
    {
        public string CODCLIENTE { get; set; }        
    }
}
