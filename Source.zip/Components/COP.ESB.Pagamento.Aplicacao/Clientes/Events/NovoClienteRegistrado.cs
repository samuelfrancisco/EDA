﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Clientes.Events
{
    public class NovoClienteRegistrado : IntegrationEvent
    {
        public string CODCLIENTE { get; set; }
        public string CGC_CPF { get; set; }
        public string SEQUENCIA { get; set; }
        public string NOME { get; set; }
        public string TIPOPESSOA { get; set; }
        public string CODCATEGORIA { get; set; }
        public string TIPOTRIBUTACAO { get; set; }
        public string CODATIVIDADE { get; set; }
        public string CODGERENTE { get; set; }
        public string STATUS { get; set; }
        public DateTime? DATACADASTRO { get; set; }
        public DateTime? DATAATUALIZACAO { get; set; }
        public string IND_FACTORING { get; set; }
        public string CLIENTEHOMEBANK { get; set; }
        public string IND_TRIBUTACPMF { get; set; }
        public DateTime? DATAVENCIMENTO { get; set; }
        public string NOMEUSUARIO { get; set; }
        public string NUMDOCUMENTO { get; set; }
        public string TIPODOCUMENTO { get; set; }
        public string ORGAOEXPEDIDOR { get; set; }
        public string UF_ORGAOEXPEDIDOR { get; set; }
        public DateTime? DATADOCUMENTO { get; set; }
        public string REGIMETRIBUTACAO { get; set; }
        public DateTime? DATARENOVACAO { get; set; }
        public string ORIGEMCADASTRO { get; set; }
        public string INDINVESTINSTIT { get; set; }
        public string INDISENTOIOF { get; set; }
        public string CODGERENTEANT { get; set; }
        public string CODFIRMA { get; set; }
        public string CODGLOBAL { get; set; }
        public string INDAUTBANK { get; set; }
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }
        public string CODCCUSTO { get; set; }
        public string CODCLASSIF_GERENCIAL { get; set; }
        public string MESCLIENTEDESDE { get; set; }
        public string ANOCLIENTEDESDE { get; set; }
        public string OBSCLIENTEDESDE { get; set; }
        public DateTime? DATADESATIVACAO { get; set; }
        public string CODAREA { get; set; }
        public string CODSETOR_ATIVIDADE { get; set; }
        public string CP_ACC { get; set; }
        public string CP_SEC { get; set; }
        public string INTRAGRUPO { get; set; }
        public DateTime? DATAATUALIZACAOGERENTE { get; set; }
        public string MOTIVOALTERACAOGERENTE { get; set; }
    }
}
