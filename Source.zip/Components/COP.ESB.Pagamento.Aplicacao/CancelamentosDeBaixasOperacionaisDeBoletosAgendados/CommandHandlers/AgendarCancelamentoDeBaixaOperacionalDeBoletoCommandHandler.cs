﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.CancelamentosDeBaixasOperacionaisDeBoletosAgendados;
using COP.ESB.Pagamento.Dominio.CancelamentosDeBaixasOperacionaisDeBoletosAgendados.Commands;
using COP.ESB.Pagamento.Dominio.CancelamentosDeBaixasOperacionaisDeBoletosAgendados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.CancelamentosDeBaixasOperacionaisDeBoletosAgendados.CommandHandlers
{
    public class AgendarCancelamentoDeBaixaOperacionalDeBoletoCommandHandler
         : CommandRequestHandler<AgendarCancelamentoDeBaixaOperacionalDeBoletoCommand>
    {
        private readonly ICancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository _cancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository;
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalBoletoRepository;

        public AgendarCancelamentoDeBaixaOperacionalDeBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ICancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository cancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalBoletoRepository)
            : base(commandHandlerRepository)
        {
            _cancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository = cancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository;
            _baixaOperacionalBoletoRepository = baixaOperacionalBoletoRepository;
        }

        protected override async Task DoHandleAsync(AgendarCancelamentoDeBaixaOperacionalDeBoletoCommand command, CancellationToken cancellationToken)
        {
            var cancelamentoDeBaixaOpreacional = new CancelamentoDeBaixaOperacionalDeBoletoAgendado(command);

            await _cancelamentoDeBaixaOperacionalDeBoletoAgendadoRepository.SaveAsync(cancelamentoDeBaixaOpreacional).ConfigureAwait(false);
        }
    }
}
