﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.DebitosDeContaCorrenteParaConvenios.CommandHandlers
{
    public class RegistrarDebitoDeContaCorrenteParaConvenioConcluidoComErroCommandHandler
        : CommandRequestHandler<RegistrarDebitoDeContaCorrenteParaConvenioConcluidoComErroCommand>
    {
        private readonly IDebitoDeContaCorrenteParaConvenioRepository _debitoDeContaCorrenteParaConvenioRepository;
        public RegistrarDebitoDeContaCorrenteParaConvenioConcluidoComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IDebitoDeContaCorrenteParaConvenioRepository debitoDeContaCorrenteParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _debitoDeContaCorrenteParaConvenioRepository = debitoDeContaCorrenteParaConvenioRepository;            
        }

        protected override async Task DoHandleAsync(RegistrarDebitoDeContaCorrenteParaConvenioConcluidoComErroCommand command,
            CancellationToken cancellationToken)
        {
            var debito = new DebitoDeContaCorrenteParaConvenio(command);

            await _debitoDeContaCorrenteParaConvenioRepository.SaveAsync(debito, command.Id).ConfigureAwait(false);
        }
    }
}
