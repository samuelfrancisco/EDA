﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrente.DTOs;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrente.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Enums;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.DebitosDeContaCorrenteParaConvenios.CommandHandlers
{
    public class RealizarDebitoDeContaCorrenteParaConvenioCommandHandle : CommandRequestHandler<RealizarDebitoDeContaCorrenteParaConvenioCommand>
    {
        private readonly IUnitOfWork _unityOfWork;
        private readonly IDebitoDeContaCorrenteParaConvenioRepository _debitoDeContaCorrenteParaConvenioRepository;
        private readonly IServicoDeDebitoDeContaCorrente _servicoDeDebitoDeContaCorrente;

        public RealizarDebitoDeContaCorrenteParaConvenioCommandHandle(ICommandHandlerRepository commandHandlerRepository,
            IUnitOfWork unityOfWork,
            IDebitoDeContaCorrenteParaConvenioRepository debitoDeContaCorrenteParaConvenioRepository,
            IServicoDeDebitoDeContaCorrente servicoDeDebitoDeContaCorrente)
            : base(commandHandlerRepository)
        {
            _unityOfWork = unityOfWork;
            _debitoDeContaCorrenteParaConvenioRepository = debitoDeContaCorrenteParaConvenioRepository;
            _servicoDeDebitoDeContaCorrente = servicoDeDebitoDeContaCorrente;
        }

        protected override async Task DoHandleAsync(RealizarDebitoDeContaCorrenteParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var debitosDeContaCorrenteParaConvenio = await _debitoDeContaCorrenteParaConvenioRepository
                .ObterPeloIdDoPagamentoDeConvenio(command.IdDoPagamentoDeConvenio).ConfigureAwait(false);

            if (debitosDeContaCorrenteParaConvenio.Any(x => x.Status == DebitoDeContaCorrenteParaConvenioStatus.Iniciado
                || x.Status == DebitoDeContaCorrenteParaConvenioStatus.Concluido))
                throw new InvalidOperationException($"Já existe um débito de conta corrente para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            var comandoDeInicializacao = new IniciarDebitoDeContaCorrenteParaConvenioCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CodigoDaColigada = command.CodigoDaColigada,
                CodigoDaAgencia = command.CodigoDaAgencia,
                NumeroDaContaCorrente = command.NumeroDaContaCorrente,
                DocumentoDoPagadorFinal = command.DocumentoDoPagadorFinal,
                TipoDePessoaDoPagadorFinal = command.TipoDePessoaDoPagadorFinal,
                ValorDoDebito = command.ValorDoDebito,
                DataDoDebito = command.DataDoDebito,
                ValidarSaldoDaContaCorrente = command.ValidarSaldoDaContaCorrente,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            var debitoDeContaCorrenteParaConvenio = new DebitoDeContaCorrenteParaConvenio(comandoDeInicializacao);

            await _debitoDeContaCorrenteParaConvenioRepository.SaveAsync(debitoDeContaCorrenteParaConvenio, comandoDeInicializacao.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);

            Result result;

            try
            {
                result = await _servicoDeDebitoDeContaCorrente.DebitarValorDaContaCorrenteAsync(new DebitoDaContaCorrenteDTO
                {
                    EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                    CodigoDaColigada = command.CodigoDaColigada,
                    CodigoDaAgencia = command.CodigoDaAgencia,
                    NumeroDaContaCorrente = command.NumeroDaContaCorrente,
                    DocumentoDoPagadorFinal = command.DocumentoDoPagadorFinal,
                    ValorDoDebito = command.ValorDoDebito,
                    DataDoDebito = command.DataDoDebito,
                    ValidarSaldoDaContaCorrente = command.ValidarSaldoDaContaCorrente
                }).ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                await RecusarDebitoAsync(command, debitoDeContaCorrenteParaConvenio, CodigosDeErro.Excecao, ex.Message)
                    .ConfigureAwait(false);

                throw ex;
            }

            if (result.IsFailure)
            {
                await RecusarDebitoAsync(command, debitoDeContaCorrenteParaConvenio, result.ErroMessage.StatusCode, result.ErroMessage.Message)
                .ConfigureAwait(false);

                return;
            }

            await ConcluirDebitoAsync(command, debitoDeContaCorrenteParaConvenio).ConfigureAwait(false);
        }

        private async Task ConcluirDebitoAsync(RealizarDebitoDeContaCorrenteParaConvenioCommand command, DebitoDeContaCorrenteParaConvenio debitoDeContaCorrenteParaConvenio)
        {
            var comandoDeConclusao = new ConcluirDebitoDeContaCorrenteParaConvenioComSucessoCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            debitoDeContaCorrenteParaConvenio.ConcluirDebitoDeContaCorrenteParaConvenioComSucesso(comandoDeConclusao);

            await _debitoDeContaCorrenteParaConvenioRepository.SaveAsync(debitoDeContaCorrenteParaConvenio, comandoDeConclusao.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);
        }

        private async Task RecusarDebitoAsync(RealizarDebitoDeContaCorrenteParaConvenioCommand command,
            DebitoDeContaCorrenteParaConvenio debitoDeContaCorrenteParaConvenio, int codigoDeErro, string descricaoDoErro)
        {
            var comandoDeRecusa = new RecusarDebitoDeContaCorrenteParaConvenioCommand
            {
                IdDoConvenio = command.IdDoConvenio,
                IdDaConsultaDeConvenio = command.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = command.IdDoPagamentoDeConvenio,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            debitoDeContaCorrenteParaConvenio.RecusarDebitoDeContaCorrenteParaConvenio(comandoDeRecusa);

            await _debitoDeContaCorrenteParaConvenioRepository.SaveAsync(debitoDeContaCorrenteParaConvenio, comandoDeRecusa.Id).ConfigureAwait(false);

            await _unityOfWork.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}
