﻿using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeConvenios.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeConvenios.Services.Interfaces
{
    public interface IComprovanteDePagamentoDeConvenioAppService
    {
        Task<Result<ComprovanteDePagamentoDeConvenioViewModel>> ConsultarComprovanteDoPagamentoDeConvenioPeloIdDoPagamentoAsync(long empresaAplicacaoId, Guid idDoPagamentoDeConvenio);
    }
}
