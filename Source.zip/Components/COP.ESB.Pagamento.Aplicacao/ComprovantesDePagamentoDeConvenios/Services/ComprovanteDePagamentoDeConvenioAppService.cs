﻿using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeConvenios.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeConvenios.ViewModels;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentoDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ComprovantesDePagamentoDeConvenios.Services
{
    public class ComprovanteDePagamentoDeConvenioAppService : IComprovanteDePagamentoDeConvenioAppService
    {
        private readonly IComprovanteDePagamentoDeConvenioRepository _comprovanteDePagamentoDeConvenioRepository;

        public ComprovanteDePagamentoDeConvenioAppService(IComprovanteDePagamentoDeConvenioRepository comprovanteDePagamentoDeConvenioRepository)
        {
            _comprovanteDePagamentoDeConvenioRepository = comprovanteDePagamentoDeConvenioRepository;
        }

        public async Task<Result<ComprovanteDePagamentoDeConvenioViewModel>> ConsultarComprovanteDoPagamentoDeConvenioPeloIdDoPagamentoAsync(long empresaAplicacaoId, 
            Guid idDoPagamentoDeConvenio)
        {
            var comprovante = await _comprovanteDePagamentoDeConvenioRepository.ConsultarComprovantePeloIdDoPagamentoAsync(empresaAplicacaoId, idDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            Result result = new Result();

            if (comprovante == null)
            {
                var mensagem = $"Comprovante do pagamento de convênio {idDoPagamentoDeConvenio} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;

                return result.ToResult<ComprovanteDePagamentoDeConvenioViewModel>();
            }

            var retorno = new ComprovanteDePagamentoDeConvenioViewModel
            {
                IdDoConvenio = comprovante.IdDoConvenio,
                IdDaConsultaDeConvenio = comprovante.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = comprovante.IdDoPagamentoDeConvenio,
                IdDoComprovanteDoPagamentoDeConvenio = comprovante.IdDoComprovanteDoPagamentoDeConvenio,
                EmpresaAplicacaoId = comprovante.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = comprovante.EmpresaAplicacaoTransacaoId,
                CodigoDaColigada = comprovante.CodigoDaColigada,
                CodigoDaAgencia = comprovante.CodigoDaAgencia,
                NumeroDaContaCorrente = comprovante.NumeroDaContaCorrente,
                DocumentoDoPagadorFinal = comprovante.DocumentoDoPagadorFinal,
                NomeDoPagadorFinal = comprovante.NomeDoPagadorFinal,
                CodigoDeBarrasDoConvenio = comprovante.CodigoDeBarrasDoConvenio,
                LinhaDigitavelDoConvenio = comprovante.LinhaDigitavelDoConvenio,
                DataDeVencimento = comprovante.DataDeVencimento,
                ValorNominal = comprovante.ValorNominal,
                DataDoPagamento = comprovante.DataDoPagamento,
                ValorDoPagamento = comprovante.ValorDoPagamento,
                CodigoDoSegmento = comprovante.CodigoDoSegmento,
                NomeDoSegmento = comprovante.NomeDoSegmento,
                CodigoDoConvenio = comprovante.CodigoDoConvenio,
                NomeDoConvenio = comprovante.NomeDoConvenio,
                CodigoDoCanalDeProcessamento = comprovante.CodigoDoCanalDeProcessamento,
                NomeDoCanalDeProcessamento = comprovante.NomeDoCanalDeProcessamento,
                Data = comprovante.Data,
                TipoDeTransacao = comprovante.TipoDeTransacao,
                TipoDePagamento = comprovante.TipoDePagamento,
                FoiEfetivadoOuEstornado = comprovante.FoiEfetivadoOuEstornado,
                ComprovanteDoLiquidante = comprovante.ComprovanteDoLiquidante
            };

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(retorno);
        }
    }
}
