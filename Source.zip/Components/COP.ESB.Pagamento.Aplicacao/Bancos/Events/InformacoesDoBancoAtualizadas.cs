﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Bancos.Events
{
    public class InformacoesDoBancoAtualizadas : IntegrationEvent
    {
        public string CODBANCO { get; set; }
        public string NOME { get; set; }
        public string NOMEFANTASIA { get; set; }
        public string CGC { get; set; }
        public string CODISPB { get; set; }
        public DateTime? DATAATUALIZACAO { get; set; }
        public string NOMEUSUARIO { get; set; }
        public DateTime? DATAINCLUSAO { get; set; }
        public string USUARIOINCLUSAO { get; set; }
        public string CODISPB_LIQ { get; set; }
        public string INDPARTICIPACOMPE { get; set; }
        public string CODBANCOINCORPORADORA { get; set; }
        public string CODBANCOREPRESENTANTE { get; set; }
        public DateTime? DATAINICOMPE { get; set; }
        public DateTime? DATAFIMCOMPE { get; set; }
        public string INDATIVOSTR { get; set; }
        public DateTime? DATAINISTR { get; set; }
        public DateTime? DATAFIMSTR { get; set; }
        public string DEBITOAUTOMATICO { get; set; }
    }
}
