﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Bancos.Events
{
    public class BancoRemovido : IntegrationEvent
    {
        public string CODBANCO { get; set; }
    }
}
