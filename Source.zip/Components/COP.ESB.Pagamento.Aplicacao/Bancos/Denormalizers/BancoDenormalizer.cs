﻿using COP.ESB.Pagamento.Aplicacao.Bancos.Events;
using COP.ESB.Pagamento.Dominio.Bancos;
using COP.ESB.Pagamento.Dominio.Bancos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Bancos.Denormalizers
{
    public class BancoDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovoBancoRegistrado>,
        IAsyncEventHandler<InformacoesDoBancoAtualizadas>,
        IAsyncEventHandler<BancoRemovido>
    {
        private readonly IBancoRepository _bancoRepository;

        public BancoDenormalizer(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository,
            IBancoRepository bancoRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _bancoRepository = bancoRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoBancoRegistrado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovoBancoRegistrado @event, CancellationToken cancellationToken)
        {
            var banco = await _bancoRepository.ObterBancoPeloCodigoAsync(@event.CODBANCO).ConfigureAwait(false);

            if (banco != null)
                return;

            banco = new Banco { CodBanco = @event.CODBANCO, CodISPB = @event.CODISPB, Nome = @event.NOME };

            await _bancoRepository.SaveAsync(banco).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<InformacoesDoBancoAtualizadas> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformacoesDoBancoAtualizadas @event, CancellationToken cancellationToken)
        {
            var banco = await _bancoRepository.ObterBancoPeloCodigoAsync(@event.CODBANCO).ConfigureAwait(false);

            if (banco == null)
                return;

            banco.CodISPB = @event.CODISPB;
            banco.Nome = @event.NOME;
            banco.Active = true;

            await _bancoRepository.SaveAsync(banco).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BancoRemovido> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(BancoRemovido @event, CancellationToken cancellationToken)
        {
            var banco = await _bancoRepository.ObterBancoPeloCodigoAsync(@event.CODBANCO).ConfigureAwait(false);

            if (banco == null)
                return;

            banco.Disable();

            await _bancoRepository.SaveAsync(banco).ConfigureAwait(false);
        }
    }
}
