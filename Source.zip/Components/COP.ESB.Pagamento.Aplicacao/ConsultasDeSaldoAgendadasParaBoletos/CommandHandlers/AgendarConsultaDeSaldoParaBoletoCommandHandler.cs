﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaBoletos;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultasDeSaldoAgendadasParaBoletos.CommandHandlers
{
    public class AgendarConsultaDeSaldoParaBoletoCommandHandler
        : CommandRequestHandler<AgendarConsultaDeSaldoParaBoletoCommand>
    {
        private readonly IConsultaDeSaldoAgendadaParaBoletoRepository _consultaDeSaldoAgendadaParaBoletoRepository;

        public AgendarConsultaDeSaldoParaBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeSaldoAgendadaParaBoletoRepository consultaDeSaldoAgendadaParaBoletoRepository) 
            : base(commandHandlerRepository)
        {
            _consultaDeSaldoAgendadaParaBoletoRepository = consultaDeSaldoAgendadaParaBoletoRepository;
        }

        protected override async Task DoHandleAsync(AgendarConsultaDeSaldoParaBoletoCommand command, CancellationToken cancellationToken)
        {
            var consultaDoSaldoAgendada = new ConsultaDeSaldoAgendadaParaBoleto(command);            

            await _consultaDeSaldoAgendadaParaBoletoRepository.SaveAsync(consultaDoSaldoAgendada).ConfigureAwait(false);            
        }
    }
}
