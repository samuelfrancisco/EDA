﻿using COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.PagamentosAnaliticos.DTOs;
using COP.ESB.Pagamento.Dominio.PagamentosAnaliticos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Enums;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.Services
{
    public class ConsultaAnaliticaDePagamentoAppService : IConsultaAnaliticaDePagamentoAppService
    {
        private readonly IPagamentoAnaliticoRepository _pagamentoAnaliticoRepository;

        public ConsultaAnaliticaDePagamentoAppService(IPagamentoAnaliticoRepository pagamentoAnaliticoRepository)
        {
            _pagamentoAnaliticoRepository = pagamentoAnaliticoRepository;
        }

        public async Task<Result<RetornoDaConsultaAnaliticaDePagamentoViewModel>> ConsultarPagamentoPeloIdParaVisualizacaoExternaAsync(long empresaAplicacaoId, 
            Guid idDoPagamento)
        {
            var pagamento = await _pagamentoAnaliticoRepository.ConsultarPagamentoPeloIdAsync(empresaAplicacaoId, idDoPagamento).ConfigureAwait(false);

            var viewModel = GerarAViewModelDoPagamentoParaVisualizacaoExterna(pagamento);

            var result = new Result();            

            if (viewModel == null)
            {
                var mensagem = $"Pagamento {idDoPagamento} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;
                return result.ToResult<RetornoDaConsultaAnaliticaDePagamentoViewModel>();
            }            

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(viewModel);
        }

        public async Task<Result<RetornoDaConsultaAnaliticaDePagamentoViewModel>> ConsultarPagamentoPeloIdParaVisualizacaoInternaAsync(long empresaAplicacaoId, 
            Guid idDoPagamento)
        {
            var pagamento = await _pagamentoAnaliticoRepository.ConsultarPagamentoPeloIdAsync(empresaAplicacaoId, idDoPagamento).ConfigureAwait(false);

            var viewModel = GerarAViewModelDoPagamentoParaVisualizacaoInterna(pagamento);

            var result = new Result();

            if (viewModel == null)
            {
                var mensagem = $"Pagamento {idDoPagamento} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;
                return result.ToResult<RetornoDaConsultaAnaliticaDePagamentoViewModel>();
            }

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(viewModel);
        }

        private RetornoDaConsultaAnaliticaDePagamentoViewModel GerarAViewModelDoPagamentoParaVisualizacaoInterna(PagamentoAnaliticoDTO pagamento)
        {
            if (pagamento == null)
                return null;

            if (((TipoDeTransacaoEnum)pagamento.IdDoTipoDeTransacao) == TipoDeTransacaoEnum.Boletos)
            {
                var viewModel = GerarAViewModelComOsDadosBasicos<RetornoDaConsultaAnaliticaDePagamentoDeBoletoViewModel>(pagamento);

                PreencherAViewModelDeBoleto(pagamento, viewModel);

                return viewModel;
            }

            if (((TipoDeTransacaoEnum)pagamento.IdDoTipoDeTransacao) == TipoDeTransacaoEnum.Convenios)
            {
                var viewModel = GerarAViewModelComOsDadosBasicos<RetornoDaConsultaAnaliticaDePagamentoDeConvenioViewModel>(pagamento);

                PreencherAViewModelDeConvenio(pagamento, viewModel);

                return viewModel;
            }

            return null;
        }        

        public T GerarAViewModelComOsDadosBasicos<T>(PagamentoAnaliticoDTO pagamento)
            where T : RetornoDaConsultaAnaliticaDePagamentoViewModel, new()
        {
            return new T
            {
                EmpresaAplicacaoId = pagamento.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                IdDoPagamento = pagamento.IdDoPagamento,
                IdentificadorDoPagamentoNoCliente = pagamento.IdentificadorDoPagamentoNoCliente,
                DocumentoDoPagadorInformadoPeloCliente = pagamento.DocumentoDoPagadorInformadoPeloCliente,
                NomeDoPagadorInformadoPeloCliente = pagamento.NomeDoPagadorInformadoPeloCliente,
                IdDoTipoDeTransacao = pagamento.IdDoTipoDeTransacao,
                TipoDeTransacao = pagamento.TipoDeTransacao,
                IdDoTipoDePagamento = pagamento.IdDoTipoDePagamento,
                TipoDePagamento = pagamento.TipoDePagamento,                
                StatusDoPagamento = pagamento.StatusDoPagamento,
                CodigoDaColigada = pagamento.CodigoDaColigada,
                CodigoDaAgencia = pagamento.CodigoDaAgencia,
                NumeroDaContaCorrente = pagamento.NumeroDaContaCorrente,
                CodigoDoCliente = pagamento.CodigoDoCliente,
                DocumentoDoCliente = pagamento.DocumentoDoCliente,
                NomeDoCliente = pagamento.NomeDoCliente,
                CodigoDeBarras = pagamento.CodigoDeBarras,
                LinhaDigitavel = pagamento.LinhaDigitavel,
                ValorNominal = pagamento.ValorNominal,
                DataDeVencimento = pagamento.DataDeVencimento,
                ValorDoPagamento = pagamento.ValorDoPagamento,
                DataDoPagamento = pagamento.DataDoPagamento,
                MotivoDaRecusaDoPagamento = pagamento.MotivoDaRecusaDoPagamento,
                DataDoUltimoEvento = pagamento.DataDoUltimoEvento
            };
        }

        private void PreencherAViewModelDeBoleto(PagamentoAnaliticoDTO pagamento, RetornoDaConsultaAnaliticaDePagamentoDeBoletoViewModel viewModel)
        {
            viewModel.Abatimento = pagamento.Abatimento;
            viewModel.Descontos = pagamento.Descontos;
            viewModel.EBoletoSemRegistro = pagamento.EBoletoSemRegistro;
            viewModel.Encargos = pagamento.Encargos;
            viewModel.FoiRealizadoEmContingencia = pagamento.FoiRealizadoEmContingencia;
            viewModel.Juros = pagamento.Juros;
            viewModel.JustificativaDoCancelamentoDoPagamento = pagamento.JustificativaDoCancelamentoDoPagamento;
            viewModel.Multa = pagamento.Multa;
            viewModel.PermitePagamentosParciais = pagamento.PermitePagamentosParciais;
            viewModel.TipoDeAutorizacaoDeRecebimentoDeValorDivergente = pagamento.TipoDeAutorizacaoDeRecebimentoDeValorDivergente;
            viewModel.TipoDeCalculo = pagamento.TipoDeCalculo;
            viewModel.ValorTotal = pagamento.ValorTotal;
            viewModel.XMLDeRespostaDaCIP = pagamento.XMLDeRespostaDaCIP;
        }

        private void PreencherAViewModelDeConvenio(PagamentoAnaliticoDTO pagamento, RetornoDaConsultaAnaliticaDePagamentoDeConvenioViewModel viewModel)
        {
            viewModel.CodigoDoSegmento = pagamento.CodigoDoSegmento;
            viewModel.NomeDoSegmento = pagamento.NomeDoSegmento;
            viewModel.CodigoDoConvenio = pagamento.CodigoDoConvenio;
            viewModel.NomeDoConvenio = pagamento.NomeDoConvenio;
            viewModel.CodigoDoCanalDeProcessamento = pagamento.CodigoDoCanalDeProcessamento;
            viewModel.NomeDoCanalDeProcessamento = pagamento.NomeDoCanalDeProcessamento;
            viewModel.TransacoesEnviadasAoCorban = pagamento.TransacoesEnviadasAoCorban
                .Select(x => new RetornoDaConsultaAnaliticaDePagamentoTransacaoCorbanViewModel
                {
                    TipoDaTransacao = x.NomeDoTipoDaTransacao,
                    StatusDaTransacao = x.NomeDoStatusDaTransacao
                })
                .ToList();
        }

        private RetornoDaConsultaAnaliticaDePagamentoViewModel GerarAViewModelDoPagamentoParaVisualizacaoExterna(PagamentoAnaliticoDTO pagamento)
        {
            var viewModel = GerarAViewModelDoPagamentoParaVisualizacaoInterna(pagamento);

            viewModel.StatusDoPagamento = ObterStatus(pagamento.IdDoStatusDoPagamento);

            return viewModel;
        }

        private string ObterStatus(int status)
        {
            switch ((StatusDoPagamentoEnum)status)
            {
                case StatusDoPagamentoEnum.EmPagamento:
                case StatusDoPagamentoEnum.DebitadoPelaAplicacao:
                case StatusDoPagamentoEnum.DebitadoPeloMotor:
                case StatusDoPagamentoEnum.PendenteDeBaixaOperacional:
                case StatusDoPagamentoEnum.PendenteDeBaixaOperacionalContingencia:
                case StatusDoPagamentoEnum.PendenteDeLiquidacao:
                    return "Em Pagamento";
                case StatusDoPagamentoEnum.Efetivado:
                    return "Efetivado";
                case StatusDoPagamentoEnum.BaixaOperacionalRecusada:
                case StatusDoPagamentoEnum.LiquidacaoRecusada:
                case StatusDoPagamentoEnum.Recusado:
                    return "Recusado";
                case StatusDoPagamentoEnum.EmEstorno:
                case StatusDoPagamentoEnum.PendenteDeCancelamentoDeBaixaOperacional:
                case StatusDoPagamentoEnum.EstornoRecusado:
                    return "Em Estorno";
                case StatusDoPagamentoEnum.Estornado:
                    return "Estornado";
                default:
                    return "Em Pagamento";
            }
        }
    }
}