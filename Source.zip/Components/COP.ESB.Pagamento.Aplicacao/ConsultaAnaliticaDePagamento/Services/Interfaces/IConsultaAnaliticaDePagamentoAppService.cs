﻿using COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.Services.Interfaces
{
    public interface IConsultaAnaliticaDePagamentoAppService
    {
        Task<Result<RetornoDaConsultaAnaliticaDePagamentoViewModel>> ConsultarPagamentoPeloIdParaVisualizacaoExternaAsync(long empresaAplicacaoId, Guid idDoPagamento);
        Task<Result<RetornoDaConsultaAnaliticaDePagamentoViewModel>> ConsultarPagamentoPeloIdParaVisualizacaoInternaAsync(long empresaAplicacaoId, Guid idDoPagamento);
    }
}
