﻿using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels
{
    /// <summary>
    /// View model do retorno da consulta analítica de pagamento de convênio
    /// </summary>
    public class RetornoDaConsultaAnaliticaDePagamentoDeConvenioViewModel : RetornoDaConsultaAnaliticaDePagamentoViewModel
    {
        /// <summary>
        /// Código do segmento
        /// </summary>
        public string CodigoDoSegmento { get; set; }

        /// <summary>
        /// Nome do segmento
        /// </summary>
        public string NomeDoSegmento { get; set; }

        /// <summary>
        /// Código do convênio
        /// </summary>
        public string CodigoDoConvenio { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        public string NomeDoConvenio { get; set; }

        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        public string CodigoDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>
        public string NomeDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Transações enviadas ao Corban
        /// </summary>
        public IEnumerable<RetornoDaConsultaAnaliticaDePagamentoTransacaoCorbanViewModel> TransacoesEnviadasAoCorban { get; set; }
    }
}
