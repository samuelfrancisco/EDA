﻿namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels
{
    /// <summary>
    /// View model do retorno da consulta analítica de pagamento de boleto
    /// </summary>
    public class RetornoDaConsultaAnaliticaDePagamentoDeBoletoViewModel : RetornoDaConsultaAnaliticaDePagamentoViewModel
    {        
        /// <summary>
        /// Multa
        /// </summary>
        public decimal? Multa { get; set; }

        /// <summary>
        /// Juros
        /// </summary>
        public decimal? Juros { get; set; }

        /// <summary>
        /// Encargos
        /// </summary>
        public decimal? Encargos { get; set; }

        /// <summary>
        /// Descontos
        /// </summary>
        public decimal? Descontos { get; set; }

        /// <summary>
        /// Abatimento
        /// </summary>
        public decimal? Abatimento { get; set; }

        /// <summary>
        /// Valor total
        /// </summary>
        public decimal? ValorTotal { get; set; }

        /// <summary>
        /// Flag indicando se são permitidos pagamentos parciais
        /// </summary>
        public bool? PermitePagamentosParciais { get; set; }

        /// <summary>
        /// Tipo de autorização de recebimento de valor divergente
        /// </summary>
        public string TipoDeAutorizacaoDeRecebimentoDeValorDivergente { get; set; }

        /// <summary>
        /// Tipo de cálculo
        /// </summary>
        public string TipoDeCalculo { get; set; }

        /// <summary>
        /// Xml retornado na colsulta do boleto na CIP
        /// </summary>
        public string XMLDeRespostaDaCIP { get; set; }

        /// <summary>
        /// Flag indicando se o pagamento do boleto foi realizado em contingência
        /// </summary>
        public bool? FoiRealizadoEmContingencia { get; set; }

        /// <summary>
        /// Flag indicando se o boleto foi tratado como um boleto sem registro na CIP
        /// </summary>
        public bool? EBoletoSemRegistro { get; set; }        

        /// <summary>
        /// Justificativa para o cancelamento do pagamento
        /// </summary>
        public string JustificativaDoCancelamentoDoPagamento { get; set; }        
    }
}
