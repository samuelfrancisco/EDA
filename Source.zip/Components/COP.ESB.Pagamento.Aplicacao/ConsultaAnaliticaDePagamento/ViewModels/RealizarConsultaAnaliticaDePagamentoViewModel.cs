﻿using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels
{
    public class RealizarConsultaAnaliticaDePagamentoViewModel
    {
        public long? EmpresaAplicacaoId { get; set; }
        public IList<int> IdsDosStatusDoPagamento { get; set; } = new List<int>();
        public IList<int> IdsDosTiposDePagamento { get; set; } = new List<int>();
        public decimal? ValorDoPagamentoMinimo { get; set; }
        public decimal? ValorDoPagamentoMaximo { get; set; }
        public DateTime? DataDePagamentoMinimo { get; set; }
        public DateTime? DataDePagamentoMaximo { get; set; }
        public Guid? IdDoPagamento { get; set; }
    }
}
