﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels
{
    /// <summary>
    /// View model do retorno da consulta analítica de pagamento
    /// </summary>
    public class RetornoDaConsultaAnaliticaDePagamentoViewModel
    {
        /// <summary>
        /// Id da Empresa X Aplicação
        /// </summary>
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Id da Empresa X Aplicação X Transação
        /// </summary>
        public long EmpresaAplicacaoTransacaoId { get; set; }

        /// <summary>
        /// Id do pagamento
        /// </summary>
        public Guid IdDoPagamento { get; set; }

        /// <summary>
        /// Identificador único do pagamento gerado pelo cliente
        /// </summary>        
        public string IdentificadorDoPagamentoNoCliente { get; set; }


        /// <summary>
        /// Documento do pagador (CPF ou CNPJ) informado pelo cliente
        /// </summary>        
        public string DocumentoDoPagadorInformadoPeloCliente { get; set; }

        /// <summary>
        /// Nome do pagador informado pelo cliente
        /// </summary>        
        public string NomeDoPagadorInformadoPeloCliente { get; set; }

        /// <summary>
        /// Id do tipo de transação
        /// </summary>
        public int IdDoTipoDeTransacao { get; set; }

        /// <summary>
        /// Tipo de transação
        /// </summary>
        public string TipoDeTransacao { get; set; }

        /// <summary>
        /// Id do tipo de pagamento
        /// </summary>
        public int IdDoTipoDePagamento { get; set; }

        /// <summary>
        /// Tipo de pagamento
        /// </summary>
        public string TipoDePagamento { get; set; }

        /// <summary>
        /// Status do pagamento
        /// </summary>
        public string StatusDoPagamento { get; set; }

        /// <summary>
        /// Código da coligada
        /// </summary>
        public string CodigoDaColigada { get; set; }

        /// <summary>
        /// Código da agência
        /// </summary>
        public string CodigoDaAgencia { get; set; }

        /// <summary>
        /// Número da conta corrente
        /// </summary>
        public string NumeroDaContaCorrente { get; set; }

        /// <summary>
        /// Código do cliente
        /// </summary>
        public string CodigoDoCliente { get; set; }

        /// <summary>
        /// Documento do cliente
        /// </summary>
        public string DocumentoDoCliente { get; set; }

        /// <summary>
        /// Nome do cliente
        /// </summary>
        public string NomeDoCliente { get; set; }        

        /// <summary>
        /// Código de barras
        /// </summary>
        public string CodigoDeBarras { get; set; }

        /// <summary>
        /// Linha digitável
        /// </summary>
        public string LinhaDigitavel { get; set; }

        /// <summary>
        /// Valor nominal
        /// </summary>
        public decimal? ValorNominal { get; set; }

        /// <summary>
        /// Data de vencimento
        /// </summary>
        public DateTime? DataDeVencimento { get; set; }        

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Data do pagamento
        /// </summary>
        public DateTimeOffset DataDoPagamento { get; set; }

        /// <summary>
        /// Motivo da recusa do pagamento
        /// </summary>
        public string MotivoDaRecusaDoPagamento { get; set; }       

        /// <summary>
        /// Data do último evento ocorrido no pagamento
        /// </summary>
        public DateTimeOffset DataDoUltimoEvento { get; set; }        
    }
}
