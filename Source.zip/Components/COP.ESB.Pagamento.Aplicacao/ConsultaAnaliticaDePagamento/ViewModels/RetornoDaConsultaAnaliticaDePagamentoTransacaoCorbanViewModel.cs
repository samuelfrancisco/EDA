﻿namespace COP.ESB.Pagamento.Aplicacao.ConsultaAnaliticaDePagamento.ViewModels
{
    /// <summary>
    /// View model da transação enviada ao Corban
    /// </summary>
    public class RetornoDaConsultaAnaliticaDePagamentoTransacaoCorbanViewModel
    {
        /// <summary>
        /// Tipo da transação
        /// </summary>
        public string TipoDaTransacao { get; set; }

        /// <summary>
        /// Status da transação
        /// </summary>
        public string StatusDaTransacao { get; set; }
    }
}
