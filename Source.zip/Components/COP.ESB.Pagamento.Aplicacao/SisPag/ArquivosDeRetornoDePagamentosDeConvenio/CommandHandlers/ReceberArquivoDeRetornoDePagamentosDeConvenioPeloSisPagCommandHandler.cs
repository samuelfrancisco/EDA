﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.Arquivos;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.DTOs;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Files.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.CommandHandlers
{
    public class ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommandHandler
        : PrimaryCommandRequestHandler<ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand>
    {
        private readonly IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
        private readonly IServicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag _servicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag;
        private readonly IServicoDePersistenciaDeArquivosDeRetornoDoSisPag _servicoDePersistenciaDeArquivosDeRetornoDoSisPag;

        public ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository,
            IServicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag servicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag,
            IServicoDePersistenciaDeArquivosDeRetornoDoSisPag servicoDePersistenciaDeArquivosDeRetornoDoSisPag)
            : base(unitOfWork, commandHandlerRepository)
        {
            _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
            _servicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag = servicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag;
            _servicoDePersistenciaDeArquivosDeRetornoDoSisPag = servicoDePersistenciaDeArquivosDeRetornoDoSisPag;
        }

        protected override async Task DoHandleAsync(ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var arquivoDeRetorno = await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository
                .ObterPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            if (arquivoDeRetorno != null)
                throw new InvalidOperationException($"O arquivo de retorno do SisPag {command.NomeDoArquivo} já foi recebido.");

            var bufferDoArquivoDeRetornoResult = await _servicoDeDownloadDeArquivoDeRetornoDePagamentosDeConvenioPeloSisPag
                .FazerDownloadDoArquivoAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            if (bufferDoArquivoDeRetornoResult.IsFailure)
            {
                await RegistrarArquivoDeRetornoRecebidoComErroAsync(command, bufferDoArquivoDeRetornoResult.ErroMessage.StatusCode,
                    bufferDoArquivoDeRetornoResult.ToString())
                    .ConfigureAwait(false);

                return;
            }

            var bufferDoArquivoDeRetorno = bufferDoArquivoDeRetornoResult.Value;

            var arquivoCnabDeConcessionariaResult = GerarArquivoCnabDeConcessionaria(bufferDoArquivoDeRetorno);

            if (arquivoCnabDeConcessionariaResult.IsFailure)
            {
                await RegistrarArquivoDeRetornoRecebidoComErroAsync(command, arquivoCnabDeConcessionariaResult.ErroMessage.StatusCode,
                    arquivoCnabDeConcessionariaResult.ToString())
                    .ConfigureAwait(false);

                return;
            }

            var arquivoCnabDeConcessionaria = arquivoCnabDeConcessionariaResult.Value;

            arquivoDeRetorno = await RegistrarArquivoDeRetornoRecebidoComSucessoAsync(command, arquivoCnabDeConcessionaria).ConfigureAwait(false);

            var persistenciaResult = await PersistirArquivoAsync(command.NomeDoArquivo, bufferDoArquivoDeRetorno).ConfigureAwait(false);

            if (persistenciaResult.IsFailure)
            {
                await MarcarArquivoDeRetornoComoPersistidoComErroAsync(arquivoDeRetorno, command, persistenciaResult.ErroMessage.StatusCode,
                    persistenciaResult.ToString())
                    .ConfigureAwait(false);

                return;
            }

            var persistencia = persistenciaResult.Value;

            await MarcarArquivoDeRetornoComoPersistidoComSucessoAsync(arquivoDeRetorno, command, persistencia).ConfigureAwait(false);
        }

        private Result<ArquivoDeConcessionaria> GerarArquivoCnabDeConcessionaria(byte[] bufferDoArquivo)
        {
            try
            {
                var conteudoDoArquivo = Encoding.ASCII.GetString(bufferDoArquivo);

                return ArquivoDeConcessionaria.From(conteudoDoArquivo);
            }
            catch (Exception ex)
            {
                var result = new Result();
                result.AddError(ex.Message, ex.Source, GetType().FullName);
                result.ErroMessage.StatusCode = CodigosDeErro.Excecao;
                result.ErroMessage.Message = $"Erro ao gerar arquivo Cnab de concessionária à partir do conteúdo recebido: {ex.Message}.";
                return result.ToResult<ArquivoDeConcessionaria>();
            }
        }

        private async Task RegistrarArquivoDeRetornoRecebidoComErroAsync(ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command,
            int codigoDeErro, string descricaoDoErro)
        {
            var comandoDeRegistroComErro = new RegistrarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComErroCommand
            {
                NomeDoArquivo = command.NomeDoArquivo,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            var arquivoDeRetorno = ArquivoDeRetornoDePagamentosDeConvenioPeloSisPag.RegistrarArquivoDeRetornoRecebidoComErro(comandoDeRegistroComErro);

            await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivoDeRetorno, comandoDeRegistroComErro.Id).ConfigureAwait(false);
        }

        private async Task<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPag> RegistrarArquivoDeRetornoRecebidoComSucessoAsync(
            ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command, ArquivoDeConcessionaria arquivoCnabDeConcessionaria)
        {
            var comandoDeRegistroComSucesso = GerarComandoDeRegistroComSucesso(command, arquivoCnabDeConcessionaria);

            var arquivoDeRetorno = ArquivoDeRetornoDePagamentosDeConvenioPeloSisPag.RegistrarArquivoDeRetornoRecebidoComSucesso(comandoDeRegistroComSucesso);

            await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivoDeRetorno, comandoDeRegistroComSucesso.Id).ConfigureAwait(false);

            await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

            return arquivoDeRetorno;
        }

        private RegistrarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComSucessoCommand GerarComandoDeRegistroComSucesso(
            ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command, ArquivoDeConcessionaria arquivoCnabDeConcessionaria)
        {
            return new RegistrarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComSucessoCommand
            {
                NomeDoArquivo = command.NomeDoArquivo,
                Pagamentos = arquivoCnabDeConcessionaria.Lotes.SelectMany(x => x.Detalhes, (x, y) => new { Lote = x, Detalhe = y })
                    .Select(x => GerarPagamentoAPartirDoDetalhe(x.Lote, x.Detalhe)).ToList(),
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };
        }

        private RegistrarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComSucessoCommandPagamento GerarPagamentoAPartirDoDetalhe(
            LoteDeConcessionaria lote, DetalheDeLoteDeConcessionaria detalhe)
        {
            var valorPago = decimal.Parse($"{detalhe.SegmentoO.ValorPago.Substring(0, detalhe.SegmentoO.ValorPago.Length - 2)}," +
                $"{detalhe.SegmentoO.ValorPago.Substring(detalhe.SegmentoO.ValorPago.Length - 2)}", new CultureInfo("pt-BR"));

            return new RegistrarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComSucessoCommandPagamento
            {
                SeuNumero = detalhe.SegmentoO.SeuNumero,
                ValorPago = valorPago,
                NossoNumero = detalhe.SegmentoO.NossoNumero,
                OcorrenciasDoLote = lote.Header.Ocorrencias,
                Ocorrencias = detalhe.SegmentoO.Ocorrencias,
                Autenticacao = detalhe.SegmentoZ?.Autenticacao
            };
        }

        private async Task<Result<PersistenciaDoArquivoDeRetornoDoSisPagDTO>> PersistirArquivoAsync(string nomeDoArquivo, byte[] conteudo)
        {
            try
            {
                var retorno = await _servicoDePersistenciaDeArquivosDeRetornoDoSisPag.PersistirArquivoDeRetornoAsync(nomeDoArquivo, conteudo)
                    .ConfigureAwait(false);

                return new Result<PersistenciaDoArquivoDeRetornoDoSisPagDTO>(retorno);
            }
            catch (Exception ex)
            {
                var result = new Result();
                result.AddError(ex.Message, ex.Source, GetType().FullName);
                result.ErroMessage.StatusCode = CodigosDeErro.Excecao;
                result.ErroMessage.Message = $"Erro ao persistir arquivo de retorno do SisPag: {ex.Message}";

                return result.ToResult<PersistenciaDoArquivoDeRetornoDoSisPagDTO>();
            }
        }

        private async Task MarcarArquivoDeRetornoComoPersistidoComErroAsync(ArquivoDeRetornoDePagamentosDeConvenioPeloSisPag arquivoDeRetorno,
            ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command, int codigoDeErro, string descricaoDoErro)
        {
            var comandoDeMarcacaoDePersistenciaComErro = new MarcarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagComoPersistidoComErroCommand
            {
                NomeDoArquivo = command.NomeDoArquivo,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            arquivoDeRetorno.MarcarComoPersistidoComErro(comandoDeMarcacaoDePersistenciaComErro);

            await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivoDeRetorno, comandoDeMarcacaoDePersistenciaComErro.Id)
                .ConfigureAwait(false);
        }

        private async Task MarcarArquivoDeRetornoComoPersistidoComSucessoAsync(ArquivoDeRetornoDePagamentosDeConvenioPeloSisPag arquivoDeRetorno,
            ReceberArquivoDeRetornoDePagamentosDeConvenioPeloSisPagCommand command, PersistenciaDoArquivoDeRetornoDoSisPagDTO persistencia)
        {
            var comandoDeMarcacaoDePersistenciaComSucesso = new MarcarArquivoDeRetornoDePagamentosDeConvenioPeloSisPagComoPersistidoComSucessoCommand
            {
                NomeDoArquivo = command.NomeDoArquivo,
                NomeCompletoDoArquivo = persistencia.NomeCompletoDoArquivo,
                TipoDePersistencia = persistencia.TipoDePersistencia,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            arquivoDeRetorno.MarcarComoPersistidoComSucesso(comandoDeMarcacaoDePersistenciaComSucesso);

            await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivoDeRetorno, comandoDeMarcacaoDePersistenciaComSucesso.Id)
                .ConfigureAwait(false);
        }
    }
}
