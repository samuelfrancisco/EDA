﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class RecusarTodasAsLiquidacoesDePagamentoDeConvenioPeloSisPagDoArquivoCommandHandler
        : CommandRequestHandler<RecusarTodasAsLiquidacoesDePagamentoDeConvenioPeloSisPagDoArquivoCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public RecusarTodasAsLiquidacoesDePagamentoDeConvenioPeloSisPagDoArquivoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository) 
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(RecusarTodasAsLiquidacoesDePagamentoDeConvenioPeloSisPagDoArquivoCommand command, CancellationToken cancellationToken)
        {
            var liquidacoes = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository
                .ObterTodasAsLiquidacoesDoArquivoAsync(command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            foreach (var liquidacao in liquidacoes)
            {
                await RecusarLiquidacaoAsync(liquidacao, command).ConfigureAwait(false);
            }
        }

        private async Task RecusarLiquidacaoAsync(LiquidacaoDePagamentoDeConvenioPeloSisPag liquidacao, 
            RecusarTodasAsLiquidacoesDePagamentoDeConvenioPeloSisPagDoArquivoCommand command)
        {
            var comandoIndividual = new RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand
            {
                IdDoConvenio = liquidacao.IdDoConvenio,
                IdDaConsultaDeConvenio = liquidacao.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = liquidacao.IdDoPagamentoDeConvenio,
                IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag = liquidacao.Id,
                EmpresaAplicacaoTransacaoId = liquidacao.EmpresaAplicacaoTransacaoId,
                CodigoDeErro = command.CodigoDeErro,
                DescricaoDoErro = command.DescricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            liquidacao.Recusar(comandoIndividual);

            await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(liquidacao, comandoIndividual.Id).ConfigureAwait(false);
        }
    }
}
