﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class RecusarAsLiquidacoesDosPagamentosDeConvenioRecusadosPeloSisPagCommandHandler
        : CommandRequestHandler<RecusarAsLiquidacoesDosPagamentosDeConvenioRecusadosPeloSisPagCommand>
    {
        private readonly IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
        private readonly IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public RecusarAsLiquidacoesDosPagamentosDeConvenioRecusadosPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository,
            IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
            _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(RecusarAsLiquidacoesDosPagamentosDeConvenioRecusadosPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var arquivoDeRetorno = await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.ObterPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var arquivoDeRemessa = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.ObterPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var liquidacoes = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository
                .ObterTodasAsLiquidacoesDoArquivoPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var liquidacoesRecusadas = (from liquidacao in liquidacoes
                                        from pagamentoEnviado in arquivoDeRemessa.PagamentosEnviados
                                        from pagamentoRecusado in arquivoDeRetorno.PagamentosRecusados
                                        where liquidacao.Id == pagamentoEnviado.IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag
                                        && pagamentoEnviado.SeuNumero == pagamentoRecusado.SeuNumero
                                        select new { Liquidacao = liquidacao, PagamentoRecusado = pagamentoRecusado })
                                        .ToList();

            foreach (var liquidacaoRecusada in liquidacoesRecusadas)
            {
                var liquidacao = liquidacaoRecusada.Liquidacao;

                var codigoDeErro = CodigosDeErro.OcorrenciasDoSisPag;

                var descricaoDoErro = liquidacaoRecusada.PagamentoRecusado.ObterADescricaoConsolidadaDasOcorrencias();

                await RecusarLiquidacaoAsync(liquidacao, command, codigoDeErro, descricaoDoErro).ConfigureAwait(false);
            }
        }

        private async Task RecusarLiquidacaoAsync(LiquidacaoDePagamentoDeConvenioPeloSisPag liquidacao,
            RecusarAsLiquidacoesDosPagamentosDeConvenioRecusadosPeloSisPagCommand command, int codigoDeErro, string descricaoDoErro)
        {
            var comandoIndividual = new RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand
            {
                IdDoConvenio = liquidacao.IdDoConvenio,
                IdDaConsultaDeConvenio = liquidacao.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = liquidacao.IdDoPagamentoDeConvenio,
                IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag = liquidacao.Id,
                EmpresaAplicacaoTransacaoId = liquidacao.EmpresaAplicacaoTransacaoId,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            liquidacao.Recusar(comandoIndividual);

            await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(liquidacao, comandoIndividual.Id).ConfigureAwait(false);
        }
    }
}
