﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class ConcluirAsLiquidacoesDosPagamentosDeConvenioEfetuadosPeloSisPagCommandHandler 
        : CommandRequestHandler<ConcluirAsLiquidacoesDosPagamentosDeConvenioEfetuadosPeloSisPagCommand>
    {
        private readonly IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
        private readonly IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public ConcluirAsLiquidacoesDosPagamentosDeConvenioEfetuadosPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository,
            IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository;
            _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(ConcluirAsLiquidacoesDosPagamentosDeConvenioEfetuadosPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var arquivoDeRetorno = await _arquivoDeRetornoDePagamentosDeConvenioPeloSisPagRepository.ObterPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var arquivoDeRemessa = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.ObterPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var liquidacoes = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository
                .ObterTodasAsLiquidacoesDoArquivoPeloNomeAsync(command.NomeDoArquivo)
                .ConfigureAwait(false);

            var liquidacoesAprovadas = (from liquidacao in liquidacoes
                                        from pagamentoEnviado in arquivoDeRemessa.PagamentosEnviados
                                        from pagamentoEfetuado in arquivoDeRetorno.PagamentosEfetuados
                                        where liquidacao.Id == pagamentoEnviado.IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag
                                        && pagamentoEnviado.SeuNumero == pagamentoEfetuado.SeuNumero
                                        select new { Liquidacao = liquidacao, PagamentoEfetuado = pagamentoEfetuado })
                                        .ToList();

            foreach (var liquidacaoAprovada in liquidacoesAprovadas)
            {
                var liquidacao = liquidacaoAprovada.Liquidacao;

                var autenticacao = liquidacaoAprovada.PagamentoEfetuado.Autenticacao;

                await ConcluirLiquidacaoAsync(liquidacao, command, autenticacao).ConfigureAwait(false);
            }
        }

        private async Task ConcluirLiquidacaoAsync(LiquidacaoDePagamentoDeConvenioPeloSisPag liquidacao,
            ConcluirAsLiquidacoesDosPagamentosDeConvenioEfetuadosPeloSisPagCommand command, string autenticacao)
        {
            var comandoIndividual = new ConcluirLiquidacaoDePagamentoDeConvenioPeloSisPagCommand
            {
                IdDoConvenio = liquidacao.IdDoConvenio,
                IdDaConsultaDeConvenio = liquidacao.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = liquidacao.IdDoPagamentoDeConvenio,
                IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag = liquidacao.Id,
                EmpresaAplicacaoTransacaoId = liquidacao.EmpresaAplicacaoTransacaoId,
                AutenticacaoDoSisPag = autenticacao,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            liquidacao.Concluir(comandoIndividual);

            await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(liquidacao, comandoIndividual.Id).ConfigureAwait(false);
        }
    }
}