﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class IniciarLiquidacaoDePagamentoDeConvenioPeloSisPagCommandHandler
        : CommandRequestHandler<IniciarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public IniciarLiquidacaoDePagamentoDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(IniciarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (liquidacao != null)
                throw new InvalidOperationException($"Já existe uma liquidação para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            liquidacao = LiquidacaoDePagamentoDeConvenioPeloSisPag.IniciarLiquidacaoDePagamentoDeConvenioPeloSisPag(command);

            await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
