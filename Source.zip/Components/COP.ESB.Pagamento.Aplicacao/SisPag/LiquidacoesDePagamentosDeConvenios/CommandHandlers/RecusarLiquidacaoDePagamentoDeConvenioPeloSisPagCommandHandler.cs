﻿using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommandHandler
        : CommandRequestHandler<RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(RecusarLiquidacaoDePagamentoDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.GetByIdAsync(command.IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (liquidacao == null)
                throw new InvalidOperationException($"Liquidação do pagamento de convênio {command.IdDaLiquidacaoDePagamentoDeConvenioPeloSisPag} não encontrada.");

            liquidacao.Recusar(command);

            await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
