﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ComprovantesDePagamentoDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.ComprovantesDePagamentoDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.ComprovantesDePagamentoDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.ComprovantesDePagamentoDeConvenios.CommandHandlers
{
    public class GerarComprovanteDePagamentoDeConvenioPeloSisPagCommandHandler : CommandRequestHandler<GerarComprovanteDePagamentoDeConvenioPeloSisPagCommand>
    {
        private readonly IComprovanteDePagamentoDeConvenioPeloSisPagRepository _comprovanteDePagamentoDeConvenioPeloSisPagRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public GerarComprovanteDePagamentoDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IComprovanteDePagamentoDeConvenioPeloSisPagRepository comprovanteDePagamentoDeConvenioPeloSisPagRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _comprovanteDePagamentoDeConvenioPeloSisPagRepository = comprovanteDePagamentoDeConvenioPeloSisPagRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(GerarComprovanteDePagamentoDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var comprovante = await _comprovanteDePagamentoDeConvenioPeloSisPagRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (comprovante != null)
                throw new InvalidOperationException($"Já existe um comprovante para o pagamento {command.IdDoPagamentoDeConvenio}.");

            comprovante = ComprovanteDePagamentoDeConvenioPeloSisPag.GerarComprovanteDePagamentoDeConvenioPeloSisPag(command, _configuracoesDoMotorService);

            await _comprovanteDePagamentoDeConvenioPeloSisPagRepository.SaveAsync(comprovante, command.Id).ConfigureAwait(false);
        }
    }
}
