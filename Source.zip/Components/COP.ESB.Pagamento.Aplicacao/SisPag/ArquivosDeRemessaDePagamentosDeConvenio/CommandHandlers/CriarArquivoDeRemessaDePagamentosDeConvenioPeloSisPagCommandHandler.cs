﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.CommandHandlers
{
    public class CriarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler 
        : CommandRequestHandler<CriarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand>
    {
        private readonly IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;        

        public CriarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;            
        }

        protected override async Task DoHandleAsync(CriarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var arquivo = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository
                .ObterPeloIdDoProcessoAsync(command.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (arquivo != null)
                throw new InvalidOperationException($"Já existe um arquivo de remessa para o processo {command.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag}.");

            var pagamentos = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.ObterOsPagamentosPendentesAsync(command.DataDeProcessamento)
                .ConfigureAwait(false);

            var ultimoSequencialDePagamentoRegistrado = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.ObterOUltimoSequencialRegistradoAsync()
                .ConfigureAwait(false);

            arquivo = ArquivoDeRemessaDePagamentosDeConvenioPeloSisPag.CriarArquivoDeRemessaDePagamentosDeConvenioPeloSisPag(command, pagamentos,
                ultimoSequencialDePagamentoRegistrado);

            await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivo, command.Id).ConfigureAwait(false);
        }
    }
}
