﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.Arquivos;
using COP.ESB.Pagamento.Dominio.SisPag.Arquivos.DTOs;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.DTOs;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Files.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.CommandHandlers
{
    public class PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler
        : CommandRequestHandler<PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand>
    {
        private readonly IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IServicoDePersistenciaDeArquivosDeRemessaDoSisPag _servicoDePersistenciaDeArquivosDeRemessaDoSisPag;

        public PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IServicoDePersistenciaDeArquivosDeRemessaDoSisPag servicoDePersistenciaDeArquivosDeRemessaDoSisPag)
            : base(commandHandlerRepository)
        {
            _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _servicoDePersistenciaDeArquivosDeRemessaDoSisPag = servicoDePersistenciaDeArquivosDeRemessaDoSisPag;
        }

        protected override async Task DoHandleAsync(PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var arquivo = await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository
                .GetByIdAsync(command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (arquivo == null)
                throw new InvalidOperationException($"Arquivo de remessa {command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag} não encontrado.");

            var configuracoesDoSisPag = _configuracoesDoMotorService?.ConfiguracoesDoMotor?.Provedores?.SisPag;

            if (configuracoesDoSisPag == null)
                throw new InvalidOperationException("Não foram encontradas as configurações do provedor SisPag.");

            Result<ArquivoDeConcessionaria> arquivoCnabResult;

            try
            {
                arquivoCnabResult = GerarArquivoCnabDeConcessionaria(arquivo, configuracoesDoSisPag);
            }
            catch (Exception ex)
            {
                await MarcarArquivoComErroAoPersistir(arquivo, command, CodigosDeErro.Excecao, ex.Message);

                return;
            }

            if (arquivoCnabResult.IsFailure)
            {
                await MarcarArquivoComErroAoPersistir(arquivo, command, CodigosDeErro.RegraDeNegocioNaoAtendida, arquivoCnabResult.ToString());

                return;
            }

            PersistenciaDoArquivoDeRemessaDoSisPagDTO retorno;

            try
            {
                var arquivoCnab = arquivoCnabResult.Value;

                var conteudoDoArquivo = Encoding.ASCII.GetBytes(arquivoCnab.ToString());

                retorno = await _servicoDePersistenciaDeArquivosDeRemessaDoSisPag.PersistirArquivoDeRemessaAsync(arquivo.NomeDoArquivo, conteudoDoArquivo).ConfigureAwait(false);                
            }
            catch (Exception ex)
            {
                await MarcarArquivoComErroAoPersistir(arquivo, command, CodigosDeErro.Excecao, ex.Message);

                return;
            }

            await MarcarArquivoComoPersistidoComSucesso(arquivo, command, retorno);
        }

        private Result<ArquivoDeConcessionaria> GerarArquivoCnabDeConcessionaria(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPag arquivo,
            ConfiguracoesDoSisPag configuracoesDoSisPag)
        {
            var arquivoDTO = new ArquivoDeConcessionariaDTO
            {
                TipoDeInscricaoDaEmpresa = configuracoesDoSisPag.TipoDeInscricaoDaEmpresa,
                NumeroDaInscricaoDaEmpresa = configuracoesDoSisPag.NumeroDaInscricaoDaEmpresa,
                Agencia = configuracoesDoSisPag.Agencia,
                Conta = configuracoesDoSisPag.Conta,
                DAC = configuracoesDoSisPag.DAC,
                NomeDaEmpresa = configuracoesDoSisPag.NomeDaEmpresa,
                NomeDoBanco = configuracoesDoSisPag.NomeDoBanco,
                DataDeGeracao = DateTime.Now,
                FinalidadeDoLote = configuracoesDoSisPag.FinalidadeDoLote,
                HistoricoDeContaCorrente = configuracoesDoSisPag.HistoricoDeContaCorrente,
                EnderecoDaEmpresa = configuracoesDoSisPag.EnderecoDaEmpresa,
                Numero = configuracoesDoSisPag.Numero,
                Complemento = configuracoesDoSisPag.Complemento,
                Cidade = configuracoesDoSisPag.Cidade,
                CEP = configuracoesDoSisPag.CEP,
                Estado = configuracoesDoSisPag.Estado,
                Pagamentos = arquivo.PagamentosEnviados.Select(x => GerarDTODoPagamento(x)).ToList()
            };

            return ArquivoDeConcessionaria.From(arquivoDTO);
        }

        private ArquivoDeConcessionariaPagamentoDTO GerarDTODoPagamento(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagPagamento pagamento)
        {
            return new ArquivoDeConcessionariaPagamentoDTO
            {
                CodigoDeBarras = pagamento.CodigoDeBarrasDoConvenio,
                CodigoDoSegmento = pagamento.CodigoDoSegmento,
                CodigoDoConvenio = pagamento.CodigoDoConvenio,
                NomeDaConcessionaria = pagamento.NomeDoConvenio,
                DataDeVencimento = pagamento.DataDeVencimentoDoConvenio,
                ValorAPagar = pagamento.ValorDoPagamento,
                DataDoPagamento = pagamento.DataDoPagamento.DateTime,
                SeuNumero = pagamento.SeuNumero
            };
        }

        private async Task MarcarArquivoComoPersistidoComSucesso(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPag arquivo,
            PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, PersistenciaDoArquivoDeRemessaDoSisPagDTO retorno)
        {
            var successCommand = new MarcarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComoPersistidoComSucessoCommand
            {                
                IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag,
                NomeCompletoDoArquivo = retorno.NomeCompletoDoArquivo,
                TipoDePersistencia = retorno.TipoDePersistencia,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            arquivo.MarcarComoPersistidoComSucesso(successCommand);

            await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivo, successCommand.Id).ConfigureAwait(false);
        }

        private async Task MarcarArquivoComErroAoPersistir(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPag arquivo,
            PersistirArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, int codigoDeErro, string descricaoDoErro)
        {
            var exceptionCommand = new MarcarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroAoPersistirCommand
            {                
                IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            arquivo.MarcarComErroAoPersistir(exceptionCommand);

            await _arquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(arquivo, exceptionCommand.Id).ConfigureAwait(false);
        }
    }
}
