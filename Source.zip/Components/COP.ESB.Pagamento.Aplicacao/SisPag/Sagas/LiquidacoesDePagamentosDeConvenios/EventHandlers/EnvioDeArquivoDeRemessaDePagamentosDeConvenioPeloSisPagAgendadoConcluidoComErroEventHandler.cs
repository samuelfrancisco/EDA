﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessaAgendados.Events;
using COP.ESB.Pagamento.Dominio.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoConcluidoComErroEventHandler
        : EventNotificationHandler<EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoConcluidoComErroEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;

        public EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoConcluidoComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository) 
            : base(eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository = sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoConcluidoComErroEvent @event, 
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.GetByIdAsync(@event.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
