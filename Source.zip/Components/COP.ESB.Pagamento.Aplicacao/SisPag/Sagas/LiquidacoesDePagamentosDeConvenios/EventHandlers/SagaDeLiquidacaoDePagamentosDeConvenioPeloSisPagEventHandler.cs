﻿using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRemessaDePagamentosDeConvenio.Events;
using COP.ESB.Pagamento.Dominio.SisPag.ArquivosDeRetornoDePagamentosDeConvenio.Events;
using COP.ESB.Pagamento.Dominio.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class SagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCriadoEvent>,
        IInternalAsyncEventHandler<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent>,
        IInternalAsyncEventHandler<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagMarcadoComErroAoPersistirEvent>,
        IInternalAsyncEventHandler<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComErroEvent>,
        IInternalAsyncEventHandler<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent>,
        IInternalAsyncEventHandler<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComErroEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;

        public SagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository = sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCriadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCriadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.GetByIdAsync(@event.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.GetByIdAsync(@event.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagMarcadoComErroAoPersistirEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRemessaDePagamentosDeConvenioPeloSisPagMarcadoComErroAoPersistirEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.GetByIdAsync(@event.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagRecebidoComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.ObterProcessoPeloNomeDoArquivoDeRemessaAsync(@event.NomeDoArquivo)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.ObterProcessoPeloNomeDoArquivoDeRemessaAsync(@event.NomeDoArquivo)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ArquivoDeRetornoDePagamentosDeConvenioPeloSisPagPersistidoComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.ObterProcessoPeloNomeDoArquivoDeRemessaAsync(@event.NomeDoArquivo)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de liquidação de pagamentos pelo SisPag não encontrado.");

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
