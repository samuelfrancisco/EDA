﻿using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.HorarioDeProcessamento.Events;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class HorarioDeProcessamentoDoSisPagAtingidoEventHandler : PrimaryEventNotificationHandler<HorarioDeProcessamentoDoSisPagAtingidoEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;
        private readonly ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository _liquidacaoDePagamentoDeConvenioPeloSisPagRepository;

        public HorarioDeProcessamentoDoSisPagAtingidoEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository,
            ILiquidacaoDePagamentoDeConvenioPeloSisPagRepository liquidacaoDePagamentoDeConvenioPeloSisPagRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository = sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository;
            _liquidacaoDePagamentoDeConvenioPeloSisPagRepository = liquidacaoDePagamentoDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(HorarioDeProcessamentoDoSisPagAtingidoEvent @event, CancellationToken cancellationToken)
        {
            var existemLiquidacoesPendentes = await _liquidacaoDePagamentoDeConvenioPeloSisPagRepository.ExistemLiquidacoesPendentesAsync(@event.Data)
                .ConfigureAwait(false);

            if (!existemLiquidacoesPendentes)
                return;

            var saga = new SagaDeLiquidacaoDePagamentosDeConvenioPeloSisPag(@event);

            await _sagaDeLiquidacaoDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
