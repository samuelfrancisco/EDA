﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Enums;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.EnviosDeArquivoDeRemessa.CommandHandlers
{
    public class EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler : CommandRequestHandler<EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
        private readonly IServicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag _servicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag;

        public EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IUnitOfWork unitOfWork,
            IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository,
            IServicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag servicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag) 
            : base(commandHandlerRepository)
        {
            _unitOfWork = unitOfWork;
            _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
            _servicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = servicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag;
        }

        protected override async Task DoHandleAsync(EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var envios = await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository
                .ObterPeloIdDoArquivoAsync(command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (envios.Any(x => x.Status == EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagStatus.Iniciado
             || (x.Status == EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagStatus.Concluido && x.FoiConcluidoComSucesso == true)))
                throw new InvalidOperationException($"Já existe um envio para o arquivo de remessa do SisPag {command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag}.");

            var comandoDeInicio = new IniciarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand
            {
                IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag,
                IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag = command.IdDoProcessoDeLiquidacaoDePagamentosDeConvenioPeloSisPag,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            var envio = EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag.Iniciar(comandoDeInicio);

            await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(envio, comandoDeInicio.Id).ConfigureAwait(false);

            try
            {
                await _servicoDeEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag
                    .EnviarArquivoDeRemessaAsync(command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag)
                    .ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                await ConcluirEnvioComErroAsync(envio, command, CodigosDeErro.Excecao, ex.Message).ConfigureAwait(false);

                throw ex;
            }

            await ConcluirEnvioComSucessoAsync(envio, command).ConfigureAwait(false);
        }

        private async Task ConcluirEnvioComErroAsync(EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag envio, 
            EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, int codigoDeErro, string descricaoDoErro)
        {
            var comandoDeConclusaoComErro = new ConcluirEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroCommand
            {
                IdDoEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = envio.Id,
                CodigoDeErro = codigoDeErro,
                DescricaoDoErro = descricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            envio.ConcluirComErro(comandoDeConclusaoComErro);

            await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(envio, comandoDeConclusaoComErro.Id).ConfigureAwait(false);
        }

        private async Task ConcluirEnvioComSucessoAsync(EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag envio, 
            EnviarArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command)
        {
            var comandoDeConclusaoComSucesso = new ConcluirEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComSucessoCommand
            {
                IdDoEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag = envio.Id,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            envio.ConcluirComSucesso(comandoDeConclusaoComSucesso);

            await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(envio, comandoDeConclusaoComSucesso.Id).ConfigureAwait(false);
        }
    }
}
