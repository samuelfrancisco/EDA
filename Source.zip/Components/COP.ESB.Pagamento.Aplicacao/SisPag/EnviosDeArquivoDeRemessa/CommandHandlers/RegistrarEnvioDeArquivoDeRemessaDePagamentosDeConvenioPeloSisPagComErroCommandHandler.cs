﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Enums;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessa.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.EnviosDeArquivoDeRemessa.CommandHandlers
{
    public class RegistrarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroCommandHandler
        : CommandRequestHandler<RegistrarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroCommand>
    {
        private readonly IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;

        public RegistrarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository)
            : base(commandHandlerRepository)
        {
            _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository = envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository;
        }

        protected override async Task DoHandleAsync(RegistrarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagComErroCommand command, CancellationToken cancellationToken)
        {
            var envios = await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository
                .ObterPeloIdDoArquivoAsync(command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag)
                .ConfigureAwait(false);

            if (envios.Any(x => x.Status == EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagStatus.Iniciado
             || (x.Status == EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagStatus.Concluido && x.FoiConcluidoComSucesso == true)))
                throw new InvalidOperationException($"Já existe um envio para o arquivo de remessa do SisPag {command.IdDoArquivoDeRemessaDePagamentosDeConvenioPeloSisPag}.");

            var envio = EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPag.RegistrarEnvioComErro(command);

            await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagRepository.SaveAsync(envio, command.Id).ConfigureAwait(false);
        }
    }
}
