﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessaAgendados;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessaAgendados.Commands;
using COP.ESB.Pagamento.Dominio.SisPag.EnviosDeArquivoDeRemessaAgendados.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.SisPag.EnviosDeArquivoDeRemessaAgendados.CommandHandlers
{
    public class AgendarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler
        : CommandRequestHandler<AgendarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand>
    {
        private readonly IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository;

        public AgendarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository) 
            : base(commandHandlerRepository)
        {
            _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository = envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository;
        }

        protected override async Task DoHandleAsync(AgendarEnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagCommand command, CancellationToken cancellationToken)
        {
            var envioAgendado = new EnvioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendado(command);

            await _envioDeArquivoDeRemessaDePagamentosDeConvenioPeloSisPagAgendadoRepository.SaveAsync(envioAgendado).ConfigureAwait(false);
        }
    }
}
