﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.RetornoDeArquivosDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.EventHandlers
{
    public class ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEventHandler
        : PrimaryEventNotificationHandler<ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent>
    {
        private readonly ISagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository = sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(ArquivoDeRetornoDeBaixaOperacionalDeBoletosPagosEmContingenciaRecebidoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.ObterASagaPeloNomeDoArquivoDaBaixaOperacionalAsync(@event.NomeDoArquivoOriginal)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
