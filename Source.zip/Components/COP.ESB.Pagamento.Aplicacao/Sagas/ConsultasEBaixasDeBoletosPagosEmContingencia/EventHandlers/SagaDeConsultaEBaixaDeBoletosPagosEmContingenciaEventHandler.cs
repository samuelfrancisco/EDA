﻿using COP.ESB.Pagamento.Aplicacao.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.ConsultasDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia;
using COP.ESB.Pagamento.Dominio.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.ConsultasEBaixasDeBoletosPagosEmContingencia.EventHandlers
{
    public class SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<ContingenciaDeBoletosDesligadaEvent>,
        IInternalAsyncEventHandler<ConsultaDeBoletosPagosEmContingenciaCanceladaEvent>,
        IInternalAsyncEventHandler<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>,
        IInternalAsyncEventHandler<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent>,
        IInternalAsyncEventHandler<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent>,
        IInternalAsyncEventHandler<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent>,
        IInternalAsyncEventHandler<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>,
        IInternalAsyncEventHandler<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent>,
        IInternalAsyncEventHandler<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent>
    {
        private readonly ISagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public SagaDeConsultaEBaixaDeBoletosPagosEmContingenciaEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository = sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        public Task HandleAsync(IEventEnvelop<ContingenciaDeBoletosDesligadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }        

        private async Task DoHandleAsync(ContingenciaDeBoletosDesligadaEvent @event, CancellationToken cancellationToken)
        {
            if ((_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.AConsultaDePagamentosEmContingenciaDeveSerAutomatica == false
                || string.IsNullOrWhiteSpace(_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeEnvioDeConsultaEmContingencia)
                || string.IsNullOrWhiteSpace(_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeRetornoDeConsultaEmContingencia))
                && (_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.ABaixaOperacionalEmContingenciaDeveSerAutomatica == false
                || string.IsNullOrWhiteSpace(_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeEnvioDeBaixaOperacionalEmContingencia)
                || string.IsNullOrWhiteSpace(_configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.LocalParaArquivosDeRetornoDeBaixaOperacionalEmContingencia)))
                return;

            var saga = new SagaDeConsultaEBaixaDeBoletosPagosEmContingencia(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeBoletosPagosEmContingenciaCanceladaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ConsultaDeBoletosPagosEmContingenciaCanceladaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }        

        public Task HandleAsync(IEventEnvelop<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(RetornoDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ErroDeArquivoDeConsultaDeBoletosPagosEmContingenciaProcessadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeBoletosPagosEmContingenciaConcluidaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ConsultaDeBoletosPagosEmContingenciaConcluidaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.GetByIdAsync(@event.IdDoProcessoDeConsultaEBaixa)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _configuracoesDoMotorService);

            await _sagaDeConsultaEBaixaDeBoletosPagosEmContingenciaRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}