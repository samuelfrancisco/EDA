﻿using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoAgendadasParaConvenios.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaConvenios.Events;
using COP.ESB.Pagamento.Dominio.Convenios.Events;
using COP.ESB.Pagamento.Dominio.Convenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.ComprovantesDePagamentoDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteParaConvenios.Events;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteParaConvenios.Events;
using COP.ESB.Pagamento.Dominio.PagNet.ComprovantesDePagamentoDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.PagNet.LiquidacoesDePagamentosDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.SisPag.ComprovantesDePagamentoDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.SisPag.LiquidacoesDePagamentosDeConvenios.Events;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.PagamentosDeConvenios.EventHandlers
{
    public class SagaDePagamentoDeConvenioEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<NovoPagamentoDeConvenioIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeConvenioIniciadoEventV2>,
        IInternalAsyncEventHandler<ValorDoSaldoDisponivelDoCorbanReservadoParaPagamentoDeConvenioEvent>,
        IInternalAsyncEventHandler<ReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioRecusadaEvent>,
        IInternalAsyncEventHandler<ConsultaDeSaldoParaConvenioRealizadaComSucessoEvent>,
        IInternalAsyncEventHandler<SaldoDisponivelDaContaCorrenteValidadoParaConvenioEvent>,
        IInternalAsyncEventHandler<DebitoDeContaCorrenteParaConvenioConcluidoComSucessoEvent>,
        IInternalAsyncEventHandler<DebitoDeContaCorrenteParaConvenioRecusadoEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloCorbanConcluidaComSucessoEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloPagNetConcluidaComSucessoEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloSisPagConcluidaComSucessoEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloCorbanRecusadaEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloPagNetRecusadaEvent>,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloSisPagRecusadaEvent>,
        IInternalAsyncEventHandler<ComprovanteDePagamentoDeConvenioPeloCorbanGeradoEvent>,
        IInternalAsyncEventHandler<ComprovanteDePagamentoDeConvenioPeloPagNetGeradoEvent>,
        IInternalAsyncEventHandler<ComprovanteDePagamentoDeConvenioPeloSisPagGeradoEvent>,
        IInternalAsyncEventHandler<CreditoDeContaCorrenteParaConvenioConcluidoComSucessoEvent>,
        IInternalAsyncEventHandler<CreditoDeContaCorrenteParaConvenioRecusadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeConvenioRecusadoEvent>
    {
        private readonly ISagaDePagamentoDeConvenioRepository _sagaDePagamentoDeConvenioRepository;
        private readonly IConvenioRepository _convenioRepository;

        public SagaDePagamentoDeConvenioEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDePagamentoDeConvenioRepository sagaDePagamentoDeConvenioRepository,
            IConvenioRepository convenioRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDePagamentoDeConvenioRepository = sagaDePagamentoDeConvenioRepository;
            _convenioRepository = convenioRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeConvenioIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeConvenioIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeConvenio(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeConvenioIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeConvenioIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeConvenio(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ValorDoSaldoDisponivelDoCorbanReservadoParaPagamentoDeConvenioEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ValorDoSaldoDisponivelDoCorbanReservadoParaPagamentoDeConvenioEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeSaldoParaConvenioRealizadaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDeSaldoParaConvenioRealizadaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeSaldoAgendadaParaConvenioConcluidaComErroEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDeSaldoAgendadaParaConvenioConcluidaComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<SaldoDisponivelDaContaCorrenteValidadoParaConvenioEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(SaldoDisponivelDaContaCorrenteValidadoParaConvenioEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<DebitoDeContaCorrenteParaConvenioConcluidoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(DebitoDeContaCorrenteParaConvenioConcluidoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<DebitoDeContaCorrenteParaConvenioRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(DebitoDeContaCorrenteParaConvenioRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloCorbanConcluidaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloCorbanConcluidaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloPagNetConcluidaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloPagNetConcluidaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloSisPagConcluidaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloSisPagConcluidaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloCorbanRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloCorbanRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloPagNetRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloPagNetRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloSisPagRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloSisPagRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ComprovanteDePagamentoDeConvenioPeloCorbanGeradoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ComprovanteDePagamentoDeConvenioPeloCorbanGeradoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ComprovanteDePagamentoDeConvenioPeloPagNetGeradoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ComprovanteDePagamentoDeConvenioPeloPagNetGeradoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ComprovanteDePagamentoDeConvenioPeloSisPagGeradoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ComprovanteDePagamentoDeConvenioPeloSisPagGeradoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CreditoDeContaCorrenteParaConvenioConcluidoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(CreditoDeContaCorrenteParaConvenioConcluidoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CreditoDeContaCorrenteParaConvenioRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(CreditoDeContaCorrenteParaConvenioRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeConvenioRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeConvenioRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }        
    }
}
