﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteAgendadosParaConvenios.Events;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.PagamentosDeConvenios.EventHandlers
{
    public class CreditoDeContaCorrenteAgendadoParaConvenioConcluidoComErroEventHandler
        : EventNotificationHandler<CreditoDeContaCorrenteAgendadoParaConvenioConcluidoComErroEvent>
    {
        private readonly ISagaDePagamentoDeConvenioRepository _sagaDePagamentoDeConvenioRepository;

        public CreditoDeContaCorrenteAgendadoParaConvenioConcluidoComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDePagamentoDeConvenioRepository sagaDePagamentoDeConvenioRepository)
            : base(eventHandlerRepository)
        {
            _sagaDePagamentoDeConvenioRepository = sagaDePagamentoDeConvenioRepository;
        }

        protected override async Task DoHandleAsync(CreditoDeContaCorrenteAgendadoParaConvenioConcluidoComErroEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeConvenioRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
              .ConfigureAwait(false);

            if (saga == null)
                throw new InvalidOperationException($"Processo de pagamento não encontrado.");

            saga.Handle(@event);

            await _sagaDePagamentoDeConvenioRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
