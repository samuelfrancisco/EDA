﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.EstornosDePagamentosDeBoletos.Events;
using COP.ESB.Pagamento.Dominio.Sagas.CancelamentosDePagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.Sagas.CancelamentosDePagamentosDeBoletos.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.CancelamentosDePagamentosDeBoletos.EventHandlers
{
    public class SagaDeCancelamentoDePagamentoDeBoletoEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent>,
        IInternalAsyncEventHandler<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent>,
        IInternalAsyncEventHandler<EstornoDePagamentoDeBoletoRealizadoComSucessoEvent>,
        IInternalAsyncEventHandler<EstornoDePagamentoDeBoletoRecusadoEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalBoletoEstornadaEvent>
    {
        private readonly ISagaDeCancelamentoDePagamentoDeBoletoRepository _sagaDeCancelamentoDePagamentoDeBoletoRepository;
        private readonly IBaixaOperacionalBoletoRepository _baixaOperacionalBoletoRepository;

        public SagaDeCancelamentoDePagamentoDeBoletoEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeCancelamentoDePagamentoDeBoletoRepository sagaDeCancelamentoDePagamentoDeBoletoRepository,
            IBaixaOperacionalBoletoRepository baixaOperacionalBoletoRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeCancelamentoDePagamentoDeBoletoRepository = sagaDeCancelamentoDePagamentoDeBoletoRepository;
            _baixaOperacionalBoletoRepository = baixaOperacionalBoletoRepository;
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;           

            saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            var baixaOperacional = await _baixaOperacionalBoletoRepository.ObterPorCodigoDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            @event.NumIdentcBaixaOperac = baixaOperacional?.NumIdentcBaixaOperac;

            saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;           

            saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            var baixaOperacional = await _baixaOperacionalBoletoRepository.ObterPorCodigoDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            @event.NumIdentcBaixaOperac = baixaOperacional?.NumIdentcBaixaOperac;

            saga = new SagaDeCancelamentoDePagamentoDeBoleto(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<EstornoDePagamentoDeBoletoRealizadoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(EstornoDePagamentoDeBoletoRealizadoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<EstornoDePagamentoDeBoletoRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(EstornoDePagamentoDeBoletoRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalBoletoEstornadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(BaixaOperacionalBoletoEstornadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeCancelamentoDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeCancelamentoDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
