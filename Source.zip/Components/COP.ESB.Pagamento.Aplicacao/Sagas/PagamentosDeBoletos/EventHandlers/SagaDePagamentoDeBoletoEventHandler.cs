﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Events;
using COP.ESB.Pagamento.Dominio.ConsultasDeSaldoParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.PagamentosDeBoletos.EventHandlers
{
    public class SagaDePagamentoDeBoletoEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoIniciadoEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEvent>,
        IInternalAsyncEventHandler<NovoPagamentoDeBoletoSemRegistroIniciadoEventV2>,
        IInternalAsyncEventHandler<PagamentoDeBoletoRecusadoEvent>,
        IInternalAsyncEventHandler<ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent>,
        IInternalAsyncEventHandler<SaldoDisponivelDaContaCorrenteValidadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeTituloParaBoletoRealizadoComSucessoEvent>,
        IInternalAsyncEventHandler<PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2>,
        IInternalAsyncEventHandler<PagamentoDeTituloParaBoletoRecusadoEvent>,
        IInternalAsyncEventHandler<PagamentoDeTituloParaBoletoRecusadoEventV2>,
        IInternalAsyncEventHandler<ComprovanteDePagamentoDeBoletoGeradoEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalBoletoRealizadaComSucessoEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalBoletoRecusadaEvent>,
        IInternalAsyncEventHandler<BaixaOperacionalBoletoRejeitadaEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent>,
        IInternalAsyncEventHandler<PagamentoDeBoletoEfetivadoEvent>
    {
        private readonly ISagaDePagamentoDeBoletoRepository _sagaDePagamentoDeBoletoRepository;

        public SagaDePagamentoDeBoletoEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDePagamentoDeBoletoRepository sagaDePagamentoDeBoletoRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDePagamentoDeBoletoRepository = sagaDePagamentoDeBoletoRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent> envelop,
            CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent @event,
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2> envelop,
            CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2 @event,
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent envelop, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(envelop.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(envelop);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, envelop.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2 envelop, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(envelop.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(envelop);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, envelop.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent envelop, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(envelop.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(envelop);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, envelop.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2 envelop, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(envelop.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(envelop);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, envelop.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<NovoPagamentoDeBoletoSemRegistroIniciadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(NovoPagamentoDeBoletoSemRegistroIniciadoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDePagamentoDeBoleto(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDeSaldoParaBoletoRealizadaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<SaldoDisponivelDaContaCorrenteValidadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(SaldoDisponivelDaContaCorrenteValidadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeTituloParaBoletoRealizadoComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeTituloParaBoletoRealizadoComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeTituloParaBoletoRealizadoComSucessoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeTituloParaBoletoRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeTituloParaBoletoRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeTituloParaBoletoRecusadoEventV2> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeTituloParaBoletoRecusadoEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ComprovanteDePagamentoDeBoletoGeradoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ComprovanteDePagamentoDeBoletoGeradoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalBoletoRealizadaComSucessoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(BaixaOperacionalBoletoRealizadaComSucessoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalBoletoRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(BaixaOperacionalBoletoRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<BaixaOperacionalBoletoRejeitadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(BaixaOperacionalBoletoRejeitadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto).ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoDeBoletoEfetivadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(PagamentoDeBoletoEfetivadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }        
    }
}
