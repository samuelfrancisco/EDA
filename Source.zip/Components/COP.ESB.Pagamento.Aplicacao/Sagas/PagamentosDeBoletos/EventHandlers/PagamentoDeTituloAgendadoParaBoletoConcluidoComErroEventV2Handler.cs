﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos.Events;
using COP.ESB.Pagamento.Dominio.Sagas.PagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Sagas.PagamentosDeBoletos.EventHandlers
{
    public class PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2Handler : EventNotificationHandler<PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2>
    {
        private readonly ISagaDePagamentoDeBoletoRepository _sagaDePagamentoDeBoletoRepository;

        public PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2Handler(IEventHandlerRepository eventHandlerRepository,
            ISagaDePagamentoDeBoletoRepository sagaDePagamentoDeBoletoRepository)
            : base(eventHandlerRepository)
        {
            _sagaDePagamentoDeBoletoRepository = sagaDePagamentoDeBoletoRepository;
        }

        protected override async Task DoHandleAsync(PagamentoDeTituloAgendadoParaBoletoConcluidoComErroEventV2 @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDePagamentoDeBoletoRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            saga.Handle(@event);

            await _sagaDePagamentoDeBoletoRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
