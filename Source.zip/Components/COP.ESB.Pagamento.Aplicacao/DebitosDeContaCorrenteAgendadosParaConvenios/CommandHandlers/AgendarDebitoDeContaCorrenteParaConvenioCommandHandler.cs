﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteAgendadosParaConvenios;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteAgendadosParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrenteAgendadosParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.DebitosDeContaCorrenteAgendadosParaConvenios.CommandHandlers
{
    public class AgendarDebitoDeContaCorrenteParaConvenioCommandHandler : CommandRequestHandler<AgendarDebitoDeContaCorrenteParaConvenioCommand>
    {
        private readonly IDebitoDeContaCorrenteAgendadoParaConvenioRepository _debitoDeContaCorrenteAgendadoParaConvenioRepository;

        public AgendarDebitoDeContaCorrenteParaConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IDebitoDeContaCorrenteAgendadoParaConvenioRepository debitoDeContaCorrenteAgendadoParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _debitoDeContaCorrenteAgendadoParaConvenioRepository = debitoDeContaCorrenteAgendadoParaConvenioRepository;
        }

        protected override async Task DoHandleAsync(AgendarDebitoDeContaCorrenteParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var debitoDeContaCorrenteAgendado = new DebitoDeContaCorrenteAgendadoParaConvenio(command);

            await _debitoDeContaCorrenteAgendadoParaConvenioRepository.SaveAsync(debitoDeContaCorrenteAgendado).ConfigureAwait(false);
        }
    }
}
