﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloAgendadosParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagamentosDeTituloAgendadosParaBoletos.CommandHandlers
{
    public class AgendarPagamentoDeTituloParaBoletoCommandHandler
        : CommandRequestHandler<AgendarPagamentoDeTituloParaBoletoCommandV2>
    {
        private readonly IPagamentoDeTituloAgendadoParaBoletoRepository _pagamentoDeTituloAgendadoParaBoletoRepository;

        public AgendarPagamentoDeTituloParaBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IPagamentoDeTituloAgendadoParaBoletoRepository pagamentoDeTituloAgendadoParaBoletoRepository) 
            : base(commandHandlerRepository)
        {
            _pagamentoDeTituloAgendadoParaBoletoRepository = pagamentoDeTituloAgendadoParaBoletoRepository;
        }

        protected override async Task DoHandleAsync(AgendarPagamentoDeTituloParaBoletoCommandV2 command, CancellationToken cancellationToken)
        {
            var pagamentoDeTituloAgendado = new PagamentoDeTituloAgendadoParaBoleto(command);            

            await _pagamentoDeTituloAgendadoParaBoletoRepository.SaveAsync(pagamentoDeTituloAgendado).ConfigureAwait(false);
        }
    }
}
