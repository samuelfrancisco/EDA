﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Commands;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.CommandHandlers
{
    public class ConfigurarNovaRotinaDoRoboCommandHandler : PrimaryCommandRequestHandler<ConfigurarNovaRotinaDoRoboCommand, Result>
    {
        private readonly IParametroDaRotinaDoRoboRepository _parametroDaRotinaDoRoboRepository;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public ConfigurarNovaRotinaDoRoboCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IParametroDaRotinaDoRoboRepository parametroDaRotinaDoRoboRepository,
            IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails)
            : base(unitOfWork, commandHandlerRepository)
        {
            _parametroDaRotinaDoRoboRepository = parametroDaRotinaDoRoboRepository;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(ConfigurarNovaRotinaDoRoboCommand command, CancellationToken cancellationToken)
        {
            var rotinas = await _parametroDaRotinaDoRoboRepository.FiltrarPorNomeAsync(command.NomeDaRotina).ConfigureAwait(false);

            if(rotinas.Any())
            {
                var result = new Result();
                result.AddError("Nome inválido.", "Já existe uma rotina com o mesmo nome.", GetType().FullName);
                result.ErroMessage.StatusCode = 400;
                result.ErroMessage.Message = "Nome inválido: já existe uma rotina com o mesmo nome.";
                return result;
            }

            var criacaoResult = ParametroDaRotinaDoRobo.ConfigurarNovaRotinaDoRobo(command, _servicoDeValidacaoDeEmails);

            if (criacaoResult.IsSuccess)
                await _parametroDaRotinaDoRoboRepository.SaveAsync(criacaoResult.Value, command.Id).ConfigureAwait(false);

            return criacaoResult;
        }
    }
}
