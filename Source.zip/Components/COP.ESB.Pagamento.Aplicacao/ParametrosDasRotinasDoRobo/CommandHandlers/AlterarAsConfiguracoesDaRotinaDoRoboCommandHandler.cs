﻿using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Mail.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Commands;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.CommandHandlers
{
    public class AlterarAsConfiguracoesDaRotinaDoRoboCommandHandler
        : PrimaryCommandRequestHandler<AlterarAsConfiguracoesDaRotinaDoRoboCommand, Result>
    {
        private readonly IParametroDaRotinaDoRoboRepository _parametroDaRotinaDoRoboRepository;
        private readonly IServicoDeValidacaoDeEmails _servicoDeValidacaoDeEmails;

        public AlterarAsConfiguracoesDaRotinaDoRoboCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IParametroDaRotinaDoRoboRepository parametroDaRotinaDoRoboRepository,
            IServicoDeValidacaoDeEmails servicoDeValidacaoDeEmails)
            : base(unitOfWork, commandHandlerRepository)
        {
            _parametroDaRotinaDoRoboRepository = parametroDaRotinaDoRoboRepository;
            _servicoDeValidacaoDeEmails = servicoDeValidacaoDeEmails;
        }

        protected override async Task<Result> DoHandleAsync(AlterarAsConfiguracoesDaRotinaDoRoboCommand command, CancellationToken cancellationToken)
        {
            var rotinaDoRobo = await _parametroDaRotinaDoRoboRepository.GetByIdAsync(command.IdDaRotina).ConfigureAwait(false);

            Result result;

            if (rotinaDoRobo == null)
            {
                result = new Result();
                result.AddError($"Rotina {command.IdDaRotina} não encontrada.",
                    $"Rotina {command.IdDaRotina} não encontrada.",
                    GetType().FullName);
                result.ErroMessage.Message = $"Rotina {command.IdDaRotina} não encontrada.";
                result.ErroMessage.StatusCode = 404;
                return result;
            }

            result = rotinaDoRobo.AlterarAsConfiguracoesDaRotinaDoRobo(command, _servicoDeValidacaoDeEmails);

            if (result.IsSuccess)
                await _parametroDaRotinaDoRoboRepository.SaveAsync(rotinaDoRobo, command.Id).ConfigureAwait(false);

            return result;
        }
    }
}
