﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Events
{
    public class ParametrosDasRotinasDoRoboAlterados : IntegrationEvent
    {
        public Guid ParametrosDasRotinasDoRoboId { get; set; }
        public string NomeDaRotina { get; set; }
        public string ExpressaoCron { get; set; }
        public int? QuantidadeTotalDeTentativas { get; set; }
        public TimeSpan? HorarioDeInicio { get; set; }
        public TimeSpan? HorarioDeTermino { get; set; }
        public string Action { get; set; }
        public string Email { get; set; }
    }
}
