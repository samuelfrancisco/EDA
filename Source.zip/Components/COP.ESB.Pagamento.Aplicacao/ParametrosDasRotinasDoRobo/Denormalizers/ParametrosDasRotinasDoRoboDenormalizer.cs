﻿using COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Denormalizers
{
    public class ParametrosDasRotinasDoRoboDenormalizer : PrimaryEventHandler,
       IAsyncEventHandler<ParametrosDasRotinasDoRoboAlterados>
    {
        private readonly IParametroDaRotinaDoRoboRepository _parametroDaRotinaDoRoboRepository;
        private readonly IEventNotificationBus _eventNotificationBus;

        public ParametrosDasRotinasDoRoboDenormalizer(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IParametroDaRotinaDoRoboRepository parametroDaRotinaDoRoboRepository,
            IEventNotificationBus eventNotificationBus)
            : base(unitOfWork, eventHandlerRepository)
        {
            _parametroDaRotinaDoRoboRepository = parametroDaRotinaDoRoboRepository;
            _eventNotificationBus = eventNotificationBus;
        }

        public Task HandleAsync(IEventEnvelop<ParametrosDasRotinasDoRoboAlterados> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ParametrosDasRotinasDoRoboAlterados @event, CancellationToken cancellationToken)
        {
            var parametrosDoRobo = await _parametroDaRotinaDoRoboRepository.ObterPorActionAsync(@event.Action).ConfigureAwait(false);

            parametrosDoRobo.ParametrosDasRotinasDoRoboAlterados(@event.ParametrosDasRotinasDoRoboId, @event.NomeDaRotina, @event.ExpressaoCron, @event.QuantidadeTotalDeTentativas,
                                                                 @event.HorarioDeInicio, @event.HorarioDeTermino, @event.Action, @event.Email);

            await _parametroDaRotinaDoRoboRepository.Save(parametrosDoRobo).ConfigureAwait(false);
        }
    }
}
