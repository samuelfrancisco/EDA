﻿using COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Services.Interfaces
{
    public interface IParametroDasRotinasDoRoboAppService
    {
        Task<IEnumerable<ParametroDasRotinasDoRoboViewModel>> ObterTodosConfiguraveisAsync();        
        Task<IEnumerable<ParametroDasRotinasDoRoboViewModel>> FiltrarAsync(string nome = "");
        Task<ParametroDasRotinasDoRoboViewModel> ObterPorIdAsync(Guid id);        
    }
}
