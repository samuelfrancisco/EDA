﻿using COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.ParametrosDasRotinasDoRobo.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.Services
{
    public class ParametroDasRotinasDoRoboAppService : IParametroDasRotinasDoRoboAppService
    {
        private readonly IParametroDaRotinaDoRoboRepository _parametroDaRotinaDoRoboRepository;

        public ParametroDasRotinasDoRoboAppService(IParametroDaRotinaDoRoboRepository parametroDaRotinaDoRoboRepository)
        {
            _parametroDaRotinaDoRoboRepository = parametroDaRotinaDoRoboRepository;
        }

        public async Task<IEnumerable<ParametroDasRotinasDoRoboViewModel>> ObterTodosConfiguraveisAsync()
        {
            var result = new Result();
            result.ErroMessage.StatusCode = 200;

            var lista = await _parametroDaRotinaDoRoboRepository.ObterTodosConfiguraveisAsync().ConfigureAwait(false);

            return lista.Select(x => new ParametroDasRotinasDoRoboViewModel
            {
                IdDaRotina = x.Id,
                Action = x.Action,
                Email = x.Email,
                ExpressaoCron = x.ExpressaoCron,
                HorarioDeInicio = x.HorarioDeInicio?.ToString("hh\\:mm"),
                HorarioDeTermino = x.HorarioDeTermino?.ToString("hh\\:mm"),
                NomeDaRotina = x.NomeDaRotina,
                QuantidadeTotalDeTentativas = x.QuantidadeTotalDeTentativas ?? 0,
                Configuravel = x.Configuravel

            }).ToList();
        }

        public async Task<IEnumerable<ParametroDasRotinasDoRoboViewModel>> FiltrarAsync(string nome = "")
        {
            var lista = await _parametroDaRotinaDoRoboRepository.ObterTodosConfiguraveisAsync().ConfigureAwait(false);

            if (!string.IsNullOrWhiteSpace(nome))
                lista = lista.Where(w => w.NomeDaRotina.Contains(nome));            

            return lista.Select(x => new ParametroDasRotinasDoRoboViewModel
            {
                IdDaRotina = x.Id,
                Action = x.Action,
                Email = x.Email,
                ExpressaoCron = x.ExpressaoCron,
                HorarioDeInicio = x.HorarioDeInicio?.ToString("hh\\:mm"),
                HorarioDeTermino = x.HorarioDeTermino?.ToString("hh\\:mm"),
                NomeDaRotina = x.NomeDaRotina,
                QuantidadeTotalDeTentativas = x.QuantidadeTotalDeTentativas ?? 0,
                Configuravel = x.Configuravel

            }).ToList();
        }

        public async Task<ParametroDasRotinasDoRoboViewModel> ObterPorIdAsync(Guid ParametrosDasRotinasDoRoboId)
        {
            var parametro = await _parametroDaRotinaDoRoboRepository.GetByIdAsync(ParametrosDasRotinasDoRoboId).ConfigureAwait(false);

            return new ParametroDasRotinasDoRoboViewModel
            {
                IdDaRotina = parametro.Id,
                Action = parametro.Action,
                Email = parametro.Email,
                ExpressaoCron = parametro.ExpressaoCron,
                HorarioDeInicio = parametro.HorarioDeInicio?.ToString("hh\\:mm"),
                HorarioDeTermino = parametro.HorarioDeTermino?.ToString("hh\\:mm"),
                NomeDaRotina = parametro.NomeDaRotina,
                QuantidadeTotalDeTentativas = parametro.QuantidadeTotalDeTentativas ?? 0,
                Configuravel = parametro.Configuravel
            };
        }       
    }
}