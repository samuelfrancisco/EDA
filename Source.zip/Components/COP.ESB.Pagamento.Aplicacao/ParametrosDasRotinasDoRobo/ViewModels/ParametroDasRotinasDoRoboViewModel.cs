﻿using System;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.ParametrosDasRotinasDoRobo.ViewModels
{
    /// <summary>
    /// View model das configurações dos parâmetros das rotinas do robô
    /// </summary>
    public class ParametroDasRotinasDoRoboViewModel
    {
        /// <summary>
        /// Id da Rotina
        /// </summary>
        [Required(ErrorMessage = "Nome da Rotina inválido.")]
        public Guid IdDaRotina { get; set; }

        /// <summary>
        /// Nome da Rotina
        /// </summary>
        [Required(ErrorMessage = "Nome da Rotina inválido.")]
        public string NomeDaRotina { get; set; }

        /// <summary>
        /// Expressão de repetição
        /// </summary>
        [Required(ErrorMessage = "Expressão de repetição.")]
        public string ExpressaoCron { get; set; }

        /// <summary>
        /// Quantidade de tentativas
        /// </summary>        
        public int? QuantidadeTotalDeTentativas { get; set; }

        /// <summary>
        /// Horário de início de execução
        /// </summary>
        public string HorarioDeInicio { get; set; }

        /// <summary>
        /// Horário de término de execução
        /// </summary>
        public string HorarioDeTermino { get; set; }

        /// <summary>
        /// Nome da ação executada no robô
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// Email de notificação
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Flag que identifica rotina Configuravel pelo usuário
        /// </summary>        
        public bool Configuravel { get; set; }
    }
}
