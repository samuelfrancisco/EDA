﻿using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class SummaryCollectionValidationAttribute : ValidationAttribute
    {
        private string SummaryProperty { get; set; }
        private string CollectionProperty { get; set; }
        private string DecimalProperty { get; set; }

        public SummaryCollectionValidationAttribute(string summaryProperty, string collectionProperty, string decimalProperty)
        {
            SummaryProperty = summaryProperty;
            CollectionProperty = collectionProperty;
            DecimalProperty = decimalProperty;
        }

        public override object TypeId
        {
            get
            {
                return this;
            }
        }

        public override bool IsValid(object value)
        {
            var summaryPropertyInfo = value.GetType().GetProperty(SummaryProperty);

            var collectionPropertyInfo = value.GetType().GetProperty(CollectionProperty);

            if (!(summaryPropertyInfo?.GetValue(value, null) is decimal summaryValue))
                return false;

            if (!(collectionPropertyInfo?.GetValue(value, null) is IList list))
                return false;

            decimal total = 0;

            foreach (var item in list)
            {
                var itemPropertyInfo = item.GetType().GetProperty(DecimalProperty);

                if (!(itemPropertyInfo.GetValue(item, null) is decimal itemValue))
                    return false;

                total += itemValue;
            }

            return summaryValue == total;
        }
    }
}
