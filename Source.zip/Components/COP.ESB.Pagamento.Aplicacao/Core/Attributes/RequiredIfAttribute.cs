﻿using System;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = true)]
    public class RequiredIfAttribute : RequiredAttribute
    {
        private string ConditionProperty { get; }
        private object ContidionValue { get; }

        public RequiredIfAttribute(string conditionProperty, object contidionValue)
        {
            ConditionProperty = conditionProperty;
            ContidionValue = contidionValue;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var conditionPropertyInfo = validationContext.ObjectType.GetProperty(ConditionProperty);

            if (conditionPropertyInfo != null)
            {
                var conditionPropertyValue = conditionPropertyInfo.GetValue(validationContext.ObjectInstance, null);

                if ((conditionPropertyValue == null && ContidionValue == null) || (conditionPropertyValue.Equals(ContidionValue)))
                {
                    return base.IsValid(value, validationContext);
                }

                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult(FormatErrorMessage(ConditionProperty));
            }
        }
    }
}
