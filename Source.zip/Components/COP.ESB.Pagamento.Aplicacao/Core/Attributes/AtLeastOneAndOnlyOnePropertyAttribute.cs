﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class AtLeastOneAndOnlyOnePropertyAttribute : ValidationAttribute
    {
        private string[] PropertyList { get; set; }

        public AtLeastOneAndOnlyOnePropertyAttribute(params string[] propertyList)
        {
            PropertyList = propertyList;
        }       

        public override object TypeId
        {
            get
            {
                return this;
            }
        }

        public override bool IsValid(object value)
        {
            var count = 0;

            PropertyInfo propertyInfo;

            foreach (string propertyName in PropertyList)
            {
                propertyInfo = value.GetType().GetProperty(propertyName);

                if (propertyInfo != null && ((!(propertyInfo.GetValue(value, null) is string) && propertyInfo.GetValue(value, null) != null)
                    || (propertyInfo.GetValue(value, null) is string && !string.IsNullOrWhiteSpace(Convert.ToString(propertyInfo.GetValue(value, null))))))
                {
                    count++;
                }
            }

            return count == 1;
        }
    }
}
