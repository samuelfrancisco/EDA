﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
    public class AcceptedValuesAttribute : ValidationAttribute
    {
        private object[] AcceptedValues { get; set; }

        public AcceptedValuesAttribute(params object[] acceptedValues)
        {
            AcceptedValues = acceptedValues;
        }

        public override bool IsValid(object value)
        {
            return AcceptedValues.Contains(value);
        }
    }
}
