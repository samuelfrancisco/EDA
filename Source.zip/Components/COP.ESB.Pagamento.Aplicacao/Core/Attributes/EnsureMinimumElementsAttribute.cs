﻿using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
    public class EnsureMinimumElementsAttribute : ValidationAttribute
    {
        private int MinElements { get; set; }
        public EnsureMinimumElementsAttribute(int minElements)
        {
            MinElements = minElements;
        }

        public override bool IsValid(object value)
        {
            if (value is IList list)
            {
                return list.Count >= MinElements;
            }

            return false;
        }
    }
}
