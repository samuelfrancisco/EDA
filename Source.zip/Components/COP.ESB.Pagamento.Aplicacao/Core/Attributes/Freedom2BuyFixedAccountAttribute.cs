﻿using COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels;
using COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace COP.ESB.Pagamento.Aplicacao.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class Freedom2BuyFixedAccountAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is IniciarNovaConsultaDeBoletoViewModel consultaDeBoleto)
            {
                var configuracoesDoMotorService = (IConfiguracoesDoMotorService)validationContext.GetService(typeof(IConfiguracoesDoMotorService));

                var empresaAplicacao = configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.ConfiguracoesDaTransacao
                    ?.EmpresasAplicacoesTransacoes?.FirstOrDefault(x => x.EmpresaAplicacaoId == consultaDeBoleto.EmpresaAplicacaoId);

                if (empresaAplicacao == null)
                    return ValidationResult.Success;

                if (empresaAplicacao?.NomeDaEmpresa?.ToUpper() != "FREEDOM2BUY")
                    return ValidationResult.Success;

                if (consultaDeBoleto.Coligada != "001" || consultaDeBoleto.Agencia != "00019" || consultaDeBoleto.ContaCorrente != "2290830005")
                    return new ValidationResult(ErrorMessage);
            }

            if (value is RealizarNovaConsultaDeConvenioViewModel consultaDeConvenio)
            {
                var configuracoesDoMotorService = (IConfiguracoesDoMotorService)validationContext.GetService(typeof(IConfiguracoesDoMotorService));

                var empresaAplicacao = configuracoesDoMotorService?.ConfiguracoesDoMotor?.Boletos?.ConfiguracoesDaTransacao
                    ?.EmpresasAplicacoesTransacoes?.FirstOrDefault(x => x.EmpresaAplicacaoId == consultaDeConvenio.EmpresaAplicacaoId);

                if (empresaAplicacao == null)
                    return ValidationResult.Success;

                if (empresaAplicacao?.NomeDaEmpresa?.ToUpper() != "FREEDOM2BUY")
                    return ValidationResult.Success;

                if (consultaDeConvenio.Coligada != "001" || consultaDeConvenio.Agencia != "00019" || consultaDeConvenio.ContaCorrente != "2290830005")
                    return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }
}
