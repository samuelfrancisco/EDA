﻿using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.CommandHandlers
{
    public class EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommandHandler
        : CommandRequestHandler<EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand>
    {
        private readonly IBoletoRepository _boletoRepository;

        public EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IBoletoRepository boletoRepository)
            : base(commandHandlerRepository)
        {
            _boletoRepository = boletoRepository;
        }

        protected override async Task DoHandleAsync(EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand command, CancellationToken cancellationToken)
        {
            var idsDosBoletos = command.Pagamentos.Select(x => x.IdDoBoleto).Distinct().ToList();

            var boletos = await _boletoRepository.ObterBoletosPelosIdsAsync(idsDosBoletos).ConfigureAwait(false);

            foreach (var boleto in boletos)
            {
                foreach (var item in command.Pagamentos.Where(x => x.IdDoBoleto == boleto.Id))
                {
                    boleto.EfetivarPagamentoDeBoleto(new EfetivarPagamentoDeBoletoCommand
                    {
                        IdDoBoleto = item.IdDoBoleto,
                        IdDaConsultaDeBoleto = item.IdDaConsultaDeBoleto,
                        IdDoPagamentoDeBoleto = item.IdDoPagamentoDeBoleto,
                        EmpresaAplicacaoTransacaoId = item.EmpresaAplicacaoTransacaoId,
                        CorrelationMessage = command,
                        OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                    });
                }

                await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);
            }
        }
    }
}
