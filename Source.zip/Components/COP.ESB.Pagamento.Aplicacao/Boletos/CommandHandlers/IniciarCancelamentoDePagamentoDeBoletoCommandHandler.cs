﻿using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.CommandHandlers
{
    public class IniciarCancelamentoDePagamentoDeBoletoCommandHandler : PrimaryCommandRequestHandler<IniciarCancelamentoDePagamentoDeBoletoCommandV2, Result>

    {
        private readonly IBoletoRepository _boletoRepository;
        private readonly ICalendarioService _calendarioService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public IniciarCancelamentoDePagamentoDeBoletoCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBoletoRepository boletoRepository,
            ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _boletoRepository = boletoRepository;
            _calendarioService = calendarioService;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result> DoHandleAsync(IniciarCancelamentoDePagamentoDeBoletoCommandV2 command, CancellationToken cancellationToken)
        {
            var boleto = await ObterBoletoAsync(command).ConfigureAwait(false);

            var result = new Result();

            if (boleto == null)
            {
                result.AddError("Id do pagamento inexistente.", "Boleto não encontrado.", GetType().FullName);
                result.ErroMessage.Message = "Id do pagamento inexistente.";
                result.ErroMessage.StatusCode = 400;

                return result;
            }

            result = await CancelarPagamentoDeBoletoAsync(boleto, command).ConfigureAwait(false);

            if (result.IsFailure)
            {
                result.ErroMessage.Message = result.ErroMessage.Errors.First().Message;
                result.ErroMessage.StatusCode = 400;

                return result;
            }

            result.ErroMessage.Message = "Cancelamento de pagamento iniciado com sucesso.";
            result.ErroMessage.StatusCode = 200;

            return result;
        }

        private async Task<Boleto> ObterBoletoAsync(IniciarCancelamentoDePagamentoDeBoletoCommandV2 command)
        {
            return await _boletoRepository.ObterBoletoPeloIdDoPagamentoAsync(command.IdDoPagamentoDeBoleto, command.EmpresaAplicacaoId).ConfigureAwait(false);
        }

        private async Task<Result> CancelarPagamentoDeBoletoAsync(Boleto boleto, IniciarCancelamentoDePagamentoDeBoletoCommandV2 command)
        {
            var result = boleto.CancelarPagamento(command, _calendarioService.ObterADataDeProcessamento(), _configuracoesDoMotorService);

            if (result.IsSuccess)
            {
                await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);
            }

            return result;
        }
    }
}
