﻿using COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.CommandHandlers
{
    public class IniciarNovoPagamentoDeBoletoCommandHandler
        : PrimaryCommandRequestHandler<IniciarNovoPagamentoDeBoletoCommandV3, Result<RetornoDoPagamentoDeBoletoViewModel>, RetornoDoPagamentoDeBoletoViewModel>
    {
        private readonly IBoletoRepository _boletoRepository;
        private readonly ICalendarioService _calendarioService;
        private readonly IPagamentoDeBoletoFactory _pagamentoDeBoletoFactory;
        private readonly IBancoService _bancoService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public IniciarNovoPagamentoDeBoletoCommandHandler(IUnitOfWork unitOfWork, 
            ICommandHandlerRepository commandHandlerRepository,
            IBoletoRepository boletoRepository,
            ICalendarioService calendarioService,
            IPagamentoDeBoletoFactory pagamentoDeBoletoFactory,
            IBancoService bancoService,
            IConfiguracoesDoMotorService configuracoesDoMotorService) 
            : base(unitOfWork, commandHandlerRepository)
        {
            _boletoRepository = boletoRepository;
            _calendarioService = calendarioService;
            _pagamentoDeBoletoFactory = pagamentoDeBoletoFactory;
            _bancoService = bancoService;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result<RetornoDoPagamentoDeBoletoViewModel>> DoHandleAsync(IniciarNovoPagamentoDeBoletoCommandV3 command, 
            CancellationToken cancellationToken)
        {
            var boleto = await ObterBoletoAsync(command).ConfigureAwait(false);

            var result = new Result();

            if(boleto == null)
            {                
                result.AddError("Id da consulta inexistente.", "Boleto não encontrado.", GetType().FullName);
                result.ErroMessage.Message = "Id da consulta inexistente: boleto não encontrado.";
                result.ErroMessage.StatusCode = 400;

                return result.ToResult<RetornoDoPagamentoDeBoletoViewModel>();
            }

            var processResult = await PagarBoletoAsync(boleto, command).ConfigureAwait(false);

            if(processResult.IsFailure)
            {
                result.Merge(processResult);
                result.ErroMessage.Message = processResult.ErroMessage.Errors.First().Message;
                result.ErroMessage.StatusCode = 400;
                return result.ToResult<RetornoDoPagamentoDeBoletoViewModel>();
            }

            result.ErroMessage.Message = "Em Pagamento";
            result.ErroMessage.StatusCode = 200;

            return result.ToResult(new RetornoDoPagamentoDeBoletoViewModel
            {
                IdDoPagamentoDeBoleto = processResult.Value.Id,
                IdentificadorDoPagamentoNoCliente = processResult.Value.IdentificadorDoPagamentoNoCliente,
                Status = "Em Pagamento"
            });
        }

        private async Task<Boleto> ObterBoletoAsync(IniciarNovoPagamentoDeBoletoCommandV3 command)
        {
            return await _boletoRepository.ObterBoletoPeloIdDaConsultaAsync(command.IdDaConsultaDeBoleto, command.EmpresaAplicacaoId).ConfigureAwait(false);
        }

        private async Task<Result<PagamentoDeBoleto>> PagarBoletoAsync(Boleto boleto, IniciarNovoPagamentoDeBoletoCommandV3 command)
        {
            var result = boleto.IniciarNovoPagamento(command, _calendarioService.ObterADataDeProcessamento(), _pagamentoDeBoletoFactory, 
                _bancoService, _configuracoesDoMotorService);

            if(result.IsSuccess)
            {
                await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);
            }

            return result;
        }
    }
}
