﻿using COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.DTOs;
using COP.ESB.Pagamento.Dominio.Boletos.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.CommandHandlers
{
    public class IniciarNovaConsultaDeBoletoCommandHandler
        : PrimaryCommandRequestHandler<IniciarNovaConsultaDeBoletoCommandV2, Result<RetornoDaConsultaDeBoletoViewModel>, RetornoDaConsultaDeBoletoViewModel>
    {
        private readonly IBoletoRepository _boletoRepository;
        private readonly ICommandRequestBus _commandRequestBus;
        private readonly IBancoService _bancoService;
        private readonly IAgenciaService _agenciaService;
        private readonly IContaService _contaService;
        private readonly ICalendarioService _calendarioService;
        private readonly IServicoDeConsultaDeBoletosNaCIP _servicoDeConsultaDeBoletosNaCIP;
        private readonly IServicoDeCalculoDeBoleto _servicoDeCalculoDeBoleto;
        private readonly ICodigoDeBarrasFactory _codigoDeBarrasFactory;
        private readonly ILinhaDigitavelFactory _linhaDigitavelFactory;
        private readonly IConsultaDeBoletoFactory _consultaDeBoletoFactory;

        public IniciarNovaConsultaDeBoletoCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IBoletoRepository boletoRepository,
            ICommandRequestBus commandRequestBus,
            IBancoService bancoService,
            IAgenciaService agenciaService,
            IContaService contaService,
            ICalendarioService calendarioService,
            IServicoDeConsultaDeBoletosNaCIP servicoDeConsultaDeBoletosNaCIP,
            IServicoDeCalculoDeBoleto servicoDeCalculoDeBoleto,
            ICodigoDeBarrasFactory codigoDeBarrasFactory,
            ILinhaDigitavelFactory linhaDigitavelFactory,
            IConsultaDeBoletoFactory consultaDeBoletoFactory)
            : base(unitOfWork, commandHandlerRepository)
        {
            _boletoRepository = boletoRepository;
            _commandRequestBus = commandRequestBus;
            _bancoService = bancoService;
            _agenciaService = agenciaService;
            _contaService = contaService;
            _calendarioService = calendarioService;
            _servicoDeConsultaDeBoletosNaCIP = servicoDeConsultaDeBoletosNaCIP;
            _servicoDeCalculoDeBoleto = servicoDeCalculoDeBoleto;
            _codigoDeBarrasFactory = codigoDeBarrasFactory;
            _linhaDigitavelFactory = linhaDigitavelFactory;
            _consultaDeBoletoFactory = consultaDeBoletoFactory;
        }

        protected override async Task<Result<RetornoDaConsultaDeBoletoViewModel>> DoHandleAsync(IniciarNovaConsultaDeBoletoCommandV2 command,
            CancellationToken cancellationToken)
        {
            Boleto boleto = await ObterBoletoAsync(command).ConfigureAwait(false);

            if (boleto == null)
            {
                var registroResult = RegistrarNovoBoleto(command);

                if (registroResult.IsFailure)
                {
                    return registroResult.ToResult<RetornoDaConsultaDeBoletoViewModel>();
                }

                boleto = registroResult.Value;
            }

            var dataDeProcessamento = _calendarioService.ObterADataDeProcessamento();

            var novaConsultaResult = boleto.IniciarNovaConsulta(command, dataDeProcessamento, _consultaDeBoletoFactory);

            if (novaConsultaResult.IsFailure)
            {
                return novaConsultaResult.ToResult<RetornoDaConsultaDeBoletoViewModel>();
            }

            await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);            

            var consulta = novaConsultaResult.Value;

            if(consulta.EBoletoSemRegistro)
            {
                return GerarRetornoDeConsultaDeBoletoSemRegistro(boleto, consulta);
            }

            if (consulta.FoiRealizadaEmContingencia)
            {
                return GerarRetornoDeConsultaEmContingencia(boleto, consulta);
            }

            var retornoDaCIPResult = await ConsultarBoletoNaCIPAsync(command.EmpresaAplicacaoId, boleto).ConfigureAwait(false);

            var retornoDaCIP = retornoDaCIPResult.Value;

            if (retornoDaCIPResult.IsFailure)
            {
                return await ConcluirAConsultaComErroNaConsultaACIPAsync(command, boleto, consulta, retornoDaCIP).ConfigureAwait(false);
            }

            return await ProcessarORetornoDaConsultaDoBoletoNaCIPAsync(command, boleto, consulta, retornoDaCIP).ConfigureAwait(false);
        }        

        private async Task<Boleto> ObterBoletoAsync(IniciarNovaConsultaDeBoletoCommandV2 command)
        {
            Boleto boleto;

            if (!string.IsNullOrWhiteSpace(command.CodigoDeBarras))
            {
                boleto = await _boletoRepository.ObterBoletoPeloCodigoDeBarrasAsync(command.CodigoDeBarras).ConfigureAwait(false);
            }
            else
            {
                boleto = await _boletoRepository.ObterBoletoPelaLinhaDigitavelAsync(command.LinhaDigitavel).ConfigureAwait(false);
            }

            return boleto;
        }

        private Result<Boleto> RegistrarNovoBoleto(IniciarNovaConsultaDeBoletoCommandV2 command)
        {
            return Boleto.RegistrarNovoBoleto(new RegistrarNovoBoletoCommand
            {
                CodigoDeBarras = command.CodigoDeBarras,
                LinhaDigitavel = command.LinhaDigitavel,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command
            }, _bancoService, _codigoDeBarrasFactory, _linhaDigitavelFactory);
        }

        private Result<RetornoDaConsultaDeBoletoViewModel> GerarRetornoDeErroNoRegistroDoBoleto(Result<Boleto> registroResult)
        {
            var primeiroErro = registroResult.ErroMessage.Errors.First();

            registroResult.ErroMessage.Message = primeiroErro.Message;
            registroResult.ErroMessage.StatusCode = 400;

            return registroResult.ToResult<RetornoDaConsultaDeBoletoViewModel>();
        }

        private Result<RetornoDaConsultaDeBoletoViewModel> GerarRetornoDeConsultaDeBoletoSemRegistro(Boleto boleto, ConsultaDeBoleto consulta)
        {
            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            var retorno = new RetornoDaConsultaDeBoletoViewModel
            {
                IdDaConsultaDeBoleto = consulta.Id,
                Duplicidade = consulta.FoiIniciadaComDuplicidade ? "S" : "N",
                Vencimento = boleto.CodigoDeBarras.ObterADataDeVencimentoDoBoleto(),
                Valor = boleto.CodigoDeBarras.ObterOValorDoBoleto().ToString("F2")
            };

            var result = new Result<RetornoDaConsultaDeBoletoViewModel>(retorno);

            result.ErroMessage.Message = "Consulta de boleto sem registro na CIP concluída com sucesso.";
            result.ErroMessage.StatusCode = 200;

            Thread.CurrentThread.CurrentCulture = currentCulture;

            return result;
        }

        private Result<RetornoDaConsultaDeBoletoViewModel> GerarRetornoDeConsultaEmContingencia(Boleto boleto, ConsultaDeBoleto consulta)
        {
            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            var retorno = new RetornoDaConsultaDeBoletoViewModel
            {
                IdDaConsultaDeBoleto = consulta.Id,
                Duplicidade = consulta.FoiIniciadaComDuplicidade ? "S" : "N",
                Vencimento = boleto.CodigoDeBarras.ObterADataDeVencimentoDoBoleto(),
                Valor = boleto.CodigoDeBarras.ObterOValorDoBoleto().ToString("F2")
            };

            var result = new Result<RetornoDaConsultaDeBoletoViewModel>(retorno);

            result.ErroMessage.Message = "Motor operando em Contingência CIP.";
            result.ErroMessage.StatusCode = 200;

            Thread.CurrentThread.CurrentCulture = currentCulture;

            return result;
        }

        private async Task<Result<RetornoDaCIPDTO>> ConsultarBoletoNaCIPAsync(long empresaAplicacaoId, Boleto boleto)
        {
            var codigoDeBarras = boleto.CodigoDeBarras.Valor;

            var valorNominal = boleto.CodigoDeBarras.ObterOValorDoBoleto();

            var retornoDaCIPResult = await _servicoDeConsultaDeBoletosNaCIP.ConsultarBoletoNaCIPAsync(empresaAplicacaoId,
                codigoDeBarras, valorNominal).ConfigureAwait(false);

            return retornoDaCIPResult;
        }

        private async Task<Result<RetornoDaConsultaDeBoletoViewModel>> ProcessarORetornoDaConsultaDoBoletoNaCIPAsync(IniciarNovaConsultaDeBoletoCommandV2 command,
            Boleto boleto, ConsultaDeBoleto consulta, RetornoDaCIPDTO retornoDaCIP)
        {
            var result = boleto.ProcessarRetornoDaConsultaDoBoletoNaCIP(new ProcessarRetornoDaConsultaDoBoletoNaCIPCommand
            {
                IdDoBoleto = boleto.Id,
                IdDaConsultaDeBoleto = consulta.Id,
                XmlRetornadoPelaCIP = retornoDaCIP.XmlRetornado,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            }, _servicoDeCalculoDeBoleto);

            await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);

            await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

            var consultaAlterada = boleto.Consultas.First(x => x.Id == consulta.Id);

            var xmlObject = RetornoDaCIPXmlDTO.FromXml(consultaAlterada.XmlRetornado);

            result.ErroMessage.StatusCode = 200;

            if (result.IsFailure)
            {
                result.ErroMessage.Message = result.ToString();
            }

            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            var retorno = new RetornoDaConsultaDeBoletoViewModel
            {
                IdDaConsultaDeBoleto = consultaAlterada.Id,
                Duplicidade = consultaAlterada.FoiIniciadaComDuplicidade ? "S" : "N",
                TipoAutorizacaoRecebimentoValorDivergente = xmlObject.TpAutcRecbtVlrDivgte,                
                PermitePagamentoParcial = xmlObject.IndrPgtoParcl,
                QtdPgtoParcl = xmlObject.QtdPgtoParcl,
                QtdPgtoParclRegtd = xmlObject.QtdPgtoParclRegtd,
                DataLimitePagamento = xmlObject.DtLimPgtoTit,
                Vencimento = xmlObject.DtVencTit,
                Valor = xmlObject.VlrTit.ToString("F2"),
                ValorMaximo = consultaAlterada.Calculo.ValorMaximoCalculado.ToString("F2"),
                ValorMinimo = consultaAlterada.Calculo.ValorMinimoCalculado.ToString("F2"),
                ValorTotal = consultaAlterada.Calculo.ValorCalculado.ToString("F2"),
                ValorDesconto = consultaAlterada.Calculo.ValorDesconto.ToString("F2"),
                ValorMulta = consultaAlterada.Calculo.ValorMulta.ToString("F2"),
                ValorJuros = consultaAlterada.Calculo.ValorJuros.ToString("F2"),
                ValorAbatimento = xmlObject.VlrAbattTit.ToString("F2"),
                PermiteAlterarValorTotal = consultaAlterada.Calculo.PermiteAlterarValorTotal,
                SituacaoDoTitulo = consultaAlterada.SituacaoDoTitulo,
                SituacaoDoTituloDescricao = consultaAlterada.SituacaoDoTituloDescricao,
                NomeOuRazaoSocialDoBeneficiario = consultaAlterada.RazaoSocialDoBeneficiario,
                CPFOuCNPJDoBeneficiario = consultaAlterada.DocumentoDoBeneficiario,
                NomeOuRazaoSocialDoPagador = consultaAlterada.RazaoSocialDoPagador,
                CPFOuCNPJDoPagador = consultaAlterada.DocumentoDoPagador
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            return result.ToResult(retorno);
        }

        private async Task<Result<RetornoDaConsultaDeBoletoViewModel>> ConcluirAConsultaComErroNaConsultaACIPAsync(IniciarNovaConsultaDeBoletoCommandV2 command,
            Boleto boleto, ConsultaDeBoleto consulta, RetornoDaCIPDTO retornoDaCIP)
        {
            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            var retorno = new RetornoDaConsultaDeBoletoViewModel
            {
                IdDaConsultaDeBoleto = consulta.Id,
                Duplicidade = consulta.FoiIniciadaComDuplicidade ? "S" : "N",
                Vencimento = boleto.CodigoDeBarras.ObterADataDeVencimentoDoBoleto(),
                Valor = boleto.CodigoDeBarras.ObterOValorDoBoleto().ToString("F2")
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var result = new Result<RetornoDaConsultaDeBoletoViewModel>(retorno);

            result.Merge(boleto.ConcluirAConsultaComErroNaConsultaACIP(new ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand
            {
                IdDoBoleto = boleto.Id,
                IdDaConsultaDeBoleto = consulta.Id,
                CodigoDeErro = retornoDaCIP.CodigoDeErro,
                DescricaoDoErro = retornoDaCIP.DescricaoDoErro,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            }));

            result.ErroMessage.Message = $"Erro ao consultar a CIP: {retornoDaCIP.DescricaoDoErro}";
            result.ErroMessage.StatusCode = 500;

            await _boletoRepository.SaveAsync(boleto, command.Id).ConfigureAwait(false);

            await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

            return result;
        }
    }
}
