﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model do comprovante do pagamento de boleto
    /// </summary>
    public class StatusDoPagamentoDeBoletoComprovanteViewModel
    {
        /// <summary>
        /// Id do Boleto
        /// </summary>
        public Guid IdDoBoleto { get; set; }

        /// <summary>
        /// Id da consulta de boleto
        /// </summary>
        public Guid IdDaConsultaDeBoleto { get; set; }

        /// <summary>
        /// Id do pagamento de boleto
        /// </summary>
        public Guid IdDoPagamentoDeBoleto { get; set; }

        /// <summary>
        /// Id do comprovante pagamento de boleto
        /// </summary>
        public Guid IdDoComprovanteDoPagamentoDeBoleto { get; set; }

        /// <summary>
        /// Id da Empresa X Aplicação
        /// </summary>
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Id da Empresa X Aplicação X Transação
        /// </summary>
        public long EmpresaAplicacaoTransacaoId { get; set; }

        /// <summary>
        /// Código da coligada
        /// </summary>
        public string CodigoDaColigada { get; set; }

        /// <summary>
        /// Código da agência
        /// </summary>
        public string CodigoDaAgencia { get; set; }

        /// <summary>
        /// Número da conta corrente
        /// </summary>
        public string NumeroDaContaCorrente { get; set; }

        /// <summary>
        /// Código do banco destinatário
        /// </summary>
        public string CodigoDoBancoDestinatario { get; set; }

        /// <summary>
        /// Nome do banco destinatário
        /// </summary>
        public string NomeDoBancoDestinatario { get; set; }

        /// <summary>
        /// Nome fatasia do beneficiário
        /// </summary>
        public string NomeFantasiaDoBeneficiario { get; set; }

        /// <summary>
        /// Razão social do beneficiário
        /// </summary>
        public string RazaoSocialDoBeneficiario { get; set; }

        /// <summary>
        /// Documento do beneficiário
        /// </summary>
        public string DocumentoDoBeneficiario { get; set; }

        /// <summary>
        /// Nome fantasia do sacador ou avalista
        /// </summary>
        public string NomeFantasiaDoSacadorOuAvalista { get; set; }

        /// <summary>
        /// Razão social do sacador ou avalista
        /// </summary>
        public string RazaoSocialDoSacadorOuAvalista { get; set; }

        /// <summary>
        /// Documento do sacador ou avalista
        /// </summary>
        public string DocumentoDoSacadorOuAvalista { get; set; }

        /// <summary>
        /// Nome fantasia do pagador
        /// </summary>
        public string NomeFantasiaDoPagador { get; set; }

        /// <summary>
        /// Razão social do pagador
        /// </summary>
        public string RazaoSocialDoPagador { get; set; }

        /// <summary>
        /// Documento do pagador
        /// </summary>
        public string DocumentoDoPagador { get; set; }

        /// <summary>
        /// Documento do pagador final
        /// </summary>
        public string DocumentoDoPagadorFinal { get; set; }

        /// <summary>
        /// Nome do pagador final
        /// </summary>
        public string NomeDoPagadorFinal { get; set; }

        /// <summary>
        /// Código de barras do boleto
        /// </summary>
        public string CodigoDeBarrasDoBoleto { get; set; }

        /// <summary>
        /// Linha digitável do boleto
        /// </summary>
        public string LinhaDigitavelDoBoleto { get; set; }

        /// <summary>
        /// Data de vencimento do boleto
        /// </summary>
        public DateTime? DataDeVencimento { get; set; }

        /// <summary>
        /// Valor nominal do boleto
        /// </summary>
        public decimal ValorNominal { get; set; }

        /// <summary>
        /// Multa
        /// </summary>
        public decimal Multa { get; set; }

        /// <summary>
        /// Juros
        /// </summary>
        public decimal Juros { get; set; }

        /// <summary>
        /// Encargos
        /// </summary>
        public decimal Encargos { get; set; }

        /// <summary>
        /// Descontos
        /// </summary>
        public decimal Descontos { get; set; }

        /// <summary>
        /// Abatimento
        /// </summary>
        public decimal Abatimento { get; set; }

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Data do pagamento
        /// </summary>
        public DateTimeOffset DataDoPagamento { get; set; }

        /// <summary>
        /// Flag indicando se o pagamento foi realizado em contingência
        /// </summary>
        public bool FoiRealizadoEmContingencia { get; set; }

        /// <summary>
        /// Data da geração do comprovante
        /// </summary>
        public DateTimeOffset Data { get; set; }

        /// <summary>
        /// Tipo de transação
        /// </summary>
        public string TipoDeTransacao { get; set; }

        /// <summary>
        /// Tipo de pagamento
        /// </summary>
        public string TipoDePagamento { get; set; }
    }
}
