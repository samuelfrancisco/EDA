﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model com o retorno do pagamento de boleto
    /// </summary>
    public class RetornoDoPagamentoDeBoletoViewModel
    {
        /// <summary>
        /// Id do pagamento de boleto
        /// </summary>
        public Guid IdDoPagamentoDeBoleto { get; set; }

        /// <summary>
        /// Identificador do pagamento no cliente
        /// </summary>
        public string IdentificadorDoPagamentoNoCliente { get; set; }

        /// <summary>
        /// Status do pagaamento
        /// </summary>
        public string Status { get; set; }
    }
}
