﻿using COP.ESB.Pagamento.Aplicacao.Core.Attributes;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model dos parâmetros para início de nova consulta de boleto
    /// </summary>
    [Freedom2BuyFixedAccount(ErrorMessage = "Conta Corrente inválida.")]
    [AtLeastOneAndOnlyOneProperty("CodigoDeBarras", "LinhaDigitavel", ErrorMessage = "Informe código de barras ou linha digitável.")]
    public class IniciarNovaConsultaDeBoletoViewModel
    {
        /// <summary>
        /// Id da Empresa x Aplicação.
        /// </summary>
        [Required(ErrorMessage = "Empresa x Aplicação inválida.")]
        public long EmpresaAplicacaoId { get; set; }        

        /// <summary>
        /// Código da coligada à qual a agência do pagador pertence.
        /// </summary>
        [Required(ErrorMessage = "Coligada inválida.")]
        public string Coligada { get; set; }

        /// <summary>
        /// Código da agência do pagador.
        /// </summary>
        [Required(ErrorMessage = "Agência inválida.")]
        public string Agencia { get; set; }

        /// <summary>
        /// Número da conta corrente do pagador.
        /// </summary>
        [Required(ErrorMessage = "Conta corrente inválida.")]
        public string ContaCorrente { get; set; }
        
        /// <summary>
        /// Código de barras do boleto.
        /// </summary>
        public string CodigoDeBarras { get; set; }

        /// <summary>
        /// Linha digitável do boleto.
        /// </summary>
        public string LinhaDigitavel { get; set; }

        /// <summary>
        /// Data de pagamento do boleto.
        /// </summary>
        [Required(ErrorMessage = "Data de pagamento inválida.")]
        public string DataDePagamento { get; set; }        
    }
}
