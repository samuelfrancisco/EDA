﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model do status do pagamento de boleto
    /// </summary>
    public class StatusDoPagamentoDeBoletoViewModel
    {
        /// <summary>
        /// Id do pagamento
        /// </summary>
        public Guid IdDoPagamentoDeBoleto { get; set; }

        /// <summary>
        /// Identificador único do pagamento gerado pelo cliente, para ser utilizado em consultas posteriores.
        /// </summary>
        public string IdentificadorDoPagamentoNoCliente { get; set; }

        /// <summary>
        /// Status do pagamento
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Compovante do pagamento
        /// </summary>
        public StatusDoPagamentoDeBoletoComprovanteViewModel Comprovante { get; set; }
    }
}
