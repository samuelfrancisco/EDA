﻿using System;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model dos parâmetros para início de novo pagamento de boleto
    /// </summary>
    public class IniciarNovoPagamentoDeBoletoViewModel
    {
        /// <summary>
        /// Id da Empresa x Aplicação
        /// </summary>
        [Required(ErrorMessage = "Empresa x Aplicação inválida.")]
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Identificador da consulta associada ao pagamento
        /// </summary>
        [Required(ErrorMessage = "Id da consulta inválido.")]
        public Guid IdDaConsultaDeBoleto { get; set; }

        /// <summary>
        /// Identificador único do pagamento gerado pelo cliente, para ser utilizado em consultas posteriores
        /// </summary>
        [Required(ErrorMessage = "Identificador único do pagamento inválido.")]
        [MaxLength(255, ErrorMessage = "O identificador único do pagamento deve ter no máximo 255 caracteres.")]
        public string IdentificadorDoPagamentoNoCliente { get; set; }        

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        [Required(ErrorMessage = "Valor do pagamento inválido.")]
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Valor do abatimento
        /// </summary>
        public decimal? ValorDoAbatimento { get; set; }

        /// <summary>
        /// Valor do desconto
        /// </summary>
        public decimal? ValorDoDesconto { get; set; }

        /// <summary>
        /// Canal do pagamento
        /// </summary>
        [Required(ErrorMessage = "Canal do Pagamento deve estar entre 1 e 8.")]
        [Range(1, 8, ErrorMessage = "Canal do Pagamento deve estar entre 1 e 8.")]
        public int CanalDoPagamento { get; set; }

        /// <summary>
        /// Meio de pagamento
        /// </summary>
        [Required(ErrorMessage = "Meio de Pagamento deve estar entre 1 e 4.")]
        [Range(1, 4, ErrorMessage = "Meio de Pagamento deve estar entre 1 e 4.")]
        public int MeioDePagamento { get; set; }

        /// <summary>
        /// Flag indicando de devem ser aceitos pagamentos em duplicidade
        /// </summary>
        [Required(ErrorMessage = "Informar se S para aceitar pagamentos em duplicidade ou N para não aceitar.")]
        public string AceitaDuplicidade { get; set; }

        /// <summary>
        /// Documento do pagador (CPF ou CNPJ)
        /// </summary>
        [MaxLength(255, ErrorMessage = "O documento do pagador deve ter no máximo 255 caracteres.")]
        public string DocumentoDoPagadorInformadoPeloCliente { get; set; }
        
        /// <summary>
        /// Nome do pagador
        /// </summary>
        [MaxLength(255, ErrorMessage = "O nome do pagador deve ter no máximo 255 caracteres.")]
        public string NomeDoPagadorInformadoPeloCliente { get; set; }       
    }
}
