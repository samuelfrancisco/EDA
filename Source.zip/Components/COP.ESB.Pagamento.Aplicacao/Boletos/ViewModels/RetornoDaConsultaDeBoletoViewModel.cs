﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels
{
    /// <summary>
    /// View model com o retorno da consulta de boleto
    /// </summary>
    public class RetornoDaConsultaDeBoletoViewModel
    {
        /// <summary>
        /// Tipo de pagamento
        /// </summary>
        public string TipoPagamentoDiverso { get; } = "Boleto";

        /// <summary>
        /// Id da consulta
        /// </summary>
        public Guid IdDaConsultaDeBoleto { get; set; }

        /// <summary>
        /// Flag indicando se houve duplicidade
        /// </summary>
        public string Duplicidade { get; set; }

        /// <summary>
        /// Tipo de autorização de recebimento de valor divergente
        /// </summary>
        public int TipoAutorizacaoRecebimentoValorDivergente { get; set; }

        /// <summary>
        /// Permite pagamento parcial
        /// </summary>
        public string PermitePagamentoParcial { get; set; }

        /// <summary>
        /// Quantidade de pagamentos parciais autorizados
        /// </summary>
        public int? QtdPgtoParcl { get; set; }

        /// <summary>
        /// Quantidade de pagamentos parciais registrados
        /// </summary>
        public int? QtdPgtoParclRegtd { get; set; }

        /// <summary>
        /// Data limite para pagamento do título
        /// </summary>
        public DateTime? DataLimitePagamento { get; set; }

        /// <summary>
        /// Data de vencimento do título
        /// </summary>
        public DateTime? Vencimento { get; set; }

        /// <summary>
        /// Valor do título
        /// </summary>
        public string Valor { get; set; }

        /// <summary>
        /// Valor máximo do pagamento
        /// </summary>
        public string ValorMaximo { get; set; }

        /// <summary>
        /// Valor mínimo do pagamento
        /// </summary>
        public string ValorMinimo { get; set; }

        /// <summary>
        /// Valor total
        /// </summary>
        public string ValorTotal { get; set; }

        /// <summary>
        /// Valor do desconto
        /// </summary>
        public string ValorDesconto { get; set; }

        /// <summary>
        /// Valor da multa
        /// </summary>
        public string ValorMulta { get; set; }

        /// <summary>
        /// Valor dos juros
        /// </summary>
        public string ValorJuros { get; set; }

        /// <summary>
        /// Valor do abatimento
        /// </summary>
        public string ValorAbatimento { get; set; }

        /// <summary>
        /// Permite alterar o valor do pagamento
        /// </summary>
        public string PermiteAlterarValorTotal { get; set; }

        /// <summary>
        /// Código da situação do título
        /// </summary>
        public string SituacaoDoTitulo { get; set; }

        /// <summary>
        /// Descrição da situação do título
        /// </summary>
        public string SituacaoDoTituloDescricao { get; set; }

        /// <summary>
        /// Nome ou Razão Social do Beneficiário
        /// </summary>
        public string NomeOuRazaoSocialDoBeneficiario { get; set; }

        /// <summary>
        /// CPF ou CNPJ do Beneficiário
        /// </summary>
        public string CPFOuCNPJDoBeneficiario { get; set; }

        /// <summary>
        /// Nome ou Razão Social do Pagador
        /// </summary>
        public string NomeOuRazaoSocialDoPagador { get; set; }

        /// <summary>
        /// CPF ou CNPJ do Pagador
        /// </summary>
        public string CPFOuCNPJDoPagador { get; set; }
    }
}
