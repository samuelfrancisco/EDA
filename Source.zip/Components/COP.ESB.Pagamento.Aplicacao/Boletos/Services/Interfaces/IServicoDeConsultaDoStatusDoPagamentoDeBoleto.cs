﻿using COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.Services.Interfaces
{
    public interface IServicoDeConsultaDoStatusDoPagamentoDeBoleto
    {
        Task<Result<StatusDoPagamentoDeBoletoViewModel>> ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(long empresaAplicacaoId, string identificadorDoPagamentoNoCliente);
    }
}
