﻿using COP.ESB.Pagamento.Aplicacao.Boletos.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Boletos.ViewModels;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Boletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentosDeBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Boletos.Services
{
    public class ServicoDeConsultaDoStatusDoPagamentoDeBoleto : IServicoDeConsultaDoStatusDoPagamentoDeBoleto
    {
        private readonly IBoletoRepository _boletoRepository;
        private readonly IComprovanteDePagamentoDeBoletoRepository _comprovanteDePagamentoDeBoletoRepository;

        public ServicoDeConsultaDoStatusDoPagamentoDeBoleto(IBoletoRepository boletoRepository,
            IComprovanteDePagamentoDeBoletoRepository comprovanteDePagamentoDeBoletoRepository)
        {
            _boletoRepository = boletoRepository;
            _comprovanteDePagamentoDeBoletoRepository = comprovanteDePagamentoDeBoletoRepository;
        }

        public async Task<Result<StatusDoPagamentoDeBoletoViewModel>> ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(long empresaAplicacaoId,
            string identificadorDoPagamentoNoCliente)
        {
            var result = new Result();

            var statusDoPagamento = await _boletoRepository
                .ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(empresaAplicacaoId, identificadorDoPagamentoNoCliente)
                .ConfigureAwait(false);

            if (statusDoPagamento == null)
            {
                var mensagem = $"Pagamento de boleto com identificação do cliente {identificadorDoPagamentoNoCliente}, da Empresa X Aplicação {empresaAplicacaoId} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;

                return result.ToResult<StatusDoPagamentoDeBoletoViewModel>();
            }

            var status = new StatusDoPagamentoDeBoletoViewModel
            {
                IdDoPagamentoDeBoleto = statusDoPagamento.IdDoPagamentoDeBoleto,
                IdentificadorDoPagamentoNoCliente = statusDoPagamento.IdentificadorDoPagamentoNoCliente,
                Status = ObterStatus(statusDoPagamento.Status),
                Comprovante = await ObterComprovanteDoPagamentoAsync(empresaAplicacaoId, statusDoPagamento.IdDoPagamentoDeBoleto).ConfigureAwait(false)
            };

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(status);
        }

        private string ObterStatus(PagamentoDeBoletoStatus status)
        {
            switch (status)
            {
                case PagamentoDeBoletoStatus.EmPagamento:
                case PagamentoDeBoletoStatus.DebitadoPelaAplicacao:
                case PagamentoDeBoletoStatus.DebitadoPeloMotor:
                case PagamentoDeBoletoStatus.PendenteDeBaixaOperacional:
                    return "Em Pagamento";
                case PagamentoDeBoletoStatus.Efetivado:
                    return "Efetivado";
                case PagamentoDeBoletoStatus.BaixaOperacionalRecusada:
                case PagamentoDeBoletoStatus.Recusado:
                    return "Recusado";
                case PagamentoDeBoletoStatus.EmEstorno:
                case PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional:
                    return "Em Estorno";
                case PagamentoDeBoletoStatus.Estornado:
                    return "Estornado";
                default:
                    return "Em Pagamento";
            }
        }

        private async Task<StatusDoPagamentoDeBoletoComprovanteViewModel> ObterComprovanteDoPagamentoAsync(long empresaAplicacaoId, Guid idDoPagamentoDeBoleto)
        {
            var comprovante = await _comprovanteDePagamentoDeBoletoRepository
                .ConsultarComprovantePeloIdDoPagamentoAsync(empresaAplicacaoId, idDoPagamentoDeBoleto)
                .ConfigureAwait(false);

            if (comprovante == null)
                return null;

            return new StatusDoPagamentoDeBoletoComprovanteViewModel
            {
                Abatimento = comprovante.Abatimento,
                CodigoDaAgencia = comprovante.CodigoDaAgencia,
                CodigoDaColigada = comprovante.CodigoDaColigada,
                CodigoDeBarrasDoBoleto = comprovante.CodigoDeBarrasDoBoleto,
                CodigoDoBancoDestinatario = comprovante.CodigoDoBancoDestinatario,
                Data = comprovante.Data,
                DataDeVencimento = comprovante.DataDeVencimento,
                DataDoPagamento = comprovante.DataDoPagamento,
                Descontos = comprovante.Descontos,
                DocumentoDoBeneficiario = comprovante.DocumentoDoBeneficiario,
                DocumentoDoPagador = comprovante.DocumentoDoPagador,
                DocumentoDoPagadorFinal = comprovante.DocumentoDoPagadorFinal,
                DocumentoDoSacadorOuAvalista = comprovante.DocumentoDoSacadorOuAvalista,
                EmpresaAplicacaoId = comprovante.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = comprovante.EmpresaAplicacaoTransacaoId,
                Encargos = comprovante.Encargos,
                FoiRealizadoEmContingencia = comprovante.FoiRealizadoEmContingencia,
                IdDaConsultaDeBoleto = comprovante.IdDaConsultaDeBoleto,
                IdDoBoleto = comprovante.IdDoBoleto,
                IdDoComprovanteDoPagamentoDeBoleto = comprovante.IdDoComprovanteDoPagamentoDeBoleto,
                IdDoPagamentoDeBoleto = comprovante.IdDoPagamentoDeBoleto,
                Juros = comprovante.Juros,
                LinhaDigitavelDoBoleto = comprovante.LinhaDigitavelDoBoleto,
                Multa = comprovante.Multa,
                NomeDoBancoDestinatario = comprovante.NomeDoBancoDestinatario,
                NomeFantasiaDoBeneficiario = comprovante.NomeFantasiaDoBeneficiario,
                NomeFantasiaDoPagador = comprovante.NomeFantasiaDoPagador,
                NomeFantasiaDoSacadorOuAvalista = comprovante.NomeFantasiaDoSacadorOuAvalista,
                NomeDoPagadorFinal = comprovante.NomeDoPagadorFinal,
                NumeroDaContaCorrente = comprovante.NumeroDaContaCorrente,
                RazaoSocialDoBeneficiario = comprovante.RazaoSocialDoBeneficiario,
                RazaoSocialDoPagador = comprovante.RazaoSocialDoPagador,
                RazaoSocialDoSacadorOuAvalista = comprovante.RazaoSocialDoSacadorOuAvalista,
                TipoDePagamento = comprovante.TipoDePagamento,
                TipoDeTransacao = comprovante.TipoDeTransacao,
                ValorDoPagamento = comprovante.ValorDoPagamento,
                ValorNominal = comprovante.ValorNominal                
            };
        }
    }
}
