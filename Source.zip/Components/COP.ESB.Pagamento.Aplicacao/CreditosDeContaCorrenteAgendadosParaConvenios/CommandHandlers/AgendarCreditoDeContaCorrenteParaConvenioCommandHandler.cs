﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteAgendadosParaConvenios;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteAgendadosParaConvenios.Commands;
using COP.ESB.Pagamento.Dominio.CreditosDeContaCorrenteAgendadosParaConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.CreditosDeContaCorrenteAgendadosParaConvenios.CommandHandlers
{
    public class AgendarCreditoDeContaCorrenteParaConvenioCommandHandler : CommandRequestHandler<AgendarCreditoDeContaCorrenteParaConvenioCommand>
    {
        private readonly ICreditoDeContaCorrenteAgendadoParaConvenioRepository _creditoDeContaCorrenteAgendadoParaConvenioRepository;

        public AgendarCreditoDeContaCorrenteParaConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ICreditoDeContaCorrenteAgendadoParaConvenioRepository creditoDeContaCorrenteAgendadoParaConvenioRepository)
            : base(commandHandlerRepository)
        {
            _creditoDeContaCorrenteAgendadoParaConvenioRepository = creditoDeContaCorrenteAgendadoParaConvenioRepository;
        }

        protected override async Task DoHandleAsync(AgendarCreditoDeContaCorrenteParaConvenioCommand command, CancellationToken cancellationToken)
        {
            var creditoDeContaCorrenteAgendado = new CreditoDeContaCorrenteAgendadoParaConvenio(command);

            await _creditoDeContaCorrenteAgendadoParaConvenioRepository.SaveAsync(creditoDeContaCorrenteAgendado).ConfigureAwait(false);
        }
    }
}
