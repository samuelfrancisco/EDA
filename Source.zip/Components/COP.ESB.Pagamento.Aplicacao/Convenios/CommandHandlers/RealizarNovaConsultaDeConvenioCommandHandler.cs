﻿using COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Clientes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using COP.ESB.Pagamento.Dominio.Convenios.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Titulares.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.CommandHandlers
{
    public class RealizarNovaConsultaDeConvenioCommandHandler :
        PrimaryCommandRequestHandler<RealizarNovaConsultaDeConvenioCommand, Result<RetornoDaConsultaDeConvenioViewModel>,
            RetornoDaConsultaDeConvenioViewModel>
    {
        private readonly IConvenioRepository _convenioRepository;
        private readonly ICodigoDeBarrasDeConvenioFactory _codigoDeBarrasDeConvenioFactory;
        private readonly ILinhaDigitavelDeConvenioFactory _linhaDigitavelDeConvenioFactory;
        private readonly IConsultaDeConvenioFactory _consultaDeConvenioFactory;
        private readonly IAgenciaService _agenciaService;
        private readonly IContaService _contaService;
        private readonly ITitularService _titularService;
        private readonly IClienteService _clienteService;
        private readonly ICalendarioService _calendarioService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public RealizarNovaConsultaDeConvenioCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IConvenioRepository convenioRepository,
            ICodigoDeBarrasDeConvenioFactory codigoDeBarrasDeConvenioFactory,
            ILinhaDigitavelDeConvenioFactory linhaDigitavelDeConvenioFactory,
            IConsultaDeConvenioFactory consultaDeConvenioFactory,
            IAgenciaService agenciaService,
            IContaService contaService,
            ITitularService titularService,
            IClienteService clienteService,
            ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _convenioRepository = convenioRepository;
            _codigoDeBarrasDeConvenioFactory = codigoDeBarrasDeConvenioFactory;
            _linhaDigitavelDeConvenioFactory = linhaDigitavelDeConvenioFactory;
            _consultaDeConvenioFactory = consultaDeConvenioFactory;
            _agenciaService = agenciaService;
            _contaService = contaService;
            _titularService = titularService;
            _clienteService = clienteService;
            _calendarioService = calendarioService;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result<RetornoDaConsultaDeConvenioViewModel>> DoHandleAsync(RealizarNovaConsultaDeConvenioCommand command,
            CancellationToken cancellationToken)
        {
            var result = await ObterOConvenioAsync(command).ConfigureAwait(false);

            if (result.IsFailure)
                return result.ToResult<RetornoDaConsultaDeConvenioViewModel>();

            Convenio convenio = result.Value;

            if (convenio == null)
            {
                result = await RegistrarNovoConvenioAsync(command).ConfigureAwait(false);

                if (result.IsFailure)
                    return result.ToResult<RetornoDaConsultaDeConvenioViewModel>();

                convenio = result.Value;
            }

            return await RealizarNovaConsultaDeConvenioAsync(command, convenio).ConfigureAwait(false);
        }

        private async Task<Result<Convenio>> ObterOConvenioAsync(RealizarNovaConsultaDeConvenioCommand command)
        {
            if (string.IsNullOrWhiteSpace(command.CodigoDeBarras) && string.IsNullOrWhiteSpace(command.LinhaDigitavel))
            {
                var result = new Result();
                result.AddError("Informe código de barras ou linha digitável.", "O código de barras e a linha digitável estão nulos", GetType().FullName);
                result.ErroMessage.Message = "Informe código de barras ou linha digitável: o código de barras e a linha digitável estão nulos.";
                result.ErroMessage.StatusCode = 400;

                return result.ToResult<Convenio>();
            }

            Convenio convenio;

            if (!string.IsNullOrWhiteSpace(command.CodigoDeBarras))
            {
                convenio = await _convenioRepository.ObterPeloCodigoDeBarrasAsync(command.CodigoDeBarras).ConfigureAwait(false);
            }
            else
            {
                convenio = await _convenioRepository.ObterPelaLinhaDigitavelAsync(command.LinhaDigitavel).ConfigureAwait(false);
            }

            return new Result<Convenio>(convenio);
        }

        private async Task<Result<Convenio>> RegistrarNovoConvenioAsync(RealizarNovaConsultaDeConvenioCommand command)
        {
            var registrarCommand = new RegistrarNovoConvenioCommand
            {
                CodigoDeBarras = command.CodigoDeBarras,
                LinhaDigitavel = command.LinhaDigitavel,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            };

            var result = Convenio.RegistrarNovoConvenio(registrarCommand, _codigoDeBarrasDeConvenioFactory, _linhaDigitavelDeConvenioFactory);

            if (result.IsSuccess)
            {
                await _convenioRepository.SaveAsync(result.Value, registrarCommand.Id).ConfigureAwait(false);

                await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);
            }

            return result;
        }

        private async Task<Result<RetornoDaConsultaDeConvenioViewModel>> RealizarNovaConsultaDeConvenioAsync(RealizarNovaConsultaDeConvenioCommand command,
            Convenio convenio)
        {
            var result = convenio.RealizarNovaConsulta(command, _consultaDeConvenioFactory, _agenciaService, _contaService,
                _titularService, _clienteService, _calendarioService, _configuracoesDoMotorService);

            if (result.IsFailure)
                return result.ToResult<RetornoDaConsultaDeConvenioViewModel>();

            var consulta = result.Value;

            await _convenioRepository.SaveAsync(convenio, command.Id).ConfigureAwait(false);

            await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

            var configuracoesDoSegmento = _configuracoesDoMotorService.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosSegmentosDeConvenio
                .First(x => x.Codigo == convenio.CodigoDoSegmento && x.Active);

            var configuracoesDoConvenio = _configuracoesDoMotorService.ConfiguracoesDoMotor.Convenios.ConfiguracoesDosConvenios
                .First(x => x.Codigo == convenio.CodigoDoConvenio && x.Active);

            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

            var retorno = new Result<RetornoDaConsultaDeConvenioViewModel>(new RetornoDaConsultaDeConvenioViewModel
            {
                IdDaConsultaDeConvenio = consulta.Id,
                CodigoDoSegmento = convenio.CodigoDoSegmento,
                NomeDoSegmento = configuracoesDoSegmento.Nome,
                CodigoDoConvenio = convenio.CodigoDoConvenio,
                NomeDoConvenio = configuracoesDoConvenio.Nome,
                Valor = convenio.Valor.HasValue
                    ? convenio.Valor.Value.ToString("F2")
                    : null,
                DataDeVencimento = convenio.DataDeVencimento.HasValue
                    ? convenio.DataDeVencimento.Value.ToString("dd/MM/yyyy")
                    : null
            });

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            retorno.ErroMessage.StatusCode = 200;

            return retorno;
        }
    }
}
