﻿using COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Clientes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Contas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios;
using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using COP.ESB.Pagamento.Dominio.Convenios.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Titulares.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.CommandHandlers
{
    public class IniciarNovoPagamentoDeConvenioCommandHandler :
        PrimaryCommandRequestHandler<IniciarNovoPagamentoDeConvenioCommandV2, Result<RetornoDoPagamentoDeConvenioViewModel>,
            RetornoDoPagamentoDeConvenioViewModel>
    {
        private readonly IConvenioRepository _convenioRepository;
        private readonly IPagamentoDeConvenioFactory _pagamentoDeConvenioFactory;
        private readonly IAgenciaService _agenciaService;
        private readonly IContaService _contaService;
        private readonly ITitularService _titularService;
        private readonly IClienteService _clienteService;
        private readonly ICalendarioService _calendarioService;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;        

        public IniciarNovoPagamentoDeConvenioCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IConvenioRepository convenioRepository,
            IPagamentoDeConvenioFactory pagamentoDeConvenioFactory,
            IAgenciaService agenciaService,
            IContaService contaService,
            ITitularService titularService,
            IClienteService clienteService,
            ICalendarioService calendarioService,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _convenioRepository = convenioRepository;
            _pagamentoDeConvenioFactory = pagamentoDeConvenioFactory;
            _agenciaService = agenciaService;
            _contaService = contaService;
            _titularService = titularService;
            _clienteService = clienteService;
            _calendarioService = calendarioService;
            _configuracoesDoMotorService = configuracoesDoMotorService;            
        }

        protected override async Task<Result<RetornoDoPagamentoDeConvenioViewModel>> DoHandleAsync(IniciarNovoPagamentoDeConvenioCommandV2 command,
            CancellationToken cancellationToken)
        {
            var convenioResult = await ObterOConvenioPeloIdDaConsultaAsync(command).ConfigureAwait(false);

            if (convenioResult.IsFailure)
                return convenioResult.ToResult<RetornoDoPagamentoDeConvenioViewModel>();

            var convenio = convenioResult.Value;

            var result = convenio.IniciarNovoPagamento(command, _pagamentoDeConvenioFactory, _agenciaService, _contaService,
                _titularService, _clienteService, _calendarioService, _configuracoesDoMotorService);

            if (result.IsFailure)
                return result.ToResult<RetornoDoPagamentoDeConvenioViewModel>();

            await _convenioRepository.SaveAsync(convenio, command.Id).ConfigureAwait(false);

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(new RetornoDoPagamentoDeConvenioViewModel
            {
                IdDoPagamentoDeConvenio = result.Value.Id,
                IdentificadorDoPagamentoNoCliente = result.Value.IdentificadorDoPagamentoNoCliente,
                Status = "Em Pagamento"
            });
        }

        private async Task<Result<Convenio>> ObterOConvenioPeloIdDaConsultaAsync(IniciarNovoPagamentoDeConvenioCommandV2 command)
        {
            var convenio = await _convenioRepository.ObterPeloIdDaConsultaAsync(command.IdDaConsultaDeConvenio).ConfigureAwait(false);

            if (convenio == null)
            {
                var result = new Result();
                result.AddError("Id da consulta inexistente.", "Convênio não encontrado.", GetType().FullName);
                result.ErroMessage.Message = "Id da consulta inexistente: convênio não encontrado.";
                result.ErroMessage.StatusCode = 400;

                return result.ToResult<Convenio>();
            }

            return new Result<Convenio>(convenio);
        }
    }
}
