﻿using COP.ESB.Pagamento.Dominio.Convenios.Commands;
using COP.ESB.Pagamento.Dominio.Convenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.CommandHandlers
{
    public class MarcarPagamentoDeConvenioComoEstornoRecusadoCommandHandler : CommandRequestHandler<MarcarPagamentoDeConvenioComoEstornoRecusadoCommand>
    {
        private readonly IConvenioRepository _convenioRepository;

        public MarcarPagamentoDeConvenioComoEstornoRecusadoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConvenioRepository boletoRepository)
            : base(commandHandlerRepository)
        {
            _convenioRepository = boletoRepository;
        }

        protected override async Task DoHandleAsync(MarcarPagamentoDeConvenioComoEstornoRecusadoCommand command, CancellationToken cancellationToken)
        {
            var convenio = await _convenioRepository.GetByIdAsync(command.IdDoConvenio).ConfigureAwait(false);

            if (convenio == null)
                throw new InvalidOperationException($"Convênio {command.IdDoConvenio} não encontrado.");

            convenio.MarcarPagamentoComoEstornoRecusado(command);

            await _convenioRepository.SaveAsync(convenio, command.Id).ConfigureAwait(false);
        }
    }
}
