﻿using COP.ESB.Pagamento.Aplicacao.Convenios.Services.Interfaces;
using COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels;
using COP.ESB.Pagamento.Dominio.ComprovantesDePagamentoDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Convenios.Enums;
using COP.ESB.Pagamento.Dominio.Convenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.Services
{
    public class ServicoDeConsultaDoStatusDoPagamentoDeConvenio : IServicoDeConsultaDoStatusDoPagamentoDeConvenio
    {
        private readonly IConvenioRepository _convenioRepository;
        private readonly IComprovanteDePagamentoDeConvenioRepository _comprovanteDePagamentoDeConvenioRepository;

        public ServicoDeConsultaDoStatusDoPagamentoDeConvenio(IConvenioRepository convenioRepository,
            IComprovanteDePagamentoDeConvenioRepository comprovanteDePagamentoDeConvenioRepository)
        {
            _convenioRepository = convenioRepository;
            _comprovanteDePagamentoDeConvenioRepository = comprovanteDePagamentoDeConvenioRepository;
        }

        public async Task<Result<StatusDoPagamentoDeConvenioViewModel>> ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(long empresaAplicacaoId, string identificadorDoPagamentoNoCliente)
        {
            var result = new Result();

            var statusDoPagamento = await _convenioRepository
               .ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(empresaAplicacaoId, identificadorDoPagamentoNoCliente)
               .ConfigureAwait(false);

            if (statusDoPagamento == null)
            {
                var mensagem = $"Pagamento de convênio com identificação do cliente {identificadorDoPagamentoNoCliente}, da Empresa X Aplicação {empresaAplicacaoId} não encontrado.";

                result.AddError(mensagem, mensagem, GetType().FullName);
                result.ErroMessage.StatusCode = 404;
                result.ErroMessage.Message = mensagem;

                return result.ToResult<StatusDoPagamentoDeConvenioViewModel>();
            }

            var status = new StatusDoPagamentoDeConvenioViewModel
            {
                IdDoPagamentoDeConvenio = statusDoPagamento.IdDoPagamentoDeConvenio,
                IdentificadorDoPagamentoNoCliente = statusDoPagamento.IdentificadorDoPagamentoNoCliente,
                Status = ObterStatus(statusDoPagamento.Status),
                Comprovante = await ObterComprovanteDoPagamentoAsync(empresaAplicacaoId, statusDoPagamento.IdDoPagamentoDeConvenio).ConfigureAwait(false)
            };

            result.ErroMessage.StatusCode = 200;

            return result.ToResult(status);
        }

        private string ObterStatus(PagamentoDeConvenioStatus status)
        {
            switch (status)
            {
                case PagamentoDeConvenioStatus.EmPagamento:
                case PagamentoDeConvenioStatus.DebitadoPelaAplicacao:
                case PagamentoDeConvenioStatus.DebitadoPeloMotor:
                case PagamentoDeConvenioStatus.PendenteDeLiquidacao:
                    return "Em Pagamento";
                case PagamentoDeConvenioStatus.Efetivado:
                    return "Efetivado";
                case PagamentoDeConvenioStatus.LiquidacaoRecusada:
                case PagamentoDeConvenioStatus.Recusado:
                    return "Recusado";
                case PagamentoDeConvenioStatus.EmEstorno:                
                    return "Em Estorno";
                case PagamentoDeConvenioStatus.Estornado:
                    return "Estornado";
                case PagamentoDeConvenioStatus.EstornoRecusado:
                    return "Estorno recusado";
                default:
                    return "Em Pagamento";
            }
        }

        private async Task<StatusDoPagamentoDeConvenioComprovanteViewModel> ObterComprovanteDoPagamentoAsync(long empresaAplicacaoId, Guid idDoPagamentoDeConvenio)
        {
            var comprovante = await _comprovanteDePagamentoDeConvenioRepository
                .ConsultarComprovantePeloIdDoPagamentoAsync(empresaAplicacaoId, idDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (comprovante == null)
                return null;

            return new StatusDoPagamentoDeConvenioComprovanteViewModel
            {
                IdDoConvenio = comprovante.IdDoConvenio,
                IdDaConsultaDeConvenio = comprovante.IdDaConsultaDeConvenio,
                IdDoPagamentoDeConvenio = comprovante.IdDoPagamentoDeConvenio,
                IdDoComprovanteDoPagamentoDeConvenio = comprovante.IdDoComprovanteDoPagamentoDeConvenio,
                EmpresaAplicacaoId = comprovante.EmpresaAplicacaoId,
                EmpresaAplicacaoTransacaoId = comprovante.EmpresaAplicacaoTransacaoId,
                CodigoDaColigada = comprovante.CodigoDaColigada,
                CodigoDaAgencia = comprovante.CodigoDaAgencia,
                NumeroDaContaCorrente = comprovante.NumeroDaContaCorrente,
                DocumentoDoPagadorFinal = comprovante.DocumentoDoPagadorFinal,
                NomeDoPagadorFinal = comprovante.NomeDoPagadorFinal,
                CodigoDeBarrasDoConvenio = comprovante.CodigoDeBarrasDoConvenio,
                LinhaDigitavelDoConvenio = comprovante.LinhaDigitavelDoConvenio,
                DataDeVencimento = comprovante.DataDeVencimento,
                ValorNominal = comprovante.ValorNominal,
                DataDoPagamento = comprovante.DataDoPagamento,
                ValorDoPagamento = comprovante.ValorDoPagamento,
                CodigoDoSegmento = comprovante.CodigoDoSegmento,
                NomeDoSegmento = comprovante.NomeDoSegmento,
                CodigoDoConvenio = comprovante.CodigoDoConvenio,
                NomeDoConvenio = comprovante.NomeDoConvenio,
                CodigoDoCanalDeProcessamento = comprovante.CodigoDoCanalDeProcessamento,
                NomeDoCanalDeProcessamento = comprovante.NomeDoCanalDeProcessamento,
                Data = comprovante.Data,
                TipoDeTransacao = comprovante.TipoDeTransacao,
                TipoDePagamento = comprovante.TipoDePagamento,
                ComprovanteDoLiquidante = comprovante.ComprovanteDoLiquidante
            };
        }
    }
}
