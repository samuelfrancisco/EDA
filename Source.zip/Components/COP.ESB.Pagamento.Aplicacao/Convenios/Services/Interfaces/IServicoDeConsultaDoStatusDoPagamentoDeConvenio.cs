﻿using COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels;
using COP.ESB.Pagamento.Dominio.Core;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.Services.Interfaces
{
    public interface IServicoDeConsultaDoStatusDoPagamentoDeConvenio
    {
        Task<Result<StatusDoPagamentoDeConvenioViewModel>> ObterStatusDoPagamentoPeloIdentificadorDoPagamentoNoClienteAsync(long empresaAplicacaoId, string identificadorDoPagamentoNoCliente);
    }
}
