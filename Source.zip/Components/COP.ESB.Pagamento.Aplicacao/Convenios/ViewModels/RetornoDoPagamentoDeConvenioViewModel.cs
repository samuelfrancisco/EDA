﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model com o retorno do pagamento de convênio
    /// </summary>
    public class RetornoDoPagamentoDeConvenioViewModel
    {
        /// <summary>
        /// Id do pagamento de convênio
        /// </summary>
        public Guid IdDoPagamentoDeConvenio { get; set; }

        /// <summary>
        /// Identificador do pagamento no cliente
        /// </summary>
        public string IdentificadorDoPagamentoNoCliente { get; set; }

        /// <summary>
        /// Status do pagaamento
        /// </summary>
        public string Status { get; set; }
    }
}
