﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model do status do pagamento de convênio
    /// </summary>
    public class StatusDoPagamentoDeConvenioViewModel
    {
        /// <summary>
        /// Id do pagamento
        /// </summary>
        public Guid IdDoPagamentoDeConvenio { get; set; }

        /// <summary>
        /// Identificador único do pagamento gerado pelo cliente, para ser utilizado em consultas posteriores.
        /// </summary>
        public string IdentificadorDoPagamentoNoCliente { get; set; }

        /// <summary>
        /// Status do pagamento
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Compovante do pagamento
        /// </summary>
        public StatusDoPagamentoDeConvenioComprovanteViewModel Comprovante { get; set; }
    }
}
