﻿using COP.ESB.Pagamento.Aplicacao.Core.Attributes;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model da forma de recebimento do pagamento
    /// </summary>
    public class IniciarNovoPagamentoDeConvenioFormaDeRecebimentoViewModel
    {
        /// <summary>
        /// Meio de pagamento
        /// </summary>
        [Required(ErrorMessage = "Meio de pagamento deve ter um dos seguintes valores: 1, 3, 4, 5 ou 6.")]
        [AcceptedValues(1, 3, 4, 5, 6, ErrorMessage = "Meio de pagamento deve ter um dos seguintes valores: 1, 3, 4, 5 ou 6.")]
        public int MeioDePagamento { get; set; }        

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        [Required(ErrorMessage = "Valor inválido.")]        
        public decimal Valor { get; set; }

        /// <summary>
        /// Tipo da conta do cartão
        /// </summary>
        [RequiredIf("MeioDePagamento", 3, ErrorMessage = "Tipo da conta do cartão deve estar entre 1 e 5.")]
        [Range(1, 5, ErrorMessage = "Tipo da conta do cartão deve estar entre 1 e 5.")]
        public int? TipoDaConta { get; set; }

        /// <summary>
        /// Modo de entrada da transação
        /// </summary>
        [RequiredIf("MeioDePagamento", 3, ErrorMessage = "Modo de entrada da transação deve estar entre 0 e 4.")]
        [Range(0, 4, ErrorMessage = "Modo de entrada da transação deve estar entre 0 e 4.")]
        public int? ModoDeEntradaDaTransacao { get; set; }

        /// <summary>
        /// Trilha 2 do cartão magnético
        /// </summary>
        [RequiredIf("MeioDePagamento", 3, ErrorMessage = "Informe a trilha 2 do cartão magnético.")]
        public string Trilha2DoCartaoMagnetico { get; set; }

        /// <summary>
        /// CVV2
        /// </summary>
        [RequiredIf("MeioDePagamento", 3, ErrorMessage = "Informe o CVV2 do cartão de crédito.")]
        public string CVV2 { get; set; }

        /// <summary>
        /// Número de série do PINPAD
        /// </summary>
        [RequiredIf("MeioDePagamento", 3, ErrorMessage = "Informe o número de série do PINPAD.")]
        public string NumeroDeSerieDoPINPAD { get; set; }

        /// <summary>
        /// Tipo de captura do cheque
        /// </summary>
        [Range(0, 1, ErrorMessage = "Tipo de captura do cheque deve estar entre 0 e 1.")]
        [RequiredIf("MeioDePagamento", 4, ErrorMessage = "Tipo de captura do cheque deve estar entre 0 e 1.")]
        public int? TipoDeCapturaDoCheque { get; set; }

        /// <summary>
        /// Dados do cheque (CMC7)
        /// </summary>
        [RequiredIf("MeioDePagamento", 4, ErrorMessage = "Informe o CMC7 do cheque.")]
        public string DadosDoCheque { get; set; }        
    }
}
