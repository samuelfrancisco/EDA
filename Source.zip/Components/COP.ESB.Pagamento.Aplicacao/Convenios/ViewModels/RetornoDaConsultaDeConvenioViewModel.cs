﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model do retorno da consulta de convênio
    /// </summary>
    public class RetornoDaConsultaDeConvenioViewModel
    {
        /// <summary>
        /// Id da consulta
        /// </summary>
        public Guid IdDaConsultaDeConvenio { get; set; }

        /// <summary>
        /// Código do segmento de convênio
        /// </summary>
        public string CodigoDoSegmento { get; set; }

        /// <summary>
        /// Nome do segmento de convênio
        /// </summary>
        public string NomeDoSegmento { get; set; }

        /// <summary>
        /// Código do convênio
        /// </summary>
        public string CodigoDoConvenio { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        public string NomeDoConvenio { get; set; }

        /// <summary>
        /// Valor do documento
        /// </summary>
        public string Valor { get; set; }

        /// <summary>
        /// Data de vencimento do documento
        /// </summary>
        public string DataDeVencimento { get; set; }
    }
}
