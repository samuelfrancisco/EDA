﻿using System;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model do comprovante do pagamento de convênio
    /// </summary>
    public class StatusDoPagamentoDeConvenioComprovanteViewModel
    {
        /// <summary>
        /// Id do Convenio
        /// </summary>
        public Guid IdDoConvenio { get; set; }

        /// <summary>
        /// Id da consulta de convênio
        /// </summary>
        public Guid IdDaConsultaDeConvenio { get; set; }

        /// <summary>
        /// Id do pagamento de convênio
        /// </summary>
        public Guid IdDoPagamentoDeConvenio { get; set; }

        /// <summary>
        /// Id do comprovante pagamento de convênio
        /// </summary>
        public Guid IdDoComprovanteDoPagamentoDeConvenio { get; set; }

        /// <summary>
        /// Id da Empresa X Aplicação
        /// </summary>
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Id da Empresa X Aplicação X Transação
        /// </summary>
        public long EmpresaAplicacaoTransacaoId { get; set; }

        /// <summary>
        /// Código da coligada
        /// </summary>
        public string CodigoDaColigada { get; set; }

        /// <summary>
        /// Código da agência
        /// </summary>
        public string CodigoDaAgencia { get; set; }

        /// <summary>
        /// Número da conta corrente
        /// </summary>
        public string NumeroDaContaCorrente { get; set; }     

        /// <summary>
        /// Documento do pagador final
        /// </summary>
        public string DocumentoDoPagadorFinal { get; set; }

        /// <summary>
        /// Nome do pagador final
        /// </summary>
        public string NomeDoPagadorFinal { get; set; }

        /// <summary>
        /// Código de barras do boleto
        /// </summary>
        public string CodigoDeBarrasDoConvenio { get; set; }

        /// <summary>
        /// Linha digitável do boleto
        /// </summary>
        public string LinhaDigitavelDoConvenio { get; set; }

        /// <summary>
        /// Data de vencimento do boleto
        /// </summary>
        public DateTime? DataDeVencimento { get; set; }

        /// <summary>
        /// Valor nominal do boleto
        /// </summary>
        public decimal? ValorNominal { get; set; }        

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Data do pagamento
        /// </summary>
        public DateTimeOffset DataDoPagamento { get; set; }

        /// <summary>
        /// Data da geração do comprovante
        /// </summary>
        public DateTimeOffset Data { get; set; }

        /// <summary>
        /// Tipo de transação
        /// </summary>
        public string TipoDeTransacao { get; set; }

        /// <summary>
        /// Tipo de pagamento
        /// </summary>
        public string TipoDePagamento { get; set; }

        /// <summary>
        /// Código do segmento
        /// </summary>
        public string CodigoDoSegmento { get; set; }

        /// <summary>
        /// Nome do segmento
        /// </summary>
        public string NomeDoSegmento { get; set; }

        /// <summary>
        /// Código do convênio
        /// </summary>
        public string CodigoDoConvenio { get; set; }

        /// <summary>
        /// Nome do convênio
        /// </summary>
        public string NomeDoConvenio { get; set; }

        /// <summary>
        /// Código do canal de processamento
        /// </summary>
        public string CodigoDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Nome do canal de processamento
        /// </summary>
        public string NomeDoCanalDeProcessamento { get; set; }

        /// <summary>
        /// Comprovante do Corban
        /// </summary>
        public string ComprovanteDoLiquidante { get; set; }
    }
}
