﻿using COP.ESB.Pagamento.Aplicacao.Core.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace COP.ESB.Pagamento.Aplicacao.Convenios.ViewModels
{
    /// <summary>
    /// View model para iniciar um novo pagamento de convênio
    /// </summary>
    [SummaryCollectionValidation("ValorDoPagamento", "FormasDeRecebimento", "Valor", ErrorMessage = "O total recebido deve ser igual ao informado no campo valor do pagamento.")]
    public class IniciarNovoPagamentoDeConvenioViewModel
    {
        /// <summary>
        /// Id da Empresa x Aplicação.
        /// </summary>
        [Required(ErrorMessage = "Empresa x Aplicação inválida.")]
        public long EmpresaAplicacaoId { get; set; }

        /// <summary>
        /// Identificador da consulta associada ao pagamento.
        /// </summary>
        [Required(ErrorMessage = "Id da consulta inválido.")]
        public Guid IdDaConsultaDeConvenio { get; set; }

        /// <summary>
        /// Identificador único do pagamento gerado pelo cliente, para ser utilizado em consultas posteriores.
        /// </summary>
        [Required(ErrorMessage = "Identificador único do pagamento inválido.")]
        [MaxLength(255, ErrorMessage = "O identificador único do pagamento de ter no máximo 255 caracteres.")]
        public string IdentificadorDoPagamentoNoCliente { get; set; }

        /// <summary>
        /// Valor do pagamento
        /// </summary>
        [Required(ErrorMessage = "Valor do pagamento inválido.")]
        public decimal ValorDoPagamento { get; set; }

        /// <summary>
        /// Canal do pagamento
        /// </summary>
        [Required(ErrorMessage = "Canal do pagamento deve estar entre 1 e 8.")]
        [Range(1, 8, ErrorMessage = "Canal do pagamento deve estar entre 1 e 8.")]
        public int CanalDoPagamento { get; set; }        

        /// <summary>
        /// Formas de recebimento do valor do pagamento
        /// </summary>
        [Required(ErrorMessage = "Informar pelo menos uma forma de recebimento.")]
        [EnsureMinimumElements(1, ErrorMessage = "Informar pelo menos uma forma de recebimento.")]
        public IEnumerable<IniciarNovoPagamentoDeConvenioFormaDeRecebimentoViewModel> FormasDeRecebimento { get; set; } = new List<IniciarNovoPagamentoDeConvenioFormaDeRecebimentoViewModel>();

        /// <summary>
        /// Flag indicando de devem ser aceitos pagamentos em duplicidade
        /// </summary>
        [Required(ErrorMessage = "Informar se S para aceitar pagamentos em duplicidade ou N para não aceitar.")]
        public string AceitaDuplicidade { get; set; }

        /// <summary>
        /// Documento do pagador (CPF ou CNPJ)
        /// </summary>
        [MaxLength(255, ErrorMessage = "O documento do pagador deve ter no máximo 255 caracteres.")]
        public string DocumentoDoPagadorInformadoPeloCliente { get; set; }

        /// <summary>
        /// Nome do pagador
        /// </summary>
        [MaxLength(255, ErrorMessage = "O nome do pagador deve ter no máximo 255 caracteres.")]
        public string NomeDoPagadorInformadoPeloCliente { get; set; }
    }
}
