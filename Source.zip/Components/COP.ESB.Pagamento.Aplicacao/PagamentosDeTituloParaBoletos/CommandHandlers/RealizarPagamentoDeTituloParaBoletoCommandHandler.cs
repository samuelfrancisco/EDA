﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.DTOs;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagamentosDeTituloParaBoletos.CommandHandlers
{
    public class RealizarPagamentoDeTituloParaBoletoCommandHandler
        : CommandRequestHandler<RealizarPagamentoDeTituloParaBoletoCommandV2>
    {
        private readonly IPagamentoDeTituloParaBoletoRepository _pagamentoDeTituloParaBoletoRepository;
        private readonly IServicoDePagamentoDeTitulo _servicoDePagamentoDeTitulo;

        public RealizarPagamentoDeTituloParaBoletoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IPagamentoDeTituloParaBoletoRepository pagamentoDeTituloParaBoletoRepository,
            IServicoDePagamentoDeTitulo servicoDePagamentoDeTitulo)
            : base(commandHandlerRepository)
        {
            _pagamentoDeTituloParaBoletoRepository = pagamentoDeTituloParaBoletoRepository;
            _servicoDePagamentoDeTitulo = servicoDePagamentoDeTitulo;
        }

        protected override async Task DoHandleAsync(RealizarPagamentoDeTituloParaBoletoCommandV2 command, CancellationToken cancellationToken)
        {
            PagamentoDeTituloParaBoleto pagamentoDeTitulo;

            var result = await _servicoDePagamentoDeTitulo.PagarTituloAsync(new PagamentoDeTituloDTO
            {
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                CodigoDeBarrasDoBoleto = command.CodigoDeBarrasDoBoleto,
                CodigoDaColigada = command.CodigoDaColigada,
                CodigoDaAgencia = command.CodigoDaAgencia,
                NumeroDaContaCorrente = command.NumeroDaContaCorrente,
                TipoDePessoaDoPagadorFinal = command.TipoDePessoaDoPagadorFinal,
                DocumentoDoPagadorFinal = !string.IsNullOrWhiteSpace(command.DocumentoDoPagadorFinal)
                    ? command.TipoDePessoaDoPagadorFinal == "J" ? command.DocumentoDoPagadorFinal.PadLeft(14, '0') : command.DocumentoDoPagadorFinal.PadLeft(11, '0')
                    : null,
                TipoDePessoaDoBeneficiario = command.TipoDePessoaDoBeneficiario,
                DocumentoDoBeneficiario = !string.IsNullOrWhiteSpace(command.DocumentoDoBeneficiario) 
                    ? command.TipoDePessoaDoBeneficiario == "J" ? command.DocumentoDoBeneficiario.PadLeft(14, '0') : command.DocumentoDoBeneficiario.PadLeft(11, '0')
                    : null,
                ValorDoPagamento = command.ValorDoPagamento,
                DataDoPagamento = command.DataDoPagamento,
                Encargos = command.Encargos,
                Descontos = command.Descontos,
                Abatimento = command.Abatimento,
                CanalDoPagamento = command.CanalDoPagamento,
                MeioDePagamento = command.MeioDePagamento,
                DebitarContaCorrente = command.DebitarContaCorrente,
                ValidarSaldoDaContaCorrente = command.ValidarSaldoDaContaCorrente,
                FoiRealizadoEmContingencia = command.FoiRealizadoEmContingencia,
            }).ConfigureAwait(false);

            if (result.IsFailure)
            {
                pagamentoDeTitulo = new PagamentoDeTituloParaBoleto(command, codigoDeErro: result.ErroMessage.StatusCode, descricaoDoErro: result.ErroMessage.Message);

                await _pagamentoDeTituloParaBoletoRepository.SaveAsync(pagamentoDeTitulo, command.Id).ConfigureAwait(false);

                return;
            }

            pagamentoDeTitulo = new PagamentoDeTituloParaBoleto(command, codigoDeErro: 0);

            await _pagamentoDeTituloParaBoletoRepository.SaveAsync(pagamentoDeTitulo, command.Id).ConfigureAwait(false);
        }
    }
}
