﻿using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.DebitosDeContaCorrente.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Commands;
using COP.ESB.Pagamento.Dominio.PagamentosDeTituloParaBoletos.Repositories.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.PagamentosDeTituloParaBoletos.CommandHandlers
{
    public class RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandHandler
        : CommandRequestHandler<RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2>
    {
        private readonly IPagamentoDeTituloParaBoletoRepository _pagamentoDeTituloParaBoletoRepository;
        private readonly IServicoDeDebitoDeContaCorrente _servicoDeDebitoDeContaCorrente;

        public RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IPagamentoDeTituloParaBoletoRepository pagamentoDeTituloParaBoletoRepository,
            IServicoDeDebitoDeContaCorrente servicoDeDebitoDeContaCorrente)
            : base(commandHandlerRepository)
        {
            _pagamentoDeTituloParaBoletoRepository = pagamentoDeTituloParaBoletoRepository;
            _servicoDeDebitoDeContaCorrente = servicoDeDebitoDeContaCorrente;
        }

        protected override async Task DoHandleAsync(RegistrarPagamentoDeTituloParaBoletoConcluidoComErroCommandV2 command, CancellationToken cancellationToken)
        {
            var debito = new PagamentoDeTituloParaBoleto(command);

            await _pagamentoDeTituloParaBoletoRepository.SaveAsync(debito, command.Id).ConfigureAwait(false);            
        }
    }
}
