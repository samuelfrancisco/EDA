﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Titulares.Events
{
    public class InformacoesDoTitularAtualizadas : IntegrationEvent
    {
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }
        public string NROCONTA { get; set; }
        public string CGC_CPF { get; set; }
        public string SEQUENCIA { get; set; }
        public string CODCLIENTE { get; set; }
        public string TITULARIDADE { get; set; }
        public short? SENHA { get; set; }
        public string NROCARTAO { get; set; }
        public string STATUS { get; set; }
        public string ENVIAR_CC { get; set; }
        public string CODUSUARIO { get; set; }
        public DateTime? DATAATU { get; set; }
        public string TIPOCCS { get; set; }
        public string NROLIG { get; set; }
        public string IBAN { get; set; }
    }
}
