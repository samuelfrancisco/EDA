﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Titulares.Events
{
    public class TitularRemovido : IntegrationEvent
    {
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }
        public string NROCONTA { get; set; }
        public string CGC_CPF { get; set; }
        public string SEQUENCIA { get; set; }
        public string CODCLIENTE { get; set; }
    }
}
