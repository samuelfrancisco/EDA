﻿using COP.ESB.Pagamento.Aplicacao.Titulares.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Titulares;
using COP.ESB.Pagamento.Dominio.Titulares.Repositories.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Titulares.Denormalizers
{
    public class TitularDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovoTitularRegistrado>,
        IAsyncEventHandler<InformacoesDoTitularAtualizadas>,
        IAsyncEventHandler<TitularRemovido>
    {
        private readonly ITitularRepository _titularRepository;

        public TitularDenormalizer(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ITitularRepository titularRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _titularRepository = titularRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovoTitularRegistrado> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovoTitularRegistrado @event, CancellationToken cancellationToken)
        {
            var titular = await _titularRepository.ObterPelaContaDocumentoCodigoESequenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA, @event.NROCONTA,
                @event.CGC_CPF, @event.CODCLIENTE, @event.SEQUENCIA)
                .ConfigureAwait(false);

            if (titular != null)
                return;

            titular = new Titular
            {
                Cgc_Cpf = @event.CGC_CPF,
                CodigoDaAgencia = @event.CODAGENCIA,
                CodigoDoCliente = @event.CODCLIENTE,
                CodigoDaColigada = @event.CODCOLIGADA,
                NumeroDaContaCorrente = @event.NROCONTA,
                Sequencia = @event.SEQUENCIA,
                Titularidade = @event.TITULARIDADE
            };

            await _titularRepository.SaveAsync(titular).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<InformacoesDoTitularAtualizadas> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformacoesDoTitularAtualizadas @event, CancellationToken cancellationToken)
        {
            var titular = await _titularRepository.ObterPelaContaDocumentoCodigoESequenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA, @event.NROCONTA,
                @event.CGC_CPF, @event.CODCLIENTE, @event.SEQUENCIA)
                .ConfigureAwait(false);

            if (titular == null)
                return;

            titular.Titularidade = @event.TITULARIDADE;
        }

        public Task HandleAsync(IEventEnvelop<TitularRemovido> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(TitularRemovido @event, CancellationToken cancellationToken)
        {
            var titular = await _titularRepository.ObterPelaContaDocumentoCodigoESequenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA, @event.NROCONTA,
                @event.CGC_CPF, @event.CODCLIENTE, @event.SEQUENCIA)
                .ConfigureAwait(false);

            if (titular == null)
                return;

            titular.Disable();
        }
    }
}
