﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;

namespace COP.ESB.Pagamento.Aplicacao.Agencias.Events
{
    public class AgenciaRemovida : IntegrationEvent
    {
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }       
    }
}
