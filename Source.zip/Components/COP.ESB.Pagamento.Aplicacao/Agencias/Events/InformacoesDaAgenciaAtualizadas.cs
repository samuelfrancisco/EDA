﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Aplicacao.Agencias.Events
{
    public class InformacoesDaAgenciaAtualizadas : IntegrationEvent
    {
        public string CODCOLIGADA { get; set; }
        public string CODAGENCIA { get; set; }
        public string NOME { get; set; }
        public string CODPRACA { get; set; }
        public string CODCAMARA { get; set; }
        public string CGC { get; set; }
        public string ENDERECO { get; set; }
        public string COMPLEMENTO { get; set; }
        public string BAIRRO { get; set; }
        public string CIDADE { get; set; }
        public string UF { get; set; }
        public string CEP { get; set; }
        public string TELEFONE { get; set; }
        public string FAX { get; set; }
        public string NOMEUSUARIO { get; set; }
        public string CODGERENTE { get; set; }
        public DateTime? DATAATUALIZACAO { get; set; }
        public string INDEXTERIOR { get; set; }
        public string CODCCUSTO { get; set; }
        public DateTime? DATAINCLUSAO { get; set; }
        public string USUARIOINCLUSAO { get; set; }
        public DateTime? DATAINICIO { get; set; }
        public DateTime? DATAFIM { get; set; }
    }
}
