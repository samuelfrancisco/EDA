﻿using COP.ESB.Pagamento.Aplicacao.Agencias.Events;
using COP.ESB.Pagamento.Dominio.Agencias;
using COP.ESB.Pagamento.Dominio.Agencias.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Agencias.Denormalizers
{
    public class AgenciaDenormalizer : PrimaryEventHandler,
        IAsyncEventHandler<NovaAgenciaRegistrada>,
        IAsyncEventHandler<InformacoesDaAgenciaAtualizadas>,
        IAsyncEventHandler<AgenciaRemovida>
    {
        private readonly IAgenciaRepository _agenciaRepository;

        public AgenciaDenormalizer(IUnitOfWork unitOfWork, IEventHandlerRepository eventHandlerRepository,
            IAgenciaRepository agenciaRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _agenciaRepository = agenciaRepository;
        }

        public Task HandleAsync(IEventEnvelop<NovaAgenciaRegistrada> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(NovaAgenciaRegistrada @event, CancellationToken cancellationToken)
        {
            var agencia = await _agenciaRepository.ObterAgenciaPeloCodColigadaECodAgenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA).ConfigureAwait(false);

            if (agencia != null)
                return;

            agencia = new Agencia { CodColigada = @event.CODCOLIGADA, CodAgencia = @event.CODAGENCIA, Nome = @event.NOME, CodPraca = @event.CODPRACA  };

            await _agenciaRepository.SaveAsync(agencia).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<InformacoesDaAgenciaAtualizadas> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformacoesDaAgenciaAtualizadas @event, CancellationToken cancellationToken)
        {
            var agencia = await _agenciaRepository.ObterAgenciaPeloCodColigadaECodAgenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA).ConfigureAwait(false);

            if (agencia == null)
                return;

            agencia.Nome = @event.NOME;
            agencia.Active = true;

            await _agenciaRepository.SaveAsync(agencia).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<AgenciaRemovida> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(AgenciaRemovida @event, CancellationToken cancellationToken)
        {
            var agencia = await _agenciaRepository.ObterAgenciaPeloCodColigadaECodAgenciaAsync(@event.CODCOLIGADA, @event.CODAGENCIA).ConfigureAwait(false);

            if (agencia == null)
                return;

            agencia.Disable();

            await _agenciaRepository.SaveAsync(agencia).ConfigureAwait(false);
        }
    }
}
