﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Commands;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.SaldoDisponivel.CommandHandlers
{
    public class ReservarValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommandHandler 
        : CommandRequestHandler<ReservarValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommand>
    {
        private readonly ISaldoDisponivelDoCorbanRepository _saldoDisponivelDoCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public ReservarValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ISaldoDisponivelDoCorbanRepository saldoDisponivelDoCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _saldoDisponivelDoCorbanRepository = saldoDisponivelDoCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(ReservarValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommand command, 
            CancellationToken cancellationToken)
        {
            var saldoDisponivel = await _saldoDisponivelDoCorbanRepository.ObterPelaDataContabilAsync(command.DataContabil)
                .ConfigureAwait(false);

            if (saldoDisponivel == null)
            {
                var corban = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDosCanaisDeProcessamento
                    ?.FirstOrDefault(x => x.Codigo.ToUpper() == CodigosDosCanaisDeProcessamento.CORBAN);                

                var configuracoesDeRepasse = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDeRepasse
                    ?.FirstOrDefault(x => x.IdDoCanalDeProcessamento == corban?.Id);                

                saldoDisponivel = SaldoDisponivelDoCorban.IniciarSaldoDisponivelDoCorban(new IniciarSaldoDisponivelDoCorbanCommand
                {
                    DataContabil = command.DataContabil,
                    LimiteMaximoDiarioDeOperacoes = configuracoesDeRepasse?.LimiteMaximoDiarioDeOperacoes,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }

            saldoDisponivel.ReservarValorDoPagamento(command, _configuracoesDoMotorService);

            await _saldoDisponivelDoCorbanRepository.SaveAsync(saldoDisponivel, command.Id).ConfigureAwait(false);
        }
    }
}
