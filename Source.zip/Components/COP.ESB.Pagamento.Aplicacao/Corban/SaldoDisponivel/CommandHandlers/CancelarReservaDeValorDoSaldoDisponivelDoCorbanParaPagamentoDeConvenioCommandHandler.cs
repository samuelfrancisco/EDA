﻿using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Commands;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.SaldoDisponivel.CommandHandlers
{
    public class CancelarReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommandHandler
        : CommandRequestHandler<CancelarReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommand>
    {
        private readonly ISaldoDisponivelDoCorbanRepository _saldoDisponivelDoCorbanRepository;        

        public CancelarReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ISaldoDisponivelDoCorbanRepository saldoDisponivelDoCorbanRepository)
            : base(commandHandlerRepository)
        {
            _saldoDisponivelDoCorbanRepository = saldoDisponivelDoCorbanRepository;            
        }

        protected override async Task DoHandleAsync(CancelarReservaDeValorDoSaldoDisponivelDoCorbanParaPagamentoDeConvenioCommand command, 
            CancellationToken cancellationToken)
        {
            var saldoDisponivel = await _saldoDisponivelDoCorbanRepository.ObterPelaDataContabilAsync(command.DataContabil)
                .ConfigureAwait(false);

            if (saldoDisponivel == null)
                return;

            saldoDisponivel.CancelarReservaDoValorDoPagamento(command);

            await _saldoDisponivelDoCorbanRepository.SaveAsync(saldoDisponivel, command.Id).ConfigureAwait(false);
        }
    }
}
