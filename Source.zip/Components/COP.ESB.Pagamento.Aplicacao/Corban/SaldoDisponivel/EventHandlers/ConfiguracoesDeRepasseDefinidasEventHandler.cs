﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Events;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Commands;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.SaldoDisponivel.EventHandlers
{
    public class ConfiguracoesDeRepasseDefinidasEventHandler : PrimaryEventHandler, IInternalAsyncEventHandler<ConfiguracoesDeRepasseDefinidasEvent>
    {
        private readonly ISaldoDisponivelDoCorbanRepository _saldoDisponivelDoCorbanRepository;

        public ConfiguracoesDeRepasseDefinidasEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISaldoDisponivelDoCorbanRepository saldoDisponivelDoCorbanRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _saldoDisponivelDoCorbanRepository = saldoDisponivelDoCorbanRepository;
        }

        public Task HandleAsync(IEventEnvelop<ConfiguracoesDeRepasseDefinidasEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ConfiguracoesDeRepasseDefinidasEvent @event, CancellationToken cancellationToken)
        {
            var dataContabil = @event.Date.Date;

            var saldoDisponivel = await _saldoDisponivelDoCorbanRepository.ObterPelaDataContabilAsync(dataContabil)
                .ConfigureAwait(false);

            if (saldoDisponivel == null)
                return;

            var command = new AlterarLimiteMaximoDiarioDeOperacoesDoSaldoDisponivelDoCorbanCommand
            {
                DataContabil = dataContabil,
                LimiteMaximoDiarioDeOperacoes = @event.LimiteMaximoDiarioDeOperacoes,
                CorrelationMessage = @event,
                OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
            };

            saldoDisponivel.AlterarLimiteMaximoDiarioDeOperacoes(command);

            await _saldoDisponivelDoCorbanRepository.SaveAsync(saldoDisponivel, command.Id).ConfigureAwait(false);
        }
    }
}
