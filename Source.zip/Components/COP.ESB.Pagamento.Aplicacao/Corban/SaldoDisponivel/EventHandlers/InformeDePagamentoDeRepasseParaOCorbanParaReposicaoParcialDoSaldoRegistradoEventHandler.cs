﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Events;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Commands;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.SaldoDisponivel.EventHandlers
{
    public class InformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoRegistradoEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<InformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoRegistradoEvent>
    {
        private readonly ISaldoDisponivelDoCorbanRepository _saldoDisponivelDoCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public InformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoRegistradoEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISaldoDisponivelDoCorbanRepository saldoDisponivelDoCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _saldoDisponivelDoCorbanRepository = saldoDisponivelDoCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        public Task HandleAsync(IEventEnvelop<InformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoRegistradoEvent> envelop,
                CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(InformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoRegistradoEvent @event, 
            CancellationToken cancellationToken)
        {
            var dataContabil = @event.Date.Date;

            var command = new RegistrarReposicaoParcialDoSaldoDisponivelDoCorbanCommand
            {
                DataContabil = dataContabil,
                IdDoInformeDePagamentoDeRepasseParaOCorban = @event.SourceId,
                DataDoPagamento = @event.Date,
                ValorDoPagamento = @event.ValorDoPagamento,
                CorrelationMessage = @event,
                OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
            };

            var saldoDisponivel = await _saldoDisponivelDoCorbanRepository.ObterPelaDataContabilAsync(dataContabil)
                .ConfigureAwait(false);

            if (saldoDisponivel == null)
            {
                var corban = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDosCanaisDeProcessamento
                    ?.FirstOrDefault(x => x.Codigo.ToUpper() == CodigosDosCanaisDeProcessamento.CORBAN);

                var configuracoesDeRepasse = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDeRepasse
                    ?.FirstOrDefault(x => x.IdDoCanalDeProcessamento == corban?.Id);

                saldoDisponivel = SaldoDisponivelDoCorban.IniciarSaldoDisponivelDoCorban(new IniciarSaldoDisponivelDoCorbanCommand
                {
                    DataContabil = dataContabil,
                    LimiteMaximoDiarioDeOperacoes = configuracoesDeRepasse?.LimiteMaximoDiarioDeOperacoes,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }            

            saldoDisponivel.RegistrarReposicaoParcialDoSaldoDisponivel(command);

            await _saldoDisponivelDoCorbanRepository.SaveAsync(saldoDisponivel, command.Id).ConfigureAwait(false);
        }
    }
}
