﻿using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.SaldoDisponivel.EventHandlers
{
    public class ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEvent>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEvent> envelop,
            CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEvent @event, CancellationToken cancellationToken)
        {
            var corban = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDosCanaisDeProcessamento
                            ?.FirstOrDefault(x => x.Active && x.Codigo.ToUpper() == CodigosDosCanaisDeProcessamento.CORBAN);

            if (corban == null)
                return;

            var configuracaoDeRepasse = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDeRepasse
                        ?.FirstOrDefault(x => x.Active && x.IdDoCanalDeProcessamento == corban.Id);

            if (configuracaoDeRepasse == null)
                return;

            var to = configuracaoDeRepasse.EmailParaNotificacao?.Split(';');

            if (to?.Any() != true) return;

            var assunto = "ALERTA – Consumo do Limite Diário de Repasse";

            var corpoDoEmail = await GerarCorpoDoEmail(corban, @event, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConfiguracoesDoCanalDeProcessamento corban,
            ValorDoSaldoDisponivelDoCorbanAtingiuOValorDoSegundoAlertaEvent @event, string assuntoDoEmail)
        {
            var currentCulture = Thread.CurrentThread.CurrentCulture;

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var model = new AlertaDeConsumoDoLimiteDiarioDeRepasseDTO
            {
                Logo = "cid:logo.png",
                TituloDoEmail = assuntoDoEmail,
                TituloDoCabecalho = "ALERTA – Consumo do Limite Diário de Repasse",
                CodigoDoCanal = corban.Codigo,
                NomeDoCanal = corban.Nome,
                DataEHora = @event.Date.ToString("dd/MM/yyyy HH:mm:ss"),
                LimiteMaximoDiarioDeOperacoes = @event.LimiteMaximoDiarioDeOperacoes.ToString("C2"),
                SaldoDisponivel = @event.SaldoDisponivel.ToString("C2")
            };

            Thread.CurrentThread.CurrentCulture = new CultureInfo(currentCulture.Name);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\AlertaDeConsumoDoLimiteDiarioDeRepasse.cshtml");

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
