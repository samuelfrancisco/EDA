﻿using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Constants;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Events;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.TransacoesAgendadas.EventHandlers
{
    public class TransacaoCorbanAgendadaConcluidaComErroEventHandler : EventNotificationHandler<TransacaoCorbanAgendadaConcluidaComErroEvent>
    {
        private readonly IEventNotificationBus _eventNotificationBus;

        public TransacaoCorbanAgendadaConcluidaComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            IEventNotificationBus eventNotificationBus) 
            : base(eventHandlerRepository)
        {
            _eventNotificationBus = eventNotificationBus;
        }

        protected override async Task DoHandleAsync(TransacaoCorbanAgendadaConcluidaComErroEvent @event, CancellationToken cancellationToken)
        {
            switch (@event.TipoDaTransacao)
            {
                case TiposDeTransacaoCorban.CONSULTA_DE_CODIGO_DE_BARRAS:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanAgendadaDeConsultaDeCodigoDeBarrasConcluidaComErroEvent
                        {
                            IdDoAgendamento = @event.IdDoAgendamento,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeErro = @event.CodigoDeErro,
                            DescricaoDoErro = @event.DescricaoDoErro,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.CONSULTA_DE_PAGAMENTO:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanAgendadaDeConsultaDePagamentoConcluidaComErroEvent
                        {
                            IdDoAgendamento = @event.IdDoAgendamento,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeErro = @event.CodigoDeErro,
                            DescricaoDoErro = @event.DescricaoDoErro,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.PAGAMENTO:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanAgendadaDePagamentoConcluidaComErroEvent
                        {
                            IdDoAgendamento = @event.IdDoAgendamento,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeErro = @event.CodigoDeErro,
                            DescricaoDoErro = @event.DescricaoDoErro,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.FECHAMENTO_DE_REPASSE:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanAgendadaDeFechamentoDeRepasseConcluidaComErroEvent
                        {
                            IdDoAgendamento = @event.IdDoAgendamento,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeErro = @event.CodigoDeErro,
                            DescricaoDoErro = @event.DescricaoDoErro,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                default:
                    break;
            }
        }
    }
}
