﻿using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Commands;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Factories;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.TransacoesAgendadas.CommandHandlers
{
    public class AgendarTransacaoCorbanDeFechamentoDeRepasseCommandHandler : CommandRequestHandler<AgendarTransacaoCorbanDeFechamentoDeRepasseCommand>
    {
        private readonly ITransacaoCorbanAgendadaRepository _transacaoAgendadaRepository;

        public AgendarTransacaoCorbanDeFechamentoDeRepasseCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ITransacaoCorbanAgendadaRepository transacaoAgendadaRepository)
            : base(commandHandlerRepository)
        {
            _transacaoAgendadaRepository = transacaoAgendadaRepository;
        }

        protected override async Task DoHandleAsync(AgendarTransacaoCorbanDeFechamentoDeRepasseCommand command, CancellationToken cancellationToken)
        {
            var transacaoAgendada = await _transacaoAgendadaRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento).ConfigureAwait(false);

            if (transacaoAgendada != null)
                throw new InvalidOperationException($"Já existe uma transação agendada com o agendamento {command.IdDoAgendamento}.");

            var transacao = new TransacaoCorbanAgendadaDeFechamentoDeRepasse(command);

            transacaoAgendada = new TransacaoCorbanAgendada(transacao.IdDoAgendamento, transacao.IdentificacaoDoTerminal, transacao.DataDeProcessamento,
                transacao.TipoDaTransacao, TransacaoCorbanAgendadaPayloadFactory.To(transacao));

            await _transacaoAgendadaRepository.SaveAsync(transacaoAgendada).ConfigureAwait(false);
        }
    }
}
