﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.Pagamentos;
using COP.ESB.Pagamento.Dominio.Corban.Pagamentos.Commands;
using COP.ESB.Pagamento.Dominio.Corban.Pagamentos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Pagamentos.CommandHandlers
{
    public class IniciarPagamentoPeloCorbanCommandHandler : CommandRequestHandler<IniciarPagamentoPeloCorbanCommand>
    {
        private readonly IPagamentoPeloCorbanRepository _pagamentoPeloCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public IniciarPagamentoPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IPagamentoPeloCorbanRepository pagamentoPeloCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _pagamentoPeloCorbanRepository = pagamentoPeloCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(IniciarPagamentoPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var pagamento = await _pagamentoPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (pagamento != null)
                throw new InvalidOperationException($"Já existe um pagamento com o agendamento {command.IdDoAgendamento}.");

            pagamento = PagamentoPeloCorban.IniciarPagamentoPeloCorban(command, _configuracoesDoMotorService);

            await _pagamentoPeloCorbanRepository.SaveAsync(pagamento, command.Id).ConfigureAwait(false);
        }
    }
}
