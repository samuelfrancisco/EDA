﻿using COP.ESB.Pagamento.Dominio.Corban.Pagamentos.Commands;
using COP.ESB.Pagamento.Dominio.Corban.Pagamentos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Pagamentos.CommandHandlers
{
    public class ConcluirPagamentoPeloCorbanComErroNoEnvioCommandHandler
        : CommandRequestHandler<ConcluirPagamentoPeloCorbanComErroNoEnvioCommand>
    {
        private readonly IPagamentoPeloCorbanRepository _consultaDePagamentoPeloCorbanRepository;

        public ConcluirPagamentoPeloCorbanComErroNoEnvioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IPagamentoPeloCorbanRepository consultaDePagamentoPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _consultaDePagamentoPeloCorbanRepository = consultaDePagamentoPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(ConcluirPagamentoPeloCorbanComErroNoEnvioCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDePagamentoPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta == null)
                throw new InvalidOperationException($"Não existe um pagamento com o agendamento {command.IdDoAgendamento}.");

            consulta.ConcluirComErroNoEnvio(command);

            await _consultaDePagamentoPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
