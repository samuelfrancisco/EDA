﻿using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class RecusarLiquidacaoDePagamentoDeConvenioPeloCorbanCommandHandler  
        : CommandRequestHandler<RecusarLiquidacaoDePagamentoDeConvenioPeloCorbanCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloCorbanRepository _liquidacaoDePagamentoDeConvenioPeloCorbanRepository;

        public RecusarLiquidacaoDePagamentoDeConvenioPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloCorbanRepository liquidacaoDePagamentoDeConvenioPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloCorbanRepository = liquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(RecusarLiquidacaoDePagamentoDeConvenioPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloCorbanRepository.GetByIdAsync(command.IdDaLiquidacaoDePagamentoDeConvenioPeloCorban)
                .ConfigureAwait(false);

            if (liquidacao == null)
                throw new InvalidOperationException($"Liquidação do pagamento de convênio {command.IdDaLiquidacaoDePagamentoDeConvenioPeloCorban} não encontrada.");

            liquidacao.Recusar(command);

            await _liquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
