﻿using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.LiquidacoesDePagamentosDeConvenios.CommandHandlers
{
    public class IniciarLiquidacaoDePagamentoDeConvenioPeloCorbanCommandHandler 
        : CommandRequestHandler<IniciarLiquidacaoDePagamentoDeConvenioPeloCorbanCommand>
    {
        private readonly ILiquidacaoDePagamentoDeConvenioPeloCorbanRepository _liquidacaoDePagamentoDeConvenioPeloCorbanRepository;

        public IniciarLiquidacaoDePagamentoDeConvenioPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            ILiquidacaoDePagamentoDeConvenioPeloCorbanRepository liquidacaoDePagamentoDeConvenioPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _liquidacaoDePagamentoDeConvenioPeloCorbanRepository = liquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(IniciarLiquidacaoDePagamentoDeConvenioPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var liquidacao = await _liquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if(liquidacao != null)
                throw new InvalidOperationException($"Já existe uma liquidação para o pagamento de convênio {command.IdDoPagamentoDeConvenio}.");

            liquidacao = LiquidacaoDePagamentoDeConvenioPeloCorban.IniciarLiquidacaoDePagamentoDeConvenioPeloCorban(command);

            await _liquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(liquidacao, command.Id).ConfigureAwait(false);
        }
    }
}
