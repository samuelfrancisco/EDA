﻿using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Constants;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesEnviadas.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.TransacoesEnviadas.EventHandlers
{
    public class TransacaoCorbanConcluidaEventHandler : PrimaryEventHandler, IInternalAsyncEventHandler<TransacaoCorbanConcluidaEvent>
    {
        private readonly IEventNotificationBus _eventNotificationBus;

        public TransacaoCorbanConcluidaEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            IEventNotificationBus eventNotificationBus)
            : base(unitOfWork, eventHandlerRepository)
        {
            _eventNotificationBus = eventNotificationBus;
        }

        public Task HandleAsync(IEventEnvelop<TransacaoCorbanConcluidaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        protected async Task DoHandleAsync(TransacaoCorbanConcluidaEvent @event, CancellationToken cancellationToken)
        {
            switch ($"{@event.TipoDaTransacao}_{@event.CodigoDeProcessamento}")
            {
                case TiposDeTransacaoCorban.CONSULTA_DE_CODIGO_DE_BARRAS:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanDeConsultaDeCodigoDeBarrasConcluidaEvent
                        {
                            IdentificacaoDoTerminal = @event.IdentificacaoDoTerminal,
                            DataDeProcessamento = @event.DataDeProcessamento,
                            NSU = @event.NSU,
                            IdDoAgendamento = @event.IdDoAgendamento.Value,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeProcessamento = @event.CodigoDeProcessamento,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.CONSULTA_DE_PAGAMENTO:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanDeConsultaDePagamentoConcluidaEvent
                        {
                            IdentificacaoDoTerminal = @event.IdentificacaoDoTerminal,
                            DataDeProcessamento = @event.DataDeProcessamento,
                            NSU = @event.NSU,
                            IdDoAgendamento = @event.IdDoAgendamento.Value,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeProcessamento = @event.CodigoDeProcessamento,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.PAGAMENTO:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanDePagamentoConcluidaEvent
                        {
                            IdentificacaoDoTerminal = @event.IdentificacaoDoTerminal,
                            DataDeProcessamento = @event.DataDeProcessamento,
                            NSU = @event.NSU,
                            IdDoAgendamento = @event.IdDoAgendamento.Value,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeProcessamento = @event.CodigoDeProcessamento,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                case TiposDeTransacaoCorban.FECHAMENTO_DE_REPASSE:
                    {
                        await _eventNotificationBus.PublishOneAsync(new TransacaoCorbanDeFechamentoDeRepasseConcluidaEvent
                        {
                            IdentificacaoDoTerminal = @event.IdentificacaoDoTerminal,
                            DataDeProcessamento = @event.DataDeProcessamento,
                            NSU = @event.NSU,
                            IdDoAgendamento = @event.IdDoAgendamento.Value,
                            TipoDaTransacao = @event.TipoDaTransacao,
                            CodigoDeProcessamento = @event.CodigoDeProcessamento,
                            CorrelationMessage = @event,
                            OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
                        }).ConfigureAwait(false);

                        break;
                    }
                default:
                    break;
            }
        }
    }
}
