﻿using COP.ESB.Pagamento.Dominio.Corban.FechamentosDeRepasse.Commands;
using COP.ESB.Pagamento.Dominio.Corban.FechamentosDeRepasse.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.FechamentosDeRepasse.CommandHandlers
{
    public class ConcluirFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanComErroNoDesfazimentoCommandHandler
        : CommandRequestHandler<ConcluirFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanComErroNoDesfazimentoCommand>
    {
        private readonly IFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository _fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository;

        public ConcluirFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanComErroNoDesfazimentoCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository = fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(ConcluirFechamentoDeRepasseDePagamentosLiquidadosPeloCorbanComErroNoDesfazimentoCommand command, CancellationToken cancellationToken)
        {
            var fechamentoDeRepasse = await _fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (fechamentoDeRepasse == null)
                throw new InvalidOperationException($"Não existe um fechamento de repasse com o agendamento {command.IdDoAgendamento}.");

            fechamentoDeRepasse.ConcluirComErroNoDesfazimento(command);

            await _fechamentoDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(fechamentoDeRepasse, command.Id).ConfigureAwait(false);
        }
    }
}
