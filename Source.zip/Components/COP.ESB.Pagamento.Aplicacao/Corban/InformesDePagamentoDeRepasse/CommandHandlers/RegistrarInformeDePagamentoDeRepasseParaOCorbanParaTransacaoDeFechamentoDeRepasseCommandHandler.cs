﻿using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Commands;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.InformesDePagamentoDeRepasse.CommandHandlers
{
    public class RegistrarInformeDePagamentoDeRepasseParaOCorbanParaTransacaoDeFechamentoDeRepasseCommandHandler
        : CommandRequestHandler<RegistrarInformeDePagamentoDeRepasseParaOCorbanParaTransacaoDeFechamentoDeRepasseCommand>
    {
        private readonly IInformeDePagamentoDeRepasseParaOCorbanRepository _informeDePagamentoDeRepasseParaOCorbanRepository;

        public RegistrarInformeDePagamentoDeRepasseParaOCorbanParaTransacaoDeFechamentoDeRepasseCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IInformeDePagamentoDeRepasseParaOCorbanRepository informeDePagamentoDeRepasseParaOCorbanRepository)
            : base(commandHandlerRepository)
        {
            _informeDePagamentoDeRepasseParaOCorbanRepository = informeDePagamentoDeRepasseParaOCorbanRepository;
        }

        protected override async Task DoHandleAsync(RegistrarInformeDePagamentoDeRepasseParaOCorbanParaTransacaoDeFechamentoDeRepasseCommand command,
            CancellationToken cancellationToken)
        {
            var informeDePagamento = await _informeDePagamentoDeRepasseParaOCorbanRepository
                .ObterPeloIdDoRepasseDePagamentosLiquidadosPeloCorbanAsync(command.IdDoRepasseDePagamentosLiquidadosPeloCorban)
                .ConfigureAwait(false);

            if (informeDePagamento != null)
                throw new InvalidOperationException($"Já existe um informe de pagamento para o repasse {command.IdDoRepasseDePagamentosLiquidadosPeloCorban}.");

            informeDePagamento = InformeDePagamentoDeRepasseParaOCorban.RegistrarParaTransacaoDeFechamentoDeRepasse(command);

            await _informeDePagamentoDeRepasseParaOCorbanRepository.SaveAsync(informeDePagamento, command.Id).ConfigureAwait(false);
        }
    }
}
