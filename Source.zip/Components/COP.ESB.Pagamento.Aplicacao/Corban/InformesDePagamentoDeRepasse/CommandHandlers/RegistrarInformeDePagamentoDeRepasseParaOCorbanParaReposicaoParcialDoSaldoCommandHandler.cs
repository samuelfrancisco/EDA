﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Commands;
using COP.ESB.Pagamento.Dominio.Corban.InformesDePagamentoDeRepasse.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.SaldoDisponivel.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.InformesDePagamentoDeRepasse.CommandHandlers
{
    public class RegistrarInformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoCommandHandler
        : PrimaryCommandRequestHandler<RegistrarInformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoCommand, Result<decimal?>, decimal?>
    {
        private readonly IInformeDePagamentoDeRepasseParaOCorbanRepository _informeDePagamentoDeRepasseParaOCorbanRepository;
        private readonly ISaldoDisponivelDoCorbanRepository _saldoDisponivelDoCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public RegistrarInformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IInformeDePagamentoDeRepasseParaOCorbanRepository informeDePagamentoDeRepasseParaOCorbanRepository,
            ISaldoDisponivelDoCorbanRepository saldoDisponivelDoCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(unitOfWork, commandHandlerRepository)
        {
            _informeDePagamentoDeRepasseParaOCorbanRepository = informeDePagamentoDeRepasseParaOCorbanRepository;
            _saldoDisponivelDoCorbanRepository = saldoDisponivelDoCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task<Result<decimal?>> DoHandleAsync(RegistrarInformeDePagamentoDeRepasseParaOCorbanParaReposicaoParcialDoSaldoCommand command,
            CancellationToken cancellationToken)
        {
            var result = InformeDePagamentoDeRepasseParaOCorban.RegistrarParaReposicaoParcialDoSaldo(command);

            if (result.IsFailure)
                return result.ToResult<decimal?>();

            await _informeDePagamentoDeRepasseParaOCorbanRepository.SaveAsync(result.Value, command.Id).ConfigureAwait(false);

            var saldoDisponivel = await ObterSaldoDisponivelAsync(result.Value.DataDoPagamento.Date).ConfigureAwait(false);

            if (saldoDisponivel != null)
                saldoDisponivel += result.Value.ValorDoPagamento;

            return result.ToResult(saldoDisponivel);
        }

        private async Task<decimal?> ObterSaldoDisponivelAsync(DateTime dataDoPagamento)
        {
            var saldoDisponivel = await _saldoDisponivelDoCorbanRepository.ObterPelaDataContabilAsync(dataDoPagamento).ConfigureAwait(false);

            if (saldoDisponivel != null)
                return saldoDisponivel.SaldoDisponivel;

            return ObterLimiteMaximoDiarioDeOperacoes();
        }

        private decimal? ObterLimiteMaximoDiarioDeOperacoes()
        {
            var corban = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDosCanaisDeProcessamento
                            ?.FirstOrDefault(x => x.Active && x.Codigo.ToUpper() == CodigosDosCanaisDeProcessamento.CORBAN);

            if (corban == null)
                return null;

            var configuracaoDeRepasse = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDeRepasse
                        ?.FirstOrDefault(x => x.Active && x.IdDoCanalDeProcessamento == corban.Id);

            if (configuracaoDeRepasse == null || configuracaoDeRepasse?.LimiteMaximoDiarioDeOperacoes == null)
                return null;

            return configuracaoDeRepasse.LimiteMaximoDiarioDeOperacoes;
        }
    }
}
