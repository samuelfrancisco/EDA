﻿using COP.ESB.Pagamento.Dominio.Corban.ConsolidacoesDePagamentosDeContaDeConsumo;
using COP.ESB.Pagamento.Dominio.Corban.ConsolidacoesDePagamentosDeContaDeConsumo.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsolidacoesDePagamentosDeContaDeConsumo.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.HorariosDeCorte.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.EnviosDeConsolidacaoDePagamentosDeContaDeConsumo.Services.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsolidacoesDePagamentosDeContaDeConsumo.EventHandlers
{
    public class HorarioDeCorteDoCorbanAtingidoEventHandler : PrimaryEventNotificationHandler<HorarioDeCorteDoCorbanAtingidoEvent>
    {
        private readonly IConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository;
        private readonly IServicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo _servicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo;

        public HorarioDeCorteDoCorbanAtingidoEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            IConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository,
            IServicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo servicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository = consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository;
            _servicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo = servicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo;
        }

        protected override async Task DoHandleAsync(HorarioDeCorteDoCorbanAtingidoEvent @event, CancellationToken cancellationToken)
        {
            var pagamentos = await _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository
                .ObterPagamentosPendentesDeConsolidacaoAsync(@event.Data).ConfigureAwait(false);

            if (!pagamentos.Any())
                return;

            var comandoDeInicializacao = new IniciarConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanCommand
            {
                DataDeProcessamento = @event.Data,
                Pagamentos = pagamentos
                    .Select(x => new IniciarConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanCommandPagamento
                    {
                        IdDoConvenio = x.IdDoConvenio,
                        IdDaConsultaDeConvenio = x.IdDaConsultaDeConvenio,
                        IdDoPagamentoDeConvenio = x.IdDoPagamentoDeConvenio,
                        EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId,
                        DataDoPagamento = x.DataDoPagamento,
                        ValorDoPagamento = x.ValorDoPagamento
                    })
                    .ToList(),
                CorrelationMessage = @event,
                OriginalCorrelationMessage = @event.OriginalCorrelationMessage ?? @event
            };

            var consolidacao = ConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorban
                .IniciarConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorban(comandoDeInicializacao);

            await _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository.SaveAsync(consolidacao, comandoDeInicializacao.Id)
                .ConfigureAwait(false);

            await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

            var result = await _servicoDeEnvioDeConsolidacaoDePagamentosDeContaDeConsumo
                .EnviarConsolidacaoDePagamentosDeContaDeConsumoAsync(consolidacao.DataDeProcessamento, consolidacao.ValorTotal)
                .ConfigureAwait(false);

            if(result.IsFailure)
            {
                var comandoDeConclusaoComErro = new ConcluirConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanComErroCommand
                {
                    IdDaConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorban = consolidacao.Id,
                    CodigoDeErro = result.ErroMessage.StatusCode,
                    DescricaoDoErro = result.ErroMessage.Message,
                    CorrelationMessage = comandoDeInicializacao,
                    OriginalCorrelationMessage = comandoDeInicializacao.OriginalCorrelationMessage ?? comandoDeInicializacao
                };

                consolidacao.ConcluirComErro(comandoDeConclusaoComErro);

                await _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository.SaveAsync(consolidacao, comandoDeConclusaoComErro.Id)
                    .ConfigureAwait(false);

                return;
            }

            var comandoDeConclusaoComSucesso = new ConcluirConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanComSucessoCommand
            {
                IdDaConsolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorban = consolidacao.Id,
                CorrelationMessage = comandoDeInicializacao,
                OriginalCorrelationMessage = comandoDeInicializacao.OriginalCorrelationMessage ?? comandoDeInicializacao
            };

            consolidacao.ConcluirComSucesso(comandoDeConclusaoComSucesso);

            await _consolidacaoDePagamentosDeContaDeConsumoLiquidadosPeloCorbanRepository.SaveAsync(consolidacao, comandoDeInicializacao.Id)
                .ConfigureAwait(false);
        }
    }
}
