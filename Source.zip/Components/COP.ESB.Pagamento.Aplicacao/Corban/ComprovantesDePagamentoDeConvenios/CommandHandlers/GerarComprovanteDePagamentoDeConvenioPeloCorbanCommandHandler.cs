﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.ComprovantesDePagamentoDeConvenios;
using COP.ESB.Pagamento.Dominio.Corban.ComprovantesDePagamentoDeConvenios.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ComprovantesDePagamentoDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ComprovantesDePagamentoDeConvenios.CommandHandlers
{
    public class GerarComprovanteDePagamentoDeConvenioPeloCorbanCommandHandler : CommandRequestHandler<GerarComprovanteDePagamentoDeConvenioPeloCorbanCommand>
    {
        private readonly IComprovanteDePagamentoDeConvenioPeloCorbanRepository _comprovanteDePagamentoDeConvenioPeloCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public GerarComprovanteDePagamentoDeConvenioPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IComprovanteDePagamentoDeConvenioPeloCorbanRepository comprovanteDePagamentoDeConvenioPeloCorbanRepository,            
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _comprovanteDePagamentoDeConvenioPeloCorbanRepository = comprovanteDePagamentoDeConvenioPeloCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(GerarComprovanteDePagamentoDeConvenioPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var comprovante = await _comprovanteDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoDeConvenioAsync(command.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (comprovante != null)
                throw new InvalidOperationException($"Já existe um comprovante para o pagamento {command.IdDoPagamentoDeConvenio}.");

            comprovante = ComprovanteDePagamentoDeConvenioPeloCorban.GerarComprovanteDePagamentoDeConvenioPeloCorban(command, _configuracoesDoMotorService);

            await _comprovanteDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(comprovante, command.Id).ConfigureAwait(false);
        }
    }
}
