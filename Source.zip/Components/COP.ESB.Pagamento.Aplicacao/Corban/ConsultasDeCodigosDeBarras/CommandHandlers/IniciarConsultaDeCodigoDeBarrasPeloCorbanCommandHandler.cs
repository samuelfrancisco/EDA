﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsultasDeCodigosDeBarras.CommandHandlers
{
    public class IniciarConsultaDeCodigoDeBarrasPeloCorbanCommandHandler : CommandRequestHandler<IniciarConsultaDeCodigoDeBarrasPeloCorbanCommand>
    {
        private readonly IConsultaDeCodigoDeBarrasPeloCorbanRepository _consultaDeCodigoDeBarrasPeloCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public IniciarConsultaDeCodigoDeBarrasPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeCodigoDeBarrasPeloCorbanRepository consultaDeCodigoDeBarrasPeloCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService) 
            : base(commandHandlerRepository)
        {
            _consultaDeCodigoDeBarrasPeloCorbanRepository = consultaDeCodigoDeBarrasPeloCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(IniciarConsultaDeCodigoDeBarrasPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeCodigoDeBarrasPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta != null)
                throw new InvalidOperationException($"Já existe uma consulta de código de barras com o agendamento {command.IdDoAgendamento}.");

            consulta = ConsultaDeCodigoDeBarrasPeloCorban.IniciarConsultaDeCodigoDeBarrasPeloCorban(command, _configuracoesDoMotorService);

            await _consultaDeCodigoDeBarrasPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
