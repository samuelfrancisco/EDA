﻿using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsultasDeCodigosDeBarras.CommandHandlers
{
    public class ConcluirConsultaDeCodigoDeBarrasPeloCorbanComErroNoEnvioCommandHandler 
        : CommandRequestHandler<ConcluirConsultaDeCodigoDeBarrasPeloCorbanComErroNoEnvioCommand>
    {
        private readonly IConsultaDeCodigoDeBarrasPeloCorbanRepository _consultaDeCodigoDeBarrasPeloCorbanRepository;        

        public ConcluirConsultaDeCodigoDeBarrasPeloCorbanComErroNoEnvioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeCodigoDeBarrasPeloCorbanRepository consultaDeCodigoDeBarrasPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeCodigoDeBarrasPeloCorbanRepository = consultaDeCodigoDeBarrasPeloCorbanRepository;            
        }

        protected override async Task DoHandleAsync(ConcluirConsultaDeCodigoDeBarrasPeloCorbanComErroNoEnvioCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeCodigoDeBarrasPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta == null)
                throw new InvalidOperationException($"Não existe uma consulta de código de barras com o agendamento {command.IdDoAgendamento}.");

            consulta.ConcluirComErroNoEnvio(command);

            await _consultaDeCodigoDeBarrasPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
