﻿using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsultasDeCodigosDeBarras.CommandHandlers
{
    public class ConcluirConsultaDeCodigoDeBarrasPeloCorbanComRespostaCommandHandler 
        : CommandRequestHandler<ConcluirConsultaDeCodigoDeBarrasPeloCorbanComRespostaCommand>
    {
        private readonly IConsultaDeCodigoDeBarrasPeloCorbanRepository _consultaDeCodigoDeBarrasPeloCorbanRepository;

        public ConcluirConsultaDeCodigoDeBarrasPeloCorbanComRespostaCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDeCodigoDeBarrasPeloCorbanRepository consultaDeCodigoDeBarrasPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _consultaDeCodigoDeBarrasPeloCorbanRepository = consultaDeCodigoDeBarrasPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(ConcluirConsultaDeCodigoDeBarrasPeloCorbanComRespostaCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDeCodigoDeBarrasPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta == null)
                throw new InvalidOperationException($"Não existe uma consulta de código de barras com o agendamento {command.IdDoAgendamento}.");

            consulta.ConcluirComResposta(command);

            await _consultaDeCodigoDeBarrasPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
