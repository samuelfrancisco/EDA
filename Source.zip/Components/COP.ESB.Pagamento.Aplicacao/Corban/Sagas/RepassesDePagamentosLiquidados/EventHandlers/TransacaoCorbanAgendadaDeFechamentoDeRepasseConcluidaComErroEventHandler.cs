﻿using COP.ESB.Pagamento.Dominio.Corban.Sagas.RepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Events;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.RepassesDePagamentosLiquidados.EventHandlers
{
    public class TransacaoCorbanAgendadaDeFechamentoDeRepasseConcluidaComErroEventHandler
        : EventNotificationHandler<TransacaoCorbanAgendadaDeFechamentoDeRepasseConcluidaComErroEvent>
    {
        private readonly ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        public TransacaoCorbanAgendadaDeFechamentoDeRepasseConcluidaComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository)
            : base(eventHandlerRepository)
        {
            _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository = sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(TransacaoCorbanAgendadaDeFechamentoDeRepasseConcluidaComErroEvent @event,
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(@event.IdDoAgendamento)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
