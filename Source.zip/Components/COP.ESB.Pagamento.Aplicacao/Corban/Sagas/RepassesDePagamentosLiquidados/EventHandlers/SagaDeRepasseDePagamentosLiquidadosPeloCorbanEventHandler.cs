﻿using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.FechamentosDeRepasse.Events;
using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Events;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.RepassesDePagamentosLiquidados;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.RepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.RepassesDePagamentosLiquidados.EventHandlers
{
    public class SagaDeRepasseDePagamentosLiquidadosPeloCorbanEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<RepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent>,        
        IInternalAsyncEventHandler<FechamentoDeRepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent>,
        IInternalAsyncEventHandler<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent>
    {
        private readonly ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        private readonly ICalendarioService _calendarioService;

        public SagaDeRepasseDePagamentosLiquidadosPeloCorbanEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository,
            ICalendarioService calendarioService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository = sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
            _calendarioService = calendarioService;
        }

        public Task HandleAsync(IEventEnvelop<RepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(RepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoRepasseAsync(@event.SourceId)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDeRepasseDePagamentosLiquidadosPeloCorban(@event, _calendarioService);

            await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }       

        public Task HandleAsync(IEventEnvelop<FechamentoDeRepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(FechamentoDeRepasseDePagamentosLiquidadosPeloCorbanIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoRepasseAsync(@event.IdDoRepasseDePagamentosLiquidadosPeloCorban)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoRepasseAsync(@event.IdDoRepasseDePagamentosLiquidadosPeloCorban)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
