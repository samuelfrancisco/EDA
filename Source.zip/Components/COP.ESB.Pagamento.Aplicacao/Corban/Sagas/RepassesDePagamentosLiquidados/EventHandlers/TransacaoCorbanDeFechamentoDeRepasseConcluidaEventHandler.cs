﻿using COP.ESB.Pagamento.Dominio.Corban.Sagas.RepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesEnviadas.Events;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesEnviadas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesRecebidas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.RepassesDePagamentosLiquidados.EventHandlers
{
    public class TransacaoCorbanDeFechamentoDeRepasseConcluidaEventHandler 
        : EventNotificationHandler<TransacaoCorbanDeFechamentoDeRepasseConcluidaEvent>
    {
        private readonly ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        private readonly ITransacaoCorbanEnviadaService _transacaoCorbanEnviadaService;
        private readonly ITransacaoCorbanRecebidaService _transacaoCorbanRecebidaService;

        public TransacaoCorbanDeFechamentoDeRepasseConcluidaEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository,
            ITransacaoCorbanEnviadaService transacaoCorbanEnviadaService,
            ITransacaoCorbanRecebidaService transacaoCorbanRecebidaService)
            : base(eventHandlerRepository)
        {
            _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository = sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
            _transacaoCorbanEnviadaService = transacaoCorbanEnviadaService;
            _transacaoCorbanRecebidaService = transacaoCorbanRecebidaService;
        }

        protected override async Task DoHandleAsync(TransacaoCorbanDeFechamentoDeRepasseConcluidaEvent @event,
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(@event.IdDoAgendamento)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _transacaoCorbanEnviadaService, _transacaoCorbanRecebidaService);

            await _sagaDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
