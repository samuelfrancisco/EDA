﻿using COP.ESB.Pagamento.Dominio.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesAgendadas.Events;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class TransacaoCorbanAgendadaDePagamentoConcluidaComErroEventHandler
        : EventNotificationHandler<TransacaoCorbanAgendadaDePagamentoConcluidaComErroEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        public TransacaoCorbanAgendadaDePagamentoConcluidaComErroEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository)
            : base(eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository = sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(TransacaoCorbanAgendadaDePagamentoConcluidaComErroEvent @event,
            CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(@event.IdDoAgendamento)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
