﻿using COP.ESB.Pagamento.Dominio.Corban.ConsultasDeCodigosDeBarras.Events;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos.Events;
using COP.ESB.Pagamento.Dominio.Corban.LiquidacoesDePagamentosDeConvenios.Events;
using COP.ESB.Pagamento.Dominio.Corban.Pagamentos.Events;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.LiquidacoesDePagamentosDeConvenios;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class SagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<LiquidacaoDePagamentoDeConvenioPeloCorbanIniciadaEvent>,
        IInternalAsyncEventHandler<ConsultaDeCodigoDeBarrasPeloCorbanIniciadaEvent>,
        IInternalAsyncEventHandler<ConsultaDeCodigoDeBarrasPeloCorbanRecusadaEvent>,
        IInternalAsyncEventHandler<ConsultaDePagamentoPeloCorbanIniciadaEvent>,
        IInternalAsyncEventHandler<ConsultaDePagamentoPeloCorbanRecusadaEvent>,
        IInternalAsyncEventHandler<PagamentoPeloCorbanIniciadoEvent>,
        IInternalAsyncEventHandler<PagamentoPeloCorbanRecusadoEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;

        public SagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository = sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        }

        public Task HandleAsync(IEventEnvelop<LiquidacaoDePagamentoDeConvenioPeloCorbanIniciadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(LiquidacaoDePagamentoDeConvenioPeloCorbanIniciadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga != null)
                return;

            saga = new SagaDeLiquidacaoDePagamentoDeConvenioPeloCorban(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeCodigoDeBarrasPeloCorbanIniciadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDeCodigoDeBarrasPeloCorbanIniciadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDeCodigoDeBarrasPeloCorbanRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDeCodigoDeBarrasPeloCorbanRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDePagamentoPeloCorbanIniciadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDePagamentoPeloCorbanIniciadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<ConsultaDePagamentoPeloCorbanRecusadaEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(ConsultaDePagamentoPeloCorbanRecusadaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoPeloCorbanIniciadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoPeloCorbanIniciadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<PagamentoPeloCorbanRecusadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(PagamentoPeloCorbanRecusadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoPagamentoAsync(@event.IdDoPagamentoDeConvenio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
