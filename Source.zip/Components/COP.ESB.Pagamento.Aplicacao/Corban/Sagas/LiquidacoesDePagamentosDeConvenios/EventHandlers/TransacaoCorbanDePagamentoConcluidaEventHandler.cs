﻿using COP.ESB.Pagamento.Dominio.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesEnviadas.Events;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesEnviadas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.TransacoesRecebidas.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.LiquidacoesDePagamentosDeConvenios.EventHandlers
{
    public class TransacaoCorbanDePagamentoConcluidaEventHandler
        : EventNotificationHandler<TransacaoCorbanDePagamentoConcluidaEvent>
    {
        private readonly ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;
        private readonly ITransacaoCorbanEnviadaService _transacaoCorbanEnviadaService;
        private readonly ITransacaoCorbanRecebidaService _transacaoCorbanRecebidaService;

        public TransacaoCorbanDePagamentoConcluidaEventHandler(IEventHandlerRepository eventHandlerRepository,
            ISagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository,
            ITransacaoCorbanEnviadaService transacaoCorbanEnviadaService,
            ITransacaoCorbanRecebidaService transacaoCorbanRecebidaService)
            : base(eventHandlerRepository)
        {
            _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository = sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository;
            _transacaoCorbanEnviadaService = transacaoCorbanEnviadaService;
            _transacaoCorbanRecebidaService = transacaoCorbanRecebidaService;
        }

        protected override async Task DoHandleAsync(TransacaoCorbanDePagamentoConcluidaEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(@event.IdDoAgendamento)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event, _transacaoCorbanEnviadaService, _transacaoCorbanRecebidaService);

            await _sagaDeLiquidacaoDePagamentoDeConvenioPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
