﻿using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Events;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.EnviosDeRepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.EnviosDeRepassesDePagamentosLiquidados.EventHandlers
{
    public class SagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoErroNoEnvioEvent>,
        IInternalAsyncEventHandler<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent>
    {
        private readonly ISagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository;

        public SagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository) 
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository = sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository;
        }

        public Task HandleAsync(IEventEnvelop<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoErroNoEnvioEvent> envelop, 
            CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoErroNoEnvioEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository.GetByIdAsync(@event.IdDoProcessoDeEnvio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }

        public Task HandleAsync(IEventEnvelop<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent> envelop, 
            CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        public async Task DoHandleAsync(RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent @event, CancellationToken cancellationToken)
        {
            var saga = await _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository.GetByIdAsync(@event.IdDoProcessoDeEnvio)
                .ConfigureAwait(false);

            if (saga == null)
                return;

            saga.Handle(@event);

            await _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
