﻿using COP.ESB.Pagamento.Dominio.Corban.HorariosDeCorte.Events;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.EnviosDeRepassesDePagamentosLiquidados;
using COP.ESB.Pagamento.Dominio.Corban.Sagas.EnviosDeRepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.Sagas.EnviosDeRepassesDePagamentosLiquidados.EventHandlers
{
    public class HorarioDeCorteDoCorbanAtingidoEventHandler : PrimaryEventNotificationHandler<HorarioDeCorteDoCorbanAtingidoEvent>
    {
        private readonly ISagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository;        

        public HorarioDeCorteDoCorbanAtingidoEventHandler(IUnitOfWork unitOfWork,
            IEventHandlerRepository eventHandlerRepository,
            ISagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository)
            : base(unitOfWork, eventHandlerRepository)
        {
            _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository = sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository;            
        }

        protected override async Task DoHandleAsync(HorarioDeCorteDoCorbanAtingidoEvent @event, CancellationToken cancellationToken)
        {
            var saga = new SagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorban(@event);

            await _sagaDeEnvioDeRepasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(saga, @event.Id).ConfigureAwait(false);
        }
    }
}
