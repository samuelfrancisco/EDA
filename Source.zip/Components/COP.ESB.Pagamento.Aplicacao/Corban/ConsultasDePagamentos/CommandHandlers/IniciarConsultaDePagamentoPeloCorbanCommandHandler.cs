﻿using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsultasDePagamentos.CommandHandlers
{
    public class IniciarConsultaDePagamentoPeloCorbanCommandHandler : CommandRequestHandler<IniciarConsultaDePagamentoPeloCorbanCommand>
    {
        private readonly IConsultaDePagamentoPeloCorbanRepository _consultaDePagamentoPeloCorbanRepository;
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;

        public IniciarConsultaDePagamentoPeloCorbanCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDePagamentoPeloCorbanRepository consultaDePagamentoPeloCorbanRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService)
            : base(commandHandlerRepository)
        {
            _consultaDePagamentoPeloCorbanRepository = consultaDePagamentoPeloCorbanRepository;
            _configuracoesDoMotorService = configuracoesDoMotorService;
        }

        protected override async Task DoHandleAsync(IniciarConsultaDePagamentoPeloCorbanCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDePagamentoPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta != null)
                throw new InvalidOperationException($"Já existe uma consulta de pagamento com o agendamento {command.IdDoAgendamento}.");

            consulta = ConsultaDePagamentoPeloCorban.IniciarConsultaDePagamentoPeloCorban(command, _configuracoesDoMotorService);

            await _consultaDePagamentoPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
