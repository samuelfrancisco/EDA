﻿using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos.Commands;
using COP.ESB.Pagamento.Dominio.Corban.ConsultasDePagamentos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.ConsultasDePagamentos.CommandHandlers
{
    public class ConcluirConsultaDePagamentoPeloCorbanComTimeoutCommandHandler
        : CommandRequestHandler<ConcluirConsultaDePagamentoPeloCorbanComTimeoutCommand>
    {
        private readonly IConsultaDePagamentoPeloCorbanRepository _consultaDePagamentoPeloCorbanRepository;

        public ConcluirConsultaDePagamentoPeloCorbanComTimeoutCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IConsultaDePagamentoPeloCorbanRepository consultaDePagamentoPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _consultaDePagamentoPeloCorbanRepository = consultaDePagamentoPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(ConcluirConsultaDePagamentoPeloCorbanComTimeoutCommand command, CancellationToken cancellationToken)
        {
            var consulta = await _consultaDePagamentoPeloCorbanRepository.ObterPeloIdDoAgendamentoAsync(command.IdDoAgendamento)
                .ConfigureAwait(false);

            if (consulta == null)
                throw new InvalidOperationException($"Não existe uma consulta de pagamento com o agendamento {command.IdDoAgendamento}.");

            consulta.ConcluirComTimeout(command);

            await _consultaDePagamentoPeloCorbanRepository.SaveAsync(consulta, command.Id).ConfigureAwait(false);
        }
    }
}
