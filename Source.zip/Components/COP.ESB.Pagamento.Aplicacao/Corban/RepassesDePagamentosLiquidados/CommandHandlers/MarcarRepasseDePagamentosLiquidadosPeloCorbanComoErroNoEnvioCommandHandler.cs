﻿using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Commands;
using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.RepassesDePagamentosLiquidados.CommandHandlers
{
    public class MarcarRepasseDePagamentosLiquidadosPeloCorbanComoErroNoEnvioCommandHandler
        : CommandRequestHandler<MarcarRepasseDePagamentosLiquidadosPeloCorbanComoErroNoEnvioCommand>
    {
        private readonly IRepasseDePagamentosLiquidadosPeloCorbanRepository _repasseDePagamentosLiquidadosPeloCorbanRepository;

        public MarcarRepasseDePagamentosLiquidadosPeloCorbanComoErroNoEnvioCommandHandler(ICommandHandlerRepository commandHandlerRepository,
            IRepasseDePagamentosLiquidadosPeloCorbanRepository repasseDePagamentosLiquidadosPeloCorbanRepository)
            : base(commandHandlerRepository)
        {
            _repasseDePagamentosLiquidadosPeloCorbanRepository = repasseDePagamentosLiquidadosPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(MarcarRepasseDePagamentosLiquidadosPeloCorbanComoErroNoEnvioCommand command, CancellationToken cancellationToken)
        {
            var repasse = await _repasseDePagamentosLiquidadosPeloCorbanRepository.GetByIdAsync(command.IdDoRepasseDePagamentosLiquidadosPeloCorban)
                .ConfigureAwait(false);

            if (repasse == null)
                throw new InvalidOperationException($"Repasse de pagamentos liquidados pelo Corban {command.IdDoRepasseDePagamentosLiquidadosPeloCorban} não encontrado.");

            repasse.MarcarComoErroNoEnvio(command);

            await _repasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(repasse, command.Id).ConfigureAwait(false);
        }
    }
}
