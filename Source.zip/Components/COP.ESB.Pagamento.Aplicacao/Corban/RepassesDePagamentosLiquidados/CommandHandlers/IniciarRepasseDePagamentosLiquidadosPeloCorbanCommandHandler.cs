﻿using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados;
using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Commands;
using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Messaging.Handling;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.RepassesDePagamentosLiquidados.CommandHandlers
{
    public class IniciarRepasseDePagamentosLiquidadosPeloCorbanCommandHandler
        : PrimaryCommandRequestHandler<IniciarRepasseDePagamentosLiquidadosPeloCorbanCommand>
    {
        private readonly IRepasseDePagamentosLiquidadosPeloCorbanRepository _repasseDePagamentosLiquidadosPeloCorbanRepository;

        public IniciarRepasseDePagamentosLiquidadosPeloCorbanCommandHandler(IUnitOfWork unitOfWork,
            ICommandHandlerRepository commandHandlerRepository,
            IRepasseDePagamentosLiquidadosPeloCorbanRepository repasseDePagamentosLiquidadosPeloCorbanRepository)
            : base(unitOfWork, commandHandlerRepository)
        {
            _repasseDePagamentosLiquidadosPeloCorbanRepository = repasseDePagamentosLiquidadosPeloCorbanRepository;
        }

        protected override async Task DoHandleAsync(IniciarRepasseDePagamentosLiquidadosPeloCorbanCommand command, 
            CancellationToken cancellationToken)
        {
            var repasse = RepasseDePagamentosLiquidadosPeloCorban.IniciarRepasseDePagamentosLiquidadosPeloCorban(command);

            await _repasseDePagamentosLiquidadosPeloCorbanRepository.SaveAsync(repasse, command.Id).ConfigureAwait(false);
        }
    }
}
