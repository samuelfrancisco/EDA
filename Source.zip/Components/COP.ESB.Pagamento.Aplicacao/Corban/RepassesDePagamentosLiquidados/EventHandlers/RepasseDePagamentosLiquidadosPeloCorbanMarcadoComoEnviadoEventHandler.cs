﻿using COP.ESB.Pagamento.Aplicacao.InformesDePagamentoDeRepasse.ViewModels;
using COP.ESB.Pagamento.Dominio.Configuracoes;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Corban.RepassesDePagamentosLiquidados.Events;
using COP.ESB.Pagamento.Dominio.Core.Data.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Handling.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.Messaging.Interfaces;
using COP.ESB.Pagamento.Dominio.Shared.Constants;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.DTOs;
using COP.ESB.Pagamento.Infra.CrossCutting.Core.Mail.Services.Interfaces;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Aplicacao.Corban.RepassesDePagamentosLiquidados.EventHandlers
{
    public class RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEventHandler : PrimaryEventHandler,
        IInternalAsyncEventHandler<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent>
    {
        private readonly IConfiguracoesDoMotorService _configuracoesDoMotorService;
        private readonly IEnvioDeEmailService _envioDeEmailService;
        private readonly IRazorTemplateParseService _razorTemplateParseService;

        public RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEventHandler(IUnitOfWork unitOfWork, 
            IEventHandlerRepository eventHandlerRepository,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IEnvioDeEmailService envioDeEmailService,
            IRazorTemplateParseService razorTemplateParseService)
            : base(unitOfWork, eventHandlerRepository)
        {
            _configuracoesDoMotorService = configuracoesDoMotorService;
            _envioDeEmailService = envioDeEmailService;
            _razorTemplateParseService = razorTemplateParseService;
        }

        public Task HandleAsync(IEventEnvelop<RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent> envelop, CancellationToken cancellationToken)
        {
            return base.HandleAsync(envelop, DoHandleAsync, cancellationToken);
        }

        private async Task DoHandleAsync(RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent @event, CancellationToken cancellationToken)
        {
            var corban = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDosCanaisDeProcessamento
                            ?.FirstOrDefault(x => x.Active && x.Codigo.ToUpper() == CodigosDosCanaisDeProcessamento.CORBAN);

            if (corban == null)
                return;

            var configuracaoDeRepasse = _configuracoesDoMotorService.ConfiguracoesDoMotor?.Convenios?.ConfiguracoesDeRepasse
                        ?.FirstOrDefault(x => x.Active && x.IdDoCanalDeProcessamento == corban.Id);

            if (configuracaoDeRepasse == null)
                return;

            var to = configuracaoDeRepasse.EmailParaNotificacao?.Split(';');

            if (to?.Any() != true) return;

            var assunto = "Repasse de Pagamentos Liquidados pelo Corban";

            var corpoDoEmail = await GerarCorpoDoEmail(corban, @event, assunto).ConfigureAwait(false);

            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            var caminhoDoLogo = Path.Combine(caminhoDaPasta, @"Mail\Templates\Images\logo.png");

            await _envioDeEmailService.EnviarMensagemAsync(new MensagemDeEmailDTO
            {
                To = to,
                Subject = assunto,
                Body = corpoDoEmail,
                IsBodyHtml = true,
                Attachments = new Dictionary<string, string>
                {
                    { "logo.png", caminhoDoLogo }
                }
            }).ConfigureAwait(false);
        }

        private async Task<string> GerarCorpoDoEmail(ConfiguracoesDoCanalDeProcessamento corban,
           RepasseDePagamentosLiquidadosPeloCorbanMarcadoComoEnviadoEvent @event, string assuntoDoEmail)
        {
            var caminhoDaPasta = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).Replace(@"file:\", "");

            string caminhoDoTemplate = string.Empty;

            object model = null;

            if(string.IsNullOrWhiteSpace(@event.DadosDoBoleto))
            {
                model = new RepasseDePagamentosLiquidadosPeloCorbanSemValorDTO
                {
                    Logo = "cid:logo.png",
                    TituloDoEmail = assuntoDoEmail,
                    TituloDoCabecalho = assuntoDoEmail,
                    Data = @event.Date.ToString("dd/MM/yyyy")
                };

                caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\RepasseDePagamentosLiquidadosPeloCorbanSemValor.cshtml");
            }
            else
            {
                var viewModel = new InformeDePagamentoDadosDoBoletoViewModel
                {
                    DadosDoBoleto = @event.DadosDoBoleto
                };

                model = new RepasseDePagamentosLiquidadosPeloCorbanComValorDTO
                {
                    Logo = "cid:logo.png",
                    TituloDoEmail = assuntoDoEmail,
                    TituloDoCabecalho = assuntoDoEmail,
                    Data = @event.Date.ToString("dd/MM/yyyy"),                    
                    ValorTotalDoRepasse = viewModel.ValorDoDocumento,
                    CodigoDoBanco = viewModel.CodigoDoBanco,
                    NomeDoBanco = viewModel.NomeDoBanco,
                    LocalDePagamento = viewModel.LocalDePagamento,
                    Beneficiario1 = viewModel.Beneficiario1,
                    AgenciaECodigoDoCedente = viewModel.AgenciaECodigoDoCedente,
                    NossoNumero = viewModel.NossoNumero,
                    DataDeVencimento = viewModel.DataDeVencimento,
                    ValorDoDocumento = viewModel.ValorDoDocumento,
                    DataDoDocumento = viewModel.DataDoDocumento,
                    NumeroDoDocumento = viewModel.NumeroDoDocumento,
                    EspecieDoDocumento = viewModel.EspecieDoDocumento,
                    Aceite = viewModel.Aceite,
                    DataDeProcessamento = viewModel.DataDeProcessamento,
                    UsoDoBanco = viewModel.UsoDoBanco,
                    Carteira = viewModel.Carteira,
                    EspecieDaMoeda = viewModel.EspecieDaMoeda,
                    Quantidade = viewModel.Quantidade,
                    Valor = viewModel.Valor,
                    Instrucoes1 = viewModel.Instrucoes1,
                    Instrucoes2 = viewModel.Instrucoes2,
                    Instrucoes3 = viewModel.Instrucoes3,
                    Pagador1 = viewModel.Pagador1,
                    Pagador2 = viewModel.Pagador2,
                    Sacador1 = viewModel.Sacador1,
                    CodigoDeBarras = viewModel.CodigoDeBarras,
                    Desconto = viewModel.Desconto,
                    OutrasDeducoes = viewModel.OutrasDeducoes,
                    MoraEMulta = viewModel.MoraEMulta,
                    OutrosAcrescimos = viewModel.OutrosAcrescimos,
                    ValorCobrado = viewModel.ValorCobrado,
                    Beneficiario2 = viewModel.Beneficiario2,
                    CPFOuCNPJDoBeneficiario = viewModel.CPFOuCNPJDoBeneficiario,
                    Sacador2 = viewModel.Sacador2,
                    Comprovante = @event.Comprovante
                };

                caminhoDoTemplate = Path.Combine(caminhoDaPasta, @"Mail\Templates\RepasseDePagamentosLiquidadosPeloCorbanComValor.cshtml");
            }            

            return await _razorTemplateParseService.ParseTemplateAsync(caminhoDoTemplate, model).ConfigureAwait(false);
        }
    }
}
