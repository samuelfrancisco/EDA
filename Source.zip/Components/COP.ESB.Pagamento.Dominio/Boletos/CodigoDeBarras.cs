﻿using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using System;
using System.Globalization;
using System.Threading;

namespace COP.ESB.Pagamento.Dominio.Boletos
{
    public class CodigoDeBarras
    {
        private static readonly int[] _multiplicadores = new int[] { 4, 3, 2, 9, 0, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

        protected CodigoDeBarras()
        {

        }

        internal CodigoDeBarras(NovoBoletoRegistradoEvent @event)
        {
            Valor = @event.CodigoDeBarras;
        }

        public virtual string Valor { get; protected set; }

        public static Result<CodigoDeBarras> Criar(string valor, IBancoService bancoService)
        {
            var validationResult = Validar(valor);

            validationResult.Merge(ValidarBanco(valor, bancoService));

            if (validationResult.IsFailure)
                return validationResult.ToResult<CodigoDeBarras>();

            return new Result<CodigoDeBarras>(new CodigoDeBarras
            {
                Valor = valor
            });
        }

        public static Result<CodigoDeBarras> Criar(LinhaDigitavel linhaDigitavel)
        {
            var valor = linhaDigitavel.ExtrairValorDoCodigoDeBarras();

            var validationResult = Validar(valor);

            if (validationResult.IsFailure)
                return validationResult.ToResult<CodigoDeBarras>();

            return new Result<CodigoDeBarras>(new CodigoDeBarras
            {
                Valor = valor
            });
        }

        public static Result Validar(string valor)
        {
            var result = new Result();

            if (string.IsNullOrWhiteSpace(valor))
            {
                result.AddError("Código de barras inválido.", "Código de barras.", typeof(CodigoDeBarras).FullName);
                return result;
            }

            if (valor?.Length != 44)
            {
                result.AddError("Código de barras inválido.", "Código de barras.", typeof(CodigoDeBarras).FullName);
                return result;
            }

            if (!valor.SoContemNumeros())
            {
                result.AddError("Código de barras inválido.", "Código de barras.", typeof(CodigoDeBarras).FullName);
                return result;
            }            

            if (!ODigitoVerificadorEValido(valor))
                result.AddError("Código de barras inválido.", "Código de barras.", typeof(CodigoDeBarras).FullName);

            if (!AMoedaEReal(valor))
                result.AddError("Código de barras inválido: a moeda é diferente de 9 - Real.", "Código de barras.", typeof(CodigoDeBarras).FullName);

            return result;
        }        

        public virtual DateTime? ObterADataDeVencimentoDoBoleto()
        {
            var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");

            var fatorDeVencimento = int.Parse(Valor.Substring(5, 4));

            if (fatorDeVencimento == 0)
                return null;

            var dataBase = DateTime.Parse("07/10/1997");

            var dataRetorno = dataBase.AddDays(fatorDeVencimento);

            Thread.CurrentThread.CurrentCulture = currentCulture;

            return dataRetorno;
        }

        public virtual decimal ObterOValorDoBoleto()
        {
            var codigoDoBanco = ObterCodigoDoBancoAPartirDoValor(Valor);

            if (codigoDoBanco == "0988")
                return 0;

            var separadorDeDecimais = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;

            return decimal.Parse(string.Format("{0}{1}{2}", Valor.Substring(9, 8), separadorDeDecimais, Valor.Substring(17, 2)));
        }

        public virtual string ObterCodigoDoBanco()
        {
            return ObterCodigoDoBancoAPartirDoValor(Valor);
        }

        private static bool ODigitoVerificadorEValido(string valor)
        {
            var caracteres = valor.ToCharArray();

            int digitoVerificadorCalculado = CalcularDigitoVerificador(caracteres);

            var digitoVerificador = int.Parse(caracteres[4].ToString());

            return digitoVerificador == digitoVerificadorCalculado;
        }

        private static int CalcularDigitoVerificador(char[] caracteres)
        {
            var resultadoDoProduto = 0;

            for (int i = 0; i < caracteres.Length; i++)
            {
                resultadoDoProduto += (int.Parse(caracteres[i].ToString()) * _multiplicadores[i]);
            }

            var restoDaDivisao = resultadoDoProduto % 11;

            var digitoVerificadorCalculado = restoDaDivisao == 0 || restoDaDivisao == 1
                ? 1
                : 11 - restoDaDivisao;

            return digitoVerificadorCalculado;
        }

        private static Result ValidarBanco(string valor, IBancoService bancoService)
        {
            var result = new Result();

            var codigoDoBanco = ObterCodigoDoBancoAPartirDoValor(valor);

            if (string.IsNullOrWhiteSpace(codigoDoBanco))
            {
                result.AddError("Código de barras inválido.", "Código de barras.", typeof(CodigoDeBarras).FullName);
                return result;
            }

            if (codigoDoBanco == "0988")
                return result;

            var banco = bancoService.ObterBancoPeloCodigoAsync(codigoDoBanco).Result;

            if (banco == null || !banco.Active)
                result.AddError("Banco inválido.", "Banco.", typeof(CodigoDeBarras).FullName);

            return result;
        }

        private static string ObterCodigoDoBancoAPartirDoValor(string valor)
        {
            if (string.IsNullOrWhiteSpace(valor))
                return null;

            return "0" + valor.Substring(0, 3);
        }

        private static bool AMoedaEReal(string valor)
        {
            if (string.IsNullOrWhiteSpace(valor))
                return false;

            return valor.Substring(3, 1) == "9";
        }        
    }
}
