﻿using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.DTOs;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Calendarios.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace COP.ESB.Pagamento.Dominio.Boletos
{
    public class CalculoDeBoleto
    {
        /// <summary>
        /// DtVencTit Data Vencimento Título
        /// </summary>
        private DateTime _dataVencimento;
        /// <summary>
        /// VlrTit Valor Título
        /// </summary>
        private readonly decimal _valorTitulo;
        /// <summary>
        ///IndrPgtoParcl Indicador Pagamento Parcial
        /// </summary>
        private string _indicadorPagamentoParcial;
        /// <summary>
        ///QtdPgtoParcl Quantidade Pagamento Parcial
        /// </summary>
        private int? _qtdPagamentoParcialAutorizado;
        /// <summary>
        /// VlrAbattTi Valor Abatimento Título
        /// </summary>
        private readonly decimal _valorAbatimento;
        /// <summary>
        ///Grupo_DDA0110R1_JurosTit Grupo Juros Título
        /// </summary>
        private GrupoValores _grupoJuros;
        /// <summary>
        ///Grupo_DDA0110R1_MultaTit Grupo Multa Título
        /// </summary>
        private GrupoValores _grupoMulta;
        /// <summary>
        /// Grupo_DDA0110R1_DesctTit Grupo Descontos Título
        /// </summary>
        private IReadOnlyCollection<GrupoValores> _grupoDesconto;
        /// <summary>
        ///TpVlr_PercMinTit Tipo Valor ou Percentual Mínimo Título
        /// </summary>
        private string _tipoValorPercentualMinimo;
        /// <summary>
        ///Vlr_PercMinTit Valor ou Percentual Mínimo Título
        /// </summary>
        private readonly decimal _valorPercentualMinimo;
        /// <summary>
        ///TpVlr_PercMaxTit Tipo Valor ou Percentual Máximo Título
        /// </summary>
        private string _tipoValorPercentualMaximo;
        /// <summary>
        ///Vlr_PercMaxTit Valor ou Percentual Máximo Título
        /// </summary>
        private readonly decimal _valorPercentualMaximo;
        /// <summary>
        ///TpModlCalc Tipo Modelo Cálculo
        /// </summary>
        private int _modeloCalculo;
        /// <summary>
        ///TpAutcRecbtVlrDivgte Tipo Autorização Recebimento Valor Divergente 
        /// </summary>
        private readonly int _tipoAutorizacaoRebVlrDivergente;
        /// <summary>
        /// 
        /// </summary>
        private IReadOnlyCollection<GrupoCalculo> _grupoCalculado;
        /// <summary>
        ///QtdPgtoParclRegtd Quantidade Pagamento Parcial Registrado
        /// </summary>
        private int? _qtdPagamentoParcialRegistrado;
        /// <summary>
        ///VlrSldTotAtlPgtoTit Valor Saldo Total Atual Pagamento Título
        /// </summary>
        private decimal _valorSaldoTotalAtual;
        /// <summary>
        /// Grupo_DDA0110R1_BaixaOperac Grupo Baixa Operacional
        /// </summary>
        private IReadOnlyCollection<GrupoBaixa> _grupoBaixaOperacional;
        /// <summary>
        /// Grupo_DDA0110R1_BaixaEft Grupo Baixa Efetiva
        /// </summary>
        private IReadOnlyCollection<GrupoBaixa> _grupoBaixaEfetiva;

        private bool _existeBaixa;
        private DateTime _dataDePagamento;
        private readonly string _codigoDaColigada;
        private readonly string _codigoDaAgencia;
        private string _codigoDaPraca;
        private ICalendarioService _calendarioService;
        private readonly IAgenciaService _agenciaService;

        protected CalculoDeBoleto()
        {

        }

        private CalculoDeBoleto(RetornoDaCIPXmlDTO xmlObject, DateTime dataDePagamento, string codigoDaColigada, string codigoDaAgencia,
            ICalendarioService calendarioService, IAgenciaService agenciaService)
        {
            _modeloCalculo = xmlObject.TpModlCalc;
            _dataVencimento = xmlObject.DtVencTit;
            _valorTitulo = xmlObject.VlrTit;
            _tipoAutorizacaoRebVlrDivergente = xmlObject.TpAutcRecbtVlrDivgte;
            _indicadorPagamentoParcial = xmlObject.IndrPgtoParcl;
            _qtdPagamentoParcialAutorizado = xmlObject.QtdPgtoParcl;
            _qtdPagamentoParcialRegistrado = xmlObject.QtdPgtoParclRegtd;
            _valorAbatimento = xmlObject.VlrAbattTit;
            _tipoValorPercentualMaximo = xmlObject.TpVlr_PercMaxTit;
            _valorPercentualMaximo = xmlObject.Vlr_PercMaxTit;
            _valorPercentualMinimo = xmlObject.Vlr_PercMinTit;
            _tipoValorPercentualMinimo = xmlObject.TpVlr_PercMinTit;

            if (xmlObject.Grupo_DDA0110R1_DesctTit != null)
                _grupoDesconto = xmlObject.Grupo_DDA0110R1_DesctTit.Select(x => new GrupoValores
                {
                    Codigo = x.CodDesctTit,
                    Data = x.DtDesctTit,
                    ValorPercentual = x.Vlr_PercDesctTit,
                    ValorCalculado = x.Vlr_PercDesctTit
                }).ToList();

            if (xmlObject.Grupo_DDA0110R1_JurosTit != null)
                _grupoJuros = new GrupoValores
                {
                    Codigo = xmlObject.Grupo_DDA0110R1_JurosTit.CodJurosTit,
                    Data = xmlObject.Grupo_DDA0110R1_JurosTit.DtJurosTit,
                    ValorPercentual = xmlObject.Grupo_DDA0110R1_JurosTit.Vlr_PercJurosTit,
                    ValorCalculado = xmlObject.Grupo_DDA0110R1_JurosTit.Vlr_PercJurosTit
                };

            if (xmlObject.Grupo_DDA0110R1_MultaTit != null)
                _grupoMulta = new GrupoValores
                {
                    Codigo = xmlObject.Grupo_DDA0110R1_MultaTit.CodMultaTit,
                    Data = xmlObject.Grupo_DDA0110R1_MultaTit.DtMultaTit,
                    ValorPercentual = xmlObject.Grupo_DDA0110R1_MultaTit.Vlr_PercMultaTit,
                    ValorCalculado = xmlObject.Grupo_DDA0110R1_MultaTit.Vlr_PercMultaTit
                };

            _valorSaldoTotalAtual = xmlObject.VlrSldTotAtlPgtoTit;

            if (xmlObject.Grupo_DDA0110R1_Calc != null)
                _grupoCalculado = xmlObject.Grupo_DDA0110R1_Calc.Select(x => new GrupoCalculo
                {
                    DataValidadeCalculo = x.DtValiddCalc,
                    ValorCalculadoDesconto = x.VlrCalcdDesct,
                    ValorCalculadoJuros = x.VlrCalcdJuros,
                    ValorCalculadoMulta = x.VlrCalcdMulta,
                    ValorTotalCobrar = x.VlrTotCobrar
                }).ToList();

            if (xmlObject.Grupo_DDA0110R1_BaixaOperac != null)
                _grupoBaixaOperacional = xmlObject.Grupo_DDA0110R1_BaixaOperac.Select(x => new GrupoBaixa
                {
                    CodigoBarras = x.NumCodBarrasBaixaOperac,
                    DataProcessamento = x.DtProcBaixaOperac,
                    DataSituacao = x.DtHrSitBaixaOperac,
                    NumeroIdentificacao = x.NumIdentcBaixaOperac,
                    NumeroReferencialAtual = x.NumRefAtlBaixaOperac,
                    NumeroSequenciaAtual = x.NumSeqAtlzBaixaOperac,
                    Valor = x.VlrBaixaOperacTit
                }).ToList();

            if (xmlObject.Grupo_DDA0110R1_BaixaEft != null)
                _grupoBaixaEfetiva = xmlObject.Grupo_DDA0110R1_BaixaEft.Select(x => new GrupoBaixa
                {
                    CanalPagamento = x.CanPgto,
                    CodigoBarras = x.NumCodBarrasBaixaEft,
                    DataProcessamento = x.DtProcBaixaEft,
                    DataSituacao = x.DtHrSitBaixaEft,
                    MeioPagamento = x.MeioPgto,
                    NumeroIdentificacao = x.NumIdentcBaixaEft,
                    NumeroReferencialAtual = x.NumRefAtlBaixaEft,
                    NumeroSequenciaAtual = x.NumSeqAtlzBaixaEft,
                    Valor = x.VlrBaixaEftTit
                }).ToList();

            _dataDePagamento = dataDePagamento;

            _codigoDaAgencia = codigoDaAgencia;
            _codigoDaColigada = codigoDaColigada;

            var agencia = agenciaService.ObterAgenciaPeloCodColigadaECodAgenciaAsync(codigoDaColigada, codigoDaAgencia).Result;

            _codigoDaPraca = agencia.CodPraca;

            _calendarioService = calendarioService;
            _agenciaService = agenciaService;

            if ((TipoAutRecebimentoValorDivergente)xmlObject.TpAutcRecbtVlrDivgte == TipoAutRecebimentoValorDivergente.NaoAceitaValorDivergente)
            {
                PermiteAlterarValorTotal = "N";
            }
            else
            {
                PermiteAlterarValorTotal = "S";
            }

            AtribuirValorASerCalculado();
        }

        private CalculoDeBoleto(int tipoModeloCalculo,
                DateTime dataVencimento,
                decimal valorTitulo,
                int tipoAutorizacaoRecVlrDivergente,
                string indicadorPagamentoParcial,
                int qtdPagamentoParcialAutorizado,
                int qtdPagamentoParcialRegistrado,
                decimal valorAbatimento,
                string tipoValorPercentualMinimo,
                decimal valorPercentualMinimo,
                string tipoValorPercentualMaximo,
                decimal valorPercentualMaximo,
                decimal valorSaldoTotalAtual,
                GrupoValores grupoJuros,
                GrupoValores grupoMulta,
                IReadOnlyCollection<GrupoValores> grupoDesconto,
                IReadOnlyCollection<GrupoCalculo> grupoCalculado,
                DateTime dataPagamento,
                ICalendarioService calendarioService,
                IReadOnlyCollection<GrupoBaixa> grupoBaixaOperacional = null,
                IReadOnlyCollection<GrupoBaixa> grupoBaixaEfetiva = null)
        {
            _modeloCalculo = tipoModeloCalculo;
            _dataVencimento = dataVencimento;
            _valorTitulo = valorTitulo;
            _tipoAutorizacaoRebVlrDivergente = tipoAutorizacaoRecVlrDivergente;
            _indicadorPagamentoParcial = indicadorPagamentoParcial;
            _qtdPagamentoParcialAutorizado = qtdPagamentoParcialAutorizado;
            _qtdPagamentoParcialRegistrado = qtdPagamentoParcialRegistrado;
            _valorAbatimento = valorAbatimento;
            _tipoValorPercentualMaximo = tipoValorPercentualMaximo;
            _valorPercentualMaximo = valorPercentualMaximo;
            _valorPercentualMinimo = valorPercentualMinimo;
            _tipoValorPercentualMinimo = tipoValorPercentualMinimo;
            _grupoDesconto = grupoDesconto;
            _grupoJuros = grupoJuros;
            _grupoMulta = grupoMulta;
            _valorSaldoTotalAtual = valorSaldoTotalAtual;
            _grupoCalculado = grupoCalculado;
            _dataDePagamento = dataPagamento;
            _grupoBaixaOperacional = grupoBaixaOperacional ?? new List<GrupoBaixa>();
            _grupoBaixaEfetiva = grupoBaixaEfetiva ?? new List<GrupoBaixa>();
            _calendarioService = calendarioService;

            if ((TipoAutRecebimentoValorDivergente)tipoAutorizacaoRecVlrDivergente == TipoAutRecebimentoValorDivergente.NaoAceitaValorDivergente)
            {
                PermiteAlterarValorTotal = "N";
            }
            else
            {
                PermiteAlterarValorTotal = "S";
            }

            AtribuirValorASerCalculado();
        }

        public CalculoDeBoleto(NovaConsultaDeBoletoConcluidaEvent @event)
        {
            Id = @event.IdDoCalculoDeBoleto;
            IdDaConsultaDeBoleto = @event.IdDaConsultaDeBoleto;
            ValorASerCalculado = @event.ValorASerCalculado;
            ValorCalculado = @event.ValorCalculado;
            ValorDesconto = @event.ValorDesconto;
            ValorJuros = @event.ValorJuros;
            ValorMaximoCalculado = @event.ValorMaximoCalculado;
            ValorMinimoCalculado = @event.ValorMinimoCalculado;
            ValorMulta = @event.ValorMulta;
            PermiteAlterarValorTotal = @event.PermiteAlterarValorTotal;
        }

        public CalculoDeBoleto(NovaConsultaDeBoletoConcluidaComErroEvent @event)
        {
            Id = @event.IdDoCalculoDeBoleto.Value;
            IdDaConsultaDeBoleto = @event.IdDaConsultaDeBoleto;
            ValorASerCalculado = @event.ValorASerCalculado.Value;
            ValorCalculado = @event.ValorCalculado.Value;
            ValorDesconto = @event.ValorDesconto.Value;
            ValorJuros = @event.ValorJuros.Value;
            ValorMaximoCalculado = @event.ValorMaximoCalculado.Value;
            ValorMinimoCalculado = @event.ValorMinimoCalculado.Value;
            ValorMulta = @event.ValorMulta.Value;
            PermiteAlterarValorTotal = @event.PermiteAlterarValorTotal;
        }

        public virtual Guid Id { get; protected set; }
        public virtual Guid IdDaConsultaDeBoleto { get; protected set; }
        public virtual string PermiteAlterarValorTotal { get; protected set; }

        private decimal _valorMaximoCalculado;
        public virtual decimal ValorMaximoCalculado
        {
            get
            {
                return _valorMaximoCalculado;
            }
            private set
            {
                _valorMaximoCalculado = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorMinimoCalculado;
        public virtual decimal ValorMinimoCalculado
        {
            get
            {
                return _valorMinimoCalculado;
            }
            private set
            {
                _valorMinimoCalculado = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorCalculado;
        public virtual decimal ValorCalculado
        {
            get
            {
                return _valorCalculado;
            }
            set
            {
                _valorCalculado = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorDesconto;
        public virtual decimal ValorDesconto
        {
            get
            {
                return _valorDesconto;
            }
            set
            {
                _valorDesconto = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorMulta;
        public virtual decimal ValorMulta
        {
            get
            {
                return _valorMulta;
            }
            set
            {
                _valorMulta = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorJuros;
        public virtual decimal ValorJuros
        {
            get
            {
                return _valorJuros;
            }
            set
            {
                _valorJuros = Math.Truncate(value * 100) / 100;
            }
        }

        private decimal _valorSerCalculado;
        public virtual decimal ValorASerCalculado
        {
            get
            {
                return _valorSerCalculado;
            }
            set
            {
                _valorSerCalculado = Math.Truncate(value * 100) / 100;
            }
        }

        public virtual decimal ValorEncargos
        {
            get
            {
                return ValorJuros + ValorMulta;
            }
        }

        public virtual ConsultaDeBoleto ConsultaDeBoleto { get; protected set; }

        private void AtribuirValorASerCalculado()
        {
            decimal _baixaOperacional = 0, _baixaEfetiva = 0;

            if (_grupoBaixaOperacional != null)
                _baixaOperacional = _grupoBaixaOperacional.Sum(s => s.Valor);

            if (_grupoBaixaEfetiva != null)
                _baixaEfetiva = _grupoBaixaEfetiva.Sum(s => s.Valor);

            ValorASerCalculado = _valorTitulo - _valorAbatimento - (_baixaOperacional + _baixaEfetiva);

            _existeBaixa = (_grupoBaixaOperacional.Any()) || (_grupoBaixaEfetiva.Any());
        }

        /// <summary>
        /// Retorna os valores calculados de acordo com o Modelo de Cálculo
        /// </summary>
        public static Result<CalculoDeBoleto> Calcular(string xml, DateTime dataDePagamento, string codigoDaColigada, string codigoDaAgencia,
            ICalendarioService calendarioService, IAgenciaService agenciaService)
        {
            var xmlObject = RetornoDaCIPXmlDTO.FromXml(xml);

            var calculo = new CalculoDeBoleto(xmlObject, dataDePagamento, codigoDaColigada, codigoDaAgencia, calendarioService, agenciaService);

            var result = new Result<CalculoDeBoleto>(calculo);

            if (calculo.ValorASerCalculado <= 0 && calculo._valorSaldoTotalAtual <= 0)
            {
                result.AddError("Pagamento do valor integral efetivado e não possui Saldo para Pagamento.", "Tipo de Modelo de Cálculo.", typeof(CalculoDeBoleto).FullName);
                return result;
            }

            switch ((TipoModeloCalculo)calculo._modeloCalculo)
            {
                case TipoModeloCalculo.NaoInformado:
                    result.AddError("Tipo de Modelo de Cálculo inválido.", "Tipo de Modelo de Cálculo.", typeof(CalculoDeBoleto).FullName);
                    break;
                case TipoModeloCalculo.ReceboraCalculaTituloVencerVencido:
                    result = calculo.Tipo1RecebedoraCalculaVencerVencidos();
                    break;
                case TipoModeloCalculo.DestinatariaCalculaVencidosRecebedoraVencer:
                    result = calculo.Tipo2RecebedoraCalculaVencer();
                    break;
                case TipoModeloCalculo.DestinatariaCalculaTituloVencerVencido:
                    result = calculo.Tipo3DestinatariaCalculaVencerVencido();
                    break;
                case TipoModeloCalculo.CIPRecebedoraCalculaParcialVencerVencidos:
                    result = calculo.Tipo1RecebedoraCalculaVencerVencidos();
                    break;
                default:
                    break;
            }

            if (result.IsSuccess)
                calculo.CalcularValorMinimoMaximo();

            return result;
        }

        /// <summary>
        /// Retorna os valores calculados de acordo com o Modelo de Cálculo
        /// </summary>
        public static Result<CalculoDeBoleto> Calcular(int tipoModeloCalculo,
                DateTime dataVencimento,
                decimal valorTitulo,
                int tipoAutorizacaoRecVlrDivergente,
                string indicadorPagamentoParcial,
                int qtdPagamentoParcialAutorizado,
                int qtdPagamentoParcialRegistrado,
                decimal valorAbatimento,
                string tipoValorPercentualMinimo,
                decimal valorPercentualMinimo,
                string tipoValorPercentualMaximo,
                decimal valorPercentualMaximo,
                decimal valorSaldoTotalAtual,
                GrupoValores grupoJuros,
                GrupoValores grupoMulta,
                IReadOnlyCollection<GrupoValores> grupoDesconto,
                IReadOnlyCollection<GrupoCalculo> grupoCalculado,
                DateTime dataDePagamento,
                ICalendarioService calendarioService,
                IReadOnlyCollection<GrupoBaixa> grupoBaixaOperacional = null,
                IReadOnlyCollection<GrupoBaixa> grupoBaixaEfetiva = null,
                string codigoDaColigada = null,
                string codigoDaAgencia = null,
                IAgenciaService agenciaService = null)
        {
            var calculo = new CalculoDeBoleto(tipoModeloCalculo,
                dataVencimento,
                valorTitulo,
                tipoAutorizacaoRecVlrDivergente,
                indicadorPagamentoParcial,
                qtdPagamentoParcialAutorizado,
                qtdPagamentoParcialRegistrado,
                valorAbatimento,
                tipoValorPercentualMinimo,
                valorPercentualMinimo,
                tipoValorPercentualMaximo,
                valorPercentualMaximo,
                valorSaldoTotalAtual,
                grupoJuros,
                grupoMulta,
                grupoDesconto,
                grupoCalculado,
                dataDePagamento,
                calendarioService,
                grupoBaixaOperacional,
                grupoBaixaEfetiva);

            var result = new Result<CalculoDeBoleto>(calculo);

            if (calculo.ValorASerCalculado <= 0 && calculo._valorSaldoTotalAtual <= 0)
            {
                result.AddError("Pagamento do valor integral efetivado e não possui Saldo para Pagamento.", "Tipo de Modelo de Cálculo.", typeof(CalculoDeBoleto).FullName);
                return result;
            }

            var agencia = agenciaService.ObterAgenciaPeloCodColigadaECodAgenciaAsync(codigoDaColigada, codigoDaAgencia).Result;

            calculo._codigoDaPraca = agencia.CodPraca;

            switch ((TipoModeloCalculo)calculo._modeloCalculo)
            {
                case TipoModeloCalculo.NaoInformado:
                    result.AddError("Tipo de Modelo de Cálculo inválido.", "Tipo de Modelo de Cálculo.", typeof(CalculoDeBoleto).FullName);
                    break;
                case TipoModeloCalculo.ReceboraCalculaTituloVencerVencido:
                    result = calculo.Tipo1RecebedoraCalculaVencerVencidos();
                    break;
                case TipoModeloCalculo.DestinatariaCalculaVencidosRecebedoraVencer:
                    result = calculo.Tipo2RecebedoraCalculaVencer();
                    break;
                case TipoModeloCalculo.DestinatariaCalculaTituloVencerVencido:
                    result = calculo.Tipo3DestinatariaCalculaVencerVencido();
                    break;
                case TipoModeloCalculo.CIPRecebedoraCalculaParcialVencerVencidos:
                    result = calculo.Tipo1RecebedoraCalculaVencerVencidos();
                    break;
                default:
                    break;
            }

            if (result.IsSuccess)
                calculo.CalcularValorMinimoMaximo();

            return result;
        }

        /// <summary>
        /// Cálcular o Valor de desconto de acordo com o tipo correspondente
        /// </summary>
        private void CalcularValorDesconto()
        {
            int diferencaDias;
            decimal valor, valorTotalPercentual;
            GrupoValores grupoDescontoUtilizado = new GrupoValores();

            // Para ser elegível a desconto não pode:
            // Pagamento parcial e ser a última parcela
            if (_indicadorPagamentoParcial.Equals("S") && (_qtdPagamentoParcialRegistrado + 1) == _qtdPagamentoParcialAutorizado)
            {
                PermiteAlterarValorTotal = "N";
                return;
            }

            if (_grupoDesconto == null)
                return;

            // Data de Pagamento precisa ser maior que data de Vencimento
            // Não pode existir nenhum tipo de baixa
            if (_dataDePagamento > _dataVencimento || _existeBaixa)
                return;

            foreach (GrupoValores item in _grupoDesconto.OrderBy(s => s.Data))
            {
                if (!item.Data.HasValue)
                    item.Data = _dataVencimento;

                diferencaDias = item.Data.Value.Subtract(_dataDePagamento.Date).Days + 1;

                switch ((TipoDesconto)item.Codigo)
                {
                    case TipoDesconto.Isento:
                        item.ValorCalculado = ValorASerCalculado;
                        break;
                    case TipoDesconto.ValorFixo:
                        item.ValorCalculado = ValorASerCalculado - item.ValorPercentual;
                        break;
                    case TipoDesconto.PercentualFixo:
                        valor = ValorASerCalculado * (item.ValorPercentual / 100);
                        item.ValorCalculado = ValorASerCalculado - valor;
                        break;
                    case TipoDesconto.ValorPorDiaCorrido:
                        valor = diferencaDias * item.ValorPercentual;
                        item.ValorCalculado = ValorASerCalculado - valor;
                        break;
                    case TipoDesconto.ValorPorDiaUtil:
                        {
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(_dataDePagamento.Date, item.Data.Value, _codigoDaPraca).QuantidadeDiasUteis;
                            valor = diferencaDias * item.ValorPercentual;
                            item.ValorCalculado = ValorASerCalculado - valor;
                        }
                        break;
                    case TipoDesconto.PercentualPorDiaCorrido:
                        valor = ValorASerCalculado * (item.ValorPercentual / 100);
                        valorTotalPercentual = diferencaDias * valor;
                        item.ValorCalculado = ValorASerCalculado - valorTotalPercentual;
                        break;
                    case TipoDesconto.PercentualPorDiaUtil:
                        {
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(_dataDePagamento.Date, item.Data.Value, _codigoDaPraca).QuantidadeDiasUteis;
                            valor = _valorSerCalculado * (item.ValorPercentual / 100);
                            valorTotalPercentual = diferencaDias * valor;
                            item.ValorCalculado = ValorASerCalculado - valorTotalPercentual;
                        }
                        break;
                    default:
                        break;
                }
            }

            if (_grupoDesconto.Count == 1)
            {
                grupoDescontoUtilizado = _grupoDesconto.FirstOrDefault();
            }
            else
            {
                grupoDescontoUtilizado = _grupoDesconto.Where(w => w.Data.Value.Subtract(_dataDePagamento.Date).Days >= 0)
                                                      .OrderBy(s => s.Data.Value.Subtract(_dataDePagamento.Date).Days)
                                                      .FirstOrDefault();
            }

            ValorDesconto = grupoDescontoUtilizado != null ? ValorASerCalculado - grupoDescontoUtilizado.ValorCalculado : 0;
        }

        /// <summary>
        /// Cálcular o Valor de juros de acordo com o tipo correspondente
        /// </summary>
        private void CalcularValorJuros()
        {
            int diferencaDias;
            decimal valor, valorPercentual, valorTotalPercentual;
            DateTime dataInicioJuros;

            valor = 0;

            if (_grupoJuros == null)
                return;

            switch ((TipoJuros)_grupoJuros.Codigo)
            {
                case TipoJuros.ValorDiaCorrido:
                case TipoJuros.PercentualDiaCorrido:
                case TipoJuros.PercentualMesCorrido:
                case TipoJuros.PercentualAnoCorrido:
                    dataInicioJuros = _grupoJuros.Data ?? _calendarioService.ObterProximoDiaUtil(_dataVencimento, _codigoDaPraca).AddDays(1);
                    break;
                case TipoJuros.ValorDiaUtil:
                case TipoJuros.PercentualDiaUtil:
                case TipoJuros.PercentualMesDiaUtil:
                case TipoJuros.PercentualAnoDiaUtil:
                default:
                    dataInicioJuros = _grupoJuros.Data.HasValue ? _calendarioService.ObterProximoDiaUtil(_grupoJuros.Data.Value, _codigoDaPraca) :
                                                         _calendarioService.ObterProximoDiaUtil(_dataVencimento, _codigoDaPraca).AddDays(1);
                    break;
            }

            if (_dataDePagamento.Date >= dataInicioJuros)
            {
                // 1 dia de cálculo para data de pagamento igual ao inicio do juros
                // Adicionar 1 para a diferença de dia, pois o subtract não considerar a data inicio como 1 dia
                diferencaDias = _dataDePagamento.Date == dataInicioJuros.Date ? 1 : _dataDePagamento.Subtract(dataInicioJuros.Date).Days + 1;

                // Verificar se a data base já possui cálculo de juros
                switch ((TipoJuros)_grupoJuros.Codigo)
                {
                    case TipoJuros.NaoInformado:
                        break;
                    case TipoJuros.ValorDiaCorrido:
                        valor = diferencaDias * _grupoJuros.ValorPercentual;
                        break;
                    case TipoJuros.PercentualDiaCorrido:
                        if (_modeloCalculo.Equals(2) || _modeloCalculo.Equals(3))
                        {
                            valorPercentual = ValorASerCalculado * (_grupoJuros.ValorPercentual / 100);
                            valor = diferencaDias * valorPercentual;
                        }
                        break;
                    case TipoJuros.PercentualMesCorrido:
                        valorPercentual = (_grupoJuros.ValorPercentual / 100) / 30;
                        valorTotalPercentual = diferencaDias * valorPercentual;
                        valor = ValorASerCalculado * valorTotalPercentual;
                        break;
                    case TipoJuros.PercentualAnoCorrido:
                        if (_modeloCalculo.Equals(2) || _modeloCalculo.Equals(3))
                        {
                            valorPercentual = (_grupoJuros.ValorPercentual / 100) / 365;

                            valorTotalPercentual = diferencaDias * valorPercentual;
                            valor = ValorASerCalculado * valorTotalPercentual;
                        }
                        break;
                    case TipoJuros.Isento:
                        _grupoJuros.ValorCalculado = ValorASerCalculado;
                        break;
                    case TipoJuros.ValorDiaUtil:
                        {
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(dataInicioJuros, _dataDePagamento.Date, _codigoDaPraca).QuantidadeDiasUteis;
                            valor = diferencaDias * _grupoJuros.ValorPercentual;
                        }
                        break;
                    case TipoJuros.PercentualDiaUtil:
                        if (_modeloCalculo.Equals(2) || _modeloCalculo.Equals(3))
                        {
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(dataInicioJuros, _dataDePagamento.Date, _codigoDaPraca).QuantidadeDiasUteis;
                            valorPercentual = _valorSerCalculado * (_grupoJuros.ValorPercentual / 100);
                            valor = diferencaDias * valorPercentual;
                        }
                        break;
                    case TipoJuros.PercentualMesDiaUtil:
                        {
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(dataInicioJuros, _dataDePagamento.Date, _codigoDaPraca).QuantidadeDiasUteis;
                            valorPercentual = (_grupoJuros.ValorPercentual / 100) / 30;
                            valorTotalPercentual = diferencaDias * valorPercentual;
                            valor = ValorASerCalculado * valorTotalPercentual;
                        }
                        break;
                    case TipoJuros.PercentualAnoDiaUtil:
                        if (_modeloCalculo.Equals(2) || _modeloCalculo.Equals(3))
                        {
                            valorPercentual = (_grupoJuros.ValorPercentual / 100) / 252;
                            diferencaDias = _calendarioService.ObterCalendarioEntreDatas(dataInicioJuros, _dataDePagamento.Date, _codigoDaPraca).QuantidadeDiasUteis;
                            valorTotalPercentual = diferencaDias * valorPercentual;
                            valor = ValorASerCalculado * valorTotalPercentual;
                        }
                        break;
                    default:
                        break;
                }
            }
            _grupoJuros.ValorCalculado = ValorASerCalculado + valor;
            ValorJuros = valor;

        }

        /// <summary>
        /// Cálcular o Valor de multa de acordo com o tipo correspondente
        /// </summary>
        private void CalcularValorMulta()
        {
            decimal valor, valorPercentual;
            DateTime dataInicioJuros;

            valor = 0;

            if (_grupoMulta == null)
                return;

            //Validar se vencimento é dia útil e caso não seja buscar próxima data útil para início de calculo
            dataInicioJuros = _grupoMulta.Data.HasValue ? _calendarioService.ObterProximoDiaUtil(_grupoMulta.Data.Value, _codigoDaPraca) :
                                                         _calendarioService.ObterProximoDiaUtil(_dataVencimento, _codigoDaPraca).AddDays(1);

            if (_dataDePagamento.Date >= dataInicioJuros.Date)
            {
                switch ((TipoMulta)_grupoMulta.Codigo)
                {
                    case TipoMulta.NaoInformado:
                    case TipoMulta.Isento:
                        break;
                    case TipoMulta.ValorFixo:
                        valor = _grupoMulta.ValorPercentual;
                        break;
                    case TipoMulta.Percentual:
                        valorPercentual = (_grupoMulta.ValorPercentual / 100);
                        valor = ValorASerCalculado * valorPercentual;
                        break;
                    default:
                        break;
                }
            }

            _grupoMulta.ValorCalculado = ValorASerCalculado + valor;
            ValorMulta = valor;

        }

        /// <summary>
        /// Cálcular os Valores Máximo e Mínimo permitidos para cobrança
        /// </summary>
        private void CalcularValorMinimoMaximo()
        {
            //Minimo
            if (_valorPercentualMinimo > 0)
            {
                if (_indicadorPagamentoParcial.Equals("S"))
                {
                    if (_tipoValorPercentualMinimo.Equals("P"))
                        ValorMinimoCalculado = _valorSaldoTotalAtual * (_valorPercentualMinimo / 100);
                    else
                        ValorMinimoCalculado = _valorPercentualMinimo;
                }
                else
                {
                    if (_tipoValorPercentualMinimo.Equals("P"))
                        ValorMinimoCalculado = ValorASerCalculado * (_valorPercentualMinimo / 100);
                    else
                        ValorMinimoCalculado = _valorPercentualMinimo;
                }
            }

            //Máximo
            if (_valorPercentualMaximo > 0)
            {
                if (_indicadorPagamentoParcial.Equals("S"))
                {
                    if (_tipoValorPercentualMaximo.Equals("P"))
                        ValorMaximoCalculado = _valorSaldoTotalAtual * (_valorPercentualMaximo / 100);
                    else
                        ValorMaximoCalculado = _valorPercentualMaximo;
                }
                else
                {
                    if (_tipoValorPercentualMaximo.Equals("P"))
                        ValorMaximoCalculado = ValorASerCalculado * (_valorPercentualMaximo / 100);
                    else
                        ValorMaximoCalculado = _valorPercentualMaximo;
                }
            }

        }

        /// <summary>
        /// Atribui valor a ser pago após os cálculos de Descontos, Juros e Multa
        /// </summary>
        private void AtribuirValorCalculado()
        {
            ValorCalculado = (ValorASerCalculado - ValorDesconto) + (ValorMulta + ValorJuros);
        }

        /// <summary>
        /// Validação Calculo Tipo 01 – Instituição recebedora calcula boletos a vencer e vencidos
        /// </summary>
        private Result ValidarTipo1RecebedoraCalculaVencerVencidos()
        {
            var result = new Result();

            if (_grupoJuros == null && !_grupoDesconto.Any())
            {
                result.AddError("Boleto não possui informação de Juros e/ou Descontos.", "Juros e desconto.", typeof(CalculoDeBoleto).FullName);
                return result;
            }
            return result;
        }

        /// <summary>
        /// Cálculo do Tipo 01 – Instituição recebedora calcula boletos a vencer e vencidos
        /// </summary>
        private Result<CalculoDeBoleto> Tipo1RecebedoraCalculaVencerVencidos()
        {
            var validationResult = ValidarTipo1RecebedoraCalculaVencerVencidos();

            if (validationResult.IsFailure)
                return validationResult.ToResult(this);

            CalcularValorDesconto();
            CalcularValorJuros();
            CalcularValorMulta();

            AtribuirValorCalculado();

            return validationResult.ToResult(this);
        }

        /// <summary>
        /// Validação Calculo Tipo 02 - Instituição destinatária calcula boletos vencidos e recebedora calcula boletos a vencer
        /// </summary>
        private Result ValidarTipo2RecebedoraCalculaVencer()
        {
            var result = new Result();

            if (_dataDePagamento > _dataVencimento)
            {
                if (_grupoJuros?.Codigo == (int)TipoJuros.Isento)
                    return result;

                if (_grupoCalculado == null)
                {
                    result.AddError("Grupo de Cálculo não encontrado para data de pagamento.", "Juros calculados.", typeof(CalculoDeBoleto).FullName);
                    return result;
                }

                if (!_grupoCalculado.Any())
                {
                    result.AddError("Grupo de Cálculo não encontrado para data de pagamento.", "Juros calculados.", typeof(CalculoDeBoleto).FullName);
                    return result;
                }
            }

            return result;
        }

        /// <summary>
        /// Cálculo do Tipo 02 - Instituição destinatária calcula boletos vencidos e recebedora calcula boletos a vencer
        /// </summary>
        private Result<CalculoDeBoleto> Tipo2RecebedoraCalculaVencer()
        {
            var validationResult = ValidarTipo2RecebedoraCalculaVencer();
            var jurosCalculado = new GrupoCalculo();

            if (validationResult.IsFailure)
                return validationResult.ToResult(this);

            if (_dataDePagamento <= _dataVencimento)
            {
                CalcularValorDesconto();
            }
            else
            {
                //DateTime dataInicioJuros = DataVencimento.AddDays(1);
                var primeiroDiaJuros = _calendarioService.ObterProximoDiaUtil(_dataVencimento.AddDays(1), _codigoDaPraca);

                var calendario = _calendarioService.ObterCalendarioEntreDatas(primeiroDiaJuros, _dataDePagamento, _codigoDaPraca);

                if (calendario.Feriados.Any())
                {
                    var dataDaPraca = _calendarioService.ObterDiaUtilAnterior(_dataDePagamento.AddDays(-calendario.Feriados.Count()).Date, _codigoDaPraca);

                    jurosCalculado = _grupoCalculado.Where(w => w.DataValidadeCalculo.Date == dataDaPraca)
                                                       .OrderBy(o => o.DataValidadeCalculo)
                                                       .FirstOrDefault();
                }
                else
                {
                    jurosCalculado = _grupoCalculado.Where(w => w.DataValidadeCalculo.Date == _dataDePagamento.Date).FirstOrDefault();
                }

                if (jurosCalculado == null)
                {
                    validationResult.AddError("Grupo de Cálculo não encontrado para data de pagamento.", "Cálculo de juros.", typeof(CalculoDeBoleto).FullName);
                    return validationResult.ToResult(this);
                }

                ValorJuros = jurosCalculado.ValorCalculadoJuros;
                ValorMulta = jurosCalculado.ValorCalculadoMulta;
            }

            AtribuirValorCalculado();

            return validationResult.ToResult(this);
        }

        /// <summary>
        /// Validação Calculo Tipo 03 – Instituição destinatária calcula boletos a vencer e vencidos
        /// </summary>
        private Result ValidarTipo3DestinatariaCalculaVencerVencido()
        {
            var result = new Result();

            if (_grupoCalculado == null)
            {
                result.AddError("Boleto não possui informação de cálculo.", "Cálculo", typeof(CalculoDeBoleto).FullName);
                return result;
            }

            if (!_grupoCalculado.Any())
            {
                result.AddError("Boleto não possui informação de cálculo.", "Cálculo", typeof(CalculoDeBoleto).FullName);
                return result;
            }

            return result;
        }

        /// <summary>
        /// Cálculo do Tipo 03 – Instituição destinatária calcula boletos a vencer e vencidos
        /// </summary>
        private Result<CalculoDeBoleto> Tipo3DestinatariaCalculaVencerVencido()
        {
            var validationResult = ValidarTipo3DestinatariaCalculaVencerVencido();

            if (validationResult.IsFailure)
                return validationResult.ToResult(this);

            var jurosCalculado = _grupoCalculado.Where(w => w.DataValidadeCalculo == _dataDePagamento).FirstOrDefault();

            if (jurosCalculado == null)
            {
                validationResult.AddError("Grupo de Cálculo não encontrado.", "Cálculo de juros.", typeof(CalculoDeBoleto).FullName);
                return validationResult.ToResult(this);
            }

            ValorCalculado = jurosCalculado.ValorTotalCobrar;
            ValorDesconto = jurosCalculado.ValorCalculadoDesconto;
            ValorJuros = jurosCalculado.ValorCalculadoJuros;
            ValorMulta = jurosCalculado.ValorCalculadoMulta;

            var proximoDiaUtilVencimento = _calendarioService.ObterProximoDiaUtil(_dataVencimento, _codigoDaPraca);

            // Se dt. Vecto não é dia útil e o pagamento é feito no dia primeiro dia útil subsequente, não devemos considerar juros
            if (_dataDePagamento.Date == proximoDiaUtilVencimento.Date && !_calendarioService.DiaUtil(_dataVencimento, _codigoDaPraca))
            {
                ValorCalculado -= (jurosCalculado.ValorCalculadoJuros + jurosCalculado.ValorCalculadoMulta);
            }
            else
            {
                ValorJuros = jurosCalculado.ValorCalculadoJuros;
                ValorMulta = jurosCalculado.ValorCalculadoMulta;
            }

            return validationResult.ToResult(this);
        }

        /// <summary>
        /// Cálculo do Tipo 04 – CIP calcula boletos a vencer e vencidos
        /// </summary>
        private Result<CalculoDeBoleto> Tipo4CIPCalculaVencerVencido()
        {
            var validationResult = new Result();

            var jurosCalculado = _grupoCalculado.FirstOrDefault();

            var proximoDiaUtilVencimento = _calendarioService.ObterProximoDiaUtil(_dataVencimento, _codigoDaPraca);

            if (jurosCalculado == null)
            {
                CalcularValorDesconto();
                CalcularValorJuros();
                CalcularValorMulta();

                if (_valorSaldoTotalAtual > 0)
                {
                    ValorCalculado = _valorSaldoTotalAtual;
                }
                else
                {
                    AtribuirValorCalculado();
                }
            }
            else
            {
                ValorCalculado = jurosCalculado.ValorTotalCobrar;

                if (jurosCalculado.ValorCalculadoDesconto == 0)
                    CalcularValorDesconto();
                else
                    ValorDesconto = jurosCalculado.ValorCalculadoDesconto;

                if (jurosCalculado.ValorCalculadoJuros == 0)
                    CalcularValorJuros();
                else
                    ValorJuros = jurosCalculado.ValorCalculadoJuros;

                if (jurosCalculado.ValorCalculadoMulta == 0)
                    CalcularValorMulta();
                else
                    ValorMulta = jurosCalculado.ValorCalculadoMulta;

                // Se dt. Vecto não é dia útil e o pagamento é feito no dia primeiro dia útil subsequente, não devemos considerar juros
                if (_dataDePagamento.Date == proximoDiaUtilVencimento.Date && !_calendarioService.DiaUtil(_dataVencimento, _codigoDaPraca))
                    ValorCalculado -= (ValorJuros + ValorMulta);
            }

            return validationResult.ToResult(this);
        }
    }
}
