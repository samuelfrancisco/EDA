﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.Boletos.Commands
{
    public class ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand : CommandBase
    {
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public int CodigoDeErro { get; set; }
        public string DescricaoDoErro { get; set; }
    }
}
