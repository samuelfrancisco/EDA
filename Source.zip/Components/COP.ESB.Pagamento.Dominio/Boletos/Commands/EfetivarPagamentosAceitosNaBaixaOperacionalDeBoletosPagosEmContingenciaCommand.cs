﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.Boletos.Commands
{
    public class EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommand : CommandBase
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public List<EfetivarPagamentosAceitosNaBaixaOperacionalDeBoletosPagosEmContingenciaCommandPagamento> Pagamentos { get; set; }
    }
}
