﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.Boletos.Commands
{
    public class ConcluirCancelamentoDePagamentoDeBoletoCommand : CommandBase
    {
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
    }
}
