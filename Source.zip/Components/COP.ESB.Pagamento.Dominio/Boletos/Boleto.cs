﻿using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Commands;
using COP.ESB.Pagamento.Dominio.Boletos.Enums;
using COP.ESB.Pagamento.Dominio.Boletos.Events;
using COP.ESB.Pagamento.Dominio.Boletos.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.Boletos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace COP.ESB.Pagamento.Dominio.Boletos
{
    public class Boleto : EventSourcedAggregateRoot
    {
        protected Boleto()
            : base()
        {
        }

        protected Boleto(CodigoDeBarras codigoDeBarras, LinhaDigitavel linhaDigitavel, RegistrarNovoBoletoCommand command)
            : base()
        {
            Update(new NovoBoletoRegistradoEvent
            {
                CodigoDeBarras = codigoDeBarras.Valor,
                LinhaDigitavel = linhaDigitavel.Valor,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public virtual CodigoDeBarras CodigoDeBarras { get; protected set; }
        public virtual LinhaDigitavel LinhaDigitavel { get; protected set; }
        public virtual IList<ConsultaDeBoleto> Consultas { get; protected set; } = new List<ConsultaDeBoleto>();
        public virtual IList<PagamentoDeBoleto> Pagamentos { get; protected set; } = new List<PagamentoDeBoleto>();

        public static Result<Boleto> RegistrarNovoBoleto(RegistrarNovoBoletoCommand command, IBancoService bancoService,
            ICodigoDeBarrasFactory codigoDeBarrasFactory, ILinhaDigitavelFactory linhaDigitavelFactory)
        {
            var validationResult = ValidarRegistroDeNovoBoleto(command.CodigoDeBarras, command.LinhaDigitavel);

            if (validationResult.IsFailure)
            {
                validationResult.ErroMessage.Message = "Dados inválidos para o registro de novo boleto.";
                validationResult.ErroMessage.StatusCode = 400;
                return validationResult.ToResult<Boleto>();
            }

            if (!string.IsNullOrWhiteSpace(command.CodigoDeBarras))
                return RegistrarNovoBoletoPeloCodigoDeBarras(command, bancoService, codigoDeBarrasFactory, linhaDigitavelFactory);

            return RegistrarNovoBoletoPelaLinhaDigitavel(command, bancoService, codigoDeBarrasFactory, linhaDigitavelFactory);
        }

        public Result<ConsultaDeBoleto> IniciarNovaConsulta(IniciarNovaConsultaDeBoletoCommandV2 command, DateTime dataDeProcessamento,
            IConsultaDeBoletoFactory consultaDeBoletoFactory)
        {
            var consultaResult = consultaDeBoletoFactory.Iniciar(command, dataDeProcessamento, CodigoDeBarras.ObterOValorDoBoleto(),
               CodigoDeBarras.ObterADataDeVencimentoDoBoleto());

            if (consultaResult.IsSuccess)
            {
                var consulta = consultaResult.Value;

                if (consulta.FoiRealizadaEmContingencia && consulta.EBoletoSemRegistro)
                {
                    Update(PreencherEventoDeInicioDeNovaConsulta(new NovaConsultaDeBoletoSemRegistroIniciadaEmContingenciaEvent(), command,
                        consulta, dataDeProcessamento));
                }
                else if (consulta.FoiRealizadaEmContingencia)
                {
                    Update(PreencherEventoDeInicioDeNovaConsulta(new NovaConsultaDeBoletoIniciadaEmContingenciaEvent(), command,
                        consulta, dataDeProcessamento));
                }
                else if (consulta.EBoletoSemRegistro)
                {
                    Update(PreencherEventoDeInicioDeNovaConsulta(new NovaConsultaDeBoletoSemRegistroIniciadaEvent(), command,
                        consulta, dataDeProcessamento));
                }
                else
                {
                    Update(PreencherEventoDeInicioDeNovaConsulta(new NovaConsultaDeBoletoIniciadaEvent(), command,
                        consulta, dataDeProcessamento));
                }
            }

            return consultaResult;
        }

        public Result ProcessarRetornoDaConsultaDoBoletoNaCIP(ProcessarRetornoDaConsultaDoBoletoNaCIPCommand command,
            IServicoDeCalculoDeBoleto servicoDeCalculoDeBoleto)
        {
            var result = new Result();

            var consulta = Consultas.FirstOrDefault(x => x.Id == command.IdDaConsultaDeBoleto);

            if (consulta == null)
            {
                result.AddError(string.Format("Consulta {0} não encontrada.", command.IdDaConsultaDeBoleto), "Consulta.", typeof(Boleto).FullName);
                return result;
            }

            if (consulta.Status == ConsultaDeBoletoStatus.Consultado)
            {
                result.AddError(string.Format("A {0} consulta já foi concluída.", consulta.Id), "Consulta.", typeof(Boleto).FullName);
                return result;
            }

            var processoResult = consulta.ProcessarORetornoDaConsultaDoBoletoNaCIP(command, servicoDeCalculoDeBoleto);

            var calculo = processoResult.Value;

            if (processoResult.IsFailure)
            {
                var stringBuilder = new StringBuilder();

                foreach (var erro in processoResult.ErroMessage.Errors)
                    stringBuilder.AppendLine(erro.Message);

                Update(new NovaConsultaDeBoletoConcluidaComErroEvent
                {
                    IdDoBoleto = Id,
                    IdDaConsultaDeBoleto = consulta.Id,
                    EmpresaAplicacaoTransacaoId = consulta.EmpresaAplicacaoTransacaoId,
                    CodigoDeErro = CodigosDeErro.RegraDeNegocioNaoAtendida,
                    DescricaoDoErro = stringBuilder.ToString(),
                    XmlRetornadoPelaCIP = command.XmlRetornadoPelaCIP,
                    FoiGeradoCalculo = calculo != null,
                    IdDoCalculoDeBoleto = calculo?.Id,
                    ValorASerCalculado = calculo?.ValorASerCalculado,
                    ValorCalculado = calculo?.ValorCalculado,
                    ValorDesconto = calculo?.ValorDesconto,
                    ValorJuros = calculo?.ValorJuros,
                    ValorMaximoCalculado = calculo?.ValorMaximoCalculado,
                    ValorMinimoCalculado = calculo?.ValorMinimoCalculado,
                    ValorMulta = calculo?.ValorMulta,
                    ValorTotal = calculo?.ValorCalculado,
                    PermiteAlterarValorTotal = calculo?.PermiteAlterarValorTotal,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });

                return processoResult;
            }

            Update(new NovaConsultaDeBoletoConcluidaEvent
            {
                IdDoBoleto = Id,
                IdDaConsultaDeBoleto = consulta.Id,
                IdDoCalculoDeBoleto = calculo.Id,
                EmpresaAplicacaoTransacaoId = consulta.EmpresaAplicacaoTransacaoId,
                XmlRetornadoPelaCIP = command.XmlRetornadoPelaCIP,
                ValorASerCalculado = calculo.ValorASerCalculado,
                ValorCalculado = calculo.ValorCalculado,
                ValorDesconto = calculo.ValorDesconto,
                ValorJuros = calculo.ValorJuros,
                ValorMaximoCalculado = calculo.ValorMaximoCalculado,
                ValorMinimoCalculado = calculo.ValorMinimoCalculado,
                ValorMulta = calculo.ValorMulta,
                ValorTotal = calculo.ValorCalculado,
                PermiteAlterarValorTotal = calculo.PermiteAlterarValorTotal,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            return processoResult;
        }

        public Result ConcluirAConsultaComErroNaConsultaACIP(ConcluirAConsultaDoBoletoComErroNaConsultaACIPCommand command)
        {
            var result = new Result();

            var consulta = Consultas.FirstOrDefault(x => x.Id == command.IdDaConsultaDeBoleto);

            if (consulta == null)
            {
                result.AddError(string.Format("Consulta {0} não encontrada.", command.IdDaConsultaDeBoleto), "Consulta.", typeof(Boleto).FullName);
                return result;
            }

            if (consulta.Status == ConsultaDeBoletoStatus.Consultado)
                result.AddError(string.Format("A {0} consulta já foi concluída.", consulta.Id), "Consulta.", typeof(Boleto).FullName);

            if (result.IsSuccess)
            {
                Update(new NovaConsultaDeBoletoConcluidaComErroNaConsultaACIPEvent
                {
                    IdDoBoleto = Id,
                    IdDaConsultaDeBoleto = consulta.Id,
                    EmpresaAplicacaoTransacaoId = consulta.EmpresaAplicacaoTransacaoId,
                    CodigoDeErro = command.CodigoDeErro,
                    DescricaoDoErro = command.DescricaoDoErro,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }

            return result;
        }

        public Result<PagamentoDeBoleto> IniciarNovoPagamento(IniciarNovoPagamentoDeBoletoCommandV3 command, DateTime dataDeProcessamento,
            IPagamentoDeBoletoFactory pagamentoDeBoletoFactory, IBancoService bancoService, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var validationResult = new Result();

            if (configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos == null)
                validationResult.AddError("Não existe uma trasação Boletos configurada no sistema.",
                    "Não existe uma trasação Boletos configurada no sistema.",
                    typeof(ConsultaDeBoleto).FullName);

            if (configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos?.ConfiguracoesDaTransacao?.EmpresasAplicacoesTransacoes?.All(x => x.EmpresaAplicacaoId != command.EmpresaAplicacaoId) == true)
                validationResult.AddError($"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {command.EmpresaAplicacaoId}.",
                    $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {command.EmpresaAplicacaoId}.",
                    typeof(ConsultaDeBoleto).FullName);

            if (validationResult.IsFailure)
                return validationResult.ToResult<PagamentoDeBoleto>();

            var empresaAplicacaoTransacao = configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes
              .First(x => x.EmpresaAplicacaoId == command.EmpresaAplicacaoId);

            var consulta = Consultas.FirstOrDefault(x => x.Id == command.IdDaConsultaDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacao.EmpresaAplicacaoTransacaoId);

            validationResult = ValidarInicioDeNovoPagamento(command, dataDeProcessamento, consulta);

            if (validationResult.IsFailure)
                return validationResult.ToResult<PagamentoDeBoleto>();

            var result = pagamentoDeBoletoFactory.IniciarNovoPagamento(command, CodigoDeBarras, consulta);

            if (result.IsFailure)
                return result;

            Update(GerarEventoDeInicioDeNovoPagamento(command, consulta, result.Value, bancoService, configuracoesDoMotorService));

            return result;
        }

        public void ValidarSaldoDisponivelDaContaCorrente(ValidarSaldoDisponivelDaContaCorrenteCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmPagamento)
                return;

            var result = pagamento.ValidarSaldoDisponivelDaContaCorrente(command.SaldoDisponivel);

            if (result.IsFailure)
            {
                Update(new PagamentoDeBoletoRecusadoEvent
                {
                    IdDoBoleto = pagamento.IdDoBoleto,
                    IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = pagamento.Id,
                    EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                    MotivoDaRecusa = "Valor do pagamento superior ao saldo disponível na conta corrente.",
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });

                return;
            }

            Update(new SaldoDisponivelDaContaCorrenteValidadoEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                CodigoDaColigada = pagamento.Consulta.CodigoDaColigada,
                CodigoDaAgencia = pagamento.Consulta.CodigoDaAgencia,
                NumeroDaContaCorrente = pagamento.Consulta.NumeroDaContaCorrente,
                ValorDoPagamento = pagamento.ValorDoPagamento,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrente(RecusarPagamentoDeBoletoPorErroAoConsultarSaldoDaContaCorrenteCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmPagamento)
                return;

            var motivoDaRecusa = !string.IsNullOrWhiteSpace(command.DescricaoDoErro)
                ? $"Não foi possível consultar o saldo da conta corrente: {command.DescricaoDoErro}."
                : "Não foi possível consultar o saldo da conta corrente.";

            Update(new PagamentoDeBoletoRecusadoEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrente(RecusarPagamentoDeBoletoPorErroAoDebitarContaCorrenteCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmPagamento)
                return;

            var motivoDaRecusa = !string.IsNullOrWhiteSpace(command.DescricaoDoErro)
                ? $"Não foi possível debitar a conta corrente: {command.DescricaoDoErro}."
                : "Não foi possível debitar a conta corrente.";

            Update(new PagamentoDeBoletoRecusadoEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                MotivoDaRecusa = motivoDaRecusa,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void MarcarPagamentoComoPendenteDeBaixaOperacional(MarcarPagamentoDeBoletoComoPendenteDeBaixaOperacionalCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmPagamento && pagamento.Status != PagamentoDeBoletoStatus.DebitadoPelaAplicacao
                && pagamento.Status != PagamentoDeBoletoStatus.DebitadoPeloMotor)
                return;

            Update(new PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void EfetivarPagamentoDeBoleto(EfetivarPagamentoDeBoletoCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status == PagamentoDeBoletoStatus.PendenteDeBaixaOperacional
                || (pagamento.EBoletoSemRegistro && (pagamento.Status == PagamentoDeBoletoStatus.EmPagamento
                || pagamento.Status == PagamentoDeBoletoStatus.DebitadoPelaAplicacao
                || pagamento.Status == PagamentoDeBoletoStatus.DebitadoPeloMotor)))
            {
                Update(new PagamentoDeBoletoEfetivadoEvent
                {
                    IdDoBoleto = pagamento.IdDoBoleto,
                    IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = pagamento.Id,
                    EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRecusada(MarcarPagamentoDeBoletoComoBaixaOperacionalRecusadaCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)
                return;

            Update(new PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                MotivoDaRecusa = command.MotivoDaRecusa,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitada(MarcarPagamentoDeBoletoComoBaixaOperacionalRejeitadaCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)
                return;

            Update(new PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                MotivoDaRecusa = command.MotivoDaRecusa,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void RecusarPagamentoDeBoletoRealizadoEmContingencia(RecusarPagamentoDeBoletoRealizadoEmContingenciaCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.PendenteDeBaixaOperacional)
                return;

            Update(new PagamentoDeBoletoRecusadoEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                MotivoDaRecusa = command.MotivoDaRecusa,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public Result CancelarPagamento(IniciarCancelamentoDePagamentoDeBoletoCommandV2 command, DateTime dataDeProcessamento, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = new Result();

            if (configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos == null)
                result.AddError("Não existe uma trasação Boletos configurada no sistema.",
                    "Não existe uma trasação Boletos configurada no sistema.",
                    typeof(ConsultaDeBoleto).FullName);

            if (configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos?.ConfiguracoesDaTransacao?.EmpresasAplicacoesTransacoes?.All(x => x.EmpresaAplicacaoId != command.EmpresaAplicacaoId) == true)
                result.AddError($"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {command.EmpresaAplicacaoId}.",
                    $"Não existe uma trasação Boletos configurada no sistema para a Empresa X Aplicacao = {command.EmpresaAplicacaoId}.",
                    typeof(ConsultaDeBoleto).FullName);

            if (result.IsFailure)
                return result;

            var empresaAplicacaoTransacao = configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos.ConfiguracoesDaTransacao.EmpresasAplicacoesTransacoes
              .First(x => x.EmpresaAplicacaoId == command.EmpresaAplicacaoId);

            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto
            && x.EmpresaAplicacaoTransacaoId == empresaAplicacaoTransacao.EmpresaAplicacaoTransacaoId);

            if (pagamento == null)
            {
                result.AddError($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.",
                    $"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.",
                    typeof(ConsultaDeBoleto).FullName);

                if (result.IsFailure)
                    return result;
            }

            var consulta = Consultas.First(x => x.Id == pagamento.IdDaConsultaDeBoleto);

            result = pagamento.ValidarCancelamento(command, dataDeProcessamento, configuracoesDoMotorService);

            if (result.IsSuccess)
            {
                Update(GerarEventoDeCancelamento(command, consulta, pagamento, configuracoesDoMotorService));
            }

            return result;
        }

        public void MarcarPagamentoComoPendenteDeCancelamentoDeBaixaOperacional(MarcarPagamentoDeBoletoComoPendenteDeCancelamentoDeBaixaOperacionalCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmEstorno)
                return;

            Update(new PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void ConcluirCancelamentoDePagamento(ConcluirCancelamentoDePagamentoDeBoletoCommand command)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == command.IdDoPagamentoDeBoleto);

            if (pagamento == null)
                throw new InvalidOperationException($"Pagamento de boleto {command.IdDoPagamentoDeBoleto} não encontrado.");

            if (pagamento.Status != PagamentoDeBoletoStatus.EmEstorno && pagamento.Status != PagamentoDeBoletoStatus.PendenteDeCancelamentoDeBaixaOperacional)
                return;

            Update(new CancelamentoDePagamentoDeBoletoConcluidoEvent
            {
                IdDoBoleto = pagamento.IdDoBoleto,
                IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = pagamento.Id,
                EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        protected NovaConsultaDeBoletoIniciadaBaseEvent PreencherEventoDeInicioDeNovaConsulta(NovaConsultaDeBoletoIniciadaBaseEvent @event,
            IniciarNovaConsultaDeBoletoCommandV2 command, ConsultaDeBoleto consulta, DateTime dataDeProcessamento)
        {
            var pagamentoRecenteValido = ObterUltimoPagamentoRecenteValido(dataDeProcessamento);

            @event.IdDoBoleto = Id;
            @event.IdDaConsultaDeBoleto = consulta.Id;
            @event.EmpresaAplicacaoTransacaoId = consulta.EmpresaAplicacaoTransacaoId;
            @event.Coligada = consulta.CodigoDaColigada;
            @event.Agencia = consulta.CodigoDaAgencia;
            @event.ContaCorrente = consulta.NumeroDaContaCorrente;
            @event.CodigoDeBarras = CodigoDeBarras.Valor;
            @event.ValorNominal = CodigoDeBarras.ObterOValorDoBoleto();
            @event.DataDePagamento = consulta.DataDePagamento;
            @event.DataDeProcessamento = dataDeProcessamento;
            @event.FoiIniciadaComDuplicidade = pagamentoRecenteValido != null;
            @event.DataDaConsulta = consulta.DataDaConsulta;
            @event.CorrelationMessage = command;
            @event.OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command;

            return @event;
        }

        protected NovoPagamentoDeBoletoIniciadoBaseEventV2 GerarEventoDeInicioDeNovoPagamento(IniciarNovoPagamentoDeBoletoCommandV3 command, ConsultaDeBoleto consulta,
            PagamentoDeBoleto pagamento, IBancoService bancoService, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var empresaAplicacaoTransacao = configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.ConfiguracoesDaTransacao?.EmpresasAplicacoesTransacoes
               ?.FirstOrDefault(x => x.EmpresaAplicacaoId == command.EmpresaAplicacaoId);

            if (pagamento.EBoletoSemRegistro && pagamento.FoiRealizadoEmContingencia && empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (pagamento.EBoletoSemRegistro && pagamento.FoiRealizadoEmContingencia)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (pagamento.EBoletoSemRegistro && empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (pagamento.EBoletoSemRegistro)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoSemRegistroIniciadoEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (pagamento.FoiRealizadoEmContingencia && empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (pagamento.FoiRealizadoEmContingencia)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            if (empresaAplicacaoTransacao.ValidarSaldoDaContaCorrente)
                return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2(),
                    command, consulta, pagamento, bancoService, empresaAplicacaoTransacao.DebitarContaCorrente);

            return PreencherEventoDeInicioDeNovoPagamento(new NovoPagamentoDeBoletoIniciadoEventV2(), command, consulta, pagamento, bancoService,
                empresaAplicacaoTransacao.DebitarContaCorrente);
        }

        protected NovoPagamentoDeBoletoIniciadoBaseEventV2 PreencherEventoDeInicioDeNovoPagamento(NovoPagamentoDeBoletoIniciadoBaseEventV2 @event,
            IniciarNovoPagamentoDeBoletoCommandV3 command, ConsultaDeBoleto consulta, PagamentoDeBoleto pagamento, IBancoService bancoService,
            bool debitarContaCorrente)
        {
            var codigoDoBanco = CodigoDeBarras.ObterCodigoDoBanco();

            var banco = bancoService.ObterBancoPeloCodigoAsync(codigoDoBanco).Result;

            var rendimento = bancoService.ObterBancoRendimentoAsync().Result;

            @event.IdDoBoleto = Id;
            @event.IdDaConsultaDeBoleto = consulta.Id;
            @event.IdDoPagamentoDeBoleto = pagamento.Id;
            @event.EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId;
            @event.IdentificadorDoPagamentoNoCliente = pagamento.IdentificadorDoPagamentoNoCliente;
            @event.DocumentoDoPagadorInformadoPeloCliente = pagamento.DocumentoDoPagadorInformadoPeloCliente;
            @event.NomeDoPagadorInformadoPeloCliente = pagamento.NomeDoPagadorInformadoPeloCliente;
            @event.CodigoDeBarrasDoBoleto = CodigoDeBarras.Valor;
            @event.LinhaDigitavelDoBoleto = LinhaDigitavel.Valor;
            @event.CodigoDaColigada = consulta.CodigoDaColigada;
            @event.CodigoDaAgencia = consulta.CodigoDaAgencia;
            @event.NumeroDaContaCorrente = consulta.NumeroDaContaCorrente;
            @event.DocumentoDoPagadorFinal = pagamento.DocumentoDoPagadorFinal;
            @event.TipoDePessoaDoPagadorFinal = pagamento.TipoDePessoaDoPagadorFinal;
            @event.ValorDoPagamento = pagamento.ValorDoPagamento;
            @event.DataDoPagamento = pagamento.DataDoPagamento;
            @event.CanalDoPagamento = pagamento.CanalDoPagamento;
            @event.MeioDePagamento = pagamento.MeioDePagamento;
            @event.TipoDeBaixaOperacional = pagamento.TipoDeBaixaOperacional;
            @event.NumeroDoCodigoDeBarrasDoBoleto = CodigoDeBarras.Valor;
            @event.NumeroControleParticipante = pagamento.DataDoPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffffff").Replace(".", "");
            @event.ISPBParticipanteRecebedorPrincipal = consulta.ISPBParticipanteRecebedorPrincipal;
            @event.ISPBParticipanteRecebedorAdministrado = consulta.ISPBParticipanteRecebedorAdministrado;
            @event.NumeroIdentificacaoTitulo = consulta.NumeroIdentificacaoTitulo;
            @event.NumeroReferenciaCadastroTituloBaixaOperacional = consulta.NumeroReferenciaCadastroTituloBaixaOperacional;
            @event.NumeroReferenciaAtualBaixaOperacional = consulta.NumeroReferenciaAtualBaixaOperacional;
            @event.NomeFantasiaDoBeneficiario = consulta.NomeFantasiaDoBeneficiario;
            @event.RazaoSocialDoBeneficiario = consulta.RazaoSocialDoBeneficiario;
            @event.DocumentoDoBeneficiario = consulta.DocumentoDoBeneficiario;
            @event.TipoDePessoaDoBeneficiario = consulta.TipoDePessoaDoBeneficiario;
            @event.NomeFantasiaDoSacadorOuAvalista = consulta.NomeFantasiaDoSacadorOuAvalista;
            @event.RazaoSocialDoSacadorOuAvalista = consulta.RazaoSocialDoSacadorOuAvalista;
            @event.DocumentoDoSacadorOuAvalista = consulta.DocumentoDoSacadorOuAvalista;
            @event.TipoDePessoaDoSacadorOuAvalista = consulta.TipoDePessoaDoSacadorOuAvalista;
            @event.NomeFantasiaDoPagador = consulta.NomeFantasiaDoPagador;
            @event.RazaoSocialDoPagador = consulta.RazaoSocialDoPagador;
            @event.DocumentoDoPagador = consulta.DocumentoDoPagador;
            @event.TipoDePessoaDoPagador = consulta.TipoDePessoaDoPagador;
            @event.DataDeVencimento = consulta.DataDeVencimento ?? CodigoDeBarras.ObterADataDeVencimentoDoBoleto();
            @event.ValorNominal = consulta.ValorNominal ?? CodigoDeBarras.ObterOValorDoBoleto();
            @event.Encargos = consulta.Calculo?.ValorEncargos ?? 0;
            @event.Descontos = pagamento.ValorDoDesconto;
            @event.Multa = consulta.Calculo?.ValorMulta ?? 0;
            @event.Juros = consulta.Calculo?.ValorJuros ?? 0;
            @event.Abatimento = pagamento.ValorDoAbatimento;
            @event.ValorTotal = consulta.Calculo?.ValorCalculado ?? CodigoDeBarras.ObterOValorDoBoleto();
            @event.EVRBoleto = pagamento.EVRBoleto;
            @event.DebitarContaCorrente = debitarContaCorrente;
            @event.EBoletoDoBancoRendimento = rendimento.CodBanco == codigoDoBanco;
            @event.ISPBBaixa = rendimento.CodISPB;
            @event.CodigoRecebedor = rendimento.CodBanco;
            @event.CodigoDoBancoDestinatario = codigoDoBanco;
            @event.NomeDoBancoDestinatario = banco.Nome;
            @event.CorrelationMessage = command;
            @event.OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command;

            return @event;
        }

        protected static Result ValidarRegistroDeNovoBoleto(string codigoDeBarras, string linhaDigitavel)
        {
            var result = new Result();

            if (string.IsNullOrWhiteSpace(codigoDeBarras) && string.IsNullOrWhiteSpace(linhaDigitavel))
            {
                result.AddError("Informe código de barras ou linha digitável.", "Código de barras e linha digitável.", typeof(Boleto).FullName);
                return result;
            }

            if (!string.IsNullOrWhiteSpace(codigoDeBarras) && !string.IsNullOrWhiteSpace(linhaDigitavel))
            {
                result.AddError("Informe código de barras ou linha digitável.", "Código de barras e linha digitável.", typeof(Boleto).FullName);
                return result;
            }

            return result;
        }

        protected static Result<Boleto> RegistrarNovoBoletoPeloCodigoDeBarras(RegistrarNovoBoletoCommand command, IBancoService bancoService,
            ICodigoDeBarrasFactory codigoDeBarrasFactory, ILinhaDigitavelFactory linhaDigitavelFactory)
        {
            var result = new Result();

            var codigoDeBarrasResult = codigoDeBarrasFactory.Criar(command.CodigoDeBarras, bancoService);

            result.Merge(codigoDeBarrasResult);

            if (result.IsFailure)
                return result.ToResult<Boleto>();

            var linhaDigitavelResult = linhaDigitavelFactory.Criar(codigoDeBarrasResult.Value);

            result.Merge(linhaDigitavelResult);

            if (result.IsFailure)
                return result.ToResult<Boleto>();

            return new Result<Boleto>(new Boleto(codigoDeBarrasResult.Value, linhaDigitavelResult.Value, command));
        }

        protected static Result<Boleto> RegistrarNovoBoletoPelaLinhaDigitavel(RegistrarNovoBoletoCommand command, IBancoService bancoService,
            ICodigoDeBarrasFactory codigoDeBarrasFactory, ILinhaDigitavelFactory linhaDigitavelFactory)
        {
            var result = new Result();

            var linhaDigitavelResult = linhaDigitavelFactory.Criar(command.LinhaDigitavel, bancoService);

            result.Merge(linhaDigitavelResult);

            if (result.IsFailure)
                return result.ToResult<Boleto>();

            var codigoDeBarrasResult = linhaDigitavelResult.Value.GerarCodigoDeBarras();

            result.Merge(codigoDeBarrasResult);

            if (result.IsFailure)
                return result.ToResult<Boleto>();

            return new Result<Boleto>(new Boleto(codigoDeBarrasResult.Value, linhaDigitavelResult.Value, command));
        }

        protected Result ValidarInicioDeNovoPagamento(IniciarNovoPagamentoDeBoletoCommandV3 command, DateTime dataDeProcessamento,
            ConsultaDeBoleto consulta)
        {
            var result = new Result();

            if (consulta == null)
            {
                result.AddError("Id da consulta inexistente.", "Consulta não encontrada.", GetType().FullName);
                return result;
            }

            if (consulta.Status != ConsultaDeBoletoStatus.Consultado)
                result.AddError("Id da consulta indisponível.", "Consulta em status diferente de Consultado.", GetType().FullName);

            if (consulta.DataDaConsulta.Date < dataDeProcessamento)
                result.AddError("Id da consulta vencido, reinicie o processo de pagamento.", "Data da consulta menor que a data de processamento.", GetType().FullName);

            if (consulta.DataDaConsulta.Date > dataDeProcessamento)
                result.AddError("Id da consulta inválido.", "Data da consulta maior que a data de processamento.", GetType().FullName);

            result.Merge(ValidarDuplicidade(command, dataDeProcessamento, consulta));

            return result;
        }

        protected Result ValidarDuplicidade(IniciarNovoPagamentoDeBoletoCommandV3 command, DateTime dataDeProcessamento,
            ConsultaDeBoleto consulta)
        {
            var result = new Result();

            if (Pagamentos.Any(x => x.IdDaConsultaDeBoleto == consulta.Id))
                result.AddError("Id da consulta indisponível.", "Já existe um pagamento para essa consulta.", GetType().FullName);

            if (consulta.IndicadorPagamentoParcial == "S")
                return result;

            if (command.AceitaDuplicidade)
                return result;

            var pagamentoRecenteValido = ObterUltimoPagamentoRecenteValido(dataDeProcessamento);

            if (pagamentoRecenteValido == null)
                return result;

            result.AddError($"Pagamento em Duplicidade – Boleto pago em {pagamentoRecenteValido.DataDoPagamento.ToString("dd/MM/yyyy")}.",
                "Pagamento em Duplicidade.", GetType().FullName);

            return result;
        }

        protected PagamentoDeBoleto ObterUltimoPagamentoRecenteValido(DateTime dataDeProcessamento)
        {
            return Pagamentos.FirstOrDefault(x => (x.DataDoPagamento.Date == dataDeProcessamento
            && x.Status != PagamentoDeBoletoStatus.Recusado && x.Status != PagamentoDeBoletoStatus.Estornado)
            || (x.DataDoPagamento.Date >= dataDeProcessamento.AddDays(-15) && x.Status == PagamentoDeBoletoStatus.Efetivado));
        }

        protected CancelamentoDePagamentoDeBoletoIniciadoBaseEvent GerarEventoDeCancelamento(IniciarCancelamentoDePagamentoDeBoletoCommandV2 command,
            ConsultaDeBoleto consulta, PagamentoDeBoleto pagamento, IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var empresaAplicacaoTransacao = configuracoesDoMotorService.ConfiguracoesDoMotor?.Boletos?.ConfiguracoesDaTransacao?.EmpresasAplicacoesTransacoes
               ?.FirstOrDefault(x => x.EmpresaAplicacaoTransacaoId == pagamento.EmpresaAplicacaoTransacaoId);

            if (pagamento.DebitarContaCorrente && empresaAplicacaoTransacao.EstornarAutomaticamente)
            {
                if (pagamento.EBoletoSemRegistro)
                    return PreencherEventoDeCancelamento(new CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent(), command, consulta, pagamento);

                if (pagamento.Status == PagamentoDeBoletoStatus.Efetivado)
                    return PreencherEventoDeCancelamento(new CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent(), command, consulta, pagamento);

                return PreencherEventoDeCancelamento(new CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent(), command, consulta, pagamento);
            }
            else
            {
                if (pagamento.EBoletoSemRegistro)
                    return PreencherEventoDeCancelamento(new CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent(), command, consulta, pagamento);

                if (pagamento.Status == PagamentoDeBoletoStatus.Efetivado)
                    return PreencherEventoDeCancelamento(new CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent(), command, consulta, pagamento);

                return PreencherEventoDeCancelamento(new CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent(), command, consulta, pagamento);
            }
        }

        protected CancelamentoDePagamentoDeBoletoIniciadoBaseEvent PreencherEventoDeCancelamento(CancelamentoDePagamentoDeBoletoIniciadoBaseEvent @event,
            IniciarCancelamentoDePagamentoDeBoletoCommandV2 command, ConsultaDeBoleto consulta, PagamentoDeBoleto pagamento)
        {
            @event.IdDoBoleto = pagamento.IdDoBoleto;
            @event.IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto;
            @event.IdDoPagamentoDeBoleto = pagamento.Id;
            @event.EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId;
            @event.CodigoDaColigada = consulta.CodigoDaColigada;
            @event.CodigoDaAgencia = consulta.CodigoDaAgencia;
            @event.NumeroDaContaCorrente = consulta.NumeroDaContaCorrente;
            @event.DocumentoDoPagadorFinal = pagamento.DocumentoDoPagadorFinal;
            @event.ValorDoPagamento = pagamento.ValorDoPagamento;
            @event.DataDoPagamento = pagamento.DataDoPagamento;
            @event.ISPBPartRecbdrPrincipal = consulta.ISPBParticipanteRecebedorPrincipal;
            @event.ISPBPartRecbdrAdmtd = consulta.ISPBParticipanteRecebedorAdministrado;
            @event.Justificativa = command.Justificativa;
            @event.CorrelationMessage = command;
            @event.OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command;

            return @event;
        }

        private void When(NovoBoletoRegistradoEvent @event)
        {
            CodigoDeBarras = new CodigoDeBarras(@event);
            LinhaDigitavel = new LinhaDigitavel(@event);
        }

        private void When(NovaConsultaDeBoletoIniciadaEvent @event)
        {
            Consultas.Add(new ConsultaDeBoleto(@event));
        }

        private void When(NovaConsultaDeBoletoSemRegistroIniciadaEvent @event)
        {
            Consultas.Add(new ConsultaDeBoleto(@event));
        }

        private void When(NovaConsultaDeBoletoIniciadaEmContingenciaEvent @event)
        {
            Consultas.Add(new ConsultaDeBoleto(@event));
        }

        private void When(NovaConsultaDeBoletoSemRegistroIniciadaEmContingenciaEvent @event)
        {
            Consultas.Add(new ConsultaDeBoleto(@event));
        }

        private void When(NovaConsultaDeBoletoConcluidaComErroEvent @event)
        {
            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.ConcluirComErro(@event);
        }

        private void When(NovaConsultaDeBoletoConcluidaComErroNaConsultaACIPEvent @event)
        {
            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.ConcluirComErroNaConsultaACIP(@event.CodigoDeErro, @event.DescricaoDoErro);
        }

        private void When(NovaConsultaDeBoletoConcluidaEvent @event)
        {
            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.Concluir(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaComValidacaoDeSaldoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEmContingenciaEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoComValidacaoDeSaldoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoSemRegistroIniciadoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEmContingenciaComValidacaoDeSaldoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEmContingenciaEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEmContingenciaEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoComValidacaoDeSaldoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEvent @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(NovoPagamentoDeBoletoIniciadoEventV2 @event)
        {
            ProcessarEventoDeInicioDeNovoPagamento(@event);
        }

        private void When(SaldoDisponivelDaContaCorrenteValidadoEvent @event)
        {

        }

        private void When(PagamentoDeBoletoRecusadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.Recusar(@event.MotivoDaRecusa);

            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.MarcarComoProcessado();
        }

        private void When(PagamentoDeBoletoMarcadoComoPendenteDeBaixaOperacionalEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.MarcarComoPendenteDeBaixaOperacional();
        }

        private void When(PagamentoDeBoletoRecusadoNaBaixaOperacionalEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.RecusarNaBaixaOperacional(@event.MotivoDaRecusa);

            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.MarcarComoProcessado();
        }

        private void When(PagamentoDeBoletoEfetivadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.Efetivar();

            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.MarcarComoProcessado();
        }

        private void When(CancelamentoComEstornoDePagamentoDeBoletoEfetivadoIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(CancelamentoDePagamentoDeBoletoEfetivadoIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(CancelamentoComEstornoDePagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(CancelamentoDePagamentoDeBoletoSemRegistroIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(CancelamentoComEstornoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(CancelamentoDePagamentoDeBoletoComBaixaRecusadaIniciadoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.IniciarCancelamento(@event.Justificativa);
        }

        private void When(PagamentoDeBoletoMarcadoComoPendenteDeCancelamentoDeBaixaOperacionalEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.MarcarComoPendenteDeCancelamentoDeBaixaOperacional();
        }

        private void When(CancelamentoDePagamentoDeBoletoConcluidoEvent @event)
        {
            var pagamento = Pagamentos.FirstOrDefault(x => x.Id == @event.IdDoPagamentoDeBoleto);

            if (pagamento == null) return;

            pagamento.ConcluirCancelamento();

            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.Cancelar();
        }

        private void ProcessarEventoDeInicioDeNovoPagamento(dynamic @event)
        {
            var consulta = Consultas.FirstOrDefault(x => x.Id == @event.IdDaConsultaDeBoleto);

            if (consulta == null) return;

            consulta.ColocarEmPagamento();

            Pagamentos.Add(new PagamentoDeBoleto(@event));
        }
    }
}