﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands
{
    public class EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand : CommandBase
    {
        public Guid IdBaixa { get; set; }
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }        
        public string NroControleParticipante { get; set; }
        public string ISPBRecebedorPrincipal { get; set; }
        public string ISPBRecebedorADM { get; set; }
        public string NrTitulo { get; set; }        
        public string NumRefCadTitBaixaOperac { get; set; }
        public string NumRefAtlBaixaOperac { get; set; }
        public int TipoBaixa { get; set; }
        public string ISPBBaixa { get; set; }
        public string CodigoRecebedor { get; set; }
        public string TipoPortador { get; set; }
        public string DocIdentificacaoPortador { get; set; }
        public DateTime DataHoraPagamento { get; set; }
        public DateTime DataProcessamento { get; set; }
        public decimal ValorPagamento { get; set; }
        public string CodigoBarras { get; set; }
        public int CanalPagamento { get; set; }
        public int MeioPagamento { get; set; }
        public string IndicadorContigencia { get; set; }
        public DateTime DataMovimento { get; set; }
    }
}
