﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands;
using COP.ESB.Pagamento.Dominio.Core;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Factories.Interfaces
{
    public interface IBaixaOperacionalBoletoFactory
    {
        BaixaOperacionalPendenteBoleto EnviarParaFila(EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand command);
    }
}
