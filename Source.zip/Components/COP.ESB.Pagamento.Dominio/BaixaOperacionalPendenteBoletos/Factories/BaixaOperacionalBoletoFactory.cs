﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Factories.Interfaces;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Factories
{
    public class BaixaOperacionalBoletoFactory : IBaixaOperacionalBoletoFactory
    {
        public BaixaOperacionalPendenteBoleto EnviarParaFila(EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand command)
        {
            return new BaixaOperacionalPendenteBoleto(command);
        }
    }
}