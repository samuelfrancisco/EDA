﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.DTOs
{
    [XmlRoot("DDA0108")]
    public class EnvioBaixaOperacionalXmlDTO
    {
        [XmlElement("CodMsg")]
        public string CodMensagem { get; set; }

        [XmlElement("NumCtrlPart")]
        public string NroControleParticipante { get; set; }

        [XmlElement("ISPBPartRecbdrPrincipal")]
        public string ISPBRecebedorPrincipal { get; set; }

        [XmlElement("ISPBPartRecbdrAdmtd")]
        public string ISPBRecebedorADM { get; set; }

        [XmlElement("NumIdentcTit")]
        public string NrTitulo { get; set; }

        [XmlElement("NumRefCadTitBaixaOperac")]
        public string NumRefCadTitBaixaOperac { get; set; }

        [XmlElement("NumRefAtlBaixaOperac")]
        public string NumRefAtlBaixaOperac { get; set; }

        [XmlElement("TpBaixaOperac")]
        public int TipoBaixa { get; set; }

        [XmlElement("ISPBPartRecbdrBaixaOperac")]
        public string ISPBBaixa { get; set; }

        [XmlElement("CodPartRecbdrBaixaOperac")]
        public string CodigoRecebedor { get; set; }

        [XmlElement("TpPessoaPort")]
        public string TipoPortador { get; set; }

        [XmlElement("CNPJ_CPFPort")]
        public string DocIdentificacaoPortador { get; set; }

        [XmlElement("DtHrProcBaixaOperac")]
        public string DataHoraPagamento { get; set; }

        [XmlElement("DtProcBaixaOperac")]
        public string DataProcessamento { get; set; }

        [XmlElement("VlrBaixaOperacTit")]
        public decimal ValorPagamento { get; set; }

        [XmlElement("NumCodBarrasBaixaOperac")]
        public string CodigoBarras { get; set; }

        [XmlElement("CanPgto")]
        public int CanalPagamento { get; set; }

        [XmlElement("MeioPgto")]
        public int MeioPagamento { get; set; }

        [XmlElement("IndrOpContg")]
        public string IndicadorContigencia { get; set; }

        [XmlElement("DtMovto")]
        public string DataMovimento { get; set; }


        public static EnvioBaixaOperacionalXmlDTO FromXml(string xml)
        {
            var xmlDocument = new XmlDocument
            {
                InnerXml = xml
            };

            var serializer = new XmlSerializer(typeof(EnvioBaixaOperacionalXmlDTO));

            using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(xmlDocument.InnerXml)))
            using (var streamReader = new StreamReader(memoryStream))
            {
                return (EnvioBaixaOperacionalXmlDTO)serializer.Deserialize(streamReader);
            }
        }

        public string ToXml(EnvioBaixaOperacionalXmlDTO envio)
        {
            var serializer = new XmlSerializer(typeof(EnvioBaixaOperacionalXmlDTO));
            var xml = "";

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces(); ns.Add("", "");
            XmlWriterSettings st = new XmlWriterSettings
            {
                OmitXmlDeclaration = true
            };


            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww, st))
                {
                    serializer.Serialize(writer, envio, ns, string.Empty);
                    xml = sww.ToString();
                }
            }

            return xml;
        }
    }
}
