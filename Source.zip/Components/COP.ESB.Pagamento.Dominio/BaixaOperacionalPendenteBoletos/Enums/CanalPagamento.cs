﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Enums
{
    public enum CanalPagamento
    {
        /// <summary>
        /// Não Informado
        /// </summary>
        NaoInformado = 0,

        /// <summary>
        /// 1 Agências - Postos tradicionais
        /// </summary>
        Agencias = 1,

        /// <summary>
        /// 2 Terminal de Auto-atendimento
        /// </summary>
        AutoAtendimento = 2,

        /// <summary>
        /// 3 Internet (home / office banking)
        /// </summary>
        Internet = 3,

        /// <summary>
        /// 5 Correspondente bancário
        /// </summary>
        CorrespondenteBancario = 5,

        /// <summary>
        /// 6 Central de atendimento (Call Center)
        /// </summary>
        CallCenter = 6,

        /// <summary>
        /// 7 Arquivo Eletrônico
        /// </summary>
        ArquivoEletronico = 7,

        /// <summary>
        /// 8 DDA
        /// </summary>
        DDA = 8,
    }
}
