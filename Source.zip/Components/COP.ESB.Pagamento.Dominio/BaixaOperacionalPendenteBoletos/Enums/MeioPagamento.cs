﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Enums
{
    public enum MeioPagamento
    {
        /// <summary>
        /// Não Informado
        /// </summary>
        NaoInformado = 0,

        /// <summary>
        /// 1 Espécie
        /// </summary>
        Especie = 1,

        /// <summary>
        /// 2 Débito em conta
        /// </summary>
        DebitoEmConta = 2,

        /// <summary>
        /// 3 Cartão de crédito
        /// </summary>
        CartaoDeCrédito = 3,

        /// <summary>
        /// 4 Cheque
        /// </summary>
        Cheque = 4,
    }
}
