﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Enums
{
    public enum TipoBaixaOperacional
    {
        /// <summary>
        /// 0 Baixa Operacional Integral Interbancária
        /// </summary>
        IntegralInterbancaria = 0,

        /// <summary>
        /// 1 Baixa Operacional Integral Intrabancária
        /// </summary>
        IntegralIntrabancaria = 1,

        /// <summary>
        /// 2 Baixa Operacional Parcial Intrabancária
        /// </summary>
        ParcialIntrabancaria = 2,

        /// <summary>
        /// 3 Baixa Operacional Parcial Interbancária
        /// </summary>
        ParcialInterbancaria = 3,
    }
}
