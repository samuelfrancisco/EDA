﻿using COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Repositories.Interfaces
{
    public interface IBaixaOperacionalPendenteBoletoRepository : IAggregateRootRepository<BaixaOperacionalPendenteBoleto>
    {
        Task<IEnumerable<BaixaOperacionalPendenteBoleto>> ObterTodasPendentesAsync(DateTime dataBase);

        void Excluir(BaixaOperacionalPendenteBoleto baixaOperacional);
    }
}
