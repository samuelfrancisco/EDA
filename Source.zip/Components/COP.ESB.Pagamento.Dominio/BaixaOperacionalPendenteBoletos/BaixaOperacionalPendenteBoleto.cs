﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto.DTOs;
using COP.ESB.Pagamento.Dominio.Core.Domain;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalPendenteBoleto
{
    public class BaixaOperacionalPendenteBoleto : AggregateRoot
    {
        protected BaixaOperacionalPendenteBoleto()
        { }

        public BaixaOperacionalPendenteBoleto(EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand command)
        {
            Id = Guid.NewGuid();
            IdDoBoleto = command.IdDoBoleto;
            IdDaConsultaDeBoleto = command.IdDaConsultaDeBoleto;
            IdDoPagamentoDeBoleto = command.IdDoPagamentoDeBoleto;
            EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId;
            DataDeEntrada = command.DataHoraPagamento;
            XmlEnvio = GerarXml(command);
            NumeroDeControleDaTransacao = string.Concat("BB", command.DataHoraPagamento.ToString("yyyy.MM.dd.HH.mm.ss.ffff").Replace(".", ""));
        }
        public Guid IdDoBoleto { get; protected set; }
        public Guid IdDaConsultaDeBoleto { get; protected set; }
        public Guid IdDoPagamentoDeBoleto { get; protected set; }
        public long EmpresaAplicacaoTransacaoId { get; protected set; }
        public string XmlEnvio { get; protected set; }
        public DateTimeOffset DataDeEntrada { get; protected set; }
        public DateTimeOffset? DataDeProcessamento { get; set; }
        public int QuantidadeDeTentativasRealizadas { get; set; }
        public string Enviado { get; protected set; } = "N";
        public string NumeroDeControleDaTransacao { get; protected set; }

        private string GerarXml(EnviarPagamentoDeBoletoParaFilaDeBaixaOperacionalCommand command)
        {
            return new EnvioBaixaOperacionalXmlDTO().ToXml(new EnvioBaixaOperacionalXmlDTO
            {
                CodMensagem = "DDA0108",
                CanalPagamento = command.CanalPagamento,
                CodigoBarras = command.CodigoBarras,
                CodigoRecebedor = command.CodigoRecebedor.Substring(1),
                DataHoraPagamento = command.DataHoraPagamento.ToString("s"),
                DataMovimento = command.DataMovimento.ToString("yyyy-MM-dd"),
                DataProcessamento = command.DataProcessamento.ToString("yyyy-MM-dd"),
                DocIdentificacaoPortador = command.DocIdentificacaoPortador,
                IndicadorContigencia = command.IndicadorContigencia,
                ISPBBaixa = command.ISPBBaixa,
                ISPBRecebedorADM = command.ISPBRecebedorADM,
                ISPBRecebedorPrincipal = command.ISPBRecebedorPrincipal,
                MeioPagamento = command.MeioPagamento,
                NumRefCadTitBaixaOperac = command.NumRefCadTitBaixaOperac,
                NroControleParticipante = command.NroControleParticipante,
                NumRefAtlBaixaOperac = command.NumRefAtlBaixaOperac,
                NrTitulo = command.NrTitulo,
                TipoBaixa = command.TipoBaixa,
                TipoPortador = command.TipoPortador,
                ValorPagamento = command.ValorPagamento
            });
        }
    }
}
