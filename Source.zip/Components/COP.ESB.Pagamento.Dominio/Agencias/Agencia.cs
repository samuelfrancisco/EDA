﻿using COP.ESB.Pagamento.Dominio.Core.ReadModels;

namespace COP.ESB.Pagamento.Dominio.Agencias
{
    public class Agencia : VersionedReadModel
    {
        public virtual string CodColigada { get; set; }
        public virtual string CodAgencia { get; set; }
        public virtual string Nome { get; set; }
        public virtual string CodPraca { get; set; }
    }
}
