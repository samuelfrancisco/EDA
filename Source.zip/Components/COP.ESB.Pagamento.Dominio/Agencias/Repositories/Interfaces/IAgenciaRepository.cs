﻿using COP.ESB.Pagamento.Dominio.Core.ReadModels.Interfaces;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Agencias.Repositories.Interfaces
{
    public interface IAgenciaRepository : IVersionedReadModelRepository<Agencia>
    {
        Task<Agencia> ObterAgenciaPeloCodColigadaECodAgenciaAsync(string codColigada, string codAgencia);
    }
}
