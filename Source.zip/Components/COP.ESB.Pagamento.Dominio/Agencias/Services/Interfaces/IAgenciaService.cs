﻿using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces
{
    public interface IAgenciaService
    {
        Task<Agencia> ObterAgenciaPeloCodColigadaECodAgenciaAsync(string codColigada, string codAgencia);
    }
}
