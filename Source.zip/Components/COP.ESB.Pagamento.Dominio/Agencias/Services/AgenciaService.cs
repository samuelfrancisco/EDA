﻿using COP.ESB.Pagamento.Dominio.Agencias.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Agencias.Services.Interfaces;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Agencias.Services
{
    public class AgenciaService : IAgenciaService
    {
        private readonly IAgenciaRepository _agenciaRepository;

        public AgenciaService(IAgenciaRepository agenciaRepository)
        {
            _agenciaRepository = agenciaRepository;
        }

        public async Task<Agencia> ObterAgenciaPeloCodColigadaECodAgenciaAsync(string codColigada, string codAgencia)
        {
            return await _agenciaRepository.ObterAgenciaPeloCodColigadaECodAgenciaAsync(codColigada, codAgencia).ConfigureAwait(false);
        }
    }
}
