﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos
{
    public class BaixaOperacionalBoleto : EventSourcedAggregateRoot
    {
        protected BaixaOperacionalBoleto()
            : base()
        { }

        public BaixaOperacionalBoleto(RealizarEnvioBaixaOperacionalBoletoParaCIPCommand command)
            : base()
        {
            Id = command.IdDaBaixaOperacionalDeBoleto;

            if (command.Sucesso)
            {
                Update(new BaixaOperacionalBoletoEnviadaComSucessoEvent
                {
                    IdDoBoleto = command.IdDoBoleto,
                    IdDaConsultaDeBoleto = command.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = command.IdDoPagamentoDeBoleto,
                    IdDaBaixaOperacionalDeBoleto = command.IdDaBaixaOperacionalDeBoleto,
                    EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                    NumeroDoControleDaTransacao = command.NumeroDoControleDaTransacao,
                    DataDeProcessamento = command.Date,
                    XmlEnviado = command.CorpoMensagem,
                    StatusRetornoTransacaoBaixaOperacional = command.StatusRetornoTransacao,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });

                return;
            }

            Update(new BaixaOperacionalBoletoEnviadaComErroEvent
            {
                IdDoBoleto = command.IdDoBoleto,
                IdDaConsultaDeBoleto = command.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = command.IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = command.IdDaBaixaOperacionalDeBoleto,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = command.NumeroDoControleDaTransacao,
                DataDeProcessamento = command.Date,
                XmlEnviado = command.CorpoMensagem,
                StatusRetornoTransacaoBaixaOperacional = command.StatusRetornoTransacao,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public BaixaOperacionalBoleto(MarcarBaixaOperacionalBoletoNaoEnviadaParaCIPCommand command)
           : base()
        {
            Update(new BaixaOperacionalBoletoNaoEnviadaComHorarioExpiradoEvent
            {
                IdDoBoleto = command.IdDoBoleto,
                IdDaConsultaDeBoleto = command.IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = command.IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = command.IdDaBaixaOperacionalDeBoleto,
                EmpresaAplicacaoTransacaoId = command.EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = command.NumeroDoControleDaTransacao,
                CorpoMensagem = command.CorpoMensagem,
                StatusRetornoTransacaoBaixaOperacional = command.StatusRetornoTransacao,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public Guid IdDoBoleto { get; protected set; }
        public Guid IdDaConsultaDeBoleto { get; protected set; }
        public Guid IdDoPagamentoDeBoleto { get; protected set; }
        public long EmpresaAplicacaoTransacaoId { get; protected set; }
        public string NumeroDoControleDaTransacao { get; protected set; }
        public string NumIdentcBaixaOperac { get; protected set; }
        public string NumeroDaMensagem { get; protected set; }
        public string XmlEnviado { get; protected set; }
        public string XmlRetorno { get; protected set; }
        public StatusRetornoTransacaoBaixaOperacional StatusDoRetornoDaTransacao { get; protected set; }
        public DateTimeOffset DataDeProcessamento { get; protected set; }
        public DateTimeOffset? DataDeRetornoCIP { get; protected set; }
        public string CodigoDaMensagemDeErro { get; protected set; }
        public string DescricaoDaMensagemDeErro { get; protected set; }
        public string CodigoDaRejeicao { get; protected set; }
        public string DescricaoDoMotivoDaRejeicao { get; protected set; }
        public string CodigoDoErroSpb { get; protected set; }
        public string DescricaoDaMensagemDoErroSpb { get; protected set; }
        public string NumeroDeControleSpb { get; protected set; }
        public string Situacao { get; protected set; }
        public string CodigoDoStatusSgr { get; protected set; }
        public string DescricaoDoStatusSgr { get; protected set; }
        public string CodigoDoStatusStr { get; protected set; }
        public string DescricaoDoStatusStr { get; protected set; }
        public StatusBaixaOperacional Status { get; protected set; }
        public string NumeroDoControleDaTransacaoDeEstorno { get; protected set; }
        public StatusRetornoTransacaoBaixaOperacional? StatusDoRetornoDaTransacaoDeEstorno { get; protected set; }
        public string XmlRetornoDeEstorno { get; protected set; }
        public string NumeroDaMensagemDeEstorno { get; protected set; }

        public void ConsultarMensagemDaCIPDeBaixaOperacionalBoleto(ConsultarMensagemDaCIPDeBaixaOperacionalBoletoCommand command)
        {
            if (command.Sucesso)
            {
                Update(new BaixaOperacionalBoletoRealizadaComSucessoEvent
                {
                    IdDoBoleto = IdDoBoleto,
                    IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                    IdDaBaixaOperacionalDeBoleto = Id,
                    EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                    NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                    NumeroDaMensagem = command.NumeroDaMensagem,
                    CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                    MensagemDaCIP = command.MensagemDaCIP,
                    CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                    MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                    CodigoDoErroSpb = command.CodigoDoErroSpb,
                    DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                    CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                    CodigoDoStatusStr = command.CodigoDoStatusStr,
                    DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                    DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                    NumeroDeControleSpb = command.NumeroDeControleSpb,
                    NumIdentcBaixaOperac = command.NumIdentcBaixaOperac,
                    XmlEnviado = command.XmlEnviado,
                    XmlRetornado = command.XmlRetorno,
                    Situacao = command.Situacao,
                    Status = StatusBaixaOperacional.Concluido
                });

                return;
            }

            Update(new BaixaOperacionalBoletoRecusadaEvent
            {
                IdDoBoleto = IdDoBoleto,
                IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = Id,
                EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                NumeroDaMensagem = command.NumeroDaMensagem,
                CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                MensagemDaCIP = command.MensagemDaCIP,
                CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                CodigoDoErroSpb = command.CodigoDoErroSpb,
                DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                CodigoDoStatusStr = command.CodigoDoStatusStr,
                DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                NumeroDeControleSpb = command.NumeroDeControleSpb,
                Situacao = command.Situacao,
                XmlEnviado = command.XmlEnviado,
                XmlRetornado = command.XmlRetorno,
                Status = StatusBaixaOperacional.Recusada,
                MensagemDeRecusa = command.MensagemDeRecusa
            });
        }

        public void ConsultarDeStatusDeBaixaOperacionalBoleto(ConsultarDeStatusDeBaixaOperacionalBoletoCommand command)
        {
            if (command.Sucesso)
            {
                Update(new BaixaOperacionalBoletoEfetivadaEvent
                {
                    IdDoBoleto = IdDoBoleto,
                    IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                    IdDaBaixaOperacionalDeBoleto = Id,
                    EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                    NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                    NumeroDaMensagem = command.NumeroDaMensagem,
                    XmlEnviado = command.XmlEnviado,
                    CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                    MensagemDaCIP = command.MensagemDaCIP,
                    CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                    MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                    CodigoDoErroSpb = command.CodigoDoErroSpb,
                    DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                    CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                    CodigoDoStatusStr = command.CodigoDoStatusStr,
                    DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                    DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                    NumeroDeControleSpb = command.NumeroDeControleSpb,
                    NumIdentcBaixaOperac = command.NumIdentcBaixaOperac,
                    Situacao = command.Situacao,
                    Status = StatusBaixaOperacional.Efetivada,
                    StatusDoRetornoDaTransacao = command.StatusDoRetornoDaTransacao
                });

                return;
            }

            Update(new BaixaOperacionalBoletoRejeitadaEvent
            {
                IdDoBoleto = IdDoBoleto,
                IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = Id,
                EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                NumeroDaMensagem = command.NumeroDaMensagem,
                XmlEnviado = command.XmlEnviado,
                CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                MensagemDaCIP = command.MensagemDaCIP,
                CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                CodigoDoErroSpb = command.CodigoDoErroSpb,
                DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                CodigoDoStatusStr = command.CodigoDoStatusStr,
                DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                NumeroDeControleSpb = command.NumeroDeControleSpb,
                NumIdentcBaixaOperac = command.NumIdentcBaixaOperac,
                Situacao = command.Situacao,
                Status = StatusBaixaOperacional.RejeitadoNoEnvio,
                StatusDoRetornoDaTransacao = command.StatusDoRetornoDaTransacao,
                MensagemDeRecusa = command.MensagemDeRecusa
            });
        }

        public void ConsultarDeStatusDeEstornoDeBaixaOperacionalBoleto(ConsultarDeStatusDeEstornoDeBaixaOperacionalBoletoCommand command)
        {

            Update(new BaixaOperacionalBoletoEstornoRecusadoEvent
            {
                IdDoBoleto = IdDoBoleto,
                IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = Id,
                EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                NumeroDaMensagem = command.NumeroDaMensagem,
                XmlEnviado = command.XmlEnviado,
                CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                MensagemDaCIP = command.MensagemDaCIP,
                CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                CodigoDoErroSpb = command.CodigoDoErroSpb,
                DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                CodigoDoStatusStr = command.CodigoDoStatusStr,
                DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                NumeroDeControleSpb = command.NumeroDeControleSpb,
                NumIdentcBaixaOperac = command.NumIdentcBaixaOperac,
                Situacao = command.Situacao,
                Status = StatusBaixaOperacional.EstornadoRecusadoCIP,
                StatusDoRetornoDaTransacao = command.StatusDoRetornoDaTransacao,
                MensagemDeRecusa = command.MensagemDeRecusa
            });
        }

        public void ConsultarMensagemDeEstornoDaCIPDeBaixaOperacionalBoleto(ConsultarMensagemDeEstornoDaCIPDeBaixaOperacionalBoletoCommand command)
        {
            if (command.Sucesso)
            {
                Update(new BaixaOperacionalBoletoEstornadaEvent
                {
                    IdDoBoleto = IdDoBoleto,
                    IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                    IdDaBaixaOperacionalDeBoleto = Id,
                    EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                    NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                    NumeroDaMensagem = command.NumeroDaMensagem,
                    NumeroDaMensagemDeEstorno = command.NumeroDaMensagemDeEstorno,
                    CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                    MensagemDaCIP = command.MensagemDaCIP,
                    CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                    MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                    CodigoDoErroSpb = command.CodigoDoErroSpb,
                    DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                    CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                    CodigoDoStatusStr = command.CodigoDoStatusStr,
                    DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                    DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                    NumeroDeControleSpb = command.NumeroDeControleSpb,
                    NumIdentcBaixaOperac = command.NumIdentcBaixaOperac,
                    Situacao = command.Situacao,
                    Status = StatusBaixaOperacional.Estornado,
                    XmlRetornadoDeEstorno = command.XmlRetornoDeEstorno,
                    XmlEnviado = command.XmlEnviado,
                    XmlRetornado = command.XmlRetorno,
                    
                    
                });

                return;
            }

            Update(new BaixaOperacionalBoletoRecusadaEvent
            {
                IdDoBoleto = IdDoBoleto,
                IdDaConsultaDeBoleto = IdDaConsultaDeBoleto,
                IdDoPagamentoDeBoleto = IdDoPagamentoDeBoleto,
                IdDaBaixaOperacionalDeBoleto = Id,
                EmpresaAplicacaoTransacaoId = EmpresaAplicacaoTransacaoId,
                NumeroDoControleDaTransacao = NumeroDoControleDaTransacao,
                NumeroDaMensagem = command.NumeroDaMensagem,
                NumeroDaMensagemDeEstorno = command.NumeroDaMensagemDeEstorno,
                CodigoDaMensagemCIP = command.CodigoDaMensagemCIP,
                MensagemDaCIP = command.MensagemDaCIP,
                CodigoDaRejeicaoCIP = command.CodigoDaRejeicaoCIP,
                MensagemDaRejeicaoCIP = command.MensagemDaRejeicaoCIP,
                CodigoDoErroSpb = command.CodigoDoErroSpb,
                DescricaoDaMensagemDoErroSpb = command.DescricaoDaMensagemDoErroSpb,
                CodigoDoStatusSgr = command.CodigoDoStatusSgr,
                CodigoDoStatusStr = command.CodigoDoStatusStr,
                DescricaoDoStatusSgr = command.DescricaoDoStatusSgr,
                DescricaoDoStatusStr = command.DescricaoDoStatusStr,
                NumeroDeControleSpb = command.NumeroDeControleSpb,
                Situacao = command.Situacao,
                Status = StatusBaixaOperacional.Recusada,
                MensagemDeRecusa = command.MensagemDeRecusa,
                XmlRetornadoDeEstorno = command.XmlRetornoDeEstorno,
                XmlEnviado = command.XmlEnviado,
                XmlRetornado = command.XmlRetorno
            });
        }

        public void RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIP(RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIPCommandV2 command, StatusRetornoTransacaoBaixaOperacional status)
        {
            Status = command.Sucesso ? StatusBaixaOperacional.EstornoEnviadoCIP : StatusBaixaOperacional.EstornadoRecusadoCIP;
            NumeroDoControleDaTransacaoDeEstorno = command.NumeroDoControleDaTransacao;
            StatusDoRetornoDaTransacaoDeEstorno = status;
        }

        public void MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIP()
        {
            Status = StatusBaixaOperacional.HorarioDeEnvioDeEstornoExpirado;
            StatusDoRetornoDaTransacaoDeEstorno = StatusRetornoTransacaoBaixaOperacional.NaoEnviada;
        }

        protected void When(BaixaOperacionalBoletoEnviadaComSucessoEvent @event)
        {
            IdDoBoleto = @event.IdDoBoleto;
            IdDaConsultaDeBoleto = @event.IdDaConsultaDeBoleto;
            IdDoPagamentoDeBoleto = @event.IdDoPagamentoDeBoleto;
            EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId;
            NumeroDoControleDaTransacao = @event.NumeroDoControleDaTransacao;
            XmlEnviado = @event.XmlEnviado;
            DataDeProcessamento = @event.DataDeProcessamento;
            StatusDoRetornoDaTransacao = @event.StatusRetornoTransacaoBaixaOperacional;
            Status = StatusBaixaOperacional.EmProcessamento;
        }

        protected void When(BaixaOperacionalBoletoNaoEnviadaComHorarioExpiradoEvent @event)
        {
            IdDoBoleto = @event.IdDoBoleto;
            IdDaConsultaDeBoleto = @event.IdDaConsultaDeBoleto;
            IdDoPagamentoDeBoleto = @event.IdDoPagamentoDeBoleto;
            EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId;
            NumeroDoControleDaTransacao = @event.NumeroDoControleDaTransacao;
            XmlEnviado = @event.CorpoMensagem;
            StatusDoRetornoDaTransacao = @event.StatusRetornoTransacaoBaixaOperacional;
            Status = StatusBaixaOperacional.HorarioDeEnvioExpirado;
            DescricaoDaMensagemDeErro = $"Não foi possível realizar a o envio da Baixa Operacional dentro do horário disponível para realização da mesma.";
        }

        protected void When(BaixaOperacionalBoletoEnviadaComErroEvent @event)
        {
            IdDoBoleto = @event.IdDoBoleto;
            IdDaConsultaDeBoleto = @event.IdDaConsultaDeBoleto;
            IdDoPagamentoDeBoleto = @event.IdDoPagamentoDeBoleto;
            EmpresaAplicacaoTransacaoId = @event.EmpresaAplicacaoTransacaoId;
            NumeroDoControleDaTransacao = @event.NumeroDoControleDaTransacao;
            XmlEnviado = @event.XmlEnviado;
            DataDeProcessamento = @event.DataDeProcessamento;
            StatusDoRetornoDaTransacao = @event.StatusRetornoTransacaoBaixaOperacional;
            Status = StatusBaixaOperacional.RejeitadoNoTransacao;
        }

        protected void When(BaixaOperacionalBoletoRealizadaComSucessoEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;
        }

        protected void When(BaixaOperacionalBoletoRecusadaEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            XmlRetornoDeEstorno = @event.XmlRetornadoDeEstorno;
            NumeroDaMensagemDeEstorno = @event.NumeroDaMensagemDeEstorno;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;


        }

        protected void When(BaixaOperacionalBoletoRejeitadaEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;
        }

        protected void When(BaixaOperacionalBoletoEfetivadaEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;
        }

        protected void When(BaixaOperacionalBoletoEstornadaEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            XmlRetornoDeEstorno = @event.XmlRetornadoDeEstorno;
            NumeroDaMensagemDeEstorno = @event.NumeroDaMensagemDeEstorno;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;
        }

        protected void When(BaixaOperacionalBoletoEstornoRecusadoEvent @event)
        {
            XmlEnviado = @event.XmlEnviado;
            XmlRetorno = @event.XmlRetornado;
            NumeroDaMensagem = @event.NumeroDaMensagem;
            NumIdentcBaixaOperac = @event.NumIdentcBaixaOperac;
            DataDeRetornoCIP = @event.Date;
            CodigoDaMensagemDeErro = @event.CodigoDaMensagemCIP;
            DescricaoDaMensagemDeErro = @event.MensagemDaCIP;
            Situacao = @event.Situacao;
            CodigoDaRejeicao = @event.CodigoDaRejeicaoCIP;
            DescricaoDoMotivoDaRejeicao = @event.MensagemDaRejeicaoCIP;
            CodigoDoErroSpb = @event.CodigoDoErroSpb;
            DescricaoDaMensagemDoErroSpb = @event.DescricaoDaMensagemDoErroSpb;
            NumeroDeControleSpb = @event.NumeroDeControleSpb;
            CodigoDoStatusSgr = @event.CodigoDoStatusSgr;
            DescricaoDoStatusSgr = @event.DescricaoDoStatusSgr;
            CodigoDoStatusStr = @event.CodigoDoStatusStr;
            DescricaoDoStatusStr = @event.DescricaoDoStatusStr;
            Status = @event.Status;
            StatusDoRetornoDaTransacao = @event.StatusDoRetornoDaTransacao;
        }

    }
}
