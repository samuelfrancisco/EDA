﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Core.Domain.Interfaces;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Repositories.Interfaces
{
    public interface IBaixaOperacionalBoletoRepository : IEventSourcedAggregateRootRepository<BaixaOperacionalBoleto>
    {
        Task<BaixaOperacionalBoleto> ObterPorCodigoDoPagamentoAsync(Guid codigoDoPagamento);
        Task<IEnumerable<BaixaOperacionalBoleto>> ObterTodasPorStatusAsync(StatusBaixaOperacional status);
        Task<string> ObterUltimaMensagemRecebidaAsync();
        Task<BaixaOperacionalBoleto> ObterPorNumeroTransacaoCIPAsync(string numeroTransacao);
        Task<BaixaOperacionalBoleto> ObterPorNumeroTransacaoDeEstornoCIPAsync(string numeroTransacao);
    }
}
