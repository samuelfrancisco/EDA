﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events
{
    public class BaixaOperacionalBoletoEfetivadaEvent : VersionedEvent
    {
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public Guid IdDaBaixaOperacionalDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public string NumeroDoControleDaTransacao { get; set; }
        public string XmlEnviado { get; set; }
        public string XmlRetornado { get; set; }
        public string NumeroDaMensagem { get; set; }
        public string NumIdentcBaixaOperac { get; set; }
        public string CodigoDaMensagemCIP { get; set; }
        public string MensagemDaCIP { get; set; }
        public string CodigoDaRejeicaoCIP { get; set; }
        public string MensagemDaRejeicaoCIP { get; set; }
        public string CodigoDoErroSpb { get; set; }
        public string DescricaoDaMensagemDoErroSpb { get; set; }
        public string NumeroDeControleSpb { get; set; }
        public string Situacao { get; set; }
        public string CodigoDoStatusSgr { get; set; }
        public string DescricaoDoStatusSgr { get; set; }
        public string CodigoDoStatusStr { get; set; }
        public string DescricaoDoStatusStr { get; set; }
        public StatusBaixaOperacional Status { get; set; }
        public StatusRetornoTransacaoBaixaOperacional StatusDoRetornoDaTransacao { get; set; }
    }
}
