﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Events
{
    public class BaixaOperacionalBoletoEnviadaComSucessoEvent : VersionedEvent
    {
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public Guid IdDaBaixaOperacionalDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public string NumeroDoControleDaTransacao { get; set; }
        public DateTimeOffset DataDeProcessamento { get; set; }
        public string XmlEnviado { get; set; }
        public StatusRetornoTransacaoBaixaOperacional StatusRetornoTransacaoBaixaOperacional { get; set; }

    }
}
