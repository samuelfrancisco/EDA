﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands;
using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.DTOs;
using COP.ESB.Pagamento.Dominio.Core;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Services.Interfaces
{
    public interface IServicoDeBaixaOperacionalDeBoleto
    {
        Task<Result<string>> EnviarBaixaOperacionalCIPAsync(RealizarEnvioBaixaOperacionalBoletoParaCIPCommand command);
        Task<Result<RetornoDaConsultaDeBaixaOperacionalDTO>> ConsultarStatusBaixaOperacionalCIPAsync(string numeroMensagem, long empresaAplicacaoTransacaoId);
        Task<Result<RetornoDaConsultaDeBaixaOperacionalDTO>> ConsultarMensagemBaixaOperacionalCIPAsync(string numeroMensagem);
        Task<Result<string>> EnviarEstornoDaBaixaOperacionalCIPAsync(RealizarEnvioDoEstornoDaBaixaOperacionalBoletoParaCIPCommandV2 command);
    }
}
