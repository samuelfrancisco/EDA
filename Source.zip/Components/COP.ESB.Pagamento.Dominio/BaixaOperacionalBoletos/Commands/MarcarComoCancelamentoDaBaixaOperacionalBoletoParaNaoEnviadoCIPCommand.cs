﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands
{
    public class MarcarComoCancelamentoDaBaixaOperacionalBoletoParaNaoEnviadoCIPCommand : CommandBase
    {       
        public Guid IdDaBaixaOperacionalDeBoleto { get; set; }
    }
}
