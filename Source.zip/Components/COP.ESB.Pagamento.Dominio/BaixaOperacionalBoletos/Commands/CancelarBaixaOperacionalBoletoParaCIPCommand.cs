﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands
{
    public class CancelarBaixaOperacionalBoletoParaCIPCommand : CommandBase
    {
        public Guid IdBaixaOperacional { get; set; }
        public Guid IdPagamento { get; set; }
        public string CorpoMensagem { get; set; }
    }
}
