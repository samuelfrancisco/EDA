﻿using COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums;
using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Commands
{
    public class RealizarEnvioBaixaOperacionalBoletoParaCIPCommand : CommandBase
    {       
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public Guid IdDaBaixaOperacionalDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public string NumeroDoControleDaTransacao { get; set; }
        public string CorpoMensagem { get; set; }
        public StatusRetornoTransacaoBaixaOperacional StatusRetornoTransacao { get; set; }
        public bool Sucesso { get; set; }
    }
}
