﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums
{
    public enum StatusRetornoTransacaoBaixaOperacional
    {
        /// <summary>
        /// EmProcessamento
        /// </summary>
        Enviado = 0,

        /// <summary>
        /// 1 – Erros genéricos
        /// </summary>
        ErrosGenericos = 1,

        /// <summary>
        /// 999 – Erros de SQL
        /// </summary>
        ErrosDeSQL = 999,

        /// <summary>
        /// 20001 – Não Enviada
        /// </summary>
        NaoEnviada = 20001,
        
        /// <summary>
        /// 4300002 – Número de controle não informado
        /// </summary>
        NumeroDeControleNaoInformado = 4300002,

        /// <summary>
        /// 4300003 – Indicador de autorização não informado
        /// </summary>
        IndicadorDeAutorizacaoNaoInformado = 4300003,

        /// <summary>
        /// 4300004 – Data Reserva não informada
        /// </summary>
        DataDaReservaNaoInformada = 4300004,

        /// <summary>
        /// 4300005 – Data/Hora da Liquidação não informada
        /// </summary>
        DataHoraDaLiquidacaoNaoInformada = 4300005,

        /// <summary>
        /// 4300006 – Formato do mensagem não informado
        /// </summary>
        FormatoDoMensagemNaoinformado = 4300006,

        /// <summary>
        /// 4300007 – Usuário responsável pela inclusão não informado
        /// </summary>
        UsuarioResponsavelPelaInclusaoNaoInformado = 4300007,

        /// <summary>
        /// 4300008 – Data da Reserva inválida
        /// </summary>
        DataDaReservaInvalida = 4300008,

        /// <summary>
        /// 4300009 – Data/Hora da liquidação inválida
        /// </summary>
        DataHoraDaLiquidacaoInvalida = 4300009,

        /// <summary>
        /// 4300010 – XML inválido
        /// </summary>
        XMLInvalido = 4300010,

        /// <summary>
        /// 4300013 – Campos obrigatórios da mensagem não preenchidos
        /// </summary>
        CamposObrigatoriosDaMensagemNaoPreenchidos = 4300013,

        /// <summary>
        /// 4300019 – Erro genérico de validação de campos fora de padrão ou domínio inválido
        /// </summary>
        ErroGenericoDeValidaçãoDeCamposForaDePadraoOuDominioInvalido = 4300019
    }
}
