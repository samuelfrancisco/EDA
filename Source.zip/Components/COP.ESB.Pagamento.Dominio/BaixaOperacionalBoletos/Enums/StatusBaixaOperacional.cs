﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.Enums
{
    public enum StatusBaixaOperacional
    {
        /// <summary>
        /// ErroDeEnvio
        /// </summary>
        RejeitadoNoTransacao = 0,
        
        /// <summary>
        /// EmProcessamento
        /// </summary>
        EmProcessamento = 1,

        /// <summary>
        /// Efetivada
        /// </summary>
        Efetivada = 2,

        /// <summary>
        /// RejeitadoNoEnvio
        /// </summary>
        RejeitadoNoEnvio = 3,

        /// <summary>
        /// Recusada
        /// </summary>
        Recusada = 4,

        /// <summary>
        /// Concluido
        /// </summary>
        Concluido = 5,

        /// <summary>
        /// Estorno Pendente De Envio para Mensageria
        /// </summary>
        EstornoPendenteDeEnvio = 6,

        /// <summary>
        /// EstornoEnviadoCIP
        /// </summary>
        EstornoEnviadoCIP = 7,

        /// <summary>
        /// Estornado
        /// </summary>
        Estornado = 8,

        /// <summary>
        /// EstornadoRecusadoCIP
        /// </summary>
        EstornadoRecusadoCIP = 9,

        /// <summary>
        /// Horário de Envio expirado
        /// </summary>
        HorarioDeEnvioExpirado = 10,

        /// <summary>
        /// Horário de Envio expirado
        /// </summary>
        HorarioDeEnvioDeEstornoExpirado = 11,
    }
}
