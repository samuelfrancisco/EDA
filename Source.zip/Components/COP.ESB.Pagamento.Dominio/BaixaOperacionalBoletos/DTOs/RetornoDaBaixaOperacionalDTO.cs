﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.DTOs
{
    public class RetornoDaBaixaOperacionalDTO
    {
        public string CodigoDeErro { get; set; }
        public string DescricaoDoErro { get; set; }
        public string XmlRetornado { get; set; }
    }
}
