﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.DTOs
{
    [XmlRoot("DDA0108R1")]
    public class RetornoBaixaOperacionalXmlDDA0108R1DTO
    {
        [XmlElement("CodMsg")]
        public string CodMsg { get; set; }

        [XmlElement("NumCtrlPart")]
        public string NumCtrlPart { get; set; }

        [XmlElement("ISPBPartRecbdrPrincipal")]
        public string ISPBPartRecbdrPrincipal { get; set; }

        [XmlElement("ISPBPartRecbdrAdmtd")]
        public string ISPBPartRecbdrAdmtd { get; set; }

        [XmlElement("NumIdentcTit")]
        public string NumIdentcTit { get; set; }

        [XmlElement("NumRefAtlCadTit")]
        public string NumRefAtlCadTit { get; set; }

        [XmlElement("NumIdentcBaixaOperac")]
        public string NumIdentcBaixaOperac { get; set; }

        [XmlElement("NumRefAtlBaixaOperac")]
        public string NumRefAtlBaixaOperac { get; set; }

        [XmlElement("NumSeqAtlzBaixaOperac")]
        public string NumSeqAtlzBaixaOperac { get; set; }

        [XmlElement("NumCtrlDDA")]
        public string NumCtrlDDA { get; set; }

        [XmlElement("DtHrDDA")]
        public DateTime DtHrDDA { get; set; }

        [XmlElement("DtMovto")]
        public DateTime DtMovto { get; set; }

    }
}
