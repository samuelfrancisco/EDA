﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.DTOs
{
    [XmlRoot("DDA0108R2")]
    public class RetornoBaixaOperacionalXmlDDA0108R2DTO
    {
        [XmlElement("CodMsg")]
        public string CodMsg { get; set; }
        [XmlElement("ISPBPartPrincipal")]
        public string ISPBPartPrincipal { get; set; }

        [XmlElement("ISPBPartAdmtd")]
        public string ISPBPartAdmtd { get; set; }

        [XmlElement("NumIdentcTit")]
        public string NumIdentcTit { get; set; }

        [XmlElement("NumRefCadTitBaixaOperac")]
        public string NumRefCadTitBaixaOperac { get; set; }

        [XmlElement("NumRefAtlCadTit")]
        public string NumRefAtlCadTit { get; set; }

        [XmlElement("NumIdentcBaixaOperac")]
        public string NumIdentcBaixaOperac { get; set; }

        [XmlElement("NumRefAtlBaixaOperac")]
        public string NumRefAtlBaixaOperac { get; set; }

        [XmlElement("NumSeqAtlzBaixaOperac")]
        public string NumSeqAtlzBaixaOperac { get; set; }

        [XmlElement("NumCtrlDDA")]
        public string NumCtrlDDA { get; set; }

        [XmlElement("TpBaixaOperac")]
        public string TpBaixaOperac { get; set; }

        [XmlElement("ISPBPartRecbdrBaixaOperac")]
        public string ISPBPartRecbdrBaixaOperac { get; set; }

        [XmlElement("CodPartRecbdrBaixaOperac")]
        public string CodPartRecbdrBaixaOperac { get; set; }

        [XmlElement("TpPessoaPort")]
        public string TpPessoaPort { get; set; }

        [XmlElement("CNPJ_CPFPort")]
        public string CNPJ_CPFPort { get; set; }

        [XmlElement("DtHrProcBaixaOperac")]
        public DateTime DtHrProcBaixaOperac { get; set; }

        [XmlElement("DtProcBaixaOperac")]
        public DateTime DtProcBaixaOperac { get; set; }

        [XmlElement("VlrBaixaOperacTit")]
        public string VlrBaixaOperacTit { get; set; }

        [XmlElement("NumCodBarrasBaixaOperac")]
        public string NumCodBarrasBaixaOperac { get; set; }

        [XmlElement("CanPgto")]
        public string CanPgto { get; set; }

        [XmlElement("MeioPgto")]
        public string MeioPgto { get; set; }

        [XmlElement("DtHrSitBaixaOperac")]
        public DateTime DtHrSitBaixaOperac { get; set; }

        [XmlElement("IndrOpContg")]
        public string IndrOpContg { get; set; }

        [XmlElement("QtdPgtoParclRegtd")]
        public string QtdPgtoParclRegtd { get; set; }

        [XmlElement("VlrSldTotAtlPgtoTit")]
        public string VlrSldTotAtlPgtoTit { get; set; }

        [XmlElement("SitTitPgto")]
        public string SitTitPgto { get; set; }

        [XmlElement("DtHrDDA")]
        public DateTime DtHrDDA { get; set; }
        [XmlElement("DtMovto")]
        public DateTime DtMovto { get; set; }
    }
}
