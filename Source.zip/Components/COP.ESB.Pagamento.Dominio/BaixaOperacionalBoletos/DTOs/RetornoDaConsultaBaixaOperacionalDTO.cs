﻿namespace COP.ESB.Pagamento.Dominio.BaixaOperacionalBoletos.DTOs
{
    public class RetornoDaConsultaDeBaixaOperacionalDTO
    {
        public string NumeroDeControleTransacao { get; set; }
        public string CodigoDaMensagem { get; set; }
        public string CodigoDaMensagemErro { get; set; }
        public string DescricaoDaMensagemErro { get; set; }
        public string NumeroDaOrigem { get; set; }
        public string XmlRetornado { get; set; }
        public string CodigoDaRejeicao { get; set; }
        public string DescricaoDoMotivoDaRejeicao { get; set; }
        public string CodigoDoErroSpb { get; set; }
        public string DescricaoDaMensagemDoErroSpb { get; set; }
        public string NumeroDeControleSpb { get; set; }
        public string Situacao { get; set; }
        public string CodigoDoStatusSgr { get; set; }
        public string DescricaoDoStatusSgr { get; set; }
        public string CodigoDoStatusStr { get; set; }
        public string DescricaoDoStatusStr { get; set; }
        public RetornoBaixaOperacionalXmlDDA0108R1DTO RetornoDeserializado { get; set; }
    }
}
