﻿using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento
    {
        public BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public string NumCtrlReqPart { get; set; }
        public string ISPBPartRecbdrPrincipal { get; set; }
        public string ISPBPartRecbdrAdmtd { get; set; }
        public int TpBaixaOperac { get; set; }
        public string ISPBPartRecbdrBaixaOperac { get; set; }
        public string CodPartRecbdrBaixaOperac { get; set; }
        public string TpPessoaPort { get; set; }
        public string CNPJ_CPFPort { get; set; }
        public DateTimeOffset DtHrProcBaixaOperac { get; set; }
        public DateTimeOffset DtProcBaixaOperac { get; set; }
        public decimal VlrBaixaOperacTit { get; set; }
        public string NumCodBarrasBaixaOperac { get; set; }
        public int CanalPagamento { get; set; }
        public int MeioPagamento { get; set; }
    }
}