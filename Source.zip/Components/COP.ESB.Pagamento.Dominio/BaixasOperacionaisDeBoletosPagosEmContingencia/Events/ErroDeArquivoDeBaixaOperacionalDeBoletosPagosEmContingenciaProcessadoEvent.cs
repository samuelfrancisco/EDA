﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public Guid IdDoArquivoDeConsultaDeBoletosPagosEmContingencia { get; set; }
        public string XmlDoRetorno { get; set; }
        public string ErroNoProcessamentoDoRetorno { get; set; }
        public DateTimeOffset DataDeProcessamentoDoRetorno { get; set; }
        public List<ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento> Pagamentos { get; set; }
    }
}
