﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }       
        public DateTimeOffset DataDeConclusao { get; set; }
    }
}
