﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class ArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaEnviadosEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public DateTimeOffset DateDeEnvio { get; set; }
        public IDictionary<Guid, string> NomesCompletosDosArquivosNoEnvio { get; set; }
    }
}
