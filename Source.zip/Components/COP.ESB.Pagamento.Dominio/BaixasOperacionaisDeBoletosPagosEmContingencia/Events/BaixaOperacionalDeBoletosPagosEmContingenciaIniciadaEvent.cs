﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public DateTime DataDeProcessamento { get; set; }
        public DateTimeOffset DataDeInicio { get; set; }
        public IEnumerable<BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo> ArquivosGerados { get; set; }
    }
}
