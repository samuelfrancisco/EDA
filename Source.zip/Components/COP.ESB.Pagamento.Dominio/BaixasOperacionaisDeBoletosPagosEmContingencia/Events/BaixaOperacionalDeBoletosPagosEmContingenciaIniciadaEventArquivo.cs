﻿using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo
    {
        public BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo()
        {
            Id = Guid.NewGuid();
            DataDeCriacao = DateTime.Now;
        }

        public Guid Id { get; set; }
        public string NomeDoArquivo { get; set; }
        public DateTime DataDeProcessamento { get; set; }
        public int Sequencia { get; set; }
        public string NumeroDeControle { get; set; }
        public string XmlGerado { get; set; }
        public DateTimeOffset DataDeCriacao { get; set; }
        public IEnumerable<BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento> PagamentosEnviados { get; set; }
    }
}