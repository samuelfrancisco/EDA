﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public Guid IdDoArquivoDeConsultaDeBoletosPagosEmContingencia { get; set; }
        public string XmlDoRetorno { get; set; }        
        public DateTimeOffset DataDeProcessamentoDoRetorno { get; set; }
        public List<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento> PagamentosAceitos { get; set; }
        public List<RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento> PagamentosRecusados { get; set; }
    }
}