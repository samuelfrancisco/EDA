﻿using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento
    {
        public Guid IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia { get; set; }
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
    }
}
