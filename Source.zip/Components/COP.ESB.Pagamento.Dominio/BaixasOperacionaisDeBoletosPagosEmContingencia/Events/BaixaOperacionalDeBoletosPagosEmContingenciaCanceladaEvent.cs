﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent : VersionedEvent
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public DateTimeOffset DataDeCancelamento { get; set; }
        public string MotivoDoCancelamento { get; set; }
    }
}
