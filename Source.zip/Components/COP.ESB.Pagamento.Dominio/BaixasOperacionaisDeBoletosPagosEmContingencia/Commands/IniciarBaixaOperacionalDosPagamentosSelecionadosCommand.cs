﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands
{
    public class IniciarBaixaOperacionalDosPagamentosSelecionadosCommand : CommandBase
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public Guid IdDaBaixaOperacionaisDeBoletosPagosEmContingencia { get; set; }
        public List<IniciarBaixaOperacionalDosPagamentosSelecionadosCommandPagamento> Pagamentos { get; set; }
    }
}
