﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands
{
    public class IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand : CommandBase
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public Guid IdDaBaixaOperacionaisDeBoletosPagosEmContingencia { get; set; }
    }
}
