﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;
using System.Collections.Generic;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands
{
    public class EnviarArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand : CommandBase
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public IDictionary<Guid, string> NomesCompletosDosArquivosNoEnvio { get; set; }
    }
}
