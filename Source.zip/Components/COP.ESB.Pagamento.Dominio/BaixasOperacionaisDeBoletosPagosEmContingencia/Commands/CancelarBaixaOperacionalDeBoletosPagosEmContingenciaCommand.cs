﻿using COP.ESB.Pagamento.Dominio.Core.Messaging;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands
{
    public class CancelarBaixaOperacionalDeBoletosPagosEmContingenciaCommand : CommandBase
    {
        public Guid IdDoProcessoDeConsultaEBaixa { get; set; }
        public string MotivoDoCancelamento { get; set; }
    }
}
