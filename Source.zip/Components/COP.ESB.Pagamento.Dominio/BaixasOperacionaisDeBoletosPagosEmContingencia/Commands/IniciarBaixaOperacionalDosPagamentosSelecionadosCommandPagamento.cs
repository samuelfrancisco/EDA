﻿using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands
{
    public class IniciarBaixaOperacionalDosPagamentosSelecionadosCommandPagamento
    {
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
    }
}
