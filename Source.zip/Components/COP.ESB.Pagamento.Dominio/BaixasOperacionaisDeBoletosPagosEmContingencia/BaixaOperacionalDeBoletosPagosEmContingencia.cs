﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Commands;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Configuracoes.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.Core;
using COP.ESB.Pagamento.Dominio.Core.EventSourcing;
using COP.ESB.Pagamento.Dominio.Core.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia
{
    public class BaixaOperacionalDeBoletosPagosEmContingencia : EventSourcedAggregateRoot
    {
        protected BaixaOperacionalDeBoletosPagosEmContingencia()
            : base()
        {
        }

        public BaixaOperacionalDeBoletosPagosEmContingencia(IniciarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command,
           DateTime dataDeProcessamento,
           IEnumerable<PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO> pagamentos,
           IBaixaOperacionalDeBoletosPagosEmContingenciaService baixaOperacionalDeBoletosPagosEmContingenciaService,
           IConfiguracoesDoMotorService configuracoesDoMotorService,
           IBancoService bancoService)
           : base()
        {
            Id = command.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia;

            var data = DateTime.Now;

            Update(new BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                DataDeProcessamento = dataDeProcessamento,
                DataDeInicio = DateTime.Now,
                ArquivosGerados = GerarArquivosParaEvento(data, dataDeProcessamento, pagamentos, baixaOperacionalDeBoletosPagosEmContingenciaService, configuracoesDoMotorService, bancoService),
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            var validacaoResult = ValidarConfiguracoesDoMotor(configuracoesDoMotorService);

            if (validacaoResult.IsFailure)
            {
                var motivo = string.Join(Environment.NewLine, validacaoResult.ErroMessage.Errors.Select(x => x.Message));

                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    DataDeCancelamento = DateTime.Now,
                    MotivoDoCancelamento = motivo,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public BaixaOperacionalDeBoletosPagosEmContingencia(IniciarBaixaOperacionalDosPagamentosSelecionadosCommand command,
         DateTime dataDeProcessamento,
         IEnumerable<PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO> pagamentos,
         IBaixaOperacionalDeBoletosPagosEmContingenciaService baixaOperacionalDeBoletosPagosEmContingenciaService,
         IConfiguracoesDoMotorService configuracoesDoMotorService,
         IBancoService bancoService)
         : base()
        {
            Id = command.IdDaBaixaOperacionaisDeBoletosPagosEmContingencia;

            var data = DateTime.Now;

            Update(new BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                DataDeProcessamento = dataDeProcessamento,
                DataDeInicio = DateTime.Now,
                ArquivosGerados = GerarArquivosParaEvento(data, dataDeProcessamento, pagamentos, baixaOperacionalDeBoletosPagosEmContingenciaService, configuracoesDoMotorService, bancoService),
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            var validacaoResult = ValidarConfiguracoesDoMotor(configuracoesDoMotorService);

            if (validacaoResult.IsFailure)
            {
                var motivo = string.Join(Environment.NewLine, validacaoResult.ErroMessage.Errors.Select(x => x.Message));

                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    MotivoDoCancelamento = motivo,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public virtual Guid IdDoProcessoDeConsultaEBaixa { get; protected set; }
        public virtual DateTime DataDeProcessamento { get; protected set; }
        public virtual DateTimeOffset DataDeInicio { get; protected set; }
        public virtual DateTimeOffset? DataDeConclusao { get; protected set; }
        public virtual DateTimeOffset? DataDeCancelamento { get; protected set; }
        public virtual string MotivoDoCancelamento { get; protected set; }
        public virtual BaixaOperacionalDeBoletosPagosEmContingenciaStatus Status { get; protected set; }
        public virtual IList<ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia> ArquivosGerados { get; protected set; } = new List<ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia>();

        public void Cancelar(CancelarBaixaOperacionalDeBoletosPagosEmContingenciaCommand command)
        {
            Update(new BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                DataDeCancelamento = DateTime.Now,
                MotivoDoCancelamento = command.MotivoDoCancelamento,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });
        }

        public void EnviarArquivos(EnviarArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command)
        {
            Update(new ArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaEnviadosEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                DateDeEnvio = DateTime.Now,
                NomesCompletosDosArquivosNoEnvio = command.NomesCompletosDosArquivosNoEnvio,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            if (!ArquivosGerados.SelectMany(x => x.PagamentosEnviados).Any())
            {
                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    DataDeConclusao = DateTime.Now,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public void ProcessarRetornoDeArquivo(ProcessarRetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command, string xmlRetornado)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.NomeDoArquivo == command.NomeDoArquivoOriginal);

            if (arquivo == null)
                throw new InvalidOperationException($"O arquivo {command.NomeDoArquivoOriginal} não faz parte da consulta {Id}.");

            if (arquivo.Status != ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Enviado)
                return;

            var xmlDTO = XmlExtensions.FromXml<ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlDTO>(xmlRetornado);

            var pagamentosAceitos = arquivo.ObterOsPagamentosAceitos(xmlDTO)
                .Select(x => new RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento
                {
                    IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia = x.Id,
                    IdDoBoleto = x.IdDoBoleto,
                    IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = x.IdDoPagamentoDeBoleto,
                    EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId
                })
                .ToList();

            var pagamentosRecusados = arquivo.ObterOsPagamentosRecusados(xmlDTO)
                 .Select(x => new RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento
                 {
                     IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia = x.Id,
                     IdDoBoleto = x.IdDoBoleto,
                     IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                     IdDoPagamentoDeBoleto = x.IdDoPagamentoDeBoleto,
                     EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId
                 })
                .ToList();

            Update(new RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                IdDoArquivoDeConsultaDeBoletosPagosEmContingencia = arquivo.Id,
                XmlDoRetorno = xmlRetornado,
                PagamentosAceitos = pagamentosAceitos,
                PagamentosRecusados = pagamentosRecusados,
                DataDeProcessamentoDoRetorno = DateTime.Now,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            if (ArquivosGerados.Where(x => x.Id != arquivo.Id).All(x => x.Status == ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado))
            {
                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    DataDeConclusao = DateTime.Now,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public void ProcessarRetornoDeArquivoComErro(ProcessarRetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command, string erro)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.NomeDoArquivo == command.NomeDoArquivoOriginal);

            if (arquivo == null)
                throw new InvalidOperationException($"O arquivo {command.NomeDoArquivoOriginal} não faz parte da consulta {Id}.");

            if (arquivo.Status != ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Enviado)
                return;

            var pagamentos = arquivo.PagamentosEnviados
                .Select(x => new RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEventPagamento
                {
                    IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia = x.Id,
                    IdDoBoleto = x.IdDoBoleto,
                    IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = x.IdDoPagamentoDeBoleto,
                    EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId
                })
                .ToList();

            Update(new RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                IdDoArquivoDeConsultaDeBoletosPagosEmContingencia = arquivo.Id,
                ErroNoProcessamentoDoRetorno = erro,
                DataDeProcessamentoDoRetorno = DateTime.Now,
                Pagamentos = pagamentos,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            if (ArquivosGerados.Where(x => x.Id != arquivo.Id).All(x => x.Status == ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado))
            {
                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    DataDeConclusao = DateTime.Now,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        public void ProcessarErroDeArquivo(ProcessarErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaCommand command,
            string xmlRetornado = null, string erro = null)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.NomeDoArquivo == command.NomeDoArquivoOriginal);

            if (arquivo == null)
                throw new InvalidOperationException($"O arquivo {command.NomeDoArquivoOriginal} não faz parte da consulta {Id}.");

            if (arquivo.Status != ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Enviado)
                return;

            var pagamentos = arquivo.PagamentosEnviados
                .Select(x => new ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEventPagamento
                {
                    IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia = x.Id,
                    IdDoBoleto = x.IdDoBoleto,
                    IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                    IdDoPagamentoDeBoleto = x.IdDoPagamentoDeBoleto,
                    EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId
                })
                .ToList();

            Update(new ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent
            {
                IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                IdDoArquivoDeConsultaDeBoletosPagosEmContingencia = arquivo.Id,
                XmlDoRetorno = xmlRetornado,
                ErroNoProcessamentoDoRetorno = erro,
                Pagamentos = pagamentos,
                DataDeProcessamentoDoRetorno = DateTime.Now,
                CorrelationMessage = command,
                OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
            });

            if (ArquivosGerados.Where(x => x.Id != arquivo.Id).All(x => x.Status == ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado))
            {
                Update(new BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent
                {
                    IdDoProcessoDeConsultaEBaixa = command.IdDoProcessoDeConsultaEBaixa,
                    DataDeConclusao = DateTime.Now,
                    CorrelationMessage = command,
                    OriginalCorrelationMessage = command.OriginalCorrelationMessage ?? command
                });
            }
        }

        private Result ValidarConfiguracoesDoMotor(IConfiguracoesDoMotorService configuracoesDoMotorService)
        {
            var result = new Result();

            if (configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos == null)
                result.AddError("Não existe uma trasação Boletos configurada no sistema.",
                    "Não existe uma trasação Boletos configurada no sistema.",
                    GetType().FullName);

            if (result.IsFailure)
                return result;

            if (string.IsNullOrWhiteSpace(configuracoesDoMotorService.ConfiguracoesDoMotor.Provedores.SGR?.ConsultaDeBoletos?.ISPBPartRecbdrPrincipal))
                result.AddError("O parâmetro ISPBPartRecbdrPrincipal da baixa operacional de boletos está configurado.",
                    "O parâmetro ISPBPartRecbdrPrincipal da baixa operacional de boletos não está configurado.",
                    GetType().FullName);

            if (result.IsFailure)
                return result;

            var horario = DateTime.Now.TimeOfDay;

            if (horario < configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos.ConfiguracoesDaTransacao.HorarioInicialDeBackOffice
                || horario > configuracoesDoMotorService.ConfiguracoesDoMotor.Boletos.ConfiguracoesDaTransacao.HorarioFinalDeBackOffice)
                result.AddError("Horário para BackOffice encerrado.", "Horário indisponível.", GetType().FullName);            

            return result;
        }

        private IEnumerable<IEnumerable<BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento>> ObterPagamentosPorArquivo
            (DateTime data, IEnumerable<PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO> pagamentos)
        {
            var listaDePagamentos = pagamentos.ToList();

            for (int i = 0; i < listaDePagamentos.Count; i += 50000)
            {
                yield return listaDePagamentos.GetRange(i, Math.Min(50000, listaDePagamentos.Count - i))
                    .Select((x, y) =>
                    {
                        var sequenciaComoString = (y + 1).ToString().PadLeft(5, '0');

                        return new BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento
                        {
                            EmpresaAplicacaoTransacaoId = x.EmpresaAplicacaoTransacaoId,
                            IdDoBoleto = x.IdDoBoleto,
                            IdDaConsultaDeBoleto = x.IdDaConsultaDeBoleto,
                            IdDoPagamentoDeBoleto = x.IdDoPagamentoDeBoleto,
                            CanalPagamento = x.CanalPagamento,
                            CNPJ_CPFPort = x.CNPJ_CPFPort,
                            CodPartRecbdrBaixaOperac = x.CodPartRecbdrBaixaOperac,
                            DtHrProcBaixaOperac = x.DtHrProcBaixaOperac,
                            DtProcBaixaOperac = x.DtProcBaixaOperac,
                            ISPBPartRecbdrAdmtd = x.ISPBPartRecbdrAdmtd,
                            Id = x.Id,
                            ISPBPartRecbdrBaixaOperac = x.ISPBPartRecbdrBaixaOperac,
                            ISPBPartRecbdrPrincipal = x.ISPBPartRecbdrPrincipal,
                            MeioPagamento = x.MeioPagamento,
                            NumCodBarrasBaixaOperac = x.NumCodBarrasBaixaOperac,
                            TpBaixaOperac = x.TpBaixaOperac,
                            TpPessoaPort = x.TpPessoaPort,
                            VlrBaixaOperacTit = x.VlrBaixaOperacTit,
                            NumCtrlReqPart = $"{data.ToString("yyyyMMddHHmm")}{sequenciaComoString}"
                        };
                    });
            }
        }

        private IEnumerable<BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo> GerarArquivosParaEvento(DateTime data,
            DateTime dataDeProcessamento,
            IEnumerable<PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO> pagamentos,
            IBaixaOperacionalDeBoletosPagosEmContingenciaService baixaOperacionalDeBoletosPagosEmContingenciaService,
            IConfiguracoesDoMotorService configuracoesDoMotorService,
            IBancoService bancoService)
        {
            var iSPBPartRecbdrPrincipal = configuracoesDoMotorService.ConfiguracoesDoMotor.Provedores.SGR?.ConsultaDeBoletos?.ISPBPartRecbdrPrincipal;

            var iSPBPartRecbdrAdmtd = configuracoesDoMotorService.ConfiguracoesDoMotor.Provedores.SGR?.ConsultaDeBoletos?.ISPBPartRecbdrAdmtd;

            var ultimaSequenciaGerada = baixaOperacionalDeBoletosPagosEmContingenciaService.ObterUltimaSequenciaDeArquivoGeradaAsync(dataDeProcessamento).Result;

            var bancoRendimento = bancoService.ObterBancoRendimentoAsync().Result;

            var sequencia = Math.Max(ultimaSequenciaGerada, 80000);

            return ObterPagamentosPorArquivo(data, pagamentos).Select(x =>
            {
                sequencia += 1;

                var sequenciaComoString = sequencia.ToString().PadLeft(5, '0');

                var nomeDoArquivo = $"ADDA114_{iSPBPartRecbdrPrincipal}_{dataDeProcessamento.ToString("yyyyMMdd")}_{sequenciaComoString}";

                var numeroDeControle = $"{data.ToString("yyyyMMddHHmm")}{sequenciaComoString}";

                return new BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo
                {
                    NomeDoArquivo = nomeDoArquivo,
                    DataDeProcessamento = dataDeProcessamento,
                    Sequencia = sequencia,
                    NumeroDeControle = numeroDeControle,
                    PagamentosEnviados = x,
                    XmlGerado = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia.ToXml(nomeDoArquivo, numeroDeControle, iSPBPartRecbdrPrincipal,
                    iSPBPartRecbdrAdmtd, bancoRendimento.CodISPB, bancoRendimento.CodBanco.Substring(bancoRendimento.CodBanco.Length - 3), 
                    dataDeProcessamento, x)
                };
            });
        }

        private void When(BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEvent @event)
        {
            IdDoProcessoDeConsultaEBaixa = @event.IdDoProcessoDeConsultaEBaixa;
            DataDeProcessamento = @event.DataDeProcessamento;
            DataDeInicio = @event.DataDeInicio;
            Status = BaixaOperacionalDeBoletosPagosEmContingenciaStatus.Iniciada;
            ArquivosGerados = @event.ArquivosGerados
                .Select(arquivo => new ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia(Id, arquivo)).ToList();
        }

        private void When(BaixaOperacionalDeBoletosPagosEmContingenciaCanceladaEvent @event)
        {
            DataDeCancelamento = @event.DataDeCancelamento;
            MotivoDoCancelamento = @event.MotivoDoCancelamento;
            Status = BaixaOperacionalDeBoletosPagosEmContingenciaStatus.Cancelada;
        }

        private void When(ArquivosDeBaixaOperacionalDeBoletosPagosEmContingenciaEnviadosEvent @event)
        {
            Status = BaixaOperacionalDeBoletosPagosEmContingenciaStatus.AguardandoRetornoDosArquivos;

            foreach (var item in @event.NomesCompletosDosArquivosNoEnvio)
            {
                var arquivo = ArquivosGerados.FirstOrDefault(x => x.Id == item.Key);

                if (arquivo == null) continue;

                arquivo.Enviar(item.Value, @event.DateDeEnvio);
            }
        }

        private void When(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.Id == @event.IdDoArquivoDeConsultaDeBoletosPagosEmContingencia);

            if (arquivo == null) return;

            arquivo.ProcessarRetorno(@event);
        }

        private void When(BaixaOperacionalDeBoletosPagosEmContingenciaConcluidaEvent @event)
        {
            DataDeConclusao = @event.DataDeConclusao;
            Status = BaixaOperacionalDeBoletosPagosEmContingenciaStatus.Concluida;
        }

        private void When(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent @event)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.Id == @event.IdDoArquivoDeConsultaDeBoletosPagosEmContingencia);

            if (arquivo == null) return;

            arquivo.ProcessarRetorno(@event);
        }

        private void When(ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event)
        {
            var arquivo = ArquivosGerados.FirstOrDefault(x => x.Id == @event.IdDoArquivoDeConsultaDeBoletosPagosEmContingencia);

            if (arquivo == null) return;

            arquivo.ProcessarRetorno(@event);
        }
    }
}