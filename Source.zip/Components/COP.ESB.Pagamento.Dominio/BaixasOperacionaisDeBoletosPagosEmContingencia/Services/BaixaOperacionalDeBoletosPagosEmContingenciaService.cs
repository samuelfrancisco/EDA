﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Services.Interfaces;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Repositories.Interfaces;
using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Services
{
    public class BaixaOperacionalDeBoletosPagosEmContingenciaService : IBaixaOperacionalDeBoletosPagosEmContingenciaService
    {
        private readonly IBaixaOperacionalDeBoletosPagosEmContingenciaRepository _baixaOperacionalDeBoletosPagosEmContingenciaRepository;

        public BaixaOperacionalDeBoletosPagosEmContingenciaService(IBaixaOperacionalDeBoletosPagosEmContingenciaRepository baixaOperacionalDeBoletosPagosEmContingenciaRepository)
        {
            _baixaOperacionalDeBoletosPagosEmContingenciaRepository = baixaOperacionalDeBoletosPagosEmContingenciaRepository;
        }

        public Task<int> ObterUltimaSequenciaDeArquivoGeradaAsync(DateTime dataDeProcessamento)
        {
            return _baixaOperacionalDeBoletosPagosEmContingenciaRepository.ObterUltimaSequenciaDeArquivoGeradaAsync(dataDeProcessamento);
        }
    }
}
