﻿using System;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Services.Interfaces
{
    public interface IBaixaOperacionalDeBoletosPagosEmContingenciaService
    {
        Task<int> ObterUltimaSequenciaDeArquivoGeradaAsync(DateTime dataDeProcessamento);
    }
}
