﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using System;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia
{
    public class PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia
    {
        protected PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia()
        {

        }

        public PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia(Guid idDoArquivoGeradoParaConsultaDeBoletosPagosEmContingencia,
            BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento pagamento)
        {
            Id = pagamento.Id;
            IdDoArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia = idDoArquivoGeradoParaConsultaDeBoletosPagosEmContingencia;
            EmpresaAplicacaoTransacaoId = pagamento.EmpresaAplicacaoTransacaoId;
            IdDoBoleto = pagamento.IdDoBoleto;
            IdDaConsultaDeBoleto = pagamento.IdDaConsultaDeBoleto;
            IdDoPagamentoDeBoleto = pagamento.IdDoPagamentoDeBoleto;
            NumCtrlReqPart = pagamento.NumCtrlReqPart;           
            TpBaixaOperac = pagamento.TpBaixaOperac;            
            TpPessoaPort = pagamento.TpPessoaPort;
            CNPJ_CPFPort = pagamento.CNPJ_CPFPort;
            DtHrProcBaixaOperac = pagamento.DtHrProcBaixaOperac;
            DtProcBaixaOperac = pagamento.DtProcBaixaOperac;
            VlrBaixaOperacTit = pagamento.VlrBaixaOperacTit;
            NumCodBarrasBaixaOperac = pagamento.NumCodBarrasBaixaOperac;
            CanalPagamento = pagamento.CanalPagamento;
            MeioPagamento = pagamento.MeioPagamento;
            Status = PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Gerado;
        }

        public virtual Guid Id { get; protected set; }
        public virtual Guid IdDoArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia { get; protected set; }
        public virtual long EmpresaAplicacaoTransacaoId { get; protected set; }
        public virtual Guid IdDoBoleto { get; protected set; }
        public virtual Guid IdDaConsultaDeBoleto { get; protected set; }
        public virtual Guid IdDoPagamentoDeBoleto { get; protected set; }
        public virtual string NumCtrlReqPart { get; protected set; }        
        public virtual int TpBaixaOperac { get; protected set; }        
        public virtual string TpPessoaPort { get; protected set; }
        public virtual string CNPJ_CPFPort { get; protected set; }
        public virtual DateTimeOffset DtHrProcBaixaOperac { get; protected set; }
        public virtual DateTimeOffset DtProcBaixaOperac { get; protected set; }
        public virtual decimal VlrBaixaOperacTit { get; protected set; }
        public virtual string NumCodBarrasBaixaOperac { get; protected set; }
        public virtual int CanalPagamento { get; protected set; }
        public virtual int MeioPagamento { get; protected set; }
        public virtual PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus Status { get; protected set; }
        public virtual ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia Arquivo { get; protected set; }

        public void Enviar()
        {
            Status = PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Enviado;
        }

        public void Aceitar()
        {
            Status = PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Aceito;
        }

        public void Recusar()
        {
            Status = PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Recusado;
        }
    }
}
