﻿using COP.ESB.Pagamento.Dominio.Core.EventSourcing.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Repositories.Interfaces
{
    public interface IBaixaOperacionalDeBoletosPagosEmContingenciaRepository : IEventSourcedAggregateRootRepository<BaixaOperacionalDeBoletosPagosEmContingencia>
    {
        Task<BaixaOperacionalDeBoletosPagosEmContingencia> ObterPeloIdDoProcessoDeConsultaEBaixaAsync(Guid idDoProcessoDeConsultaEBaixa);
        Task<int> ObterUltimaSequenciaDeArquivoGeradaAsync(DateTime dataDeProcessamento);
        Task<IList<BaixaOperacionalDeBoletosPagosEmContingencia>> ObterArquivosPendentesDeRetornoAsync();
    }
}
