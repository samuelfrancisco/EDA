﻿using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    [XmlRoot("Grupo_ADDA114RET_TitActo")]
    public class GrupoDeRetornoDeBaixaOperacionalEmContingenciaAceitaXmlDTO
    {
        [XmlElement("NumCtrlReqPart")]
        public string NumCtrlReqPart { get; set; }

        [XmlElement("ISPBPartRecbdrPrincipal")]
        public string ISPBPartRecbdrPrincipal { get; set; }

        [XmlElement("ISPBPartRecbdrAdmtd")]
        public string ISPBPartRecbdrAdmtd { get; set; }

        [XmlElement("NumIdentcTit")]
        public string NumIdentcTit { get; set; }

        [XmlElement("NumRefAtlCadTit")]
        public string NumRefAtlCadTit { get; set; }

        [XmlElement("NumIdentcBaixaOperac")]
        public string NumIdentcBaixaOperac { get; set; }

        [XmlElement("NumRefAtlBaixaOperac")]
        public string NumRefAtlBaixaOperac { get; set; }

        [XmlElement("NumSeqAtlzBaixaOperac")]
        public string NumSeqAtlzBaixaOperac { get; set; }

        [XmlElement("NumCodBarrasBaixaOperac")]
        public string NumCodBarrasBaixaOperac { get; set; }

        [XmlElement("NumCtrlDDA")]
        public string NumCtrlDDA { get; set; }

    }
}
