﻿using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    [XmlRoot("Grupo_ADDA114RET_TitRecsd")]
    public class GrupoDeRetornoDeBaixaOperacionalEmContingenciaRecusadaXmlDTO
    {
        [XmlElement("NumCtrlReqPart")]
        public string NumCtrlReqPart { get; set; }

        [XmlElement("ISPBPartRecbdrPrincipal")]
        public string ISPBPartRecbdrPrincipal { get; set; }

        [XmlElement("ISPBPartRecbdrAdmtd")]
        public string ISPBPartRecbdrAdmtd { get; set; }

        [XmlElement("TpBaixaOperac")]
        public string TpBaixaOperac { get; set; }

        [XmlElement("ISPBPartRecbdrBaixaOperac")]
        public string ISPBPartRecbdrBaixaOperac { get; set; }

        [XmlElement("CodPartRecbdrBaixaOperac")]
        public string CodPartRecbdrBaixaOperac { get; set; }

        [XmlElement("TpPessoaPort")]
        public string TpPessoaPort { get; set; }

        [XmlElement("CNPJ_CPFPort")]
        public string CNPJ_CPFPort { get; set; }

        [XmlElement("DtHrProcBaixaOperac")]
        public string DtHrProcBaixaOperac { get; set; }

        [XmlElement("DtProcBaixaOperac")]
        public string DtProcBaixaOperac { get; set; }

        [XmlElement("VlrBaixaOperacTit")]
        public string VlrBaixaOperacTit { get; set; }

        [XmlElement("NumCodBarrasBaixaOperac")]
        public string NumCodBarrasBaixaOperac { get; set; }

        [XmlElement("CanPgto")]
        public string CanPgto { get; set; }

        [XmlElement("MeioPgto")]
        public string MeioPgto { get; set; }

        [XmlElement("IndrOpContg")]
        public string IndrOpContg { get; set; }
    }
}
