﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    [XmlRoot("ADDADOC", Namespace = "http://www.bcb.gov.br/ARQ/ADDA114.xsd")]
    public class ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlDTO
    {
        public ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlDTO()
        {
            Id = Guid.NewGuid();
            DataDeProcessamento = DateTime.Now;
        }

        public Guid Id { get; set; }
        public string NomeDoArquivo { get; set; }
        public DateTime DataDeProcessamento { get; set; }

        [XmlElement("SISARQ")]
        public ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlSISARQDTO SISARQ { get; set; }
    }
}
