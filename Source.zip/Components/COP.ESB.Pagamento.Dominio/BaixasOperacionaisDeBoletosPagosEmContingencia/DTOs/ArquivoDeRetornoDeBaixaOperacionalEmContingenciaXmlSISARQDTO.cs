﻿using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    public class ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlSISARQDTO
    {
        [XmlElement("ADDA114RET")]
        public ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlADDA114RETDTO ADDA114RET { get; set; }
    }
}
