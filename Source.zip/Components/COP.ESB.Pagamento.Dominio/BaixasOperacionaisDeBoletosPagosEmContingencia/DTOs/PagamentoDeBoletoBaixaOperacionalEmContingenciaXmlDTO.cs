﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    [XmlRoot("Grupo_ADDA114_Tit")]
    public class PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO
    {

        public PagamentoDeBoletoBaixaOperacionalEmContingenciaXmlDTO()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; set; }
        public long EmpresaAplicacaoTransacaoId { get; set; }
        public Guid IdDoBoleto { get; set; }
        public Guid IdDaConsultaDeBoleto { get; set; }
        public Guid IdDoPagamentoDeBoleto { get; set; }

        [XmlElement("NumCtrlReqPart")]
        public string NumCtrlReqPart { get; set; }

        [XmlElement("ISPBPartRecbdrPrincipal")]
        public string ISPBPartRecbdrPrincipal { get; set; }

        [XmlElement("ISPBPartRecbdrAdmtd")]
        public string ISPBPartRecbdrAdmtd { get; set; }

        [XmlElement("TpBaixaOperac")]
        public int TpBaixaOperac { get; set; }

        [XmlElement("ISPBPartRecbdrBaixaOperac")]
        public string ISPBPartRecbdrBaixaOperac { get; set; }

        [XmlElement("CodPartRecbdrBaixaOperac")]
        public string CodPartRecbdrBaixaOperac { get; set; }

        [XmlElement("TpPessoaPort")]
        public string TpPessoaPort { get; set; }

        [XmlElement("CNPJ_CPFPort")]
        public string CNPJ_CPFPort { get; set; }

        [XmlElement("DtHrProcBaixaOperac")]
        public DateTimeOffset DtHrProcBaixaOperac { get; set; }

        [XmlElement("DtProcBaixaOperac")]
        public DateTimeOffset DtProcBaixaOperac { get; set; }

        [XmlElement("VlrBaixaOperacTit")]
        public decimal VlrBaixaOperacTit { get; set; }

        [XmlElement("NumCodBarrasBaixaOperac")]
        public string NumCodBarrasBaixaOperac { get; set; }
        
        [XmlElement("CanPgto")]
        public int CanalPagamento { get; set; }

        [XmlElement("MeioPgto")]
        public int MeioPagamento { get; set; }

        [XmlElement("IndrOpContg")]
        private string IndicadorContigencia { get; set; } = "S";
    }
}
