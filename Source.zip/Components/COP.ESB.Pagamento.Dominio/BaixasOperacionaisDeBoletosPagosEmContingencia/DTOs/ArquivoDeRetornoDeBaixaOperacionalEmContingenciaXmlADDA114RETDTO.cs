﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs
{
    public class ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlADDA114RETDTO
    {
        [XmlElement("Grupo_ADDA114RET_TitActo")]
        public List<GrupoDeRetornoDeBaixaOperacionalEmContingenciaAceitaXmlDTO> BaixasOperacionaisAceitas { get; set; }

        [XmlElement("Grupo_ADDA114RET_TitRecsd")]
        public List<GrupoDeRetornoDeBaixaOperacionalEmContingenciaRecusadaXmlDTO> BaixasOperacionaisRecusadas { get; set; }
    }
}
