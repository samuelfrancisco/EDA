﻿using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.DTOs;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums;
using COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Events;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;

namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia
{
    public class ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia
    {
        protected ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia()
        {

        }

        public ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingencia(Guid idDaConsultaDeBoletosPagosEmContingencia,
            BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventArquivo arquivo)
        {
            Id = arquivo.Id;
            IdDaBaixaOperacionalDeBoletosPagosEmContingencia = idDaConsultaDeBoletosPagosEmContingencia;
            NomeDoArquivo = arquivo.NomeDoArquivo;
            DataDeProcessamento = arquivo.DataDeProcessamento;
            Sequencia = arquivo.Sequencia;
            DataDeCriacao = arquivo.DataDeCriacao;
            NumeroDeControle = arquivo.NumeroDeControle;
            XmlGerado = arquivo.XmlGerado;
            PagamentosEnviados = arquivo.PagamentosEnviados
                .Select(pagamento => new PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia(arquivo.Id, pagamento)).ToList();
            Status = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Gerado;
        }

        public virtual Guid Id { get; protected set; }
        public virtual Guid IdDaBaixaOperacionalDeBoletosPagosEmContingencia { get; protected set; }
        public virtual string NomeDoArquivo { get; protected set; }
        public virtual DateTime DataDeProcessamento { get; protected set; }
        public virtual int Sequencia { get; protected set; }
        public virtual string NumeroDeControle { get; protected set; }
        public virtual string XmlGerado { get; protected set; }
        public virtual DateTimeOffset DataDeCriacao { get; protected set; }
        public virtual string NomeCompletoDoArquivoNoEnvio { get; protected set; }
        public virtual DateTimeOffset? DataDeEnvio { get; protected set; }
        public virtual bool? FoiProcessadoComSucesso { get; protected set; }
        public virtual string XmlDoRetorno { get; protected set; }
        public virtual string ErroNoProcessamentoDoRetorno { get; protected set; }
        public virtual DateTimeOffset? DataDeProcessamentoDoRetorno { get; protected set; }
        public virtual ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus Status { get; protected set; }
        public virtual IList<PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia> PagamentosEnviados { get; protected set; } = new List<PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia>();
        public virtual BaixaOperacionalDeBoletosPagosEmContingencia BaixaOperacional { get; protected set; }

        public static string ToXml(string nomeDoArquivo, string numeroDeControle, string iSPBPartRecbdrPrincipal, string iSPBPartRecbdrAdmtd, string iSPBRendimento, string codigoRendimento,
               DateTime dataDeProcessamento, IEnumerable<BaixaOperacionalDeBoletosPagosEmContingenciaIniciadaEventPagamento> pagamentosEnviados)
        {
            var flagDeFim = pagamentosEnviados.Any() ? "N" : "S";

            var xml = new StringBuilder();
            xml.AppendLine("<ADDADOC xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.bcb.gov.br/ARQ/ADDA114.xsd\">");
            xml.AppendLine("<BCARQ>");
            xml.AppendLine($"<NomArq>{nomeDoArquivo}</NomArq>");
            xml.AppendLine($"<NumCtrlEmis>{numeroDeControle}</NumCtrlEmis>");
            xml.AppendLine($"<ISPBEmissor>{iSPBPartRecbdrPrincipal}</ISPBEmissor>");
            xml.AppendLine($"<ISPBDestinatario>17423302</ISPBDestinatario>");
            //xml.AppendLine($"<DtHrDDA>{dataDeProcessamento.ToString("s")}</DtHrDDA>");
            xml.AppendLine($"<IndrFlagFim>{flagDeFim}</IndrFlagFim>");
            xml.AppendLine($"<DtMovto>{dataDeProcessamento.ToString("yyyy-MM-dd")}</DtMovto>");
            xml.AppendLine("</BCARQ>");

            if (pagamentosEnviados.Any())
            {
                xml.AppendLine("<SISARQ>");
                xml.AppendLine("<ADDA114>");

                var currentCulture = new CultureInfo(Thread.CurrentThread.CurrentCulture.Name);

                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

                var grupos = string.Join(Environment.NewLine, pagamentosEnviados.Select((x, y) =>
                {
                    var registro = new StringBuilder();
                    registro.AppendLine("<Grupo_ADDA114_Tit>");
                    registro.AppendLine($"<NumCtrlReqPart>{x.NumCtrlReqPart}</NumCtrlReqPart>");
                    registro.AppendLine($"<ISPBPartRecbdrPrincipal>{iSPBPartRecbdrPrincipal}</ISPBPartRecbdrPrincipal>");
                    registro.AppendLine($"<ISPBPartRecbdrAdmtd>{iSPBPartRecbdrAdmtd}</ISPBPartRecbdrAdmtd>");
                    registro.AppendLine($"<TpBaixaOperac>{x.TpBaixaOperac}</TpBaixaOperac>");
                    registro.AppendLine($"<ISPBPartRecbdrBaixaOperac>{iSPBRendimento}</ISPBPartRecbdrBaixaOperac>");
                    registro.AppendLine($"<CodPartRecbdrBaixaOperac>{codigoRendimento}</CodPartRecbdrBaixaOperac>");
                    registro.AppendLine($"<TpPessoaPort>{x.TpPessoaPort}</TpPessoaPort>");
                    registro.AppendLine($"<CNPJ_CPFPort>{x.CNPJ_CPFPort}</CNPJ_CPFPort>");
                    registro.AppendLine($"<DtHrProcBaixaOperac>{x.DtHrProcBaixaOperac.ToString("s")}</DtHrProcBaixaOperac>");
                    registro.AppendLine($"<DtProcBaixaOperac>{x.DtProcBaixaOperac.ToString("yyyy-MM-dd")}</DtProcBaixaOperac>");
                    registro.AppendLine($"<VlrBaixaOperacTit>{x.VlrBaixaOperacTit.ToString("F2")}</VlrBaixaOperacTit>");
                    registro.AppendLine($"<NumCodBarrasBaixaOperac>{x.NumCodBarrasBaixaOperac}</NumCodBarrasBaixaOperac>");
                    registro.AppendLine($"<CanPgto>{x.CanalPagamento}</CanPgto>");
                    registro.AppendLine($"<MeioPgto>{x.MeioPagamento}</MeioPgto>");
                    registro.AppendLine($"<IndrOpContg>S</IndrOpContg>");
                    registro.AppendLine("</Grupo_ADDA114_Tit>");
                    return registro.ToString();
                }).ToList());

                Thread.CurrentThread.CurrentCulture = currentCulture;

                xml.Append(grupos);
                xml.AppendLine("</ADDA114>");
                xml.AppendLine("</SISARQ>");
            }
            else
            {
                xml.AppendLine("<SISARQ />");
            }

            xml.AppendLine("<ESTARQ />");
            xml.AppendLine("</ADDADOC>");

            return xml.ToString();
        }

        public List<PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia> ObterOsPagamentosAceitos(ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlDTO xmlDTO)
        {
            return PagamentosEnviados.Where(x => xmlDTO.SISARQ.ADDA114RET.BaixasOperacionaisAceitas.Any(y => y.NumCtrlReqPart
            == x.NumCtrlReqPart)).ToList();
        }

        public List<PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingencia> ObterOsPagamentosRecusados(ArquivoDeRetornoDeBaixaOperacionalEmContingenciaXmlDTO xmlDTO)
        {
            return PagamentosEnviados.Where(x => xmlDTO.SISARQ.ADDA114RET.BaixasOperacionaisRecusadas.Any(y => y.NumCtrlReqPart
            == x.NumCtrlReqPart)).ToList();
        }

        public void Enviar(string nomeCompletoDoArquivoNoEnvio, DateTimeOffset dataDeEnvio)
        {
            NomeCompletoDoArquivoNoEnvio = nomeCompletoDoArquivoNoEnvio;
            DataDeEnvio = dataDeEnvio;
            Status = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Enviado;

            foreach (var pagamento in PagamentosEnviados)
            {
                pagamento.Enviar();
            }
        }

        public void ProcessarRetorno(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event)
        {
            foreach (var pagamento in PagamentosEnviados)
            {
                if (@event.PagamentosRecusados.Any(x => x.IdDoPagamentoEnviadoNaConsultaDeBoletosPagosEmContingencia == pagamento.Id))
                {
                    pagamento.Recusar();
                    continue;
                }

                pagamento.Aceitar();
            }

            FoiProcessadoComSucesso = true;
            XmlDoRetorno = @event.XmlDoRetorno;
            DataDeProcessamentoDoRetorno = @event.DataDeProcessamentoDoRetorno;
            Status = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado;
        }

        public void ProcessarRetorno(RetornoDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoComErroEvent @event)
        {
            FoiProcessadoComSucesso = false;
            XmlDoRetorno = null;
            ErroNoProcessamentoDoRetorno = @event.ErroNoProcessamentoDoRetorno;
            DataDeProcessamentoDoRetorno = @event.DataDeProcessamentoDoRetorno;
            Status = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado;
        }

        public void ProcessarRetorno(ErroDeArquivoDeBaixaOperacionalDeBoletosPagosEmContingenciaProcessadoEvent @event)
        {
            FoiProcessadoComSucesso = false;
            XmlDoRetorno = @event.XmlDoRetorno;
            ErroNoProcessamentoDoRetorno = @event.ErroNoProcessamentoDoRetorno;
            DataDeProcessamentoDoRetorno = @event.DataDeProcessamentoDoRetorno;
            Status = ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus.Processado;
        }
    }
}
