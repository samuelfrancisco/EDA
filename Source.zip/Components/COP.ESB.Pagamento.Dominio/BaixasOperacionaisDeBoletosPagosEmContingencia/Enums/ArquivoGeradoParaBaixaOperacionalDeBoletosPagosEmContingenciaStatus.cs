﻿namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums
{
    public enum ArquivoGeradoParaBaixaOperacionalDeBoletosPagosEmContingenciaStatus
    {
        Gerado = 1,
        Enviado = 2,
        Processado = 3
    }
}
