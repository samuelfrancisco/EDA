﻿namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums
{
    public enum BaixaOperacionalDeBoletosPagosEmContingenciaStatus
    {
        Iniciada = 1,
        AguardandoRetornoDosArquivos = 2,
        Concluida = 3,
        Cancelada = 4
    }
}
