﻿namespace COP.ESB.Pagamento.Dominio.BaixasOperacionaisDeBoletosPagosEmContingencia.Enums
{
    public enum PagamentoEnviadoNaBaixaOperacionalDeBoletosPagosEmContingenciaStatus
    {
        Gerado = 1,
        Enviado = 2,
        Aceito = 3,
        Recusado = 4
    }
}
