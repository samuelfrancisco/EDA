﻿using COP.ESB.Pagamento.Dominio.Core.ReadModels;

namespace COP.ESB.Pagamento.Dominio.Bancos
{
    public class Banco : VersionedReadModel
    {
        public virtual string CodBanco { get; set; }
        public virtual string CodISPB { get; set; }
        public virtual string Nome { get; set; }
    }
}
