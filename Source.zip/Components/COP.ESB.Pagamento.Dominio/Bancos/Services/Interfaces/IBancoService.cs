﻿using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces
{
    public interface IBancoService
    {
        Task<Banco> ObterBancoPeloCodigoAsync(string codigo);

        Task<Banco> ObterBancoRendimentoAsync();
    }
}
