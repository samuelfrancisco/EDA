﻿using COP.ESB.Pagamento.Dominio.Bancos.Repositories.Interfaces;
using COP.ESB.Pagamento.Dominio.Bancos.Services.Interfaces;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Bancos.Services
{
    public class BancoService : IBancoService
    {
        private readonly IBancoRepository _bancoRepository;

        public BancoService(IBancoRepository bancoRepository)
        {
            _bancoRepository = bancoRepository;
        }

        public async Task<Banco> ObterBancoPeloCodigoAsync(string codigo)
        {
            return await _bancoRepository.ObterBancoPeloCodigoAsync(codigo).ConfigureAwait(false);
        }

        public async Task<Banco> ObterBancoRendimentoAsync()
        {
            return await _bancoRepository.ObterBancoPeloCodigoAsync("0633").ConfigureAwait(false);
        }
    }
}
