﻿using COP.ESB.Pagamento.Dominio.Core.ReadModels.Interfaces;
using System.Threading.Tasks;

namespace COP.ESB.Pagamento.Dominio.Bancos.Repositories.Interfaces
{
    public interface IBancoRepository : IVersionedReadModelRepository<Banco>
    {
        Task<Banco> ObterBancoPeloCodigoAsync(string codigo);              
    }
}
